from pathlib import Path
import gzip, hashlib, json, re, subprocess, tarfile
ROOT=Path.cwd(); RUN=ROOT/'target/quality-task-044/run-20261113'
OUT=ROOT/'docs/quality/task044-20261113'
PHASES={'stable':RUN/'measurement-07','branch':RUN/'branch-02','miri':RUN/'miri-final'}
EXCLUDED='crates/pqc_scan_cli/src/probe_resolver.rs'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p): return json.loads(p.read_text())
def raw(p): return json.loads(p.read_text() if p.exists() else gzip.open(str(p)+'.gz','rt').read())
records={}; zeros={}
for phase,label in [('stable','default'),('stable','all-features'),('branch','branch-default'),('branch','branch-all-features')]:
 folder=PHASES[phase]/label; summary=load(folder/'summary.json'); export=raw(folder/'coverage.json')
 for kind in ['lines','regions','functions','branches']:
  for key in ['count','covered']:
   assert summary['totals'][kind][key] == export['data'][0]['totals'][kind][key]
 logs='\n'.join(p.read_text() for p in folder.glob('test-*.log'))
 assert 'test result: FAILED' not in logs
 counts={k:sum(map(int,re.findall(pattern,logs))) for k,pattern in [('passed',r'test result: ok\. (\d+) passed'),('ignored',r'; (\d+) ignored;')]}
 subset={}
 for kind in ['lines','regions','functions','branches']:
  numerator=sum(v[kind]['covered'] for k,v in summary['files'].items() if k!=EXCLUDED)
  denominator=sum(v[kind]['count'] for k,v in summary['files'].items() if k!=EXCLUDED)
  measured=kind!='branches' or phase=='branch'
  subset[kind]={'covered':numerator,'count':denominator,'percent':100*numerator/denominator if measured and denominator else None,'status':'Measured' if measured else 'Not Measured'}
 records[label]={'phase':phase,'tests':counts,'rawLlvmTotals':summary['totals'],'mappingSubsetTotals':subset,'excludedFromSubset':[] if EXCLUDED not in summary['files'] else [EXCLUDED], 'unmappedSourceFiles':summary['unmappedSourceFiles'],'sourceFileCount':len(summary['files'])}
 zeros[label]={f['filename'].removeprefix('/source/'):[{'line':s[0],'column':s[1]} for s in f['segments'] if s[2]==0 and s[3] and s[4] and not s[5]] for f in export['data'][0]['files']}
for phase,root in PHASES.items():
 host=load(root/'HOST-RESULTS.json'); assert host['exit']==0 and host['containerRemoved'] and host['sourceBeforeAfterMatch']
 assert host['limits']['memoryEnforced'] and host['limits']['aggregateDiskEnforced']
source=load(PHASES['miri']/'miri-source.json'); original=ROOT/source['source'].removeprefix('/source/')
fragment=original.read_bytes()[source['startByte']:source['endByteExclusive']]
assert hashlib.sha256(fragment).hexdigest()==source['fragmentSha256']
assert source['harness'].encode().startswith(fragment)
assert load(PHASES['miri']/'feasibility.json')['miriScopeExit']==0
# Bind all protected product/test/config/rule/schema inputs to each actual study.
protected=subprocess.check_output(['git','ls-files','-z','crates','rules','schemas','Cargo.toml','Cargo.lock','rust-toolchain.toml']).decode().split('\0')
protected={p:sha(ROOT/p) for p in protected if p}
for phase,root in PHASES.items():
 bindings=load(root/'HOST-RESULTS.json')['sourceBindings']
 assert all(bindings[p]==value for p,value in protected.items())
for p,value in protected.items():
 baseline=subprocess.check_output(['git','show','f8aff1888525f0f3e350a734166c12c6de3e71ed:'+p])
 assert hashlib.sha256(baseline).hexdigest()==value,p
OUT.mkdir(exist_ok=False)
def save(name,value): (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
save('MEASUREMENTS.json',{'baseHead':'f8aff1888525f0f3e350a734166c12c6de3e71ed','branch':'codex/quality-assessment-model','records':records,'knownAmbiguousFile':EXCLUDED,'mappingSubsetReason':'Same source compiled as CLI module and #[path] integration-test module; observed counters disagree with passed execution and differ across compiler configurations. Raw totals remain unchanged. env_clear also prevents child profile collection.','miri':load(PHASES['miri']/'feasibility.json'),'coreMiriAttempt':load(PHASES['stable']/'feasibility.json')['miriIdentityExit']})
save('UNOBSERVED-COUNTERS.json',{'meaning':'Zero-count mapped region-entry start positions; not proof of unexecuted source or branch coverage. probe_resolver.rs is excluded from definitive gap interpretation.','records':zeros})
save('SOURCE-MATCH.json',{'baseHead':'f8aff1888525f0f3e350a734166c12c6de3e71ed','protectedCount':len(protected),'protectedSha256':protected,'allProtectedMatchHeadAndAllThreeStudies':True,'miriSourceFragmentMatches':True,'harnessCurrentSha256':{p:sha(ROOT/p) for p in ['tests/quality/task044/entry.py','tests/quality/task044/coverage.py','tests/quality/test_coverage044.py','tests/protocol/container_entry.py','tests/protocol/container_runner.py']},'sourceScopeNote':'Stable and branch runs retain their original driver hashes. Later changes add only Miri fragment scope/metadata; final Miri run binds the final driver. Administrative task/doc changes are not executable changes.'})
for label,r in records.items():
 print(label,'raw',r['rawLlvmTotals'],'subset',r['mappingSubsetTotals'])
# Keep failed attempts and tool preparation logs; never archive Docker images or caches.
with tarfile.open(OUT/'RAW-EVIDENCE.tar.gz','w:gz') as archive:
 for path in sorted(RUN.rglob('*')):
  if path.is_file() and path.suffix!='.pyc' and path.name!='finalize-evidence.py':
   archive.add(path,arcname=str(path.relative_to(RUN)),recursive=False)
print('archive', (OUT/'RAW-EVIDENCE.tar.gz').stat().st_size, 'protected',len(protected))
