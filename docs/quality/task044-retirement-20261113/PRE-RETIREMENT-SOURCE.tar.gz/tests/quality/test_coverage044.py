"""Hand-derived LLVM coverage accounting; no target code executes here."""
import unittest
from task044.coverage import summarize


class Coverage044Tests(unittest.TestCase):
    def test_production_only_and_zero_denominators(self):
        def row(name, total, covered):
            return {'filename': name, 'summary': {
                kind: {'count': total, 'covered': covered}
                for kind in ('lines', 'regions', 'functions', 'branches')}}
        result = summarize({'data': [{'files': [
            row('/source/crates/a/src/lib.rs', 4, 3),
            row('/source/crates/a/tests/check.rs', 100, 100),
            row('/scratch/cargo/registry/dep.rs', 100, 100),
            row('/source/crates/b/src/lib.rs', 0, 0)]}]})
        self.assertEqual(result['totals']['lines'], {'count': 4, 'covered': 3, 'percent': 75.0})
        self.assertEqual(result['files']['crates/b/src/lib.rs']['lines']['percent'], None)
        self.assertEqual(set(result['files']), {'crates/a/src/lib.rs', 'crates/b/src/lib.rs'})
        self.assertIsNone(result['totals']['branches']['percent'])
        self.assertEqual(result['totals']['branches']['status'], 'Not Measured')

    def test_invalid_evidence_and_duplicate_paths_fail(self):
        for value in ({}, {'data': []}, {'data': [{'files': []}]}):
            with self.subTest(value=value), self.assertRaises(ValueError):
                summarize(value)
        row = {'filename': '/source/crates/a/src/lib.rs', 'summary': {
            kind: {'count': 2, 'covered': 3} for kind in ('lines','regions','functions','branches')}}
        with self.assertRaises(ValueError):
            summarize({'data': [{'files': [row]}]})
        for kind in row['summary'].values():
            kind['covered'] = 1
        with self.assertRaises(ValueError):
            summarize({'data': [{'files': [row, row]}]})

    def test_branch_counters_are_not_inferred_from_lines(self):
        row = {'filename': '/source/crates/a/src/lib.rs', 'summary': {
            kind: {'count': 6, 'covered': 2} for kind in ('lines','regions','functions','branches')}}
        result = summarize({'data': [{'files': [row]}]}, branches=True)
        self.assertAlmostEqual(result['totals']['branches']['percent'], 100 / 3)
        self.assertEqual(result['totals']['branches']['status'], 'Measured')
