from pathlib import Path
import difflib,json,hashlib
R=Path.cwd();P=R/'target/quality-task-043-maintainability-20261112';E=json.loads((P/'ENTRY.json').read_text());paths=sorted(p for name in ['crates','rules'] for p in (R/name).rglob('*') if p.is_file());parts=[];rows=[]
for f in paths:
 name=str(f.relative_to(R));h=hashlib.sha256(f.read_bytes()).hexdigest();old=E['bindings'].get(name)
 if old==h:continue
 before=P/'before'/name;rows.append(dict(path=name,beforeSha256=old,afterSha256=h));parts.extend(difflib.unified_diff(before.read_text().splitlines(True) if before.exists() else [],f.read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(P/'CHANGE.patch').write_text(''.join(parts));(P/'CHANGES.json').write_text(json.dumps(rows,indent=2)+'\n');print(len(rows),'code files changed relative to request entry')
