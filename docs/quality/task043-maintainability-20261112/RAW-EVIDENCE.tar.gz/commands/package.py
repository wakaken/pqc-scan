from pathlib import Path
import json,hashlib,subprocess,shutil,tarfile,datetime,re,sys
R=Path.cwd();P=R/'target/quality-task-043-maintainability-20261112';D=R/'docs/quality/task043-maintainability-20261112';D.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
def save(name,value):(D/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
entry=load(P/'ENTRY.json');changes=load(P/'CHANGES.json');allowed={r['path'] for r in changes};frozen={}
for name,h in entry['bindings'].items():
 if name.startswith(('rules/','schemas/','tests/quality/')) or name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','docs/quality/RULE-QUALITY-METADATA.json','docs/quality/SELF-SCAN-EXPECTATIONS.json']:
  assert sha(R/name)==h,name;frozen[name]=h
save('FROZEN.json',dict(status='Verified',fileCount=len(frozen),bindings=frozen))
comparisons=[];last=None
for name in ['043','042','legacy','lock','original']:
 b=load(P/'before/target'/name/'summary.json');a=load(P/('final-'+name)/'summary.json');last=a
 assert a['accuracy']==b['accuracy'];assert a['corpusInput']==b['corpusInput'];assert a['truthSha256']==b['truthSha256'];assert a['environment']['harnessDigest']==b['environment']['harnessDigest']
 for key in ['semanticDigest','diagnosticDigest','orderDigest']:
  assert len({x[key] for x in b['repeatability']['samples']+a['repeatability']['samples']})==1,(name,key)
 for summary in [a,b]:assert all(s['exitCode']==0 and not s['timedOut'] for s in summary['repeatability']['samples'])
 comparisons.append(dict(corpus=name,corpusVersion=a['corpusVersion'],status='Passed',unchanged=['corpusInput','truthSha256','harnessDigest','accuracy','semanticDigest','diagnosticDigest','orderDigest'],beforeRuntime=b['environment']['runtimeSourceDigest'],afterRuntime=a['environment']['runtimeSourceDigest'],beforeBinary=b['environment']['binarySha256'],afterBinary=a['environment']['binarySha256'],repeatsPerVersion=3))
save('COMPARISON.json',comparisons)
b=load(P/'before/target/performance/summary.json');a=load(P/'performance/summary.json');performance=[]
for name,after in a['benchmarks'].items():
 before=b['benchmarks'][name];assert after['input']==before['input'];row=dict(workload=name,warmSamples=3)
 for field in ['wallSeconds','peakRssBytes']:
  old=before['warmDistribution'][field];new=after['warmDistribution'][field];row[field]=None if old is None or new is None else dict(before=old,after=new,maxRatio=new['max']/old['max'],investigationSignal=new['max']>2*old['max'])
 performance.append(row)
save('PERFORMANCE.json',dict(status='Measured',policy='Existing TASK023 2x wall/RSS investigation signal; no new gate',workloads=performance,scope='Same local host/default features/release/one scan thread; synthetic warm workloads, not general performance assurance'))
sys.path.insert(0,str(R/'tests/quality'));from run import environment
actual=environment(R/'target/release/pqc-scan')
for field in ['binarySha256','runtimeSourceDigest','harnessDigest']:assert actual[field]==last['environment'][field],field
before=load(P/'before/target/043/summary.json')['environment'];prior=load(R/'docs/quality/task043-fixes-20261112/FINAL-quality.json')['environment']
for field in ['binarySha256','runtimeSourceDigest']:assert before[field]==prior[field],field
save('SOURCE-MATCH.json',dict(status='Verified',current=actual,priorFixesBaseline=dict(binarySha256=before['binarySha256'],runtimeSourceDigest=before['runtimeSourceDigest']),beforeMatchesPriorAcceptance=True))
checks=load(P/'CHECKS.json');assert all(c['exitCode']==0 for c in checks)
save('VALIDATION.json',dict(status='Passed',commands=checks,rustTests=390,qualityPython=54,protocolPassed=5,protocolSkipped=6,distributionPython=10,nodeTests=31,sourceCommit=entry['head'],branch=entry['branch'],worktree='Uncommitted current follow-up; earlier work preserved',selfScan=load(P/'self-scan-audit.json'),sourceMatch='SOURCE-MATCH.json',frozenInputs='FROZEN.json'))
for name in ['ENTRY.json','CHANGES.json','CHECKS.json','MEASUREMENTS.json','FINAL-MEASUREMENT-COMMANDS.json','IMPLEMENTATION-REVIEW.md','TEST-REVIEW.md','TEST-REVIEW-BINDINGS.json']:
 shutil.copyfile(P/name,D/name)
shutil.copyfile(P/'CHANGE.patch',D/'CHANGE.patch')
with tarfile.open(D/'RAW-EVIDENCE.tar.gz','w:gz') as tar:
 for name in ['043','042','legacy','lock','original']:
  tar.add(P/'before/target'/name,arcname='before/'+name)
  tar.add(P/('final-'+name),arcname='after/'+name)
  tar.add(P/('final-'+name+'-report'),arcname='reports/'+name)
 for root,label in [(P/'before/target/performance','before/performance'),(P/'performance','after/performance')]:tar.add(root,arcname=label)
 for f in sorted(P.glob('*.log')):tar.add(f,arcname='logs/'+f.name,recursive=False)
 for f in sorted(P.glob('*.py')):tar.add(f,arcname='commands/'+f.name,recursive=False)
 for f in ['self-scan/report.sarif','self-scan-upload.sarif']:tar.add(P/f,arcname=f,recursive=False)
with tarfile.open(D/'SOURCE-OVERLAYS.tar.gz','w:gz') as tar:
 for root,env,label in [(P/'before',before,'before'),(R,actual,'after')]:
  for name,h in env['runtimeSourceBindings'].items():assert sha(root/name)==h,name;tar.add(root/name,arcname=label+'/'+name,recursive=False)
index={str(f.relative_to(D)):dict(sha256=sha(f),bytes=f.stat().st_size) for f in sorted(D.rglob('*')) if f.is_file()};save('EVIDENCE-INDEX.json',index)
print(len(frozen),'frozen files unchanged; 5 exact comparisons; current source/binary/harness match; packet',len(index),'files')
