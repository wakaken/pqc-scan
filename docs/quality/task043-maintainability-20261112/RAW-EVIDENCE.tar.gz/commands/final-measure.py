from pathlib import Path
import subprocess,json,datetime,time
R=Path.cwd();P=R/'target/quality-task-043-maintainability-20261112';S=P/'before';rows=[]
def run(name,cmd,root):
 print('START',name,flush=True);start=time.monotonic();log=P/(name+'.log')
 with log.open('w') as out:r=subprocess.run(cmd,cwd=root,stdout=out,stderr=subprocess.STDOUT)
 rows.append(dict(name=name,command=cmd,cwd=str(root),exitCode=r.returncode,wallSeconds=time.monotonic()-start,log=str(log.relative_to(R)),timestampUtc=datetime.datetime.now(datetime.timezone.utc).isoformat()));(P/'FINAL-MEASUREMENT-COMMANDS.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode:print(log.read_text()[-2000:]);raise SystemExit(1)
for name,corpus in [('043','task043-corpus-v2'),('042','expanded-v2'),('legacy','expanded'),('lock','expanded-v2-lock-controls'),('original',None)]:
 out=str((P/('final-'+name)).relative_to(R));opts=[] if corpus is None else ['--corpus-dir','tests/quality/'+corpus]
 run('final-'+name,['python3','tests/quality/run.py','--out-dir',out,'--build-profile','release','--repeats','3','--skip-benchmarks']+opts,R)
 run('final-'+name+'-report',['python3','tests/quality/report.py','--baseline',out,'--out-dir',out+'-report','--reference',str(S/'target'/name/'summary.json')]+opts,R)
# Existing workload and approved 2x investigation signals only; no new threshold.
for label,root in [('before',S),('after',R)]:
 out='target/performance' if label=='before' else str((P/'performance').relative_to(R))
 run('performance-'+label,['python3','tests/quality/run.py','--out-dir',out,'--build-profile','release','--repeats','3','--warm-samples','3'],root)
 run('performance-'+label+'-report',['python3','tests/quality/report.py','--baseline',out,'--out-dir',out+'-report']+(['--reference',str(S/'target/performance/summary.json')] if label=='after' else []),root)
