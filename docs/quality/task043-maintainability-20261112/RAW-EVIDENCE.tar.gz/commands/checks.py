from pathlib import Path
import subprocess,json,time,datetime
P=Path('target/quality-task-043-maintainability-20261112');rows=[]
checks=[('fmt',['cargo','fmt','--all','--','--check']),('workspace',['cargo','test','--workspace','--offline','--locked']),('clippy',['cargo','clippy','--workspace','--all-targets','--offline','--locked','--','-D','warnings']),('build',['cargo','build','--workspace','--release','--offline','--locked']),('quality',['python3','-m','unittest','discover','-s','tests/quality','-p','test_*.py']),('protocol',['python3','-m','unittest','discover','-s','tests/protocol','-p','test_*.py']),('distribution',['python3','-m','unittest','discover','-s','tests/distribution']),('node',['node','--test',*map(str,sorted(Path('shell').glob('*.test.cjs')))])]
for name,cmd in checks:
 print('START',name,flush=True);start=time.monotonic();log=P/('check-'+name+'.log')
 with log.open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
 rows.append(dict(name=name,command=cmd,exitCode=r.returncode,wallSeconds=time.monotonic()-start,log=str(log),timestampUtc=datetime.datetime.now(datetime.timezone.utc).isoformat()));(P/'CHECKS.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode:print(log.read_text()[-2200:],flush=True)
raise SystemExit(any(r['exitCode'] for r in rows))
