from pathlib import Path
import json,hashlib,subprocess,shutil,time,datetime,sys
R=Path.cwd();P=R/'target/quality-task-043-maintainability-20261112';S=P/'before';D=P/'before'/'target'/'release';D.mkdir(parents=True,exist_ok=True);shutil.copy2(P/'before-pqc-scan',D/'pqc-scan');(D/'pqc-scan').chmod(0o755)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for f in (R/'tests/quality').glob('**/corpus.json'):
 d=json.loads(f.read_text())
 for item in d.get('files',[]):
  if 'source' not in item:continue
  src=R/item['source'];assert sha(src)==item['sha256'];dst=S/item['source'];dst.parent.mkdir(parents=True,exist_ok=True)
  if not dst.exists():shutil.copyfile(src,dst)
records=[]
def run(name,args,cwd):
 log=P/(name+'.log');start=time.monotonic();print('START',name,flush=True)
 with log.open('w') as out:r=subprocess.run(args,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
 records.append(dict(name=name,command=args,cwd=str(cwd),exitCode=r.returncode,wallSeconds=time.monotonic()-start,log=str(log.relative_to(R)),timestampUtc=datetime.datetime.now(datetime.timezone.utc).isoformat()));(P/'MEASUREMENTS.json').write_text(json.dumps(records,indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode:print(log.read_text()[-2000:]);sys.exit(1)
for label,root in [('before',S),('after',R)]:
 for name,corpus in [('043','task043-corpus-v2'),('042','expanded-v2'),('legacy','expanded'),('lock','expanded-v2-lock-controls'),('original',None)]:
  out=('target/'+name) if label=='before' else str((P/('after-'+name)).relative_to(R))
  options=[] if corpus is None else ['--corpus-dir','tests/quality/'+corpus]
  run(label+'-'+name,['python3','tests/quality/run.py','--out-dir',out,'--build-profile','release','--repeats','3','--skip-benchmarks']+options,root)
  cmd=['python3','tests/quality/report.py','--baseline',out,'--out-dir',out+'-report']+options
  if label=='after':cmd+=['--reference',str(S/'target'/name/'summary.json')]
  run(label+'-'+name+'-report',cmd,root)
