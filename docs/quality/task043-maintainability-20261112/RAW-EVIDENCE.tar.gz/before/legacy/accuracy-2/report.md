# PQC Migration Scan Report

Generated: 2026-11-12 03:02:20.250792 UTC

Risk candidates: 71 / Inventory findings: 45 / Scanned files: 141

Static evidence does not prove runtime use or completed PQC migration.

|Severity|Count (all findings)|
|---|---:|
|critical|9|
|high|11|
|info|45|
|low|4|
|medium|47|

## Risk candidate index

|Rule / description|Severity|Risk|Hits|Files|
|---|---|---|---:|---:|
|[CERT_RSA_SIGNATURE](#rule-0) Certificate signed with an RSA-based algorithm detected.|critical|quantum-vulnerable|4|4|
|[JWT_RS256](#rule-1) RS256 (RSA-based JWT signing) is in use.|critical|quantum-vulnerable|1|1|
|[PRIVATE_KEY_OPENSSH_HEADER](#rule-2) OpenSSH private key header detected.|critical|non-quantum-risk|1|1|
|[PRIVATE_KEY_PKCS8_HEADER](#rule-3) PKCS#8 private key header detected.|critical|non-quantum-risk|1|1|
|[PRIVATE_KEY_RSA_HEADER](#rule-4) RSA private key header detected.|critical|non-quantum-risk|1|1|
|[TS_JWT_RSA_ALGS](#rule-5) RSA-family JWT signing algorithms detected in AST nodes.|critical|quantum-vulnerable|1|1|
|[API_JOSE_RSA_ALG](#rule-6) RSA-family JOSE algorithm detected.|high|quantum-vulnerable|1|1|
|[API_SIGNATURE_RSA](#rule-7) RSA signature API usage detected.|high|quantum-vulnerable|1|1|
|[CERT_ECDSA_SIGNATURE](#rule-8) ECDSA certificate signature detected.|high|quantum-vulnerable|1|1|
|[CERT_RSA_3072](#rule-9) Certificate subject public key is 3072-bit RSA.|high|quantum-vulnerable|4|4|
|[SSH_DSS_SIGALG](#rule-10) Deprecated ssh-dss usage detected.|high|non-quantum-risk|1|1|
|[TS_JAVA_RSA_API](#rule-11) RSA-related API symbols detected from Java AST.|high|quantum-vulnerable|1|1|
|[TS_RSA_KEY_SIZE_LITERAL](#rule-12) Classical public-key size literals detected in AST nodes.|high|quantum-vulnerable|2|2|
|[API_NODE_CRYPTO_SIGN_RSA](#rule-13) Node.js RSA signing API usage detected.|medium|quantum-vulnerable|4|1|
|[CERT_P12_CONTAINER](#rule-14) PKCS#12/PFX container file detected.|medium|quantum-uncertain|4|4|
|[DEP_BOUNCYCASTLE](#rule-15) BouncyCastle dependency detected.|medium|quantum-uncertain|4|4|
|[DEP_JAVA_BOUNCYCASTLE](#rule-16) Java BouncyCastle dependency detected.|medium|quantum-uncertain|4|4|
|[DEP_OPENSSL](#rule-17) OpenSSL dependency detected.|medium|quantum-uncertain|9|9|
|[DEP_PYCA_CRYPTOGRAPHY](#rule-18) Python cryptography dependency detected.|medium|quantum-uncertain|3|3|
|[DEP_RUBY_OPENSSL](#rule-19) Ruby OpenSSL dependency detected.|medium|quantum-uncertain|5|5|
|[DEP_RUST_OPENSSL](#rule-20) Rust TLS/crypto dependency detected.|medium|quantum-uncertain|1|1|
|[JWT_LIB_JOSE](#rule-21) jose dependency detected.|medium|quantum-uncertain|3|3|
|[PQC_DRAFT_ALGORITHM](#rule-22) Pre-standard PQC algorithm name referenced; check compatibility before replacing it.|medium|quantum-uncertain|1|1|
|[PQC_JAVA_CLASSICAL_GROUPS](#rule-23) Explicit classical-only Java property intent in assignment, XML entry or static System.setProperty; ...|medium|quantum-uncertain|1|1|
|[SSH_DH_GROUP14_SHA1](#rule-24) SHA-1 dependent SSH KEX detected.|medium|non-quantum-risk|1|1|
|[TS_NODE_RSA_USAGE](#rule-25) RSA-related API symbols detected from JavaScript/TypeScript AST.|medium|quantum-vulnerable|7|3|
|[CERT_PEM_CONTAINER](#rule-26) Certificate container file detected.|low|quantum-uncertain|4|4|

## Informational inventory index

|Rule / description|Severity|Risk|Hits|Files|
|---|---|---|---:|---:|
|[DEP_PQC_CAPABLE_LIBRARY](#rule-27) Library with version-dependent PQC capabilities inventoried; capability is not an enabled-state find...|info|quantum-uncertain|17|17|
|[PQC_GO_API](#rule-28) Standard Go PQC package imported; import alone does not prove negotiated protection.|info|quantum-safe|1|1|
|[PQC_JAVA_API](#rule-29) Standard PQC algorithm requested through Java APIs; runtime success is not established.|info|quantum-safe|4|4|
|[PQC_NODE_API](#rule-30) Node-style PQC key generation call; bindings and actual execution require confirmation.|info|quantum-safe|15|8|
|[PQC_PYTHON_API](#rule-31) Python PQC key generation reference; backend support is not established.|info|quantum-safe|3|2|
|[PQC_RUBY_API](#rule-32) Ruby PQC algorithm literal referenced; key generation or signing success is not established.|info|quantum-safe|2|2|
|[PQC_RUST_API](#rule-33) Rust PQC crate symbol referenced; execution and protocol use require confirmation.|info|quantum-safe|2|2|
|[PQC_WEBCRYPTO_API](#rule-34) WebCrypto-style PQC algorithm request; this is not proof of browser support.|info|quantum-safe|1|1|

<a id="rule-0"></a>

## CERT_RSA_SIGNATURE

Certificate signed with an RSA-based algorithm detected.

Check: Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-0"></a>[tuning/certs/public-rsa3072.cer:1:1](#finding-0)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-1"></a>[tuning/certs/public-rsa3072.crt:1:1](#finding-1)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-2"></a>[tuning/certs/public-rsa3072.pem:1:1](#finding-2)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / [Source](#source-2)|
|<a id="finding-3"></a>[tuning/certs/rsa3072.der:1:1](#finding-3)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)

<a id="source-2"></a>

### tuning/certs/public-rsa3072.pem:1:1

    > 1 -----BEGIN CERTIFICATE-----
      2 [masked-sensitive-content]
      3 c2Nhbi1wdWJsaWMtdGVzdDAeFw0yNjExMDkwNzU1NTFaFw0zNjExMDYwNzU1NTFa

<a id="rule-1"></a>

## JWT_RS256

RS256 (RSA-based JWT signing) is in use.

Check: Migrate to ML-DSA signatures.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-4"></a>[tuning/jwt/sign.js:1:33](#finding-4)|RS256|Stop issuing new JWTs with RSA/PKCS#1/ECDSA-only algorithms / [Stop issuing new JWTs with RSA/PKCS#1/ECDSA-only algorithms](#action-2) / [Upgrade Node.js runtime for built-in WebCrypto PQC support](#action-3) / [Source](#source-4)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-4"></a>

### tuning/jwt/sign.js:1:33

    > 1 sign(payload, key, {algorithm: "RS256"});

<a id="rule-2"></a>

## PRIVATE_KEY_OPENSSH_HEADER

OpenSSH private key header detected.

Check: Treat OpenSSH private-key exposure as an urgent incident.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-5"></a>[tuning/markers/PRIVATE_KEY_OPENSSH_HEADER/marker.txt:1:1](#finding-5)|\[masked-private-key\]|Rotate exposed private keys and revoke affected credentials / [Rotate exposed private keys and revoke affected credentials](#action-5) / [Source](#source-5)|

<a id="source-5"></a>

### tuning/markers/PRIVATE_KEY_OPENSSH_HEADER/marker.txt:1:1

    > 1 [masked-private-key-material]

<a id="rule-3"></a>

## PRIVATE_KEY_PKCS8_HEADER

PKCS#8 private key header detected.

Check: Investigate private-key exposure and rotate credentials.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-6"></a>[tuning/markers/PRIVATE_KEY_PKCS8_HEADER/marker.txt:1:1](#finding-6)|\[masked-private-key\]|Rotate exposed private keys and revoke affected credentials / [Rotate exposed private keys and revoke affected credentials](#action-5) / [Source](#source-6)|

<a id="source-6"></a>

### tuning/markers/PRIVATE_KEY_PKCS8_HEADER/marker.txt:1:1

    > 1 [masked-private-key-material]

<a id="rule-4"></a>

## PRIVATE_KEY_RSA_HEADER

RSA private key header detected.

Check: Rotate exposed private keys immediately and strengthen key handling.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-7"></a>[tuning/markers/PRIVATE_KEY_RSA_HEADER/marker.txt:1:1](#finding-7)|\[masked-private-key\]|Rotate exposed private keys and revoke affected credentials / [Rotate exposed private keys and revoke affected credentials](#action-5) / [Source](#source-7)|

<a id="source-7"></a>

### tuning/markers/PRIVATE_KEY_RSA_HEADER/marker.txt:1:1

    > 1 [masked-private-key-material]

<a id="rule-5"></a>

## TS_JWT_RSA_ALGS

RSA-family JWT signing algorithms detected in AST nodes.

Check: Migrate JWT signing to ML-DSA or hybrid signatures.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-8"></a>[tuning/jwt/sign.js:1:33](#finding-8)|RS256|Stop issuing new JWTs with RSA/PKCS#1/ECDSA-only algorithms / [Stop issuing new JWTs with RSA/PKCS#1/ECDSA-only algorithms](#action-2) / [Upgrade Node.js runtime for built-in WebCrypto PQC support](#action-3) / [Source](#source-8)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-8"></a>

### tuning/jwt/sign.js:1:33

    > 1 sign(payload, key, {algorithm: "RS256"});

<a id="rule-6"></a>

## API_JOSE_RSA_ALG

RSA-family JOSE algorithm detected.

Check: Update JOSE algorithms to PQC-ready alternatives.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-9"></a>[tuning/jwt/sign.js:1:33](#finding-9)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-9)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Introduce crypto abstraction boundary for algorithm agility](#action-6)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-9"></a>

### tuning/jwt/sign.js:1:33

    > 1 sign(payload, key, {algorithm: "RS256"});

<a id="rule-7"></a>

## API_SIGNATURE_RSA

RSA signature API usage detected.

Check: Migrate to ML-DSA signing APIs.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-10"></a>[tuning/java/Neg.java:1:1](#finding-10)|Signatur***thRSA"|Provide BouncyCastle PQC fallback path / [Upgrade Java runtime baseline for standard PQC APIs](#action-7) / [Provide BouncyCastle PQC fallback path](#action-8) / [Source](#source-10)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Verify deployed runtime and protocol PQC capabilities](#action-9)

<a id="source-10"></a>

### tuning/java/Neg.java:1:1

    > 1 Signature.getInstance("SHA256withRSA");

<a id="rule-8"></a>

## CERT_ECDSA_SIGNATURE

ECDSA certificate signature detected.

Check: Evaluate ML-DSA and SLH-DSA alternatives.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-11"></a>[tuning/certs/p256.der:1:1](#finding-11)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)

<a id="rule-9"></a>

## CERT_RSA_3072

Certificate subject public key is 3072-bit RSA.

Check: Evaluate standardized PQC signatures in supported issuance and verification environments.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-12"></a>[tuning/certs/public-rsa3072.cer:1:1](#finding-12)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / Source unavailable|
|<a id="finding-13"></a>[tuning/certs/public-rsa3072.crt:1:1](#finding-13)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / Source unavailable|
|<a id="finding-14"></a>[tuning/certs/public-rsa3072.pem:1:1](#finding-14)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / [Source](#source-14)|
|<a id="finding-15"></a>[tuning/certs/rsa3072.der:1:1](#finding-15)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)

<a id="source-14"></a>

### tuning/certs/public-rsa3072.pem:1:1

    > 1 -----BEGIN CERTIFICATE-----
      2 [masked-sensitive-content]
      3 c2Nhbi1wdWJsaWMtdGVzdDAeFw0yNjExMDkwNzU1NTFaFw0zNjExMDYwNzU1NTFa

<a id="rule-10"></a>

## SSH_DSS_SIGALG

Deprecated ssh-dss usage detected.

Check: Disable ssh-dss.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-16"></a>[tuning/ssh/dsa.conf:1:19](#finding-16)|ssh-dss|Disable ssh-dss. / [Source](#source-16)|

<a id="source-16"></a>

### tuning/ssh/dsa.conf:1:19

    > 1 HostKeyAlgorithms ssh-dss

<a id="rule-11"></a>

## TS_JAVA_RSA_API

RSA-related API symbols detected from Java AST.

Check: Replace Java RSA API usage with PQC-capable libraries.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-17"></a>[tuning/java/Neg.java:1:1](#finding-17)|Signatur***ithRSA|Provide BouncyCastle PQC fallback path / [Upgrade Java runtime baseline for standard PQC APIs](#action-7) / [Provide BouncyCastle PQC fallback path](#action-8) / [Source](#source-17)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Verify deployed runtime and protocol PQC capabilities](#action-9)

<a id="source-17"></a>

### tuning/java/Neg.java:1:1

    > 1 Signature.getInstance("SHA256withRSA");

<a id="rule-12"></a>

## TS_RSA_KEY_SIZE_LITERAL

Classical public-key size literals detected in AST nodes.

Check: Shift from key-length based planning to PQC signatures/key exchange.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-18"></a>[holdout/rsa-sign.js:8:3](#finding-18)|modulusLength: 2048|Shift from key-length based planning to PQC signatures/key exchange. / [Source](#source-18)|
|<a id="finding-19"></a>[tuning/js/same-line.js:1:44](#finding-19)|KeyPairS***m-1024|Shift from key-length based planning to PQC signatures/key exchange. / [Source](#source-19)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-18"></a>

### holdout/rsa-sign.js:8:3

      6 
      7 const { privateKey, publicKey } = generateKeyPairSync('rsa', {
    > 8   modulusLength: 2048,
      9 });
      10 

<a id="source-19"></a>

### tuning/js/same-line.js:1:44

    > 1 generateKeyPairSync("ml-kem-512"); generateKeyPairSync("ml-kem-1024");

<a id="rule-13"></a>

## API_NODE_CRYPTO_SIGN_RSA

Node.js RSA signing API usage detected.

Check: Plan PQC replacement for node:crypto RSA operations.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-20"></a>[holdout/rsa-sign.js:11:14](#finding-20)|createSign('SHA256'|Plan PQC replacement for node:crypto RSA operations. / [Source](#source-20)|
|<a id="finding-21"></a>[holdout/rsa-sign.js:14:19](#finding-21)|sign.sign(privateKey|Plan PQC replacement for node:crypto RSA operations. / [Source](#source-21)|
|<a id="finding-22"></a>[holdout/rsa-sign.js:16:16](#finding-22)|createVe***HA256'|Plan PQC replacement for node:crypto RSA operations. / [Source](#source-22)|
|<a id="finding-23"></a>[holdout/rsa-sign.js:19:13](#finding-23)|verify.v***licKey|Plan PQC replacement for node:crypto RSA operations. / [Source](#source-23)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Introduce crypto abstraction boundary for algorithm agility](#action-6)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-20"></a>

### holdout/rsa-sign.js:11:14

      9 });
      10 
    > 11 const sign = createSign('SHA256');
      12 sign.update('some data to sign');
      13 sign.end();

<a id="source-21"></a>

### holdout/rsa-sign.js:14:19

      12 sign.update('some data to sign');
      13 sign.end();
    > 14 const signature = sign.sign(privateKey);
      15 
      16 const verify = createVerify('SHA256');

<a id="source-22"></a>

### holdout/rsa-sign.js:16:16

      14 const signature = sign.sign(privateKey);
      15 
    > 16 const verify = createVerify('SHA256');
      17 verify.update('some data to sign');
      18 verify.end();

<a id="source-23"></a>

### holdout/rsa-sign.js:19:13

      17 verify.update('some data to sign');
      18 verify.end();
    > 19 console.log(verify.verify(publicKey, signature));
      20 // Prints: true

<a id="rule-14"></a>

## CERT_P12_CONTAINER

PKCS#12/PFX container file detected.

Check: Audit algorithms used inside PKCS#12/PFX containers.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-24"></a>[tuning/certs/broken.p12:1:1](#finding-24)|broken.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-25"></a>[tuning/certs/broken.pfx:1:1](#finding-25)|broken.pfx|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-26"></a>[tuning/certs/public-only.p12:1:1](#finding-26)|public-only.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-27"></a>[tuning/certs/public-only.pfx:1:1](#finding-27)|public-only.pfx|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)

<a id="rule-15"></a>

## DEP_BOUNCYCASTLE

BouncyCastle dependency detected.

Check: Verify BouncyCastle PQC support status.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-28"></a>[tuning/manifests/build.gradle.kts/declared/build.gradle.kts:1:1](#finding-28)|org.boun***n@1.80|Verify BouncyCastle PQC support status. / [Source](#source-28)|
|<a id="finding-29"></a>[tuning/manifests/build.gradle/declared/build.gradle:1:1](#finding-29)|org.boun***n@1.80|Verify BouncyCastle PQC support status. / [Source](#source-29)|
|<a id="finding-30"></a>[tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1](#finding-30)|org.boun***n@1.80|Verify BouncyCastle PQC support status. / [Source](#source-30)|
|<a id="finding-31"></a>[tuning/manifests/pom.xml/declared/pom.xml:1:1](#finding-31)|org.boun***n@1.80|Verify BouncyCastle PQC support status. / [Source](#source-31)|

Shared checks for these locations (not verified facts about each line):

- [Prefer TLS 1.3 and review legacy key exchange](#action-10)
- [Track PQC readiness of dependent libraries](#action-11)

<a id="source-28"></a>

### tuning/manifests/build.gradle.kts/declared/build.gradle.kts:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-29"></a>

### tuning/manifests/build.gradle/declared/build.gradle:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-30"></a>

### tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-31"></a>

### tuning/manifests/pom.xml/declared/pom.xml:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-16"></a>

## DEP_JAVA_BOUNCYCASTLE

Java BouncyCastle dependency detected.

Check: Evaluate adoption of BouncyCastle PQC provider modules.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-32"></a>[tuning/manifests/build.gradle.kts/declared/build.gradle.kts:1:1](#finding-32)|org.boun***n@1.80|Evaluate adoption of BouncyCastle PQC provider modules. / [Source](#source-32)|
|<a id="finding-33"></a>[tuning/manifests/build.gradle/declared/build.gradle:1:1](#finding-33)|org.boun***n@1.80|Evaluate adoption of BouncyCastle PQC provider modules. / [Source](#source-33)|
|<a id="finding-34"></a>[tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1](#finding-34)|org.boun***n@1.80|Evaluate adoption of BouncyCastle PQC provider modules. / [Source](#source-34)|
|<a id="finding-35"></a>[tuning/manifests/pom.xml/declared/pom.xml:1:1](#finding-35)|org.boun***n@1.80|Evaluate adoption of BouncyCastle PQC provider modules. / [Source](#source-35)|

Shared checks for these locations (not verified facts about each line):

- [Introduce crypto abstraction boundary for algorithm agility](#action-6)
- [Track PQC readiness of dependent libraries](#action-11)

<a id="source-32"></a>

### tuning/manifests/build.gradle.kts/declared/build.gradle.kts:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-33"></a>

### tuning/manifests/build.gradle/declared/build.gradle:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-34"></a>

### tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-35"></a>

### tuning/manifests/pom.xml/declared/pom.xml:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-17"></a>

## DEP_OPENSSL

OpenSSL dependency detected.

Check: Review the OpenSSL PQC roadmap.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-36"></a>[tuning/manifests/Cargo.lock/declared/Cargo.lock:3:1](#finding-36)|openssl@0.10.75|Review the OpenSSL PQC roadmap. / [Source](#source-36)|
|<a id="finding-37"></a>[tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1](#finding-37)|openssl@0.10.75|Review the OpenSSL PQC roadmap. / [Source](#source-37)|
|<a id="finding-38"></a>[tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1](#finding-38)|openssl@3.3.0|Review the OpenSSL PQC roadmap. / [Source](#source-38)|
|<a id="finding-39"></a>[tuning/manifests/Gemfile/declared/Gemfile:1:1](#finding-39)|openssl@3.3.0|Review the OpenSSL PQC roadmap. / [Source](#source-39)|
|<a id="finding-40"></a>[tuning/manifests/fixture.gemspec/declared/fixture.gemspec:2:1](#finding-40)|openssl@3.3.0|Review the OpenSSL PQC roadmap. / [Source](#source-40)|
|<a id="finding-41"></a>[tuning/manifests/gems.locked/declared/gems.locked:3:1](#finding-41)|openssl@3.3.0|Review the OpenSSL PQC roadmap. / [Source](#source-41)|
|<a id="finding-42"></a>[tuning/manifests/gems.rb/declared/gems.rb:1:1](#finding-42)|openssl@3.3.0|Verify deployed runtime and protocol PQC capabilities / [Verify deployed runtime and protocol PQC capabilities](#action-12) / [Source](#source-42)|
|<a id="finding-43"></a>[tuning/sbom/CycloneDX-1.5/declared/bom.json:1:1](#finding-43)|openssl@3.5.0|Review the OpenSSL PQC roadmap. / [Source](#source-43)|
|<a id="finding-44"></a>[tuning/sbom/SPDX-2.3/declared/bom.json:1:1](#finding-44)|openssl@3.5.0|Review the OpenSSL PQC roadmap. / [Source](#source-44)|

Shared checks for these locations (not verified facts about each line):

- [Prefer TLS 1.3 and review legacy key exchange](#action-10)
- [Track PQC readiness of dependent libraries](#action-11)

<a id="source-36"></a>

### tuning/manifests/Cargo.lock/declared/Cargo.lock:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-37"></a>

### tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-38"></a>

### tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-39"></a>

### tuning/manifests/Gemfile/declared/Gemfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-40"></a>

### tuning/manifests/fixture.gemspec/declared/fixture.gemspec:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-41"></a>

### tuning/manifests/gems.locked/declared/gems.locked:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-42"></a>

### tuning/manifests/gems.rb/declared/gems.rb:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-43"></a>

### tuning/sbom/CycloneDX-1.5/declared/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-44"></a>

### tuning/sbom/SPDX-2.3/declared/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-18"></a>

## DEP_PYCA_CRYPTOGRAPHY

Python cryptography dependency detected.

Check: Track PQC support status in the cryptography package.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-45"></a>[tuning/manifests/Pipfile.lock/declared/Pipfile.lock:1:1](#finding-45)|cryptogr***48.0.0|Track PQC support status in the cryptography package. / [Source](#source-45)|
|<a id="finding-46"></a>[tuning/manifests/poetry.lock/declared/poetry.lock:2:1](#finding-46)|cryptography@48.0.0|Track PQC support status in the cryptography package. / [Source](#source-46)|
|<a id="finding-47"></a>[tuning/manifests/requirements.txt/declared/requirements.txt:1:1](#finding-47)|cryptography@48.0.0|Track PQC support status in the cryptography package. / [Source](#source-47)|

Shared checks for these locations (not verified facts about each line):

- [Introduce crypto abstraction boundary for algorithm agility](#action-6)
- [Track PQC readiness of dependent libraries](#action-11)

<a id="source-45"></a>

### tuning/manifests/Pipfile.lock/declared/Pipfile.lock:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-46"></a>

### tuning/manifests/poetry.lock/declared/poetry.lock:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-47"></a>

### tuning/manifests/requirements.txt/declared/requirements.txt:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-19"></a>

## DEP_RUBY_OPENSSL

Ruby OpenSSL dependency detected.

Check: Review OpenSSL usage in Ruby and prepare PQC migration path.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-48"></a>[tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1](#finding-48)|openssl@3.3.0|Review OpenSSL usage in Ruby and prepare PQC migration path. / [Source](#source-48)|
|<a id="finding-49"></a>[tuning/manifests/Gemfile/declared/Gemfile:1:1](#finding-49)|openssl@3.3.0|Review OpenSSL usage in Ruby and prepare PQC migration path. / [Source](#source-49)|
|<a id="finding-50"></a>[tuning/manifests/fixture.gemspec/declared/fixture.gemspec:2:1](#finding-50)|openssl@3.3.0|Review OpenSSL usage in Ruby and prepare PQC migration path. / [Source](#source-50)|
|<a id="finding-51"></a>[tuning/manifests/gems.locked/declared/gems.locked:3:1](#finding-51)|openssl@3.3.0|Review OpenSSL usage in Ruby and prepare PQC migration path. / [Source](#source-51)|
|<a id="finding-52"></a>[tuning/manifests/gems.rb/declared/gems.rb:1:1](#finding-52)|openssl@3.3.0|Verify deployed runtime and protocol PQC capabilities / [Verify deployed runtime and protocol PQC capabilities](#action-12) / [Source](#source-52)|

Shared checks for these locations (not verified facts about each line):

- [Introduce crypto abstraction boundary for algorithm agility](#action-6)
- [Track PQC readiness of dependent libraries](#action-11)

<a id="source-48"></a>

### tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-49"></a>

### tuning/manifests/Gemfile/declared/Gemfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-50"></a>

### tuning/manifests/fixture.gemspec/declared/fixture.gemspec:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-51"></a>

### tuning/manifests/gems.locked/declared/gems.locked:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-52"></a>

### tuning/manifests/gems.rb/declared/gems.rb:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-20"></a>

## DEP_RUST_OPENSSL

Rust TLS/crypto dependency detected.

Check: Track PQC migration options for Rust openssl/rustls crypto stacks.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-53"></a>[tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1](#finding-53)|openssl@0.10.75|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-53)|

Shared checks for these locations (not verified facts about each line):

- [Introduce crypto abstraction boundary for algorithm agility](#action-6)
- [Track PQC readiness of dependent libraries](#action-11)

<a id="source-53"></a>

### tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="rule-21"></a>

## JWT_LIB_JOSE

jose dependency detected.

Check: Verify PQC support in the JOSE implementation.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-54"></a>[tuning/manifests/package-lock.json/declared/package-lock.json:1:1](#finding-54)|jose@6.0.0|Verify PQC support in the JOSE implementation. / [Source](#source-54)|
|<a id="finding-55"></a>[tuning/manifests/package.json/declared/package.json:1:1](#finding-55)|jose@6.0.0|Verify PQC support in the JOSE implementation. / [Source](#source-55)|
|<a id="finding-56"></a>[tuning/manifests/pnpm-lock.yaml/declared/pnpm-lock.yaml:3:1](#finding-56)|jose@6.0.0|Verify PQC support in the JOSE implementation. / [Source](#source-56)|

Shared checks for these locations (not verified facts about each line):

- [Stop issuing new JWTs with RSA/PKCS#1/ECDSA-only algorithms](#action-2)

<a id="source-54"></a>

### tuning/manifests/package-lock.json/declared/package-lock.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-55"></a>

### tuning/manifests/package.json/declared/package.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-56"></a>

### tuning/manifests/pnpm-lock.yaml/declared/pnpm-lock.yaml:3:1

    > 3 [masked-sensitive-file-content]

<a id="rule-22"></a>

## PQC_DRAFT_ALGORITHM

Pre-standard PQC algorithm name referenced; check compatibility before replacing it.

Check: Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-57"></a>[tuning/js/draft.js:1:22](#finding-57)|kyber768|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-57)|

<a id="source-57"></a>

### tuning/js/draft.js:1:22

    > 1 generateKeyPairSync("kyber768");

<a id="rule-23"></a>

## PQC_JAVA_CLASSICAL_GROUPS

Explicit classical-only Java property intent in assignment, XML entry or static System.setProperty; effective loading is not established.

Check: Review explicit group restrictions against the deployed JSSE version and peer support.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-58"></a>[tuning/tls/positive.conf:1:1](#finding-58)|System.s***4r1");|Review explicit group restrictions against the deployed JSSE version and peer support. / [Review the explicit PQC override: jdk.tls.namedGroups](#action-13) / [Source](#source-58)|

<a id="source-58"></a>

### tuning/tls/positive.conf:1:1

    > 1 System.setProperty("jdk.tls.namedGroups", "secp256r1,secp384r1");

<a id="rule-24"></a>

## SSH_DH_GROUP14_SHA1

SHA-1 dependent SSH KEX detected.

Check: Retire SHA-1 based key exchange.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-59"></a>[tuning/ssh/dh.conf:1:15](#finding-59)|diffie-h***4-sha1|Retire SHA-1 based key exchange. / [Source](#source-59)|

<a id="source-59"></a>

### tuning/ssh/dh.conf:1:15

    > 1 KexAlgorithms diffie-hellman-group14-sha1

<a id="rule-25"></a>

## TS_NODE_RSA_USAGE

RSA-related API symbols detected from JavaScript/TypeScript AST.

Check: Migrate Node.js RSA signing/verification logic to a PQC-ready design.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-60"></a>[holdout/rsa-sign.js:7:35](#finding-60)|generate***('rsa'|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-60)|
|<a id="finding-61"></a>[holdout/rsa-sign.js:11:14](#finding-61)|createSign('SHA256'|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-61)|
|<a id="finding-62"></a>[holdout/rsa-sign.js:14:19](#finding-62)|sign.sign(privateKey|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-62)|
|<a id="finding-63"></a>[holdout/rsa-sign.js:16:16](#finding-63)|createVe***HA256'|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-63)|
|<a id="finding-64"></a>[holdout/rsa-sign.js:19:13](#finding-64)|verify.v***licKey|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-64)|
|<a id="finding-65"></a>[tuning/js/mixed.js:1:1](#finding-65)|generate***("rsa"|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-65)|
|<a id="finding-66"></a>[tuning/jwt/sign.js:1:33](#finding-66)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-66)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Introduce crypto abstraction boundary for algorithm agility](#action-6)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-60"></a>

### holdout/rsa-sign.js:7:35

      5 } = await import('node:crypto');
      6 
    > 7 const { privateKey, publicKey } = generateKeyPairSync('rsa', {
      8   modulusLength: 2048,
      9 });

<a id="source-61"></a>

### holdout/rsa-sign.js:11:14

      9 });
      10 
    > 11 const sign = createSign('SHA256');
      12 sign.update('some data to sign');
      13 sign.end();

<a id="source-62"></a>

### holdout/rsa-sign.js:14:19

      12 sign.update('some data to sign');
      13 sign.end();
    > 14 const signature = sign.sign(privateKey);
      15 
      16 const verify = createVerify('SHA256');

<a id="source-63"></a>

### holdout/rsa-sign.js:16:16

      14 const signature = sign.sign(privateKey);
      15 
    > 16 const verify = createVerify('SHA256');
      17 verify.update('some data to sign');
      18 verify.end();

<a id="source-64"></a>

### holdout/rsa-sign.js:19:13

      17 verify.update('some data to sign');
      18 verify.end();
    > 19 console.log(verify.verify(publicKey, signature));
      20 // Prints: true

<a id="source-65"></a>

### tuning/js/mixed.js:1:1

    > 1 generateKeyPairSync("rsa"); generateKeyPairSync("ml-kem-768");

<a id="source-66"></a>

### tuning/jwt/sign.js:1:33

    > 1 sign(payload, key, {algorithm: "RS256"});

<a id="rule-26"></a>

## CERT_PEM_CONTAINER

Certificate container file detected.

Check: Validate signing algorithms in PEM-based certificates.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-67"></a>[tuning/certs/broken.cer:1:1](#finding-67)|broken.cer|Validate signing algorithms in PEM-based certificates. / [Source](#source-67)|
|<a id="finding-68"></a>[tuning/certs/broken.crt:1:1](#finding-68)|broken.crt|Validate signing algorithms in PEM-based certificates. / [Source](#source-68)|
|<a id="finding-69"></a>[tuning/certs/broken.der:1:1](#finding-69)|broken.der|Validate signing algorithms in PEM-based certificates. / [Source](#source-69)|
|<a id="finding-70"></a>[tuning/certs/broken.pem:1:1](#finding-70)|broken.pem|Validate signing algorithms in PEM-based certificates. / [Source](#source-70)|

Shared checks for these locations (not verified facts about each line):

- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)

<a id="source-67"></a>

### tuning/certs/broken.cer:1:1

    > 1 not a certificate

<a id="source-68"></a>

### tuning/certs/broken.crt:1:1

    > 1 not a certificate

<a id="source-69"></a>

### tuning/certs/broken.der:1:1

    > 1 not a certificate

<a id="source-70"></a>

### tuning/certs/broken.pem:1:1

    > 1 not a certificate

<a id="rule-27"></a>

## DEP_PQC_CAPABLE_LIBRARY

Library with version-dependent PQC capabilities inventoried; capability is not an enabled-state finding.

Check: Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-71"></a>[tuning/manifests/Cargo.lock/declared/Cargo.lock:3:1](#finding-71)|openssl@0.10.75|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-71)|
|<a id="finding-72"></a>[tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1](#finding-72)|openssl@0.10.75|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-72)|
|<a id="finding-73"></a>[tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1](#finding-73)|openssl@3.3.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-73)|
|<a id="finding-74"></a>[tuning/manifests/Gemfile/declared/Gemfile:1:1](#finding-74)|openssl@3.3.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-74)|
|<a id="finding-75"></a>[tuning/manifests/Pipfile.lock/declared/Pipfile.lock:1:1](#finding-75)|cryptogr***48.0.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-75)|
|<a id="finding-76"></a>[tuning/manifests/build.gradle.kts/declared/build.gradle.kts:1:1](#finding-76)|org.boun***n@1.80|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-76)|
|<a id="finding-77"></a>[tuning/manifests/build.gradle/declared/build.gradle:1:1](#finding-77)|org.boun***n@1.80|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-77)|
|<a id="finding-78"></a>[tuning/manifests/fixture.gemspec/declared/fixture.gemspec:2:1](#finding-78)|openssl@3.3.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-78)|
|<a id="finding-79"></a>[tuning/manifests/gems.locked/declared/gems.locked:3:1](#finding-79)|openssl@3.3.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-79)|
|<a id="finding-80"></a>[tuning/manifests/gems.rb/declared/gems.rb:1:1](#finding-80)|openssl@3.3.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-80)|
|<a id="finding-81"></a>[tuning/manifests/go.mod/declared/go.mod:3:1](#finding-81)|github.c***v1.6.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-81)|
|<a id="finding-82"></a>[tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1](#finding-82)|org.boun***n@1.80|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-82)|
|<a id="finding-83"></a>[tuning/manifests/poetry.lock/declared/poetry.lock:2:1](#finding-83)|cryptography@48.0.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-83)|
|<a id="finding-84"></a>[tuning/manifests/pom.xml/declared/pom.xml:1:1](#finding-84)|org.boun***n@1.80|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-84)|
|<a id="finding-85"></a>[tuning/manifests/requirements.txt/declared/requirements.txt:1:1](#finding-85)|cryptography@48.0.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-85)|
|<a id="finding-86"></a>[tuning/sbom/CycloneDX-1.5/declared/bom.json:1:1](#finding-86)|openssl@3.5.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-86)|
|<a id="finding-87"></a>[tuning/sbom/SPDX-2.3/declared/bom.json:1:1](#finding-87)|openssl@3.5.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-87)|

Shared checks for these locations (not verified facts about each line):

- [Track PQC readiness of dependent libraries](#action-11)

<a id="source-71"></a>

### tuning/manifests/Cargo.lock/declared/Cargo.lock:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-72"></a>

### tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-73"></a>

### tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-74"></a>

### tuning/manifests/Gemfile/declared/Gemfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-75"></a>

### tuning/manifests/Pipfile.lock/declared/Pipfile.lock:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-76"></a>

### tuning/manifests/build.gradle.kts/declared/build.gradle.kts:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-77"></a>

### tuning/manifests/build.gradle/declared/build.gradle:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-78"></a>

### tuning/manifests/fixture.gemspec/declared/fixture.gemspec:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-79"></a>

### tuning/manifests/gems.locked/declared/gems.locked:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-80"></a>

### tuning/manifests/gems.rb/declared/gems.rb:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-81"></a>

### tuning/manifests/go.mod/declared/go.mod:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-82"></a>

### tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-83"></a>

### tuning/manifests/poetry.lock/declared/poetry.lock:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-84"></a>

### tuning/manifests/pom.xml/declared/pom.xml:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-85"></a>

### tuning/manifests/requirements.txt/declared/requirements.txt:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-86"></a>

### tuning/sbom/CycloneDX-1.5/declared/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-87"></a>

### tuning/sbom/SPDX-2.3/declared/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-28"></a>

## PQC_GO_API

Standard Go PQC package imported; import alone does not prove negotiated protection.

Check: crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-88"></a>[tuning/go/main.go:2:8](#finding-88)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-88)|

<a id="source-88"></a>

### tuning/go/main.go:2:8

      1 package data
    > 2 import "crypto/mlkem"

<a id="rule-29"></a>

## PQC_JAVA_API

Standard PQC algorithm requested through Java APIs; runtime success is not established.

Check: JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-89"></a>[tuning/java/Broken.java:1:1](#finding-89)|Signatur***SA-65"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-89)|
|<a id="finding-90"></a>[tuning/java/Kem.java:1:1](#finding-90)|KEM.getI***-1024"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-90)|
|<a id="finding-91"></a>[tuning/java/ML.java:1:1](#finding-91)|Signatur***SA-44"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-91)|
|<a id="finding-92"></a>[tuning/java/Slh.java:1:1](#finding-92)|Signatur***-256s"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-92)|

<a id="source-89"></a>

### tuning/java/Broken.java:1:1

    > 1 Signature.getInstance("ML-DSA-65"

<a id="source-90"></a>

### tuning/java/Kem.java:1:1

    > 1 KEM.getInstance("ML-KEM-1024");

<a id="source-91"></a>

### tuning/java/ML.java:1:1

    > 1 Signature.getInstance("ML-DSA-44");

<a id="source-92"></a>

### tuning/java/Slh.java:1:1

    > 1 Signature.getInstance("SLH-DSA-SHAKE-256s");

<a id="rule-30"></a>

## PQC_NODE_API

Node-style PQC key generation call; bindings and actual execution require confirmation.

Check: Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-93"></a>[holdout/ml-dsa.js:16:25](#finding-93)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-93)|
|<a id="finding-94"></a>[holdout/ml-dsa.js:54:7](#finding-94)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-94)|
|<a id="finding-95"></a>[holdout/ml-dsa.js:66:7](#finding-95)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-95)|
|<a id="finding-96"></a>[holdout/ml-kem.js:16:25](#finding-96)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-96)|
|<a id="finding-97"></a>[holdout/ml-kem.js:32:7](#finding-97)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-97)|
|<a id="finding-98"></a>[holdout/ml-kem.js:43:7](#finding-98)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-98)|
|<a id="finding-99"></a>[holdout/slh-dsa.js:20:25](#finding-99)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-99)|
|<a id="finding-100"></a>[holdout/slh-dsa.js:40:7](#finding-100)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-100)|
|<a id="finding-101"></a>[holdout/slh-dsa.js:51:7](#finding-101)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-101)|
|<a id="finding-102"></a>[tuning/js/alias.js:2:1](#finding-102)|make("ml-dsa-65"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-102)|
|<a id="finding-103"></a>[tuning/js/dead.js:1:12](#finding-103)|generate***m-768"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-103)|
|<a id="finding-104"></a>[tuning/js/direct.js:1:1](#finding-104)|generate***m-512"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-104)|
|<a id="finding-105"></a>[tuning/js/mixed.js:1:29](#finding-105)|generate***m-768"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-105)|
|<a id="finding-106"></a>[tuning/js/same-line.js:1:1](#finding-106)|generate***m-512"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-106)|
|<a id="finding-107"></a>[tuning/js/same-line.js:1:36](#finding-107)|generate***-1024"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-107)|

<a id="source-93"></a>

### holdout/ml-dsa.js:16:25

      14 if (!hasOpenSSL(3, 5)) {
      15   for (const asymmetricKeyType of ['ml-dsa-44', 'ml-dsa-65', 'ml-dsa-87']) {
    > 16     assert.throws(() => generateKeyPair(asymmetricKeyType, common.mustNotCall()), {
      17       code: 'ERR_INVALID_ARG_VALUE',
      18       message: /The argument 'type' must be a supported key type/

<a id="source-94"></a>

### holdout/ml-dsa.js:54:7

      52       [{ format: 'der', type: 'spki' }, (publicKey) => assert.strictEqual(Buffer.isBuffer(publicKey), true)],
      53     ]) {
    > 54       generateKeyPair(asymmetricKeyType, { publicKeyEncoding }, common.mustSucceed(validate));
      55     }
      56     for (const [privateKeyEncoding, validate] of [

<a id="source-95"></a>

### holdout/ml-dsa.js:66:7

      64       [{ format: 'der', type: 'pkcs8' }, (_, privateKey) => assert.strictEqual(Buffer.isBuffer(privateKey), true)],
      65     ]) {
    > 66       generateKeyPair(asymmetricKeyType, { privateKeyEncoding }, common.mustSucceed(validate));
      67     }
      68   }

<a id="source-96"></a>

### holdout/ml-kem.js:16:25

      14 if (!hasOpenSSL(3, 5)) {
      15   for (const asymmetricKeyType of ['ml-kem-512', 'ml-kem-768', 'ml-kem-1024']) {
    > 16     assert.throws(() => generateKeyPair(asymmetricKeyType, common.mustNotCall()), {
      17       code: 'ERR_INVALID_ARG_VALUE',
      18       message: /The argument 'type' must be a supported key type/

<a id="source-97"></a>

### holdout/ml-kem.js:32:7

      30       [{ format: 'der', type: 'spki' }, (publicKey) => assert.strictEqual(Buffer.isBuffer(publicKey), true)],
      31     ]) {
    > 32       generateKeyPair(asymmetricKeyType, { publicKeyEncoding }, common.mustSucceed(validate));
      33     }
      34     for (const [privateKeyEncoding, validate] of [

<a id="source-98"></a>

### holdout/ml-kem.js:43:7

      41       [{ format: 'der', type: 'pkcs8' }, (_, privateKey) => assert.strictEqual(Buffer.isBuffer(privateKey), true)],
      42     ]) {
    > 43       generateKeyPair(asymmetricKeyType, { privateKeyEncoding }, common.mustSucceed(validate));
      44     }
      45   }

<a id="source-99"></a>

### holdout/slh-dsa.js:20:25

      18     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',
      19   ]) {
    > 20     assert.throws(() => generateKeyPair(asymmetricKeyType, common.mustNotCall()), {
      21       code: 'ERR_INVALID_ARG_VALUE',
      22       message: /The argument 'type' must be a supported key type/

<a id="source-100"></a>

### holdout/slh-dsa.js:40:7

      38       [{ format: 'der', type: 'spki' }, (publicKey) => assert.strictEqual(Buffer.isBuffer(publicKey), true)],
      39     ]) {
    > 40       generateKeyPair(asymmetricKeyType, { publicKeyEncoding }, common.mustSucceed(validate));
      41     }
      42     for (const [privateKeyEncoding, validate] of [

<a id="source-101"></a>

### holdout/slh-dsa.js:51:7

      49       [{ format: 'der', type: 'pkcs8' }, (_, privateKey) => assert.strictEqual(Buffer.isBuffer(privateKey), true)],
      50     ]) {
    > 51       generateKeyPair(asymmetricKeyType, { privateKeyEncoding }, common.mustSucceed(validate));
      52     }
      53   }

<a id="source-102"></a>

### tuning/js/alias.js:2:1

      1 import {generateKeyPairSync as make} from "node:crypto";
    > 2 make("ml-dsa-65");

<a id="source-103"></a>

### tuning/js/dead.js:1:12

    > 1 if (false) generateKeyPairSync("ml-kem-768");

<a id="source-104"></a>

### tuning/js/direct.js:1:1

    > 1 generateKeyPairSync("ml-kem-512");

<a id="source-105"></a>

### tuning/js/mixed.js:1:29

    > 1 generateKeyPairSync("rsa"); generateKeyPairSync("ml-kem-768");

<a id="source-106"></a>

### tuning/js/same-line.js:1:1

    > 1 generateKeyPairSync("ml-kem-512"); generateKeyPairSync("ml-kem-1024");

<a id="source-107"></a>

### tuning/js/same-line.js:1:36

    > 1 generateKeyPairSync("ml-kem-512"); generateKeyPairSync("ml-kem-1024");

<a id="rule-31"></a>

## PQC_PYTHON_API

Python PQC key generation reference; backend support is not established.

Check: cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-108"></a>[tuning/python/broken.py:1:7](#finding-108)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-108)|
|<a id="finding-109"></a>[tuning/python/pqc.py:1:1](#finding-109)|from cry*** mlkem|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-109)|
|<a id="finding-110"></a>[tuning/python/pqc.py:2:5](#finding-110)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-110)|

<a id="source-108"></a>

### tuning/python/broken.py:1:7

    > 1 key = mlkem.MLKEM768PrivateKey.generate(

<a id="source-109"></a>

### tuning/python/pqc.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric import mlkem
      2 k = mlkem.MLKEM768PrivateKey.generate()

<a id="source-110"></a>

### tuning/python/pqc.py:2:5

      1 from cryptography.hazmat.primitives.asymmetric import mlkem
    > 2 k = mlkem.MLKEM768PrivateKey.generate()

<a id="rule-32"></a>

## PQC_RUBY_API

Ruby PQC algorithm literal referenced; key generation or signing success is not established.

Check: Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-111"></a>[tuning/ruby/negative.rb:1:6](#finding-111)|"SLH-DSA-SHA2-128s"|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-111)|
|<a id="finding-112"></a>[tuning/ruby/pqc.rb:1:28](#finding-112)|"ML-DSA-87"|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-112)|

<a id="source-111"></a>

### tuning/ruby/negative.rb:1:6

    > 1 puts "SLH-DSA-SHA2-128s"

<a id="source-112"></a>

### tuning/ruby/pqc.rb:1:28

    > 1 OpenSSL::PKey.generate_key("ML-DSA-87")

<a id="rule-33"></a>

## PQC_RUST_API

Rust PQC crate symbol referenced; execution and protocol use require confirmation.

Check: Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-113"></a>[tuning/rust/broken.rs:1:5](#finding-113)|ml_kem::|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-113)|
|<a id="finding-114"></a>[tuning/rust/pqc.rs:1:5](#finding-114)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-114)|

<a id="source-113"></a>

### tuning/rust/broken.rs:1:5

    > 1 use ml_kem::

<a id="source-114"></a>

### tuning/rust/pqc.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="rule-34"></a>

## PQC_WEBCRYPTO_API

WebCrypto-style PQC algorithm request; this is not proof of browser support.

Check: Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-115"></a>[tuning/typescript/web.ts:1:15](#finding-115)|generate***M-768"|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-115)|

<a id="source-115"></a>

### tuning/typescript/web.ts:1:15

    > 1 crypto.subtle.generateKey({name: "ML-KEM-768"}, true, ["encapsulateBits"]);

## Action details

Each location links only to its applicable action. Identical payloads are printed once.

<a id="action-0"></a>


#### Adopt a phased hybrid PQC migration plan (near-term)

The detected primitive is vulnerable to cryptographically relevant quantum attacks. Hybrid rollout minimizes compatibility risk.

1. Inventory all call sites using this algorithm and owner teams.
2. Introduce dual-stack or hybrid mode (classical + PQC) before hard cut-over.
3. Define retirement dates for legacy classical algorithms.

References:

- https://www.nist.gov/itl/post-quantum-cryptography
- https://csrc.nist.gov/pubs/fips/203/final
- https://csrc.nist.gov/pubs/fips/204/final
<a id="action-1"></a>


#### Prepare hybrid certificate issuance and trust-store rollout (near-term)

PKI updates require coordinated CA, chain, and relying-party compatibility planning.

1. Inventory certificate signature algorithms and key sizes from CBOM/report output.
2. Pilot hybrid chain issuance in non-production trust stores.
3. Define reissuance plan for quantum-vulnerable roots/intermediates/end-entity certs.

References:

- https://csrc.nist.gov/pubs/fips/204/final
- https://csrc.nist.gov/pubs/fips/205/final
<a id="action-2"></a>


#### Stop issuing new JWTs with RSA/PKCS#1/ECDSA-only algorithms (near-term)

JWT signatures using classical public-key algorithms become long-term high risk under quantum adversaries.

1. Restrict accepted alg values and explicitly deny weak/legacy defaults.
2. Introduce short-lived tokens during the migration phase.
3. Prepare verifier rollout before signer rollout to avoid compatibility outages.
4. Confirm JOSE algorithm identifiers, key encoding, JWT library support and all verifiers before changing token signatures; primitive support alone is insufficient.

References:

- https://www.rfc-editor.org/rfc/rfc7519
<a id="action-3"></a>


#### Upgrade Node.js runtime for built-in WebCrypto PQC support (planned)

Node.js runtime level determines whether built-in PQC APIs are available for direct migration.

1. Node crypto: ML-DSA 24.6+, ML-KEM 24.7+, SLH-DSA 24.8+; WebCrypto ML-DSA/ML-KEM 24.7+. Check exact runtime and algorithm support.
2. Distinguish Node.js from browser execution; TypeScript types do not establish runtime capabilities. ML-KEM key exchange does not replace JWT signatures.

References:

- https://nodejs.org/api/webcrypto.html

Before (javascript)

    import jwt from "jsonwebtoken";
    const token = jwt.sign(payload, privateKey, { algorithm: "RS256" });

After

    // Replace RS256 token-signing path with a PQC-capable signing service
    // or WebCrypto ML-DSA workflow once runtime support is enabled.
    const token = await signWithPqc(payload);

<a id="action-4"></a>


#### Verify deployed runtime and protocol PQC capabilities (planned)

Source declarations and primitive availability do not establish deployment or peer support.

1. Node crypto ML-DSA requires 24.6+, ML-KEM 24.7+, SLH-DSA 24.8+; WebCrypto ML-DSA/ML-KEM requires 24.7+. Verify browser support independently of TypeScript declarations.
2. Check resolved versions, provider/features and interoperability before changing production policy.

References:

- https://nodejs.org/api/webcrypto.html
<a id="action-5"></a>


#### Rotate exposed private keys and revoke affected credentials (immediate)

Private key material was detected. This is an active key-management incident and must be remediated immediately.

1. Revoke/disable the exposed key and issue a replacement key pair.
2. Invalidate sessions/tokens signed by the compromised key if applicable.
3. Move keys to a secret manager or HSM and enforce commit scanning in CI.

References:

- https://cheatsheetseries.owasp.org/cheatsheets/Secrets_Management_Cheat_Sheet.html
<a id="action-6"></a>


#### Introduce crypto abstraction boundary for algorithm agility (near-term)

Direct algorithm calls create high migration cost. A boundary layer enables staged classical-to-PQC transitions.

1. Wrap signing, verification, keygen, and key exchange behind stable interfaces.
2. Add policy controls to select classical, hybrid, or PQC paths at runtime.

References:

- https://www.nist.gov/itl/post-quantum-cryptography
<a id="action-7"></a>


#### Upgrade Java runtime baseline for standard PQC APIs (planned)

Detected Java version appears older than JDK releases with standardized PQC APIs.

1. Target JDK 24+ for ML-KEM and ML-DSA support planning.
2. Pilot compatibility testing in CI before production migration.

References:

- https://openjdk.org/jeps/496
- https://openjdk.org/jeps/497
<a id="action-8"></a>


#### Provide BouncyCastle PQC fallback path (near-term)

BouncyCastle can be used as a pragmatic transition option when standard runtime support is unavailable or incomplete.

1. Add BC provider initialization at bootstrap.
2. Use BC ML-DSA / ML-KEM parameter specs for migration pilot implementations.
3. Document provider ordering and FIPS/compliance impact.

References:

- https://www.bouncycastle.org/java.html
- https://downloads.bouncycastle.org/java/docs/bcprov-jdk18on-javadoc/

Before (java)

    Security.addProvider(new BouncyCastleProvider());
    Signature sig = Signature.getInstance("SHA256withRSA", "BC");

After

    Security.addProvider(new BouncyCastlePQCProvider());
    Signature sig = Signature.getInstance("ML-DSA", "BCPQC");
    // Configure parameter set (example): MLDSAParameterSpec.ml_dsa_65

<a id="action-9"></a>


#### Verify deployed runtime and protocol PQC capabilities (planned)

Source declarations and primitive availability do not establish deployment or peer support.

1. JDK 24 adds ML-KEM and ML-DSA primitives. Check deployed JSSE hybrid TLS support separately and inspect jdk.tls.namedGroups restrictions.
2. Check resolved versions, provider/features and interoperability before changing production policy.

References:

- https://docs.oracle.com/en/java/javase/27/security/java-secure-socket-extension-jsse-reference-guide.html
<a id="action-10"></a>


#### Prefer TLS 1.3 and review legacy key exchange (near-term)

RSA key exchange and legacy protocol versions are high-priority migration blockers for PQC readiness.

1. Prefer TLS 1.3; restrict connections to TLS 1.3 when all peers support it. Disable TLS 1.0 and 1.1.
2. Retain securely configured TLS 1.2 only where interoperability requires it, and record the compatibility reason.
3. Prefer ECDHE today and plan hybrid KEM suites for next phase.
4. Continuously test interoperability across clients and load balancers.

References:

- https://www.rfc-editor.org/rfc/rfc8446
<a id="action-11"></a>


#### Track PQC readiness of dependent libraries (planned)

Dependency-level crypto libraries strongly influence migration options and operational timelines.

1. Record current versions in dependency-sbom.json and define upgrade targets.
2. Subscribe to release notes for PQC feature availability and API changes.
3. Run integration tests for PQC or hybrid modes before promoting to production.

References:

- https://cyclonedx.org/
- https://spdx.dev/
<a id="action-12"></a>


#### Verify deployed runtime and protocol PQC capabilities (planned)

Source declarations and primitive availability do not establish deployment or peer support.

1. Check openssl gem and linked library/provider versions. gem 4 adds groups=, sigalgs= and negotiated group inspection; Ruby version alone is insufficient.
2. Check resolved versions, provider/features and interoperability before changing production policy.

References:

- https://ruby.github.io/openssl/History_md.html
<a id="action-13"></a>


#### Review the explicit PQC override: jdk.tls.namedGroups (near-term)

The detected setting restricts hybrid key exchange. It does not establish RSA usage or the negotiated TLS version.

1. Inspect jdk.tls.namedGroups at this location and confirm why the override is required.
2. Verify deployed library and peer support before testing a hybrid group or removing the override.
3. Check key exchange, TLS protocol version and certificate signatures separately; TLS 1.3 alone does not establish PQC protection.

References:

- https://go.dev/doc/godebug
- https://www.rfc-editor.org/rfc/rfc9325.html#section-3.1.1

## Inventory exports

- [CBOM](cbom.json): 116
- [Dependency SBOM](dependency-sbom.json): 38


## Inspection coverage

Completeness covers supported inspection within the declared scope, after ignore settings, exclusions and size limits. It does not prove runtime use, certificate trust or security. Unenumerated files remain unknown.

|Item|Value|
|---|---|
|Status|Some inspection could not complete (partial)|
|Selected files|141|
|Read successfully|141|
|Read failed|0|
|Analyzed|94|
|Partial|26|
|Analysis failed|0|
|Unsupported|0|
|Not applicable|0|
|Unknown|21|
|Enumerated exclusions|0|
|Enumeration failures|0|
|Unenumerated population|Unknown|

## Inspection diagnostics

Safe reason codes, paths and detector names; file contents and arbitrary error messages are omitted.

|Item|Value|
|---|---|
|Detector does not report completeness (detector_not_reported)|- / dependency_detector|
|Only part of inspection completed (detector_partial)|tuning/certs/broken.cer / certificate_detector|
|Only part of inspection completed (detector_partial)|tuning/certs/broken.crt / certificate_detector|
|Only part of inspection completed (detector_partial)|tuning/certs/broken.der / certificate_detector|
|Only part of inspection completed (detector_partial)|tuning/certs/broken.p12 / certificate_detector|
|Only part of inspection completed (detector_partial)|tuning/certs/broken.pem / certificate_detector|
|Only part of inspection completed (detector_partial)|tuning/certs/broken.pfx / certificate_detector|
|Inspection unsupported (detector_unsupported)|tuning/certs/public-only.p12 / certificate_detector|
|Inspection unsupported (detector_unsupported)|tuning/certs/public-only.pfx / certificate_detector|
|Only part of inspection completed (detector_partial)|tuning/go/broken.go / tree_sitter_detector|
|Only part of inspection completed (detector_partial)|tuning/java/Broken.java / tree_sitter_detector|
|Only part of inspection completed (detector_partial)|tuning/jwt/broken.js / regex_detector|
|Only part of inspection completed (detector_partial)|tuning/jwt/broken.js / tree_sitter_detector|
|Detector failed (detector_failed)|tuning/manifests/Cargo.lock/malformed/Cargo.lock / dependency_detector|
|Detector failed (detector_failed)|tuning/manifests/Cargo.toml/malformed/Cargo.toml / dependency_detector|
|Detector failed (detector_failed)|tuning/manifests/Pipfile.lock/malformed/Pipfile.lock / dependency_detector|
|Only part of inspection completed (detector_partial)|tuning/manifests/gems.rb/malformed/gems.rb / tree_sitter_detector|
|Detector failed (detector_failed)|tuning/manifests/package-lock.json/malformed/package-lock.json / dependency_detector|
|Detector failed (detector_failed)|tuning/manifests/package.json/malformed/package.json / dependency_detector|
|Inspection unsupported (detector_unsupported)|tuning/manifests/pnpm-lock.yaml/malformed/pnpm-lock.yaml / dependency_detector|
|Detector failed (detector_failed)|tuning/manifests/poetry.lock/malformed/poetry.lock / dependency_detector|
|Detector failed (detector_failed)|tuning/manifests/pom.xml/malformed/pom.xml / dependency_detector|
|Only part of inspection completed (detector_partial)|tuning/python/broken.py / tree_sitter_detector|
|Only part of inspection completed (detector_partial)|tuning/ruby/broken.rb / tree_sitter_detector|
|Only part of inspection completed (detector_partial)|tuning/rust/broken.rs / tree_sitter_detector|
|Detector failed (detector_failed)|tuning/sbom/CycloneDX-1.5/malformed/bom.json / dependency_detector|
|Detector failed (detector_failed)|tuning/sbom/SPDX-2.3/malformed/bom.json / dependency_detector|
|Only part of inspection completed (detector_partial)|tuning/typescript/broken.ts / regex_detector|
|Only part of inspection completed (detector_partial)|tuning/typescript/broken.ts / tree_sitter_detector|
