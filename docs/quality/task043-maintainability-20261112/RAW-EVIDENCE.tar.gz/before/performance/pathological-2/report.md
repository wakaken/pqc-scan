# PQC Migration Scan Report

Generated: 2026-11-12 03:10:31.221087 UTC

Risk candidates: 128 / Inventory findings: 0 / Scanned files: 1

Static evidence does not prove runtime use or completed PQC migration.

|Severity|Count (all findings)|
|---|---:|
|critical|64|
|high|32|
|medium|32|

## Risk candidate index

|Rule / description|Severity|Risk|Hits|Files|
|---|---|---|---:|---:|
|[JWT_RS256](#rule-0) RS256 (RSA-based JWT signing) is in use.|critical|quantum-vulnerable|32|1|
|[TS_JWT_RSA_ALGS](#rule-1) RSA-family JWT signing algorithms detected in AST nodes.|critical|quantum-vulnerable|32|1|
|[API_JOSE_RSA_ALG](#rule-2) RSA-family JOSE algorithm detected.|high|quantum-vulnerable|32|1|
|[TS_NODE_RSA_USAGE](#rule-3) RSA-related API symbols detected from JavaScript/TypeScript AST.|medium|quantum-vulnerable|32|1|

## Informational inventory index

|Rule / description|Severity|Risk|Hits|Files|
|---|---|---|---:|---:|

<a id="rule-0"></a>

## JWT_RS256

RS256 (RSA-based JWT signing) is in use.

Check: Migrate to ML-DSA signatures.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-0"></a>[repeated.js:1:15](#finding-0)|RS256|Migrate to ML-DSA signatures. / [Source](#source-0)|
|<a id="finding-1"></a>[repeated.js:1:21](#finding-1)|RS256|Migrate to ML-DSA signatures. / [Source](#source-1)|
|<a id="finding-2"></a>[repeated.js:1:27](#finding-2)|RS256|Migrate to ML-DSA signatures. / [Source](#source-2)|
|<a id="finding-3"></a>[repeated.js:1:33](#finding-3)|RS256|Migrate to ML-DSA signatures. / [Source](#source-3)|
|<a id="finding-4"></a>[repeated.js:1:39](#finding-4)|RS256|Migrate to ML-DSA signatures. / [Source](#source-4)|
|<a id="finding-5"></a>[repeated.js:1:45](#finding-5)|RS256|Migrate to ML-DSA signatures. / [Source](#source-5)|
|<a id="finding-6"></a>[repeated.js:1:51](#finding-6)|RS256|Migrate to ML-DSA signatures. / [Source](#source-6)|
|<a id="finding-7"></a>[repeated.js:1:57](#finding-7)|RS256|Migrate to ML-DSA signatures. / [Source](#source-7)|
|<a id="finding-8"></a>[repeated.js:1:63](#finding-8)|RS256|Migrate to ML-DSA signatures. / [Source](#source-8)|
|<a id="finding-9"></a>[repeated.js:1:69](#finding-9)|RS256|Migrate to ML-DSA signatures. / [Source](#source-9)|
|<a id="finding-10"></a>[repeated.js:1:75](#finding-10)|RS256|Migrate to ML-DSA signatures. / [Source](#source-10)|
|<a id="finding-11"></a>[repeated.js:1:81](#finding-11)|RS256|Migrate to ML-DSA signatures. / [Source](#source-11)|
|<a id="finding-12"></a>[repeated.js:1:87](#finding-12)|RS256|Migrate to ML-DSA signatures. / [Source](#source-12)|
|<a id="finding-13"></a>[repeated.js:1:93](#finding-13)|RS256|Migrate to ML-DSA signatures. / [Source](#source-13)|
|<a id="finding-14"></a>[repeated.js:1:99](#finding-14)|RS256|Migrate to ML-DSA signatures. / [Source](#source-14)|
|<a id="finding-15"></a>[repeated.js:1:105](#finding-15)|RS256|Migrate to ML-DSA signatures. / [Source](#source-15)|
|<a id="finding-16"></a>[repeated.js:1:111](#finding-16)|RS256|Migrate to ML-DSA signatures. / [Source](#source-16)|
|<a id="finding-17"></a>[repeated.js:1:117](#finding-17)|RS256|Migrate to ML-DSA signatures. / [Source](#source-17)|
|<a id="finding-18"></a>[repeated.js:1:123](#finding-18)|RS256|Migrate to ML-DSA signatures. / [Source](#source-18)|
|<a id="finding-19"></a>[repeated.js:1:129](#finding-19)|RS256|Migrate to ML-DSA signatures. / [Source](#source-19)|
|<a id="finding-20"></a>[repeated.js:1:135](#finding-20)|RS256|Migrate to ML-DSA signatures. / [Source](#source-20)|
|<a id="finding-21"></a>[repeated.js:1:141](#finding-21)|RS256|Migrate to ML-DSA signatures. / [Source](#source-21)|
|<a id="finding-22"></a>[repeated.js:1:147](#finding-22)|RS256|Migrate to ML-DSA signatures. / [Source](#source-22)|
|<a id="finding-23"></a>[repeated.js:1:153](#finding-23)|RS256|Migrate to ML-DSA signatures. / [Source](#source-23)|
|<a id="finding-24"></a>[repeated.js:1:159](#finding-24)|RS256|Migrate to ML-DSA signatures. / [Source](#source-24)|
|<a id="finding-25"></a>[repeated.js:1:165](#finding-25)|RS256|Migrate to ML-DSA signatures. / [Source](#source-25)|
|<a id="finding-26"></a>[repeated.js:1:171](#finding-26)|RS256|Migrate to ML-DSA signatures. / [Source](#source-26)|
|<a id="finding-27"></a>[repeated.js:1:177](#finding-27)|RS256|Migrate to ML-DSA signatures. / [Source](#source-27)|
|<a id="finding-28"></a>[repeated.js:1:183](#finding-28)|RS256|Migrate to ML-DSA signatures. / [Source](#source-28)|
|<a id="finding-29"></a>[repeated.js:1:189](#finding-29)|RS256|Migrate to ML-DSA signatures. / [Source](#source-29)|
|<a id="finding-30"></a>[repeated.js:1:195](#finding-30)|RS256|Migrate to ML-DSA signatures. / [Source](#source-30)|
|<a id="finding-31"></a>[repeated.js:1:201](#finding-31)|RS256|Migrate to ML-DSA signatures. / [Source](#source-31)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Stop issuing new JWTs with RSA/PKCS#1/ECDSA-only algorithms](#action-1)
- [Upgrade Node.js runtime for built-in WebCrypto PQC support](#action-2)
- [Verify deployed runtime and protocol PQC capabilities](#action-3)

<a id="source-0"></a>

### repeated.js:1:15

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-1"></a>

### repeated.js:1:21

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-2"></a>

### repeated.js:1:27

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-3"></a>

### repeated.js:1:33

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-4"></a>

### repeated.js:1:39

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-5"></a>

### repeated.js:1:45

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-6"></a>

### repeated.js:1:51

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-7"></a>

### repeated.js:1:57

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-8"></a>

### repeated.js:1:63

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-9"></a>

### repeated.js:1:69

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-10"></a>

### repeated.js:1:75

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-11"></a>

### repeated.js:1:81

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-12"></a>

### repeated.js:1:87

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-13"></a>

### repeated.js:1:93

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-14"></a>

### repeated.js:1:99

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-15"></a>

### repeated.js:1:105

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-16"></a>

### repeated.js:1:111

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-17"></a>

### repeated.js:1:117

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-18"></a>

### repeated.js:1:123

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-19"></a>

### repeated.js:1:129

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-20"></a>

### repeated.js:1:135

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-21"></a>

### repeated.js:1:141

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-22"></a>

### repeated.js:1:147

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-23"></a>

### repeated.js:1:153

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-24"></a>

### repeated.js:1:159

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-25"></a>

### repeated.js:1:165

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-26"></a>

### repeated.js:1:171

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-27"></a>

### repeated.js:1:177

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-28"></a>

### repeated.js:1:183

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-29"></a>

### repeated.js:1:189

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-30"></a>

### repeated.js:1:195

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-31"></a>

### repeated.js:1:201

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="rule-1"></a>

## TS_JWT_RSA_ALGS

RSA-family JWT signing algorithms detected in AST nodes.

Check: Migrate JWT signing to ML-DSA or hybrid signatures.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-32"></a>[repeated.js:1:15](#finding-32)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-32)|
|<a id="finding-33"></a>[repeated.js:1:21](#finding-33)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-33)|
|<a id="finding-34"></a>[repeated.js:1:27](#finding-34)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-34)|
|<a id="finding-35"></a>[repeated.js:1:33](#finding-35)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-35)|
|<a id="finding-36"></a>[repeated.js:1:39](#finding-36)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-36)|
|<a id="finding-37"></a>[repeated.js:1:45](#finding-37)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-37)|
|<a id="finding-38"></a>[repeated.js:1:51](#finding-38)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-38)|
|<a id="finding-39"></a>[repeated.js:1:57](#finding-39)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-39)|
|<a id="finding-40"></a>[repeated.js:1:63](#finding-40)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-40)|
|<a id="finding-41"></a>[repeated.js:1:69](#finding-41)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-41)|
|<a id="finding-42"></a>[repeated.js:1:75](#finding-42)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-42)|
|<a id="finding-43"></a>[repeated.js:1:81](#finding-43)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-43)|
|<a id="finding-44"></a>[repeated.js:1:87](#finding-44)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-44)|
|<a id="finding-45"></a>[repeated.js:1:93](#finding-45)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-45)|
|<a id="finding-46"></a>[repeated.js:1:99](#finding-46)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-46)|
|<a id="finding-47"></a>[repeated.js:1:105](#finding-47)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-47)|
|<a id="finding-48"></a>[repeated.js:1:111](#finding-48)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-48)|
|<a id="finding-49"></a>[repeated.js:1:117](#finding-49)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-49)|
|<a id="finding-50"></a>[repeated.js:1:123](#finding-50)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-50)|
|<a id="finding-51"></a>[repeated.js:1:129](#finding-51)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-51)|
|<a id="finding-52"></a>[repeated.js:1:135](#finding-52)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-52)|
|<a id="finding-53"></a>[repeated.js:1:141](#finding-53)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-53)|
|<a id="finding-54"></a>[repeated.js:1:147](#finding-54)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-54)|
|<a id="finding-55"></a>[repeated.js:1:153](#finding-55)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-55)|
|<a id="finding-56"></a>[repeated.js:1:159](#finding-56)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-56)|
|<a id="finding-57"></a>[repeated.js:1:165](#finding-57)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-57)|
|<a id="finding-58"></a>[repeated.js:1:171](#finding-58)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-58)|
|<a id="finding-59"></a>[repeated.js:1:177](#finding-59)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-59)|
|<a id="finding-60"></a>[repeated.js:1:183](#finding-60)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-60)|
|<a id="finding-61"></a>[repeated.js:1:189](#finding-61)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-61)|
|<a id="finding-62"></a>[repeated.js:1:195](#finding-62)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-62)|
|<a id="finding-63"></a>[repeated.js:1:201](#finding-63)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-63)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Stop issuing new JWTs with RSA/PKCS#1/ECDSA-only algorithms](#action-1)
- [Upgrade Node.js runtime for built-in WebCrypto PQC support](#action-2)
- [Verify deployed runtime and protocol PQC capabilities](#action-3)

<a id="source-32"></a>

### repeated.js:1:15

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-33"></a>

### repeated.js:1:21

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-34"></a>

### repeated.js:1:27

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-35"></a>

### repeated.js:1:33

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-36"></a>

### repeated.js:1:39

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-37"></a>

### repeated.js:1:45

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-38"></a>

### repeated.js:1:51

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-39"></a>

### repeated.js:1:57

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-40"></a>

### repeated.js:1:63

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-41"></a>

### repeated.js:1:69

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-42"></a>

### repeated.js:1:75

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-43"></a>

### repeated.js:1:81

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-44"></a>

### repeated.js:1:87

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-45"></a>

### repeated.js:1:93

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-46"></a>

### repeated.js:1:99

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-47"></a>

### repeated.js:1:105

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-48"></a>

### repeated.js:1:111

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-49"></a>

### repeated.js:1:117

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-50"></a>

### repeated.js:1:123

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-51"></a>

### repeated.js:1:129

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-52"></a>

### repeated.js:1:135

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-53"></a>

### repeated.js:1:141

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-54"></a>

### repeated.js:1:147

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-55"></a>

### repeated.js:1:153

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-56"></a>

### repeated.js:1:159

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-57"></a>

### repeated.js:1:165

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-58"></a>

### repeated.js:1:171

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-59"></a>

### repeated.js:1:177

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-60"></a>

### repeated.js:1:183

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-61"></a>

### repeated.js:1:189

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-62"></a>

### repeated.js:1:195

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-63"></a>

### repeated.js:1:201

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="rule-2"></a>

## API_JOSE_RSA_ALG

RSA-family JOSE algorithm detected.

Check: Update JOSE algorithms to PQC-ready alternatives.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-64"></a>[repeated.js:1:15](#finding-64)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-64)|
|<a id="finding-65"></a>[repeated.js:1:21](#finding-65)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-65)|
|<a id="finding-66"></a>[repeated.js:1:27](#finding-66)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-66)|
|<a id="finding-67"></a>[repeated.js:1:33](#finding-67)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-67)|
|<a id="finding-68"></a>[repeated.js:1:39](#finding-68)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-68)|
|<a id="finding-69"></a>[repeated.js:1:45](#finding-69)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-69)|
|<a id="finding-70"></a>[repeated.js:1:51](#finding-70)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-70)|
|<a id="finding-71"></a>[repeated.js:1:57](#finding-71)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-71)|
|<a id="finding-72"></a>[repeated.js:1:63](#finding-72)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-72)|
|<a id="finding-73"></a>[repeated.js:1:69](#finding-73)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-73)|
|<a id="finding-74"></a>[repeated.js:1:75](#finding-74)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-74)|
|<a id="finding-75"></a>[repeated.js:1:81](#finding-75)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-75)|
|<a id="finding-76"></a>[repeated.js:1:87](#finding-76)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-76)|
|<a id="finding-77"></a>[repeated.js:1:93](#finding-77)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-77)|
|<a id="finding-78"></a>[repeated.js:1:99](#finding-78)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-78)|
|<a id="finding-79"></a>[repeated.js:1:105](#finding-79)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-79)|
|<a id="finding-80"></a>[repeated.js:1:111](#finding-80)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-80)|
|<a id="finding-81"></a>[repeated.js:1:117](#finding-81)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-81)|
|<a id="finding-82"></a>[repeated.js:1:123](#finding-82)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-82)|
|<a id="finding-83"></a>[repeated.js:1:129](#finding-83)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-83)|
|<a id="finding-84"></a>[repeated.js:1:135](#finding-84)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-84)|
|<a id="finding-85"></a>[repeated.js:1:141](#finding-85)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-85)|
|<a id="finding-86"></a>[repeated.js:1:147](#finding-86)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-86)|
|<a id="finding-87"></a>[repeated.js:1:153](#finding-87)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-87)|
|<a id="finding-88"></a>[repeated.js:1:159](#finding-88)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-88)|
|<a id="finding-89"></a>[repeated.js:1:165](#finding-89)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-89)|
|<a id="finding-90"></a>[repeated.js:1:171](#finding-90)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-90)|
|<a id="finding-91"></a>[repeated.js:1:177](#finding-91)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-91)|
|<a id="finding-92"></a>[repeated.js:1:183](#finding-92)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-92)|
|<a id="finding-93"></a>[repeated.js:1:189](#finding-93)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-93)|
|<a id="finding-94"></a>[repeated.js:1:195](#finding-94)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-94)|
|<a id="finding-95"></a>[repeated.js:1:201](#finding-95)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-95)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Introduce crypto abstraction boundary for algorithm agility](#action-4)
- [Verify deployed runtime and protocol PQC capabilities](#action-3)

<a id="source-64"></a>

### repeated.js:1:15

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-65"></a>

### repeated.js:1:21

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-66"></a>

### repeated.js:1:27

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-67"></a>

### repeated.js:1:33

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-68"></a>

### repeated.js:1:39

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-69"></a>

### repeated.js:1:45

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-70"></a>

### repeated.js:1:51

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-71"></a>

### repeated.js:1:57

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-72"></a>

### repeated.js:1:63

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-73"></a>

### repeated.js:1:69

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-74"></a>

### repeated.js:1:75

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-75"></a>

### repeated.js:1:81

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-76"></a>

### repeated.js:1:87

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-77"></a>

### repeated.js:1:93

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-78"></a>

### repeated.js:1:99

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-79"></a>

### repeated.js:1:105

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-80"></a>

### repeated.js:1:111

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-81"></a>

### repeated.js:1:117

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-82"></a>

### repeated.js:1:123

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-83"></a>

### repeated.js:1:129

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-84"></a>

### repeated.js:1:135

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-85"></a>

### repeated.js:1:141

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-86"></a>

### repeated.js:1:147

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-87"></a>

### repeated.js:1:153

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-88"></a>

### repeated.js:1:159

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-89"></a>

### repeated.js:1:165

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-90"></a>

### repeated.js:1:171

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-91"></a>

### repeated.js:1:177

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-92"></a>

### repeated.js:1:183

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-93"></a>

### repeated.js:1:189

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-94"></a>

### repeated.js:1:195

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-95"></a>

### repeated.js:1:201

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="rule-3"></a>

## TS_NODE_RSA_USAGE

RSA-related API symbols detected from JavaScript/TypeScript AST.

Check: Migrate Node.js RSA signing/verification logic to a PQC-ready design.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-96"></a>[repeated.js:1:15](#finding-96)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-96)|
|<a id="finding-97"></a>[repeated.js:1:21](#finding-97)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-97)|
|<a id="finding-98"></a>[repeated.js:1:27](#finding-98)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-98)|
|<a id="finding-99"></a>[repeated.js:1:33](#finding-99)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-99)|
|<a id="finding-100"></a>[repeated.js:1:39](#finding-100)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-100)|
|<a id="finding-101"></a>[repeated.js:1:45](#finding-101)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-101)|
|<a id="finding-102"></a>[repeated.js:1:51](#finding-102)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-102)|
|<a id="finding-103"></a>[repeated.js:1:57](#finding-103)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-103)|
|<a id="finding-104"></a>[repeated.js:1:63](#finding-104)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-104)|
|<a id="finding-105"></a>[repeated.js:1:69](#finding-105)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-105)|
|<a id="finding-106"></a>[repeated.js:1:75](#finding-106)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-106)|
|<a id="finding-107"></a>[repeated.js:1:81](#finding-107)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-107)|
|<a id="finding-108"></a>[repeated.js:1:87](#finding-108)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-108)|
|<a id="finding-109"></a>[repeated.js:1:93](#finding-109)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-109)|
|<a id="finding-110"></a>[repeated.js:1:99](#finding-110)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-110)|
|<a id="finding-111"></a>[repeated.js:1:105](#finding-111)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-111)|
|<a id="finding-112"></a>[repeated.js:1:111](#finding-112)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-112)|
|<a id="finding-113"></a>[repeated.js:1:117](#finding-113)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-113)|
|<a id="finding-114"></a>[repeated.js:1:123](#finding-114)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-114)|
|<a id="finding-115"></a>[repeated.js:1:129](#finding-115)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-115)|
|<a id="finding-116"></a>[repeated.js:1:135](#finding-116)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-116)|
|<a id="finding-117"></a>[repeated.js:1:141](#finding-117)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-117)|
|<a id="finding-118"></a>[repeated.js:1:147](#finding-118)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-118)|
|<a id="finding-119"></a>[repeated.js:1:153](#finding-119)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-119)|
|<a id="finding-120"></a>[repeated.js:1:159](#finding-120)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-120)|
|<a id="finding-121"></a>[repeated.js:1:165](#finding-121)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-121)|
|<a id="finding-122"></a>[repeated.js:1:171](#finding-122)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-122)|
|<a id="finding-123"></a>[repeated.js:1:177](#finding-123)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-123)|
|<a id="finding-124"></a>[repeated.js:1:183](#finding-124)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-124)|
|<a id="finding-125"></a>[repeated.js:1:189](#finding-125)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-125)|
|<a id="finding-126"></a>[repeated.js:1:195](#finding-126)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-126)|
|<a id="finding-127"></a>[repeated.js:1:201](#finding-127)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-127)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Introduce crypto abstraction boundary for algorithm agility](#action-4)
- [Verify deployed runtime and protocol PQC capabilities](#action-3)

<a id="source-96"></a>

### repeated.js:1:15

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-97"></a>

### repeated.js:1:21

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-98"></a>

### repeated.js:1:27

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-99"></a>

### repeated.js:1:33

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-100"></a>

### repeated.js:1:39

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-101"></a>

### repeated.js:1:45

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-102"></a>

### repeated.js:1:51

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-103"></a>

### repeated.js:1:57

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-104"></a>

### repeated.js:1:63

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-105"></a>

### repeated.js:1:69

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-106"></a>

### repeated.js:1:75

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-107"></a>

### repeated.js:1:81

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-108"></a>

### repeated.js:1:87

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-109"></a>

### repeated.js:1:93

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-110"></a>

### repeated.js:1:99

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-111"></a>

### repeated.js:1:105

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-112"></a>

### repeated.js:1:111

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-113"></a>

### repeated.js:1:117

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-114"></a>

### repeated.js:1:123

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-115"></a>

### repeated.js:1:129

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-116"></a>

### repeated.js:1:135

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-117"></a>

### repeated.js:1:141

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-118"></a>

### repeated.js:1:147

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-119"></a>

### repeated.js:1:153

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-120"></a>

### repeated.js:1:159

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-121"></a>

### repeated.js:1:165

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-122"></a>

### repeated.js:1:171

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-123"></a>

### repeated.js:1:177

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-124"></a>

### repeated.js:1:183

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-125"></a>

### repeated.js:1:189

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-126"></a>

### repeated.js:1:195

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

<a id="source-127"></a>

### repeated.js:1:201

    > 1 const data = "RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS256 RS25...

## Action details

Each location links only to its applicable action. Identical payloads are printed once.

<a id="action-0"></a>


#### Adopt a phased hybrid PQC migration plan (near-term)

The detected primitive is vulnerable to cryptographically relevant quantum attacks. Hybrid rollout minimizes compatibility risk.

1. Inventory all call sites using this algorithm and owner teams.
2. Introduce dual-stack or hybrid mode (classical + PQC) before hard cut-over.
3. Define retirement dates for legacy classical algorithms.

References:

- https://www.nist.gov/itl/post-quantum-cryptography
- https://csrc.nist.gov/pubs/fips/203/final
- https://csrc.nist.gov/pubs/fips/204/final
<a id="action-1"></a>


#### Stop issuing new JWTs with RSA/PKCS#1/ECDSA-only algorithms (near-term)

JWT signatures using classical public-key algorithms become long-term high risk under quantum adversaries.

1. Restrict accepted alg values and explicitly deny weak/legacy defaults.
2. Introduce short-lived tokens during the migration phase.
3. Prepare verifier rollout before signer rollout to avoid compatibility outages.
4. Confirm JOSE algorithm identifiers, key encoding, JWT library support and all verifiers before changing token signatures; primitive support alone is insufficient.

References:

- https://www.rfc-editor.org/rfc/rfc7519
<a id="action-2"></a>


#### Upgrade Node.js runtime for built-in WebCrypto PQC support (planned)

Node.js runtime level determines whether built-in PQC APIs are available for direct migration.

1. Node crypto: ML-DSA 24.6+, ML-KEM 24.7+, SLH-DSA 24.8+; WebCrypto ML-DSA/ML-KEM 24.7+. Check exact runtime and algorithm support.
2. Distinguish Node.js from browser execution; TypeScript types do not establish runtime capabilities. ML-KEM key exchange does not replace JWT signatures.

References:

- https://nodejs.org/api/webcrypto.html

Before (javascript)

    import jwt from "jsonwebtoken";
    const token = jwt.sign(payload, privateKey, { algorithm: "RS256" });

After

    // Replace RS256 token-signing path with a PQC-capable signing service
    // or WebCrypto ML-DSA workflow once runtime support is enabled.
    const token = await signWithPqc(payload);

<a id="action-3"></a>


#### Verify deployed runtime and protocol PQC capabilities (planned)

Source declarations and primitive availability do not establish deployment or peer support.

1. Node crypto ML-DSA requires 24.6+, ML-KEM 24.7+, SLH-DSA 24.8+; WebCrypto ML-DSA/ML-KEM requires 24.7+. Verify browser support independently of TypeScript declarations.
2. Check resolved versions, provider/features and interoperability before changing production policy.

References:

- https://nodejs.org/api/webcrypto.html
<a id="action-4"></a>


#### Introduce crypto abstraction boundary for algorithm agility (near-term)

Direct algorithm calls create high migration cost. A boundary layer enables staged classical-to-PQC transitions.

1. Wrap signing, verification, keygen, and key exchange behind stable interfaces.
2. Add policy controls to select classical, hybrid, or PQC paths at runtime.

References:

- https://www.nist.gov/itl/post-quantum-cryptography

## Inventory exports

- [CBOM](cbom.json): 4
- [Dependency SBOM](dependency-sbom.json): 0


## Inspection coverage

Completeness covers supported inspection within the declared scope, after ignore settings, exclusions and size limits. It does not prove runtime use, certificate trust or security. Unenumerated files remain unknown.

|Item|Value|
|---|---|
|Status|Some inspection could not complete (partial)|
|Selected files|1|
|Read successfully|1|
|Read failed|0|
|Analyzed|0|
|Partial|1|
|Analysis failed|0|
|Unsupported|0|
|Not applicable|0|
|Unknown|0|
|Enumerated exclusions|0|
|Enumeration failures|0|
|Unenumerated population|Unknown|

## Inspection diagnostics

Safe reason codes, paths and detector names; file contents and arbitrary error messages are omitted.

|Item|Value|
|---|---|
|Inspection limit reached (detector_truncated)|repeated.js / regex_detector|
|Inspection limit reached (detector_truncated)|repeated.js / tree_sitter_detector|
