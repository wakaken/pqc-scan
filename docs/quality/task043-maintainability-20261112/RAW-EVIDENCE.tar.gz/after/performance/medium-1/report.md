# PQC Migration Scan Report

Generated: 2026-11-12 03:10:32.766510 UTC

Risk candidates: 160 / Inventory findings: 176 / Scanned files: 328

Static evidence does not prove runtime use or completed PQC migration.

|Severity|Count (all findings)|
|---|---:|
|critical|32|
|high|24|
|info|176|
|low|32|
|medium|72|

## Risk candidate index

|Rule / description|Severity|Risk|Hits|Files|
|---|---|---|---:|---:|
|[CERT_RSA_1024](#rule-0) Certificate subject public key is 1024-bit RSA.|critical|non-quantum-risk|8|8|
|[CERT_RSA_SIGNATURE](#rule-1) Certificate signed with an RSA-based algorithm detected.|critical|quantum-vulnerable|16|16|
|[PRIVATE_KEY_PKCS8_HEADER](#rule-2) PKCS#8 private key header detected.|critical|non-quantum-risk|8|8|
|[API_SIGNATURE_RSA](#rule-3) RSA signature API usage detected.|high|quantum-vulnerable|8|8|
|[CERT_ECDSA_SIGNATURE](#rule-4) ECDSA certificate signature detected.|high|quantum-vulnerable|8|8|
|[TS_JAVA_RSA_API](#rule-5) RSA-related API symbols detected from Java AST.|high|quantum-vulnerable|8|8|
|[CERT_P12_CONTAINER](#rule-6) PKCS#12/PFX container file detected.|medium|quantum-uncertain|8|8|
|[DEP_OPENSSL](#rule-7) OpenSSL dependency detected.|medium|quantum-uncertain|8|8|
|[DEP_RUST_OPENSSL](#rule-8) Rust TLS/crypto dependency detected.|medium|quantum-uncertain|16|16|
|[PQC_DRAFT_ALGORITHM](#rule-9) Pre-standard PQC algorithm name referenced; check compatibility before replacing it.|medium|quantum-uncertain|8|8|
|[PQC_GO_TLS_DISABLED](#rule-10) Go hybrid TLS default explicitly disabled; inspect effective environment and group overrides.|medium|quantum-uncertain|8|8|
|[PQC_JAVA_CLASSICAL_GROUPS](#rule-11) Explicit classical-only Java property intent in assignment, XML entry or static System.setProperty; ...|medium|quantum-uncertain|16|16|
|[PQC_RUBY_CLASSICAL_GROUPS](#rule-12) Ruby-style group assignment explicitly restricts the recognized list to classical groups.|medium|quantum-uncertain|8|8|
|[CERT_PEM_CONTAINER](#rule-13) Certificate container file detected.|low|quantum-uncertain|32|32|

## Informational inventory index

|Rule / description|Severity|Risk|Hits|Files|
|---|---|---|---:|---:|
|[DEP_PQC_CAPABLE_LIBRARY](#rule-14) Library with version-dependent PQC capabilities inventoried; capability is not an enabled-state find...|info|quantum-uncertain|24|24|
|[PQC_GO_API](#rule-15) Standard Go PQC package imported; import alone does not prove negotiated protection.|info|quantum-safe|8|8|
|[PQC_JAVA_API](#rule-16) Standard PQC algorithm requested through Java APIs; runtime success is not established.|info|quantum-safe|24|24|
|[PQC_NODE_API](#rule-17) Node-style PQC key generation call; bindings and actual execution require confirmation.|info|quantum-safe|40|32|
|[PQC_PYTHON_API](#rule-18) Python PQC key generation reference; backend support is not established.|info|quantum-safe|40|32|
|[PQC_RUBY_API](#rule-19) Ruby PQC algorithm literal referenced; key generation or signing success is not established.|info|quantum-safe|16|16|
|[PQC_RUST_API](#rule-20) Rust PQC crate symbol referenced; execution and protocol use require confirmation.|info|quantum-safe|8|8|
|[PQC_WEBCRYPTO_API](#rule-21) WebCrypto-style PQC algorithm request; this is not proof of browser support.|info|quantum-safe|16|16|

<a id="rule-0"></a>

## CERT_RSA_1024

Certificate subject public key is 1024-bit RSA.

Check: Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-0"></a>[copy-000/tuning/rsa1024.der:1:1](#finding-0)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-1"></a>[copy-001/tuning/rsa1024.der:1:1](#finding-1)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-2"></a>[copy-002/tuning/rsa1024.der:1:1](#finding-2)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-3"></a>[copy-003/tuning/rsa1024.der:1:1](#finding-3)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-4"></a>[copy-004/tuning/rsa1024.der:1:1](#finding-4)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-5"></a>[copy-005/tuning/rsa1024.der:1:1](#finding-5)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-6"></a>[copy-006/tuning/rsa1024.der:1:1](#finding-6)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-7"></a>[copy-007/tuning/rsa1024.der:1:1](#finding-7)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Prepare hybrid certificate issuance and trust-store rollout](#action-0)

<a id="rule-1"></a>

## CERT_RSA_SIGNATURE

Certificate signed with an RSA-based algorithm detected.

Check: Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-8"></a>[copy-000/tuning/p256-rsa-signed.der:1:1](#finding-8)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-9"></a>[copy-000/tuning/rsa1024.der:1:1](#finding-9)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-10"></a>[copy-001/tuning/p256-rsa-signed.der:1:1](#finding-10)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-11"></a>[copy-001/tuning/rsa1024.der:1:1](#finding-11)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-12"></a>[copy-002/tuning/p256-rsa-signed.der:1:1](#finding-12)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-13"></a>[copy-002/tuning/rsa1024.der:1:1](#finding-13)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-14"></a>[copy-003/tuning/p256-rsa-signed.der:1:1](#finding-14)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-15"></a>[copy-003/tuning/rsa1024.der:1:1](#finding-15)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-16"></a>[copy-004/tuning/p256-rsa-signed.der:1:1](#finding-16)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-17"></a>[copy-004/tuning/rsa1024.der:1:1](#finding-17)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-18"></a>[copy-005/tuning/p256-rsa-signed.der:1:1](#finding-18)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-19"></a>[copy-005/tuning/rsa1024.der:1:1](#finding-19)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-20"></a>[copy-006/tuning/p256-rsa-signed.der:1:1](#finding-20)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-21"></a>[copy-006/tuning/rsa1024.der:1:1](#finding-21)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-22"></a>[copy-007/tuning/p256-rsa-signed.der:1:1](#finding-22)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-23"></a>[copy-007/tuning/rsa1024.der:1:1](#finding-23)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-1)
- [Prepare hybrid certificate issuance and trust-store rollout](#action-0)

<a id="rule-2"></a>

## PRIVATE_KEY_PKCS8_HEADER

PKCS#8 private key header detected.

Check: Investigate private-key exposure and rotate credentials.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-24"></a>[copy-000/tuning/marker.pem:1:1](#finding-24)|\[masked-private-key\]|Investigate private-key exposure and rotate credentials. / [Source](#source-24)|
|<a id="finding-25"></a>[copy-001/tuning/marker.pem:1:1](#finding-25)|\[masked-private-key\]|Investigate private-key exposure and rotate credentials. / [Source](#source-25)|
|<a id="finding-26"></a>[copy-002/tuning/marker.pem:1:1](#finding-26)|\[masked-private-key\]|Investigate private-key exposure and rotate credentials. / [Source](#source-26)|
|<a id="finding-27"></a>[copy-003/tuning/marker.pem:1:1](#finding-27)|\[masked-private-key\]|Investigate private-key exposure and rotate credentials. / [Source](#source-27)|
|<a id="finding-28"></a>[copy-004/tuning/marker.pem:1:1](#finding-28)|\[masked-private-key\]|Investigate private-key exposure and rotate credentials. / [Source](#source-28)|
|<a id="finding-29"></a>[copy-005/tuning/marker.pem:1:1](#finding-29)|\[masked-private-key\]|Investigate private-key exposure and rotate credentials. / [Source](#source-29)|
|<a id="finding-30"></a>[copy-006/tuning/marker.pem:1:1](#finding-30)|\[masked-private-key\]|Investigate private-key exposure and rotate credentials. / [Source](#source-30)|
|<a id="finding-31"></a>[copy-007/tuning/marker.pem:1:1](#finding-31)|\[masked-private-key\]|Investigate private-key exposure and rotate credentials. / [Source](#source-31)|

Shared checks for these locations (not verified facts about each line):

- [Rotate exposed private keys and revoke affected credentials](#action-2)

<a id="source-24"></a>

### copy-000/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-25"></a>

### copy-001/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-26"></a>

### copy-002/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-27"></a>

### copy-003/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-28"></a>

### copy-004/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-29"></a>

### copy-005/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-30"></a>

### copy-006/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-31"></a>

### copy-007/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="rule-3"></a>

## API_SIGNATURE_RSA

RSA signature API usage detected.

Check: Migrate to ML-DSA signing APIs.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-32"></a>[copy-000/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-32)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-32)|
|<a id="finding-33"></a>[copy-001/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-33)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-33)|
|<a id="finding-34"></a>[copy-002/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-34)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-34)|
|<a id="finding-35"></a>[copy-003/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-35)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-35)|
|<a id="finding-36"></a>[copy-004/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-36)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-36)|
|<a id="finding-37"></a>[copy-005/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-37)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-37)|
|<a id="finding-38"></a>[copy-006/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-38)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-38)|
|<a id="finding-39"></a>[copy-007/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-39)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-39)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-1)
- [Upgrade Java runtime baseline for standard PQC APIs](#action-3)
- [Provide BouncyCastle PQC fallback path](#action-4)
- [Verify deployed runtime and protocol PQC capabilities](#action-5)

<a id="source-32"></a>

### copy-000/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-33"></a>

### copy-001/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-34"></a>

### copy-002/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-35"></a>

### copy-003/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-36"></a>

### copy-004/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-37"></a>

### copy-005/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-38"></a>

### copy-006/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-39"></a>

### copy-007/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="rule-4"></a>

## CERT_ECDSA_SIGNATURE

ECDSA certificate signature detected.

Check: Evaluate ML-DSA and SLH-DSA alternatives.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-40"></a>[copy-000/tuning/p521.der:1:1](#finding-40)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-41"></a>[copy-001/tuning/p521.der:1:1](#finding-41)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-42"></a>[copy-002/tuning/p521.der:1:1](#finding-42)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-43"></a>[copy-003/tuning/p521.der:1:1](#finding-43)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-44"></a>[copy-004/tuning/p521.der:1:1](#finding-44)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-45"></a>[copy-005/tuning/p521.der:1:1](#finding-45)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-46"></a>[copy-006/tuning/p521.der:1:1](#finding-46)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-47"></a>[copy-007/tuning/p521.der:1:1](#finding-47)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-1)
- [Prepare hybrid certificate issuance and trust-store rollout](#action-0)

<a id="rule-5"></a>

## TS_JAVA_RSA_API

RSA-related API symbols detected from Java AST.

Check: Replace Java RSA API usage with PQC-capable libraries.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-48"></a>[copy-000/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-48)|Signatur***ithRSA|Replace Java RSA API usage with PQC-capable libraries. / [Source](#source-48)|
|<a id="finding-49"></a>[copy-001/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-49)|Signatur***ithRSA|Replace Java RSA API usage with PQC-capable libraries. / [Source](#source-49)|
|<a id="finding-50"></a>[copy-002/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-50)|Signatur***ithRSA|Replace Java RSA API usage with PQC-capable libraries. / [Source](#source-50)|
|<a id="finding-51"></a>[copy-003/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-51)|Signatur***ithRSA|Replace Java RSA API usage with PQC-capable libraries. / [Source](#source-51)|
|<a id="finding-52"></a>[copy-004/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-52)|Signatur***ithRSA|Replace Java RSA API usage with PQC-capable libraries. / [Source](#source-52)|
|<a id="finding-53"></a>[copy-005/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-53)|Signatur***ithRSA|Replace Java RSA API usage with PQC-capable libraries. / [Source](#source-53)|
|<a id="finding-54"></a>[copy-006/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-54)|Signatur***ithRSA|Replace Java RSA API usage with PQC-capable libraries. / [Source](#source-54)|
|<a id="finding-55"></a>[copy-007/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-55)|Signatur***ithRSA|Replace Java RSA API usage with PQC-capable libraries. / [Source](#source-55)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-1)
- [Upgrade Java runtime baseline for standard PQC APIs](#action-3)
- [Provide BouncyCastle PQC fallback path](#action-4)
- [Verify deployed runtime and protocol PQC capabilities](#action-5)

<a id="source-48"></a>

### copy-000/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-49"></a>

### copy-001/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-50"></a>

### copy-002/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-51"></a>

### copy-003/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-52"></a>

### copy-004/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-53"></a>

### copy-005/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-54"></a>

### copy-006/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-55"></a>

### copy-007/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="rule-6"></a>

## CERT_P12_CONTAINER

PKCS#12/PFX container file detected.

Check: Audit algorithms used inside PKCS#12/PFX containers.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-56"></a>[copy-000/holdout/unsupported.p12:1:1](#finding-56)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-57"></a>[copy-001/holdout/unsupported.p12:1:1](#finding-57)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-58"></a>[copy-002/holdout/unsupported.p12:1:1](#finding-58)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-59"></a>[copy-003/holdout/unsupported.p12:1:1](#finding-59)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-60"></a>[copy-004/holdout/unsupported.p12:1:1](#finding-60)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-61"></a>[copy-005/holdout/unsupported.p12:1:1](#finding-61)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-62"></a>[copy-006/holdout/unsupported.p12:1:1](#finding-62)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-63"></a>[copy-007/holdout/unsupported.p12:1:1](#finding-63)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Prepare hybrid certificate issuance and trust-store rollout](#action-0)

<a id="rule-7"></a>

## DEP_OPENSSL

OpenSSL dependency detected.

Check: Review the OpenSSL PQC roadmap.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-64"></a>[copy-000/holdout/sbom.json (line unavailable)](#finding-64)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-64)|
|<a id="finding-65"></a>[copy-001/holdout/sbom.json (line unavailable)](#finding-65)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-65)|
|<a id="finding-66"></a>[copy-002/holdout/sbom.json (line unavailable)](#finding-66)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-66)|
|<a id="finding-67"></a>[copy-003/holdout/sbom.json (line unavailable)](#finding-67)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-67)|
|<a id="finding-68"></a>[copy-004/holdout/sbom.json (line unavailable)](#finding-68)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-68)|
|<a id="finding-69"></a>[copy-005/holdout/sbom.json (line unavailable)](#finding-69)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-69)|
|<a id="finding-70"></a>[copy-006/holdout/sbom.json (line unavailable)](#finding-70)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-70)|
|<a id="finding-71"></a>[copy-007/holdout/sbom.json (line unavailable)](#finding-71)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-71)|

Shared checks for these locations (not verified facts about each line):

- [Prefer TLS 1.3 and review legacy key exchange](#action-6)
- [Track PQC readiness of dependent libraries](#action-7)

<a id="source-64"></a>

### copy-000/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-65"></a>

### copy-001/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-66"></a>

### copy-002/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-67"></a>

### copy-003/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-68"></a>

### copy-004/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-69"></a>

### copy-005/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-70"></a>

### copy-006/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-71"></a>

### copy-007/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="rule-8"></a>

## DEP_RUST_OPENSSL

Rust TLS/crypto dependency detected.

Check: Track PQC migration options for Rust openssl/rustls crypto stacks.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-72"></a>[copy-000/holdout/sbom.json (line unavailable)](#finding-72)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-72)|
|<a id="finding-73"></a>[copy-000/tuning/Cargo.toml:3:1](#finding-73)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-73)|
|<a id="finding-74"></a>[copy-001/holdout/sbom.json (line unavailable)](#finding-74)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-74)|
|<a id="finding-75"></a>[copy-001/tuning/Cargo.toml:3:1](#finding-75)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-75)|
|<a id="finding-76"></a>[copy-002/holdout/sbom.json (line unavailable)](#finding-76)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-76)|
|<a id="finding-77"></a>[copy-002/tuning/Cargo.toml:3:1](#finding-77)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-77)|
|<a id="finding-78"></a>[copy-003/holdout/sbom.json (line unavailable)](#finding-78)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-78)|
|<a id="finding-79"></a>[copy-003/tuning/Cargo.toml:3:1](#finding-79)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-79)|
|<a id="finding-80"></a>[copy-004/holdout/sbom.json (line unavailable)](#finding-80)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-80)|
|<a id="finding-81"></a>[copy-004/tuning/Cargo.toml:3:1](#finding-81)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-81)|
|<a id="finding-82"></a>[copy-005/holdout/sbom.json (line unavailable)](#finding-82)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-82)|
|<a id="finding-83"></a>[copy-005/tuning/Cargo.toml:3:1](#finding-83)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-83)|
|<a id="finding-84"></a>[copy-006/holdout/sbom.json (line unavailable)](#finding-84)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-84)|
|<a id="finding-85"></a>[copy-006/tuning/Cargo.toml:3:1](#finding-85)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-85)|
|<a id="finding-86"></a>[copy-007/holdout/sbom.json (line unavailable)](#finding-86)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-86)|
|<a id="finding-87"></a>[copy-007/tuning/Cargo.toml:3:1](#finding-87)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-87)|

Shared checks for these locations (not verified facts about each line):

- [Introduce crypto abstraction boundary for algorithm agility](#action-8)
- [Track PQC readiness of dependent libraries](#action-7)

<a id="source-72"></a>

### copy-000/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-73"></a>

### copy-000/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-74"></a>

### copy-001/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-75"></a>

### copy-001/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-76"></a>

### copy-002/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-77"></a>

### copy-002/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-78"></a>

### copy-003/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-79"></a>

### copy-003/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-80"></a>

### copy-004/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-81"></a>

### copy-004/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-82"></a>

### copy-005/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-83"></a>

### copy-005/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-84"></a>

### copy-006/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-85"></a>

### copy-006/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-86"></a>

### copy-007/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-87"></a>

### copy-007/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="rule-9"></a>

## PQC_DRAFT_ALGORITHM

Pre-standard PQC algorithm name referenced; check compatibility before replacing it.

Check: Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-88"></a>[copy-000/tuning/variants/draft.js:1:19](#finding-88)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-88)|
|<a id="finding-89"></a>[copy-001/tuning/variants/draft.js:1:19](#finding-89)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-89)|
|<a id="finding-90"></a>[copy-002/tuning/variants/draft.js:1:19](#finding-90)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-90)|
|<a id="finding-91"></a>[copy-003/tuning/variants/draft.js:1:19](#finding-91)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-91)|
|<a id="finding-92"></a>[copy-004/tuning/variants/draft.js:1:19](#finding-92)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-92)|
|<a id="finding-93"></a>[copy-005/tuning/variants/draft.js:1:19](#finding-93)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-93)|
|<a id="finding-94"></a>[copy-006/tuning/variants/draft.js:1:19](#finding-94)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-94)|
|<a id="finding-95"></a>[copy-007/tuning/variants/draft.js:1:19](#finding-95)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-95)|

<a id="source-88"></a>

### copy-000/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-89"></a>

### copy-001/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-90"></a>

### copy-002/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-91"></a>

### copy-003/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-92"></a>

### copy-004/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-93"></a>

### copy-005/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-94"></a>

### copy-006/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-95"></a>

### copy-007/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="rule-10"></a>

## PQC_GO_TLS_DISABLED

Go hybrid TLS default explicitly disabled; inspect effective environment and group overrides.

Check: Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-96"></a>[copy-000/tuning/overrides.conf:1:1](#finding-96)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-96)|
|<a id="finding-97"></a>[copy-001/tuning/overrides.conf:1:1](#finding-97)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-97)|
|<a id="finding-98"></a>[copy-002/tuning/overrides.conf:1:1](#finding-98)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-98)|
|<a id="finding-99"></a>[copy-003/tuning/overrides.conf:1:1](#finding-99)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-99)|
|<a id="finding-100"></a>[copy-004/tuning/overrides.conf:1:1](#finding-100)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-100)|
|<a id="finding-101"></a>[copy-005/tuning/overrides.conf:1:1](#finding-101)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-101)|
|<a id="finding-102"></a>[copy-006/tuning/overrides.conf:1:1](#finding-102)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-102)|
|<a id="finding-103"></a>[copy-007/tuning/overrides.conf:1:1](#finding-103)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-103)|

Shared checks for these locations (not verified facts about each line):

- [Review the explicit PQC override: GODEBUG=tlsmlkem=0](#action-9)

<a id="source-96"></a>

### copy-000/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-97"></a>

### copy-001/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-98"></a>

### copy-002/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-99"></a>

### copy-003/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-100"></a>

### copy-004/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-101"></a>

### copy-005/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-102"></a>

### copy-006/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-103"></a>

### copy-007/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="rule-11"></a>

## PQC_JAVA_CLASSICAL_GROUPS

Explicit classical-only Java property intent in assignment, XML entry or static System.setProperty; effective loading is not established.

Check: Review explicit group restrictions against the deployed JSSE version and peer support.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-104"></a>[copy-000/holdout/approval-adapter/archive-policy.xml:6:1](#finding-104)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-104)|
|<a id="finding-105"></a>[copy-000/tuning/overrides.conf:2:1](#finding-105)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-105)|
|<a id="finding-106"></a>[copy-001/holdout/approval-adapter/archive-policy.xml:6:1](#finding-106)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-106)|
|<a id="finding-107"></a>[copy-001/tuning/overrides.conf:2:1](#finding-107)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-107)|
|<a id="finding-108"></a>[copy-002/holdout/approval-adapter/archive-policy.xml:6:1](#finding-108)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-108)|
|<a id="finding-109"></a>[copy-002/tuning/overrides.conf:2:1](#finding-109)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-109)|
|<a id="finding-110"></a>[copy-003/holdout/approval-adapter/archive-policy.xml:6:1](#finding-110)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-110)|
|<a id="finding-111"></a>[copy-003/tuning/overrides.conf:2:1](#finding-111)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-111)|
|<a id="finding-112"></a>[copy-004/holdout/approval-adapter/archive-policy.xml:6:1](#finding-112)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-112)|
|<a id="finding-113"></a>[copy-004/tuning/overrides.conf:2:1](#finding-113)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-113)|
|<a id="finding-114"></a>[copy-005/holdout/approval-adapter/archive-policy.xml:6:1](#finding-114)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-114)|
|<a id="finding-115"></a>[copy-005/tuning/overrides.conf:2:1](#finding-115)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-115)|
|<a id="finding-116"></a>[copy-006/holdout/approval-adapter/archive-policy.xml:6:1](#finding-116)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-116)|
|<a id="finding-117"></a>[copy-006/tuning/overrides.conf:2:1](#finding-117)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-117)|
|<a id="finding-118"></a>[copy-007/holdout/approval-adapter/archive-policy.xml:6:1](#finding-118)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-118)|
|<a id="finding-119"></a>[copy-007/tuning/overrides.conf:2:1](#finding-119)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-119)|

Shared checks for these locations (not verified facts about each line):

- [Review the explicit PQC override: jdk.tls.namedGroups](#action-10)

<a id="source-104"></a>

### copy-000/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-105"></a>

### copy-000/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-106"></a>

### copy-001/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-107"></a>

### copy-001/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-108"></a>

### copy-002/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-109"></a>

### copy-002/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-110"></a>

### copy-003/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-111"></a>

### copy-003/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-112"></a>

### copy-004/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-113"></a>

### copy-004/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-114"></a>

### copy-005/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-115"></a>

### copy-005/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-116"></a>

### copy-006/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-117"></a>

### copy-006/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-118"></a>

### copy-007/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-119"></a>

### copy-007/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="rule-12"></a>

## PQC_RUBY_CLASSICAL_GROUPS

Ruby-style group assignment explicitly restricts the recognized list to classical groups.

Check: Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-120"></a>[copy-000/tuning/overrides.conf:3:1](#finding-120)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-120)|
|<a id="finding-121"></a>[copy-001/tuning/overrides.conf:3:1](#finding-121)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-121)|
|<a id="finding-122"></a>[copy-002/tuning/overrides.conf:3:1](#finding-122)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-122)|
|<a id="finding-123"></a>[copy-003/tuning/overrides.conf:3:1](#finding-123)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-123)|
|<a id="finding-124"></a>[copy-004/tuning/overrides.conf:3:1](#finding-124)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-124)|
|<a id="finding-125"></a>[copy-005/tuning/overrides.conf:3:1](#finding-125)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-125)|
|<a id="finding-126"></a>[copy-006/tuning/overrides.conf:3:1](#finding-126)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-126)|
|<a id="finding-127"></a>[copy-007/tuning/overrides.conf:3:1](#finding-127)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-127)|

Shared checks for these locations (not verified facts about each line):

- [Review the explicit PQC override: groups= / ecdh_curves=](#action-11)

<a id="source-120"></a>

### copy-000/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-121"></a>

### copy-001/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-122"></a>

### copy-002/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-123"></a>

### copy-003/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-124"></a>

### copy-004/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-125"></a>

### copy-005/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-126"></a>

### copy-006/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-127"></a>

### copy-007/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="rule-13"></a>

## CERT_PEM_CONTAINER

Certificate container file detected.

Check: Validate signing algorithms in PEM-based certificates.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-128"></a>[copy-000/holdout/ec.pem:1:1](#finding-128)|\[masked-sensitive-content\]|Validate signing algorithms in PEM-based certificates. / [Source](#source-128)|
|<a id="finding-129"></a>[copy-000/holdout/misleading-rsa1024.der:1:1](#finding-129)|misleadi***24.der|Validate signing algorithms in PEM-based certificates. / [Source](#source-129)|
|<a id="finding-130"></a>[copy-000/tuning/marker.pem:1:1](#finding-130)|\[masked-sensitive-content\]|Validate signing algorithms in PEM-based certificates. / [Source](#source-130)|
|<a id="finding-131"></a>[copy-000/tuning/public.pem:1:1](#finding-131)|public.pem|Validate signing algorithms in PEM-based certificates. / [Source](#source-131)|
|<a id="finding-132"></a>[copy-001/holdout/ec.pem:1:1](#finding-132)|\[masked-sensitive-content\]|Validate signing algorithms in PEM-based certificates. / [Source](#source-132)|
|<a id="finding-133"></a>[copy-001/holdout/misleading-rsa1024.der:1:1](#finding-133)|misleadi***24.der|Validate signing algorithms in PEM-based certificates. / [Source](#source-133)|
|<a id="finding-134"></a>[copy-001/tuning/marker.pem:1:1](#finding-134)|\[masked-sensitive-content\]|Validate signing algorithms in PEM-based certificates. / [Source](#source-134)|
|<a id="finding-135"></a>[copy-001/tuning/public.pem:1:1](#finding-135)|public.pem|Validate signing algorithms in PEM-based certificates. / [Source](#source-135)|
|<a id="finding-136"></a>[copy-002/holdout/ec.pem:1:1](#finding-136)|\[masked-sensitive-content\]|Validate signing algorithms in PEM-based certificates. / [Source](#source-136)|
|<a id="finding-137"></a>[copy-002/holdout/misleading-rsa1024.der:1:1](#finding-137)|misleadi***24.der|Validate signing algorithms in PEM-based certificates. / [Source](#source-137)|
|<a id="finding-138"></a>[copy-002/tuning/marker.pem:1:1](#finding-138)|\[masked-sensitive-content\]|Validate signing algorithms in PEM-based certificates. / [Source](#source-138)|
|<a id="finding-139"></a>[copy-002/tuning/public.pem:1:1](#finding-139)|public.pem|Validate signing algorithms in PEM-based certificates. / [Source](#source-139)|
|<a id="finding-140"></a>[copy-003/holdout/ec.pem:1:1](#finding-140)|\[masked-sensitive-content\]|Validate signing algorithms in PEM-based certificates. / [Source](#source-140)|
|<a id="finding-141"></a>[copy-003/holdout/misleading-rsa1024.der:1:1](#finding-141)|misleadi***24.der|Validate signing algorithms in PEM-based certificates. / [Source](#source-141)|
|<a id="finding-142"></a>[copy-003/tuning/marker.pem:1:1](#finding-142)|\[masked-sensitive-content\]|Validate signing algorithms in PEM-based certificates. / [Source](#source-142)|
|<a id="finding-143"></a>[copy-003/tuning/public.pem:1:1](#finding-143)|public.pem|Validate signing algorithms in PEM-based certificates. / [Source](#source-143)|
|<a id="finding-144"></a>[copy-004/holdout/ec.pem:1:1](#finding-144)|\[masked-sensitive-content\]|Validate signing algorithms in PEM-based certificates. / [Source](#source-144)|
|<a id="finding-145"></a>[copy-004/holdout/misleading-rsa1024.der:1:1](#finding-145)|misleadi***24.der|Validate signing algorithms in PEM-based certificates. / [Source](#source-145)|
|<a id="finding-146"></a>[copy-004/tuning/marker.pem:1:1](#finding-146)|\[masked-sensitive-content\]|Validate signing algorithms in PEM-based certificates. / [Source](#source-146)|
|<a id="finding-147"></a>[copy-004/tuning/public.pem:1:1](#finding-147)|public.pem|Validate signing algorithms in PEM-based certificates. / [Source](#source-147)|
|<a id="finding-148"></a>[copy-005/holdout/ec.pem:1:1](#finding-148)|\[masked-sensitive-content\]|Validate signing algorithms in PEM-based certificates. / [Source](#source-148)|
|<a id="finding-149"></a>[copy-005/holdout/misleading-rsa1024.der:1:1](#finding-149)|misleadi***24.der|Validate signing algorithms in PEM-based certificates. / [Source](#source-149)|
|<a id="finding-150"></a>[copy-005/tuning/marker.pem:1:1](#finding-150)|\[masked-sensitive-content\]|Validate signing algorithms in PEM-based certificates. / [Source](#source-150)|
|<a id="finding-151"></a>[copy-005/tuning/public.pem:1:1](#finding-151)|public.pem|Validate signing algorithms in PEM-based certificates. / [Source](#source-151)|
|<a id="finding-152"></a>[copy-006/holdout/ec.pem:1:1](#finding-152)|\[masked-sensitive-content\]|Validate signing algorithms in PEM-based certificates. / [Source](#source-152)|
|<a id="finding-153"></a>[copy-006/holdout/misleading-rsa1024.der:1:1](#finding-153)|misleadi***24.der|Validate signing algorithms in PEM-based certificates. / [Source](#source-153)|
|<a id="finding-154"></a>[copy-006/tuning/marker.pem:1:1](#finding-154)|\[masked-sensitive-content\]|Validate signing algorithms in PEM-based certificates. / [Source](#source-154)|
|<a id="finding-155"></a>[copy-006/tuning/public.pem:1:1](#finding-155)|public.pem|Validate signing algorithms in PEM-based certificates. / [Source](#source-155)|
|<a id="finding-156"></a>[copy-007/holdout/ec.pem:1:1](#finding-156)|\[masked-sensitive-content\]|Validate signing algorithms in PEM-based certificates. / [Source](#source-156)|
|<a id="finding-157"></a>[copy-007/holdout/misleading-rsa1024.der:1:1](#finding-157)|misleadi***24.der|Validate signing algorithms in PEM-based certificates. / [Source](#source-157)|
|<a id="finding-158"></a>[copy-007/tuning/marker.pem:1:1](#finding-158)|\[masked-sensitive-content\]|Validate signing algorithms in PEM-based certificates. / [Source](#source-158)|
|<a id="finding-159"></a>[copy-007/tuning/public.pem:1:1](#finding-159)|public.pem|Validate signing algorithms in PEM-based certificates. / [Source](#source-159)|

Shared checks for these locations (not verified facts about each line):

- [Prepare hybrid certificate issuance and trust-store rollout](#action-0)

<a id="source-128"></a>

### copy-000/holdout/ec.pem:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-129"></a>

### copy-000/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-130"></a>

### copy-000/tuning/marker.pem:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-131"></a>

### copy-000/tuning/public.pem:1:1

    > 1 -----BEGIN PUBLIC KEY-----
      2 synthetic public placeholder
      3 -----END PUBLIC KEY-----

<a id="source-132"></a>

### copy-001/holdout/ec.pem:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-133"></a>

### copy-001/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-134"></a>

### copy-001/tuning/marker.pem:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-135"></a>

### copy-001/tuning/public.pem:1:1

    > 1 -----BEGIN PUBLIC KEY-----
      2 synthetic public placeholder
      3 -----END PUBLIC KEY-----

<a id="source-136"></a>

### copy-002/holdout/ec.pem:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-137"></a>

### copy-002/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-138"></a>

### copy-002/tuning/marker.pem:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-139"></a>

### copy-002/tuning/public.pem:1:1

    > 1 -----BEGIN PUBLIC KEY-----
      2 synthetic public placeholder
      3 -----END PUBLIC KEY-----

<a id="source-140"></a>

### copy-003/holdout/ec.pem:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-141"></a>

### copy-003/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-142"></a>

### copy-003/tuning/marker.pem:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-143"></a>

### copy-003/tuning/public.pem:1:1

    > 1 -----BEGIN PUBLIC KEY-----
      2 synthetic public placeholder
      3 -----END PUBLIC KEY-----

<a id="source-144"></a>

### copy-004/holdout/ec.pem:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-145"></a>

### copy-004/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-146"></a>

### copy-004/tuning/marker.pem:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-147"></a>

### copy-004/tuning/public.pem:1:1

    > 1 -----BEGIN PUBLIC KEY-----
      2 synthetic public placeholder
      3 -----END PUBLIC KEY-----

<a id="source-148"></a>

### copy-005/holdout/ec.pem:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-149"></a>

### copy-005/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-150"></a>

### copy-005/tuning/marker.pem:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-151"></a>

### copy-005/tuning/public.pem:1:1

    > 1 -----BEGIN PUBLIC KEY-----
      2 synthetic public placeholder
      3 -----END PUBLIC KEY-----

<a id="source-152"></a>

### copy-006/holdout/ec.pem:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-153"></a>

### copy-006/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-154"></a>

### copy-006/tuning/marker.pem:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-155"></a>

### copy-006/tuning/public.pem:1:1

    > 1 -----BEGIN PUBLIC KEY-----
      2 synthetic public placeholder
      3 -----END PUBLIC KEY-----

<a id="source-156"></a>

### copy-007/holdout/ec.pem:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-157"></a>

### copy-007/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-158"></a>

### copy-007/tuning/marker.pem:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-159"></a>

### copy-007/tuning/public.pem:1:1

    > 1 -----BEGIN PUBLIC KEY-----
      2 synthetic public placeholder
      3 -----END PUBLIC KEY-----

<a id="rule-14"></a>

## DEP_PQC_CAPABLE_LIBRARY

Library with version-dependent PQC capabilities inventoried; capability is not an enabled-state finding.

Check: Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-160"></a>[copy-000/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-160)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-160)|
|<a id="finding-161"></a>[copy-000/holdout/sbom.json (line unavailable)](#finding-161)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-161)|
|<a id="finding-162"></a>[copy-000/tuning/Cargo.toml:2:1](#finding-162)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-162)|
|<a id="finding-163"></a>[copy-001/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-163)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-163)|
|<a id="finding-164"></a>[copy-001/holdout/sbom.json (line unavailable)](#finding-164)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-164)|
|<a id="finding-165"></a>[copy-001/tuning/Cargo.toml:2:1](#finding-165)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-165)|
|<a id="finding-166"></a>[copy-002/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-166)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-166)|
|<a id="finding-167"></a>[copy-002/holdout/sbom.json (line unavailable)](#finding-167)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-167)|
|<a id="finding-168"></a>[copy-002/tuning/Cargo.toml:2:1](#finding-168)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-168)|
|<a id="finding-169"></a>[copy-003/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-169)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-169)|
|<a id="finding-170"></a>[copy-003/holdout/sbom.json (line unavailable)](#finding-170)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-170)|
|<a id="finding-171"></a>[copy-003/tuning/Cargo.toml:2:1](#finding-171)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-171)|
|<a id="finding-172"></a>[copy-004/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-172)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-172)|
|<a id="finding-173"></a>[copy-004/holdout/sbom.json (line unavailable)](#finding-173)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-173)|
|<a id="finding-174"></a>[copy-004/tuning/Cargo.toml:2:1](#finding-174)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-174)|
|<a id="finding-175"></a>[copy-005/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-175)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-175)|
|<a id="finding-176"></a>[copy-005/holdout/sbom.json (line unavailable)](#finding-176)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-176)|
|<a id="finding-177"></a>[copy-005/tuning/Cargo.toml:2:1](#finding-177)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-177)|
|<a id="finding-178"></a>[copy-006/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-178)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-178)|
|<a id="finding-179"></a>[copy-006/holdout/sbom.json (line unavailable)](#finding-179)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-179)|
|<a id="finding-180"></a>[copy-006/tuning/Cargo.toml:2:1](#finding-180)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-180)|
|<a id="finding-181"></a>[copy-007/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-181)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-181)|
|<a id="finding-182"></a>[copy-007/holdout/sbom.json (line unavailable)](#finding-182)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-182)|
|<a id="finding-183"></a>[copy-007/tuning/Cargo.toml:2:1](#finding-183)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-183)|

Shared checks for these locations (not verified facts about each line):

- [Track PQC readiness of dependent libraries](#action-7)

<a id="source-160"></a>

### copy-000/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-161"></a>

### copy-000/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-162"></a>

### copy-000/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-163"></a>

### copy-001/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-164"></a>

### copy-001/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-165"></a>

### copy-001/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-166"></a>

### copy-002/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-167"></a>

### copy-002/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-168"></a>

### copy-002/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-169"></a>

### copy-003/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-170"></a>

### copy-003/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-171"></a>

### copy-003/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-172"></a>

### copy-004/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-173"></a>

### copy-004/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-174"></a>

### copy-004/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-175"></a>

### copy-005/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-176"></a>

### copy-005/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-177"></a>

### copy-005/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-178"></a>

### copy-006/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-179"></a>

### copy-006/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-180"></a>

### copy-006/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-181"></a>

### copy-007/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-182"></a>

### copy-007/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-183"></a>

### copy-007/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="rule-15"></a>

## PQC_GO_API

Standard Go PQC package imported; import alone does not prove negotiated protection.

Check: crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-184"></a>[copy-000/tuning/example.go:3:8](#finding-184)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-184)|
|<a id="finding-185"></a>[copy-001/tuning/example.go:3:8](#finding-185)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-185)|
|<a id="finding-186"></a>[copy-002/tuning/example.go:3:8](#finding-186)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-186)|
|<a id="finding-187"></a>[copy-003/tuning/example.go:3:8](#finding-187)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-187)|
|<a id="finding-188"></a>[copy-004/tuning/example.go:3:8](#finding-188)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-188)|
|<a id="finding-189"></a>[copy-005/tuning/example.go:3:8](#finding-189)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-189)|
|<a id="finding-190"></a>[copy-006/tuning/example.go:3:8](#finding-190)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-190)|
|<a id="finding-191"></a>[copy-007/tuning/example.go:3:8](#finding-191)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-191)|

<a id="source-184"></a>

### copy-000/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-185"></a>

### copy-001/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-186"></a>

### copy-002/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-187"></a>

### copy-003/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-188"></a>

### copy-004/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-189"></a>

### copy-005/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-190"></a>

### copy-006/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-191"></a>

### copy-007/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="rule-16"></a>

## PQC_JAVA_API

Standard PQC algorithm requested through Java APIs; runtime success is not established.

Check: JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-192"></a>[copy-000/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-192)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-192)|
|<a id="finding-193"></a>[copy-000/tuning/Example.java:3:9](#finding-193)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-193)|
|<a id="finding-194"></a>[copy-000/tuning/variants/dead.java:1:55](#finding-194)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-194)|
|<a id="finding-195"></a>[copy-001/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-195)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-195)|
|<a id="finding-196"></a>[copy-001/tuning/Example.java:3:9](#finding-196)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-196)|
|<a id="finding-197"></a>[copy-001/tuning/variants/dead.java:1:55](#finding-197)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-197)|
|<a id="finding-198"></a>[copy-002/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-198)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-198)|
|<a id="finding-199"></a>[copy-002/tuning/Example.java:3:9](#finding-199)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-199)|
|<a id="finding-200"></a>[copy-002/tuning/variants/dead.java:1:55](#finding-200)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-200)|
|<a id="finding-201"></a>[copy-003/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-201)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-201)|
|<a id="finding-202"></a>[copy-003/tuning/Example.java:3:9](#finding-202)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-202)|
|<a id="finding-203"></a>[copy-003/tuning/variants/dead.java:1:55](#finding-203)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-203)|
|<a id="finding-204"></a>[copy-004/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-204)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-204)|
|<a id="finding-205"></a>[copy-004/tuning/Example.java:3:9](#finding-205)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-205)|
|<a id="finding-206"></a>[copy-004/tuning/variants/dead.java:1:55](#finding-206)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-206)|
|<a id="finding-207"></a>[copy-005/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-207)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-207)|
|<a id="finding-208"></a>[copy-005/tuning/Example.java:3:9](#finding-208)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-208)|
|<a id="finding-209"></a>[copy-005/tuning/variants/dead.java:1:55](#finding-209)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-209)|
|<a id="finding-210"></a>[copy-006/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-210)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-210)|
|<a id="finding-211"></a>[copy-006/tuning/Example.java:3:9](#finding-211)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-211)|
|<a id="finding-212"></a>[copy-006/tuning/variants/dead.java:1:55](#finding-212)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-212)|
|<a id="finding-213"></a>[copy-007/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-213)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-213)|
|<a id="finding-214"></a>[copy-007/tuning/Example.java:3:9](#finding-214)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-214)|
|<a id="finding-215"></a>[copy-007/tuning/variants/dead.java:1:55](#finding-215)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-215)|

<a id="source-192"></a>

### copy-000/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-193"></a>

### copy-000/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-194"></a>

### copy-000/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-195"></a>

### copy-001/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-196"></a>

### copy-001/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-197"></a>

### copy-001/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-198"></a>

### copy-002/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-199"></a>

### copy-002/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-200"></a>

### copy-002/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-201"></a>

### copy-003/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-202"></a>

### copy-003/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-203"></a>

### copy-003/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-204"></a>

### copy-004/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-205"></a>

### copy-004/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-206"></a>

### copy-004/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-207"></a>

### copy-005/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-208"></a>

### copy-005/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-209"></a>

### copy-005/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-210"></a>

### copy-006/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-211"></a>

### copy-006/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-212"></a>

### copy-006/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-213"></a>

### copy-007/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-214"></a>

### copy-007/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-215"></a>

### copy-007/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="rule-17"></a>

## PQC_NODE_API

Node-style PQC key generation call; bindings and actual execution require confirmation.

Check: Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-216"></a>[copy-000/holdout/approval-adapter/rotation_queue.js:6:3](#finding-216)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-216)|
|<a id="finding-217"></a>[copy-000/tuning/example.js:1:1](#finding-217)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-217)|
|<a id="finding-218"></a>[copy-000/tuning/variants/alias.js:2:1](#finding-218)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-218)|
|<a id="finding-219"></a>[copy-000/tuning/variants/twice.js:1:1](#finding-219)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-219)|
|<a id="finding-220"></a>[copy-000/tuning/variants/twice.js:1:36](#finding-220)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-220)|
|<a id="finding-221"></a>[copy-001/holdout/approval-adapter/rotation_queue.js:6:3](#finding-221)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-221)|
|<a id="finding-222"></a>[copy-001/tuning/example.js:1:1](#finding-222)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-222)|
|<a id="finding-223"></a>[copy-001/tuning/variants/alias.js:2:1](#finding-223)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-223)|
|<a id="finding-224"></a>[copy-001/tuning/variants/twice.js:1:1](#finding-224)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-224)|
|<a id="finding-225"></a>[copy-001/tuning/variants/twice.js:1:36](#finding-225)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-225)|
|<a id="finding-226"></a>[copy-002/holdout/approval-adapter/rotation_queue.js:6:3](#finding-226)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-226)|
|<a id="finding-227"></a>[copy-002/tuning/example.js:1:1](#finding-227)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-227)|
|<a id="finding-228"></a>[copy-002/tuning/variants/alias.js:2:1](#finding-228)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-228)|
|<a id="finding-229"></a>[copy-002/tuning/variants/twice.js:1:1](#finding-229)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-229)|
|<a id="finding-230"></a>[copy-002/tuning/variants/twice.js:1:36](#finding-230)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-230)|
|<a id="finding-231"></a>[copy-003/holdout/approval-adapter/rotation_queue.js:6:3](#finding-231)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-231)|
|<a id="finding-232"></a>[copy-003/tuning/example.js:1:1](#finding-232)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-232)|
|<a id="finding-233"></a>[copy-003/tuning/variants/alias.js:2:1](#finding-233)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-233)|
|<a id="finding-234"></a>[copy-003/tuning/variants/twice.js:1:1](#finding-234)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-234)|
|<a id="finding-235"></a>[copy-003/tuning/variants/twice.js:1:36](#finding-235)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-235)|
|<a id="finding-236"></a>[copy-004/holdout/approval-adapter/rotation_queue.js:6:3](#finding-236)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-236)|
|<a id="finding-237"></a>[copy-004/tuning/example.js:1:1](#finding-237)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-237)|
|<a id="finding-238"></a>[copy-004/tuning/variants/alias.js:2:1](#finding-238)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-238)|
|<a id="finding-239"></a>[copy-004/tuning/variants/twice.js:1:1](#finding-239)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-239)|
|<a id="finding-240"></a>[copy-004/tuning/variants/twice.js:1:36](#finding-240)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-240)|
|<a id="finding-241"></a>[copy-005/holdout/approval-adapter/rotation_queue.js:6:3](#finding-241)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-241)|
|<a id="finding-242"></a>[copy-005/tuning/example.js:1:1](#finding-242)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-242)|
|<a id="finding-243"></a>[copy-005/tuning/variants/alias.js:2:1](#finding-243)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-243)|
|<a id="finding-244"></a>[copy-005/tuning/variants/twice.js:1:1](#finding-244)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-244)|
|<a id="finding-245"></a>[copy-005/tuning/variants/twice.js:1:36](#finding-245)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-245)|
|<a id="finding-246"></a>[copy-006/holdout/approval-adapter/rotation_queue.js:6:3](#finding-246)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-246)|
|<a id="finding-247"></a>[copy-006/tuning/example.js:1:1](#finding-247)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-247)|
|<a id="finding-248"></a>[copy-006/tuning/variants/alias.js:2:1](#finding-248)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-248)|
|<a id="finding-249"></a>[copy-006/tuning/variants/twice.js:1:1](#finding-249)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-249)|
|<a id="finding-250"></a>[copy-006/tuning/variants/twice.js:1:36](#finding-250)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-250)|
|<a id="finding-251"></a>[copy-007/holdout/approval-adapter/rotation_queue.js:6:3](#finding-251)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-251)|
|<a id="finding-252"></a>[copy-007/tuning/example.js:1:1](#finding-252)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-252)|
|<a id="finding-253"></a>[copy-007/tuning/variants/alias.js:2:1](#finding-253)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-253)|
|<a id="finding-254"></a>[copy-007/tuning/variants/twice.js:1:1](#finding-254)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-254)|
|<a id="finding-255"></a>[copy-007/tuning/variants/twice.js:1:36](#finding-255)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-255)|

<a id="source-216"></a>

### copy-000/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-217"></a>

### copy-000/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-218"></a>

### copy-000/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-219"></a>

### copy-000/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-220"></a>

### copy-000/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-221"></a>

### copy-001/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-222"></a>

### copy-001/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-223"></a>

### copy-001/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-224"></a>

### copy-001/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-225"></a>

### copy-001/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-226"></a>

### copy-002/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-227"></a>

### copy-002/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-228"></a>

### copy-002/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-229"></a>

### copy-002/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-230"></a>

### copy-002/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-231"></a>

### copy-003/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-232"></a>

### copy-003/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-233"></a>

### copy-003/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-234"></a>

### copy-003/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-235"></a>

### copy-003/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-236"></a>

### copy-004/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-237"></a>

### copy-004/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-238"></a>

### copy-004/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-239"></a>

### copy-004/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-240"></a>

### copy-004/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-241"></a>

### copy-005/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-242"></a>

### copy-005/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-243"></a>

### copy-005/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-244"></a>

### copy-005/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-245"></a>

### copy-005/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-246"></a>

### copy-006/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-247"></a>

### copy-006/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-248"></a>

### copy-006/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-249"></a>

### copy-006/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-250"></a>

### copy-006/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-251"></a>

### copy-007/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-252"></a>

### copy-007/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-253"></a>

### copy-007/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-254"></a>

### copy-007/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-255"></a>

### copy-007/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="rule-18"></a>

## PQC_PYTHON_API

Python PQC key generation reference; backend support is not established.

Check: cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-256"></a>[copy-000/holdout/approval-adapter/approval_backend.py:3:1](#finding-256)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-256)|
|<a id="finding-257"></a>[copy-000/tuning/example.py:1:1](#finding-257)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-257)|
|<a id="finding-258"></a>[copy-000/tuning/variants/alias.py:1:1](#finding-258)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-258)|
|<a id="finding-259"></a>[copy-000/tuning/variants/alias.py:2:1](#finding-259)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-259)|
|<a id="finding-260"></a>[copy-000/tuning/variants/broken.py:1:1](#finding-260)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-260)|
|<a id="finding-261"></a>[copy-001/holdout/approval-adapter/approval_backend.py:3:1](#finding-261)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-261)|
|<a id="finding-262"></a>[copy-001/tuning/example.py:1:1](#finding-262)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-262)|
|<a id="finding-263"></a>[copy-001/tuning/variants/alias.py:1:1](#finding-263)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-263)|
|<a id="finding-264"></a>[copy-001/tuning/variants/alias.py:2:1](#finding-264)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-264)|
|<a id="finding-265"></a>[copy-001/tuning/variants/broken.py:1:1](#finding-265)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-265)|
|<a id="finding-266"></a>[copy-002/holdout/approval-adapter/approval_backend.py:3:1](#finding-266)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-266)|
|<a id="finding-267"></a>[copy-002/tuning/example.py:1:1](#finding-267)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-267)|
|<a id="finding-268"></a>[copy-002/tuning/variants/alias.py:1:1](#finding-268)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-268)|
|<a id="finding-269"></a>[copy-002/tuning/variants/alias.py:2:1](#finding-269)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-269)|
|<a id="finding-270"></a>[copy-002/tuning/variants/broken.py:1:1](#finding-270)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-270)|
|<a id="finding-271"></a>[copy-003/holdout/approval-adapter/approval_backend.py:3:1](#finding-271)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-271)|
|<a id="finding-272"></a>[copy-003/tuning/example.py:1:1](#finding-272)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-272)|
|<a id="finding-273"></a>[copy-003/tuning/variants/alias.py:1:1](#finding-273)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-273)|
|<a id="finding-274"></a>[copy-003/tuning/variants/alias.py:2:1](#finding-274)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-274)|
|<a id="finding-275"></a>[copy-003/tuning/variants/broken.py:1:1](#finding-275)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-275)|
|<a id="finding-276"></a>[copy-004/holdout/approval-adapter/approval_backend.py:3:1](#finding-276)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-276)|
|<a id="finding-277"></a>[copy-004/tuning/example.py:1:1](#finding-277)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-277)|
|<a id="finding-278"></a>[copy-004/tuning/variants/alias.py:1:1](#finding-278)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-278)|
|<a id="finding-279"></a>[copy-004/tuning/variants/alias.py:2:1](#finding-279)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-279)|
|<a id="finding-280"></a>[copy-004/tuning/variants/broken.py:1:1](#finding-280)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-280)|
|<a id="finding-281"></a>[copy-005/holdout/approval-adapter/approval_backend.py:3:1](#finding-281)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-281)|
|<a id="finding-282"></a>[copy-005/tuning/example.py:1:1](#finding-282)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-282)|
|<a id="finding-283"></a>[copy-005/tuning/variants/alias.py:1:1](#finding-283)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-283)|
|<a id="finding-284"></a>[copy-005/tuning/variants/alias.py:2:1](#finding-284)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-284)|
|<a id="finding-285"></a>[copy-005/tuning/variants/broken.py:1:1](#finding-285)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-285)|
|<a id="finding-286"></a>[copy-006/holdout/approval-adapter/approval_backend.py:3:1](#finding-286)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-286)|
|<a id="finding-287"></a>[copy-006/tuning/example.py:1:1](#finding-287)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-287)|
|<a id="finding-288"></a>[copy-006/tuning/variants/alias.py:1:1](#finding-288)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-288)|
|<a id="finding-289"></a>[copy-006/tuning/variants/alias.py:2:1](#finding-289)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-289)|
|<a id="finding-290"></a>[copy-006/tuning/variants/broken.py:1:1](#finding-290)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-290)|
|<a id="finding-291"></a>[copy-007/holdout/approval-adapter/approval_backend.py:3:1](#finding-291)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-291)|
|<a id="finding-292"></a>[copy-007/tuning/example.py:1:1](#finding-292)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-292)|
|<a id="finding-293"></a>[copy-007/tuning/variants/alias.py:1:1](#finding-293)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-293)|
|<a id="finding-294"></a>[copy-007/tuning/variants/alias.py:2:1](#finding-294)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-294)|
|<a id="finding-295"></a>[copy-007/tuning/variants/broken.py:1:1](#finding-295)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-295)|

<a id="source-256"></a>

### copy-000/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-257"></a>

### copy-000/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-258"></a>

### copy-000/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-259"></a>

### copy-000/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-260"></a>

### copy-000/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-261"></a>

### copy-001/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-262"></a>

### copy-001/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-263"></a>

### copy-001/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-264"></a>

### copy-001/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-265"></a>

### copy-001/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-266"></a>

### copy-002/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-267"></a>

### copy-002/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-268"></a>

### copy-002/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-269"></a>

### copy-002/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-270"></a>

### copy-002/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-271"></a>

### copy-003/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-272"></a>

### copy-003/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-273"></a>

### copy-003/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-274"></a>

### copy-003/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-275"></a>

### copy-003/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-276"></a>

### copy-004/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-277"></a>

### copy-004/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-278"></a>

### copy-004/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-279"></a>

### copy-004/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-280"></a>

### copy-004/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-281"></a>

### copy-005/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-282"></a>

### copy-005/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-283"></a>

### copy-005/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-284"></a>

### copy-005/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-285"></a>

### copy-005/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-286"></a>

### copy-006/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-287"></a>

### copy-006/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-288"></a>

### copy-006/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-289"></a>

### copy-006/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-290"></a>

### copy-006/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-291"></a>

### copy-007/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-292"></a>

### copy-007/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-293"></a>

### copy-007/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-294"></a>

### copy-007/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-295"></a>

### copy-007/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="rule-19"></a>

## PQC_RUBY_API

Ruby PQC algorithm literal referenced; key generation or signing success is not established.

Check: Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-296"></a>[copy-000/tuning/example.rb:1:28](#finding-296)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-296)|
|<a id="finding-297"></a>[copy-000/tuning/variants/display.rb:1:6](#finding-297)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-297)|
|<a id="finding-298"></a>[copy-001/tuning/example.rb:1:28](#finding-298)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-298)|
|<a id="finding-299"></a>[copy-001/tuning/variants/display.rb:1:6](#finding-299)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-299)|
|<a id="finding-300"></a>[copy-002/tuning/example.rb:1:28](#finding-300)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-300)|
|<a id="finding-301"></a>[copy-002/tuning/variants/display.rb:1:6](#finding-301)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-301)|
|<a id="finding-302"></a>[copy-003/tuning/example.rb:1:28](#finding-302)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-302)|
|<a id="finding-303"></a>[copy-003/tuning/variants/display.rb:1:6](#finding-303)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-303)|
|<a id="finding-304"></a>[copy-004/tuning/example.rb:1:28](#finding-304)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-304)|
|<a id="finding-305"></a>[copy-004/tuning/variants/display.rb:1:6](#finding-305)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-305)|
|<a id="finding-306"></a>[copy-005/tuning/example.rb:1:28](#finding-306)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-306)|
|<a id="finding-307"></a>[copy-005/tuning/variants/display.rb:1:6](#finding-307)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-307)|
|<a id="finding-308"></a>[copy-006/tuning/example.rb:1:28](#finding-308)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-308)|
|<a id="finding-309"></a>[copy-006/tuning/variants/display.rb:1:6](#finding-309)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-309)|
|<a id="finding-310"></a>[copy-007/tuning/example.rb:1:28](#finding-310)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-310)|
|<a id="finding-311"></a>[copy-007/tuning/variants/display.rb:1:6](#finding-311)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-311)|

<a id="source-296"></a>

### copy-000/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-297"></a>

### copy-000/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-298"></a>

### copy-001/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-299"></a>

### copy-001/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-300"></a>

### copy-002/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-301"></a>

### copy-002/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-302"></a>

### copy-003/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-303"></a>

### copy-003/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-304"></a>

### copy-004/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-305"></a>

### copy-004/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-306"></a>

### copy-005/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-307"></a>

### copy-005/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-308"></a>

### copy-006/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-309"></a>

### copy-006/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-310"></a>

### copy-007/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-311"></a>

### copy-007/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="rule-20"></a>

## PQC_RUST_API

Rust PQC crate symbol referenced; execution and protocol use require confirmation.

Check: Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-312"></a>[copy-000/tuning/example.rs:1:5](#finding-312)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-312)|
|<a id="finding-313"></a>[copy-001/tuning/example.rs:1:5](#finding-313)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-313)|
|<a id="finding-314"></a>[copy-002/tuning/example.rs:1:5](#finding-314)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-314)|
|<a id="finding-315"></a>[copy-003/tuning/example.rs:1:5](#finding-315)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-315)|
|<a id="finding-316"></a>[copy-004/tuning/example.rs:1:5](#finding-316)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-316)|
|<a id="finding-317"></a>[copy-005/tuning/example.rs:1:5](#finding-317)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-317)|
|<a id="finding-318"></a>[copy-006/tuning/example.rs:1:5](#finding-318)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-318)|
|<a id="finding-319"></a>[copy-007/tuning/example.rs:1:5](#finding-319)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-319)|

<a id="source-312"></a>

### copy-000/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-313"></a>

### copy-001/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-314"></a>

### copy-002/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-315"></a>

### copy-003/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-316"></a>

### copy-004/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-317"></a>

### copy-005/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-318"></a>

### copy-006/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-319"></a>

### copy-007/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="rule-21"></a>

## PQC_WEBCRYPTO_API

WebCrypto-style PQC algorithm request; this is not proof of browser support.

Check: Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-320"></a>[copy-000/tuning/example.ts:1:8](#finding-320)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-320)|
|<a id="finding-321"></a>[copy-000/tuning/variants/typed.ts:1:44](#finding-321)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-321)|
|<a id="finding-322"></a>[copy-001/tuning/example.ts:1:8](#finding-322)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-322)|
|<a id="finding-323"></a>[copy-001/tuning/variants/typed.ts:1:44](#finding-323)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-323)|
|<a id="finding-324"></a>[copy-002/tuning/example.ts:1:8](#finding-324)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-324)|
|<a id="finding-325"></a>[copy-002/tuning/variants/typed.ts:1:44](#finding-325)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-325)|
|<a id="finding-326"></a>[copy-003/tuning/example.ts:1:8](#finding-326)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-326)|
|<a id="finding-327"></a>[copy-003/tuning/variants/typed.ts:1:44](#finding-327)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-327)|
|<a id="finding-328"></a>[copy-004/tuning/example.ts:1:8](#finding-328)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-328)|
|<a id="finding-329"></a>[copy-004/tuning/variants/typed.ts:1:44](#finding-329)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-329)|
|<a id="finding-330"></a>[copy-005/tuning/example.ts:1:8](#finding-330)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-330)|
|<a id="finding-331"></a>[copy-005/tuning/variants/typed.ts:1:44](#finding-331)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-331)|
|<a id="finding-332"></a>[copy-006/tuning/example.ts:1:8](#finding-332)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-332)|
|<a id="finding-333"></a>[copy-006/tuning/variants/typed.ts:1:44](#finding-333)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-333)|
|<a id="finding-334"></a>[copy-007/tuning/example.ts:1:8](#finding-334)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-334)|
|<a id="finding-335"></a>[copy-007/tuning/variants/typed.ts:1:44](#finding-335)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-335)|

<a id="source-320"></a>

### copy-000/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-321"></a>

### copy-000/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-322"></a>

### copy-001/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-323"></a>

### copy-001/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-324"></a>

### copy-002/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-325"></a>

### copy-002/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-326"></a>

### copy-003/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-327"></a>

### copy-003/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-328"></a>

### copy-004/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-329"></a>

### copy-004/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-330"></a>

### copy-005/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-331"></a>

### copy-005/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-332"></a>

### copy-006/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-333"></a>

### copy-006/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-334"></a>

### copy-007/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-335"></a>

### copy-007/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

## Action details

Each location links only to its applicable action. Identical payloads are printed once.

<a id="action-0"></a>


#### Prepare hybrid certificate issuance and trust-store rollout (near-term)

PKI updates require coordinated CA, chain, and relying-party compatibility planning.

1. Inventory certificate signature algorithms and key sizes from CBOM/report output.
2. Pilot hybrid chain issuance in non-production trust stores.
3. Define reissuance plan for quantum-vulnerable roots/intermediates/end-entity certs.

References:

- https://csrc.nist.gov/pubs/fips/204/final
- https://csrc.nist.gov/pubs/fips/205/final
<a id="action-1"></a>


#### Adopt a phased hybrid PQC migration plan (near-term)

The detected primitive is vulnerable to cryptographically relevant quantum attacks. Hybrid rollout minimizes compatibility risk.

1. Inventory all call sites using this algorithm and owner teams.
2. Introduce dual-stack or hybrid mode (classical + PQC) before hard cut-over.
3. Define retirement dates for legacy classical algorithms.

References:

- https://www.nist.gov/itl/post-quantum-cryptography
- https://csrc.nist.gov/pubs/fips/203/final
- https://csrc.nist.gov/pubs/fips/204/final
<a id="action-2"></a>


#### Rotate exposed private keys and revoke affected credentials (immediate)

Private key material was detected. This is an active key-management incident and must be remediated immediately.

1. Revoke/disable the exposed key and issue a replacement key pair.
2. Invalidate sessions/tokens signed by the compromised key if applicable.
3. Move keys to a secret manager or HSM and enforce commit scanning in CI.

References:

- https://cheatsheetseries.owasp.org/cheatsheets/Secrets_Management_Cheat_Sheet.html
<a id="action-3"></a>


#### Upgrade Java runtime baseline for standard PQC APIs (planned)

Detected Java version appears older than JDK releases with standardized PQC APIs.

1. Target JDK 24+ for ML-KEM and ML-DSA support planning.
2. Pilot compatibility testing in CI before production migration.

References:

- https://openjdk.org/jeps/496
- https://openjdk.org/jeps/497
<a id="action-4"></a>


#### Provide BouncyCastle PQC fallback path (near-term)

BouncyCastle can be used as a pragmatic transition option when standard runtime support is unavailable or incomplete.

1. Add BC provider initialization at bootstrap.
2. Use BC ML-DSA / ML-KEM parameter specs for migration pilot implementations.
3. Document provider ordering and FIPS/compliance impact.

References:

- https://www.bouncycastle.org/java.html
- https://downloads.bouncycastle.org/java/docs/bcprov-jdk18on-javadoc/

Before (java)

    Security.addProvider(new BouncyCastleProvider());
    Signature sig = Signature.getInstance("SHA256withRSA", "BC");

After

    Security.addProvider(new BouncyCastlePQCProvider());
    Signature sig = Signature.getInstance("ML-DSA", "BCPQC");
    // Configure parameter set (example): MLDSAParameterSpec.ml_dsa_65

<a id="action-5"></a>


#### Verify deployed runtime and protocol PQC capabilities (planned)

Source declarations and primitive availability do not establish deployment or peer support.

1. JDK 24 adds ML-KEM and ML-DSA primitives. Check deployed JSSE hybrid TLS support separately and inspect jdk.tls.namedGroups restrictions.
2. Check resolved versions, provider/features and interoperability before changing production policy.

References:

- https://docs.oracle.com/en/java/javase/27/security/java-secure-socket-extension-jsse-reference-guide.html
<a id="action-6"></a>


#### Prefer TLS 1.3 and review legacy key exchange (near-term)

RSA key exchange and legacy protocol versions are high-priority migration blockers for PQC readiness.

1. Prefer TLS 1.3; restrict connections to TLS 1.3 when all peers support it. Disable TLS 1.0 and 1.1.
2. Retain securely configured TLS 1.2 only where interoperability requires it, and record the compatibility reason.
3. Prefer ECDHE today and plan hybrid KEM suites for next phase.
4. Continuously test interoperability across clients and load balancers.

References:

- https://www.rfc-editor.org/rfc/rfc8446
<a id="action-7"></a>


#### Track PQC readiness of dependent libraries (planned)

Dependency-level crypto libraries strongly influence migration options and operational timelines.

1. Record current versions in dependency-sbom.json and define upgrade targets.
2. Subscribe to release notes for PQC feature availability and API changes.
3. Run integration tests for PQC or hybrid modes before promoting to production.

References:

- https://cyclonedx.org/
- https://spdx.dev/
<a id="action-8"></a>


#### Introduce crypto abstraction boundary for algorithm agility (near-term)

Direct algorithm calls create high migration cost. A boundary layer enables staged classical-to-PQC transitions.

1. Wrap signing, verification, keygen, and key exchange behind stable interfaces.
2. Add policy controls to select classical, hybrid, or PQC paths at runtime.

References:

- https://www.nist.gov/itl/post-quantum-cryptography
<a id="action-9"></a>


#### Review the explicit PQC override: GODEBUG=tlsmlkem=0 (near-term)

The detected setting restricts hybrid key exchange. It does not establish RSA usage or the negotiated TLS version.

1. Inspect GODEBUG=tlsmlkem=0 at this location and confirm why the override is required.
2. Verify deployed library and peer support before testing a hybrid group or removing the override.
3. Check key exchange, TLS protocol version and certificate signatures separately; TLS 1.3 alone does not establish PQC protection.

References:

- https://go.dev/doc/godebug
- https://www.rfc-editor.org/rfc/rfc9325.html#section-3.1.1
<a id="action-10"></a>


#### Review the explicit PQC override: jdk.tls.namedGroups (near-term)

The detected setting restricts hybrid key exchange. It does not establish RSA usage or the negotiated TLS version.

1. Inspect jdk.tls.namedGroups at this location and confirm why the override is required.
2. Verify deployed library and peer support before testing a hybrid group or removing the override.
3. Check key exchange, TLS protocol version and certificate signatures separately; TLS 1.3 alone does not establish PQC protection.

References:

- https://go.dev/doc/godebug
- https://www.rfc-editor.org/rfc/rfc9325.html#section-3.1.1
<a id="action-11"></a>


#### Review the explicit PQC override: groups= / ecdh_curves= (near-term)

The detected setting restricts hybrid key exchange. It does not establish RSA usage or the negotiated TLS version.

1. Inspect groups= / ecdh_curves= at this location and confirm why the override is required.
2. Verify deployed library and peer support before testing a hybrid group or removing the override.
3. Check key exchange, TLS protocol version and certificate signatures separately; TLS 1.3 alone does not establish PQC protection.

References:

- https://go.dev/doc/godebug
- https://www.rfc-editor.org/rfc/rfc9325.html#section-3.1.1

## Inventory exports

- [CBOM](cbom.json): 328
- [Dependency SBOM](dependency-sbom.json): 48


## Inspection coverage

Completeness covers supported inspection within the declared scope, after ignore settings, exclusions and size limits. It does not prove runtime use, certificate trust or security. Unenumerated files remain unknown.

|Item|Value|
|---|---|
|Status|Some inspection could not complete (partial)|
|Selected files|328|
|Read successfully|328|
|Read failed|0|
|Analyzed|264|
|Partial|56|
|Analysis failed|0|
|Unsupported|0|
|Not applicable|0|
|Unknown|8|
|Enumerated exclusions|0|
|Enumeration failures|0|
|Unenumerated population|Unknown|

## Inspection diagnostics

Safe reason codes, paths and detector names; file contents and arbitrary error messages are omitted.

|Item|Value|
|---|---|
|Detector does not report completeness (detector_not_reported)|- / dependency_detector|
|Detector failed (detector_failed)|copy-000/holdout/broken-sbom.json / dependency_detector|
|Inspection unsupported (detector_unsupported)|copy-000/holdout/ec.pem / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-000/holdout/misleading-rsa1024.der / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-000/holdout/unsupported.p12 / certificate_detector|
|Inspection unsupported (detector_unsupported)|copy-000/tuning/marker.pem / certificate_detector|
|Inspection unsupported (detector_unsupported)|copy-000/tuning/public.pem / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-000/tuning/variants/broken.py / tree_sitter_detector|
|Detector failed (detector_failed)|copy-001/holdout/broken-sbom.json / dependency_detector|
|Inspection unsupported (detector_unsupported)|copy-001/holdout/ec.pem / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-001/holdout/misleading-rsa1024.der / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-001/holdout/unsupported.p12 / certificate_detector|
|Inspection unsupported (detector_unsupported)|copy-001/tuning/marker.pem / certificate_detector|
|Inspection unsupported (detector_unsupported)|copy-001/tuning/public.pem / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-001/tuning/variants/broken.py / tree_sitter_detector|
|Detector failed (detector_failed)|copy-002/holdout/broken-sbom.json / dependency_detector|
|Inspection unsupported (detector_unsupported)|copy-002/holdout/ec.pem / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-002/holdout/misleading-rsa1024.der / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-002/holdout/unsupported.p12 / certificate_detector|
|Inspection unsupported (detector_unsupported)|copy-002/tuning/marker.pem / certificate_detector|
|Inspection unsupported (detector_unsupported)|copy-002/tuning/public.pem / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-002/tuning/variants/broken.py / tree_sitter_detector|
|Detector failed (detector_failed)|copy-003/holdout/broken-sbom.json / dependency_detector|
|Inspection unsupported (detector_unsupported)|copy-003/holdout/ec.pem / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-003/holdout/misleading-rsa1024.der / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-003/holdout/unsupported.p12 / certificate_detector|
|Inspection unsupported (detector_unsupported)|copy-003/tuning/marker.pem / certificate_detector|
|Inspection unsupported (detector_unsupported)|copy-003/tuning/public.pem / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-003/tuning/variants/broken.py / tree_sitter_detector|
|Detector failed (detector_failed)|copy-004/holdout/broken-sbom.json / dependency_detector|
|Inspection unsupported (detector_unsupported)|copy-004/holdout/ec.pem / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-004/holdout/misleading-rsa1024.der / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-004/holdout/unsupported.p12 / certificate_detector|
|Inspection unsupported (detector_unsupported)|copy-004/tuning/marker.pem / certificate_detector|
|Inspection unsupported (detector_unsupported)|copy-004/tuning/public.pem / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-004/tuning/variants/broken.py / tree_sitter_detector|
|Detector failed (detector_failed)|copy-005/holdout/broken-sbom.json / dependency_detector|
|Inspection unsupported (detector_unsupported)|copy-005/holdout/ec.pem / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-005/holdout/misleading-rsa1024.der / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-005/holdout/unsupported.p12 / certificate_detector|
|Inspection unsupported (detector_unsupported)|copy-005/tuning/marker.pem / certificate_detector|
|Inspection unsupported (detector_unsupported)|copy-005/tuning/public.pem / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-005/tuning/variants/broken.py / tree_sitter_detector|
|Detector failed (detector_failed)|copy-006/holdout/broken-sbom.json / dependency_detector|
|Inspection unsupported (detector_unsupported)|copy-006/holdout/ec.pem / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-006/holdout/misleading-rsa1024.der / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-006/holdout/unsupported.p12 / certificate_detector|
|Inspection unsupported (detector_unsupported)|copy-006/tuning/marker.pem / certificate_detector|
|Inspection unsupported (detector_unsupported)|copy-006/tuning/public.pem / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-006/tuning/variants/broken.py / tree_sitter_detector|
|Detector failed (detector_failed)|copy-007/holdout/broken-sbom.json / dependency_detector|
|Inspection unsupported (detector_unsupported)|copy-007/holdout/ec.pem / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-007/holdout/misleading-rsa1024.der / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-007/holdout/unsupported.p12 / certificate_detector|
|Inspection unsupported (detector_unsupported)|copy-007/tuning/marker.pem / certificate_detector|
|Inspection unsupported (detector_unsupported)|copy-007/tuning/public.pem / certificate_detector|
|Only part of inspection completed (detector_partial)|copy-007/tuning/variants/broken.py / tree_sitter_detector|
