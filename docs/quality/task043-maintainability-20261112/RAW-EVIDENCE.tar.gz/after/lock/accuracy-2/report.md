# PQC Migration Scan Report

Generated: 2026-11-12 03:10:25.138583 UTC

Risk candidates: 0 / Inventory findings: 2 / Scanned files: 2

Static evidence does not prove runtime use or completed PQC migration.

|Severity|Count (all findings)|
|---|---:|
|info|2|

## Risk candidate index

|Rule / description|Severity|Risk|Hits|Files|
|---|---|---|---:|---:|

## Informational inventory index

|Rule / description|Severity|Risk|Hits|Files|
|---|---|---|---:|---:|
|[DEP_PQC_CAPABLE_LIBRARY](#rule-0) Library with version-dependent PQC capabilities inventoried; capability is not an enabled-state find...|info|quantum-uncertain|2|2|

<a id="rule-0"></a>

## DEP_PQC_CAPABLE_LIBRARY

Library with version-dependent PQC capabilities inventoried; capability is not an enabled-state finding.

Check: Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-0"></a>[tuning/package-lock.json:1:1](#finding-0)|@noble/p***@0.7.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-0)|
|<a id="finding-1"></a>[tuning/pnpm-lock.yaml:3:1](#finding-1)|@noble/p***@0.7.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-1)|

Shared checks for these locations (not verified facts about each line):

- [Track PQC readiness of dependent libraries](#action-0)

<a id="source-0"></a>

### tuning/package-lock.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-1"></a>

### tuning/pnpm-lock.yaml:3:1

    > 3 [masked-sensitive-file-content]

## Action details

Each location links only to its applicable action. Identical payloads are printed once.

<a id="action-0"></a>


#### Track PQC readiness of dependent libraries (planned)

Dependency-level crypto libraries strongly influence migration options and operational timelines.

1. Record current versions in dependency-sbom.json and define upgrade targets.
2. Subscribe to release notes for PQC feature availability and API changes.
3. Run integration tests for PQC or hybrid modes before promoting to production.

References:

- https://cyclonedx.org/
- https://spdx.dev/

## Inventory exports

- [CBOM](cbom.json): 2
- [Dependency SBOM](dependency-sbom.json): 2


## Inspection coverage

Completeness covers supported inspection within the declared scope, after ignore settings, exclusions and size limits. It does not prove runtime use, certificate trust or security. Unenumerated files remain unknown.

|Item|Value|
|---|---|
|Status|Inspection complete within declared scope (complete_within_scope)|
|Selected files|2|
|Read successfully|2|
|Read failed|0|
|Analyzed|2|
|Partial|0|
|Analysis failed|0|
|Unsupported|0|
|Not applicable|0|
|Unknown|0|
|Enumerated exclusions|0|
|Enumeration failures|0|
|Unenumerated population|Unknown|

## Inspection diagnostics

Safe reason codes, paths and detector names; file contents and arbitrary error messages are omitted.

|Item|Value|
|---|---|
