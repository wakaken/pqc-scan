from pathlib import Path
import json,hashlib,datetime,subprocess,sys,tarfile
R=Path.cwd();P=R/'target/quality-task-043-maintainability-20261112';D=R/'docs/quality/task043-maintainability-20261112';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text())
assert all(row['exitCode']==0 for row in load(D/'CHECKS.json'))
assert '承認' in (D/'IMPLEMENTATION-REVIEW.md').read_text();assert '承認' in (D/'TEST-REVIEW.md').read_text()
assert load(D/'TEST-REVIEW-BINDINGS.json').get('errors')==[]
for row in load(D/'CHANGES.json'):assert sha(R/row['path'])==row['afterSha256'],row['path']
for name,h in load(D/'FROZEN.json')['bindings'].items():assert sha(R/name)==h,name
old=R/'docs/quality/task043-fixes-20261112';prior=load(old/'EVIDENCE-INDEX.json')
for name,row in prior.items():assert sha(old/name)==row['sha256'] and (old/name).stat().st_size==row['bytes'],name
sys.path.insert(0,str(R/'tests/quality'));from run import environment
current=environment(R/'target/release/pqc-scan');measured=load(P/'final-043/summary.json')['environment']
for key in ['binarySha256','runtimeSourceDigest','harnessDigest']:assert current[key]==measured[key],key
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==load(D/'ENTRY.json')['head']
acceptance=dict(task='043',followup='maintainability',status='done',decision='Passed',timestampUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseCommit=load(D/'ENTRY.json')['head'],branch='codex/quality-assessment-model',worktree='Uncommitted changes; prior work preserved',requirements=[dict(id='canonical-rule-definitions',status='Passed',evidence=['CHANGE.patch','IMPLEMENTATION-REVIEW.md'],detail='Six pattern/scope/kind fingerprints derive from canonical YAML; Node/Python selector/recovery reuse loaded compiled pattern'),dict(id='remove-unnecessary-special-cases',status='Passed',detail='No evaluation-case IDs/paths/line exceptions found; shared evidence extraction no longer branches on Rust rule ID; Rust recovery derives from namespace registry; language/API semantics retained'),dict(id='compatibility-and-regression',status='Passed',evidence=['COMPARISON.json','SOURCE-MATCH.json'],corpora=5,repeatsPerVersion=3,detail='Same inputs/truth/harness, score/semantic findings/positions/IDs/diagnostics/order identical'),dict(id='required-validation',status='Passed',evidence='VALIDATION.json'),dict(id='independent-implementation-review',status='Passed',evidence='IMPLEMENTATION-REVIEW.md',unresolved=[]),dict(id='independent-test-review',status='Passed',evidence='TEST-REVIEW.md',unresolved=[])],historicalEvidence=dict(priorPacket='docs/quality/task043-fixes-20261112/EVIDENCE-INDEX.json',priorPacketIndexSha256=sha(old/'EVIDENCE-INDEX.json'),verifiedFiles=len(prior),unchanged=True),remainingRequiredWork=[],notClaimed=['Arbitrary API/language semantics from YAML','New independently held-out accuracy trial','Whole Q1-Q6 or release readiness'],publication='No commit/push/PR/merge/tag/release')
(D/'ACCEPTANCE.json').write_text(json.dumps(acceptance,ensure_ascii=False,indent=2)+'\n')
p=R/'tasks/043-quality-detection-triage.yaml';s=p.read_text().replace('status: review\nowner: Reviewer Agent','status: done\nowner: Evaluator Agent',1);a=s.index('maintainability_followup:');s=s[:a]+s[a:].replace('status: in-progress','status: done',1);s+='''  report: docs/quality/TASK-043-MAINTAINABILITY-RESULTS.md
  completion_evidence: docs/quality/task043-maintainability-20261112/ACCEPTANCE.json
  outcome: 既定6規則の重複定義とNode/Pythonの再列挙を解消。必要な言語/API解釈は保持。5コーパスの前後結果が完全同値。
  reviews: 実装・試験妥当性の各1名が承認。必須未解消なし。
  validation: Rust390・品質Python54・配布10・Node31成功。protocol5成功/6skipを明示。fmt/Clippy/release成功。
  publication: commit/push/PR/merge/tag/releaseは未実施。
''';p.write_text(s)
p=R/'docs/quality/QUALITY-ROADMAP.md';s=p.read_text().replace('043には、YAMLとRustの重複管理を解消する追加依頼があり、[保守性改善](TASK-043-MAINTAINABILITY-PLAN.md)を実施中です。','043の追加依頼であるYAMLとRustの重複管理も解消し、[保守性改善の受入](TASK-043-MAINTAINABILITY-RESULTS.md)を完了しました。');p.write_text(s)
p=R/'docs/quality/TASK-043-MAINTAINABILITY-RESULTS.md';s=p.read_text()+'\nEvaluatorは全必須条件と二段階レビューを照合し、043の保守性改善をdoneとしました。[最終受入](task043-maintainability-20261112/ACCEPTANCE.json)に判定を保存しています。\n';p.write_text(s)
with tarfile.open(D/'FINALIZATION-EVIDENCE.tar.gz','w:gz') as tar:
 for name in ['close.py','review-bindings.py']:
  if (P/name).exists():tar.add(P/name,arcname=name,recursive=False)
 tar.add(R/'tasks/043-quality-detection-triage.yaml',arcname='tasks/043-quality-detection-triage.yaml',recursive=False)
index={str(f.relative_to(D)):dict(sha256=sha(f),bytes=f.stat().st_size) for f in sorted(D.rglob('*')) if f.is_file() and f.name!='EVIDENCE-INDEX.json'}
(D/'EVIDENCE-INDEX.json').write_text(json.dumps(index,indent=2)+'\n')
for name,row in index.items():assert sha(D/name)==row['sha256'] and (D/name).stat().st_size==row['bytes'],name
print('done;',len(index),'packet files verified;',len(prior),'prior packet files unchanged; code/binary/harness match final measurement')
