from pathlib import Path
import json,hashlib,re,sys
R=Path.cwd();P=R/'target/quality-task-043-maintainability-20261112'
sys.path.insert(0,str(R/'tests/quality'))
from evaluate import digest,semantic_digest,order_digest
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
out={}; errors=[]
for row in json.loads((P/'CHANGES.json').read_text()):
 if sha(R/row['path'])!=row['afterSha256']:errors.append(['changed-source',row['path']])
out['changedSourceHashesMatch']=not errors
out['workspacePassed']=sum(int(v) for v in re.findall(r'test result: ok\. (\d+) passed;', (P/'check-workspace.log').read_text()))
out['corpora']={}
for name in ['043','042','legacy','lock','original']:
 before=P/f'before/target/{name}';after=P/f'final-{name}'
 b=json.loads((before/'summary.json').read_text());a=json.loads((after/'summary.json').read_text())
 row={'details':len(a['accuracy']['details']),'files':a['corpusInput']['files']}
 for field in ['corpusSha256','truthSha256','corpusInput','accuracy']:
  row[field+'Equal']=b[field]==a[field]
  if not row[field+'Equal']:errors.append([name,field])
 row['harnessEqual']=b['environment']['harnessBindings']==a['environment']['harnessBindings']
 if not row['harnessEqual']:errors.append([name,'harness'])
 for d,root,label in [(a,R,'after'),(b,P/'before','before')]:
  e=d['environment'];bad=[]
  for group in ['runtimeSourceBindings','harnessBindings']:
   for f,h in e[group].items():
    if not (root/f).is_file() or sha(root/f)!=h:bad.append(f)
  row[label+'BindingsMatch']=not bad
  if bad:errors.append([name,label+'bindings',bad])
  binary=Path(e['binary']); row[label+'BinarySha256']=e['binarySha256']
  if sha(binary)!=e['binarySha256']:errors.append([name,label+'binary'])
  for i,sample in enumerate(d['repeatability']['samples']):
   raw=json.loads((after if label=='after' else before).joinpath(f'accuracy-{i}/report.json').read_text())
   diag=json.loads((after if label=='after' else before).joinpath(f'accuracy-{i}/diagnostics.json').read_text())
   for k,v in [('semanticDigest',semantic_digest(raw)),('orderDigest',order_digest(raw)),('diagnosticDigest',digest({k:v for k,v in diag.items() if k!='generated_at'}))]:
    if sample[k]!=v:errors.append([name,label,i,k])
 for k in ['semanticDigest','orderDigest','diagnosticDigest']:
  row[k+'Equal']=len({s[k] for d in [a,b] for s in d['repeatability']['samples']})==1
  if not row[k+'Equal']:errors.append([name,k])
 out['corpora'][name]=row
out['errors']=errors
(P/'TEST-REVIEW-BINDINGS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2));assert not errors
