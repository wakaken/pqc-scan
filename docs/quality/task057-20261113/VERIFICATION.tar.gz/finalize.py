import hashlib,json,re,shutil,subprocess,tarfile
from pathlib import Path
root=Path.cwd(); run=Path('target/quality-task-057/run-20261113'); confined=run/'confined'; dest=Path('docs/quality/task057-20261113');dest.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text())
def save(name,v):
 for directory in [Path('target/quality-task-057'),dest]:
  (directory/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
commands=read(confined/'commands.json'); host=read(confined/'HOST-RESULTS.json')
assert host['exit']==0 and host['sourceBeforeAfterMatch'] and host['containerRemoved']
assert all(c['exit']==0 for c in commands)
logs={mode:(confined/f'{mode}-tests.log').read_text() for mode in ['default','all-features']}
def tests(path,names):
 text=Path(path).read_text(); h=hashlib.sha256(Path(path).read_bytes()).hexdigest()
 for name in names:
  assert f'fn {name}(' in text,(path,name)
  assert any(f'{name} ... ok' in log for log in logs.values()),name
 return {'source':path,'sha256':h,'tests':names,'result':'passed in fresh confined workspace tests'}
privacy=[
 tests('crates/pqc_scan_core/tests/evidence_privacy.rs',['redaction_preserves_legacy_ids_native_associations_cbom_rows_and_technical_metadata','initial_source_snapshot_masks_body_even_if_a_detector_changes_the_file','detector_error_content_is_not_exported_by_diagnostics_or_inventory','quality057_unknown_line_or_column_preserves_conservative_redaction']),
 tests('crates/pqc_scan_cli/tests/evidence_privacy.rs',['private_bodies_and_inline_credentials_never_survive_cli_report_paths']),
 tests('crates/pqc_scan_cli/tests/dependency_privacy.rs',['dependency_locator_credentials_are_omitted_from_all_outputs_and_stderr']),
 tests('crates/pqc_scan_report/tests/evidence_privacy.rs',['known_secret_syntax_is_omitted_in_all_legacy_formats_and_both_languages']),
 tests('crates/pqc_scan_report/tests/probe_reports.rs',['recognized_secret_syntax_is_omitted_consistently_and_disclosed_as_export_loss','failed_serialization_does_not_disclose_arbitrary_error_text_or_create_outputs']),
 tests('crates/pqc_scan_core/src/privacy.rs',['known_literals_keys_urls_and_encoded_value_strings_are_redacted']),
 tests('crates/pqc_scan_report/tests/cyclonedx_17.rs',['separate_public_objects_have_resolving_refs_and_no_secret_claims','private_marker_observation_does_not_invent_a_key_asset'])]
save('privacy-matrix.json',{'requirement':'Q4-04','collectionPaths':[
 {'from':'source/PEM/private marker/evidence snapshot/unknown positions/detector errors','to':'legacy JSON + native inventory + diagnostics; all formats via CLI','evidence':[0,1]},
 {'from':'manifest/dependency URL credentials/purl','to':'all CLI outputs and stderr','evidence':[2]},
 {'from':'finding/evidence/metadata/actions/examples/references/snippets/CBOM/dependency rows','to':'JSON/HTML/Markdown/SARIF/CycloneDX/CSV, English and Japanese','evidence':[3]},
 {'from':'TLS/SSH probe envelope and details/serializer errors','to':'JSON/HTML/Markdown; error leaves no outputs','evidence':[4]}],
 'nativePublicObjectBoundary':'CycloneDX native public objects and private marker observations checked by evidence6; source redaction recognized syntax checked by evidence5','evidence':privacy,'staticCanary':read(confined/'static-network057.json'),'outsideContract':['file paths and stable identifiers','arbitrary opaque/encoded values without recognized secret syntax','absence of canary is not proof of all real secrets being recognized']})
save('failure-matrix.json',{'requirement':'Q4-01','controls':read(confined/'failure-controls057.json'),'classification':'exit42 means explicitly caught Rust panic in controlled worker; exit86 is reserved for invariant violation; arbitrary product codes are not inferred','retention':'timeout stdout retained; following CPU and static-scan results collected; original quality055 fault rows retained in both settings','productFailuresFound':0,'productFaultRetention':{m:read(confined/m/'assessment/file-outcomes.json') for m in logs}})
save('filesystem-safety.json',{'requirement':'Q4-06','tests':[
 tests('crates/pqc_scan_core/src/safe_read.rs',['growing_input_is_stopped_at_limit_plus_one','read_bounds_and_rejects_replaced_files_and_parent_links']),
 tests('crates/pqc_scan_core/src/walker.rs',['special_entries_are_failed_without_selecting_or_following_them']),
 tests('crates/pqc_scan_core/src/safe_read057.rs',['parent_link_replacement_never_reads_the_outside_control','hard_links_are_bounded_regular_files_not_proof_of_origin'])],
 'raceObservations':{m:read(confined/m/'raw/filesystem057.json') for m in logs},'platforms':{'Linux arm64':'fresh full workspace and race tests','macOS arm64':'host targeted privacy and filesystem tests','Windows':'not executed; source has separate handle verification implementation; no claim of Windows runtime certification'},'limitations':['hard links are regular files: byte bound holds, original path provenance cannot be inferred','concurrent content writes do not provide an atomic filesystem snapshot','finite race stress is not an exhaustive interleaving proof']})
networktests=[tests('crates/pqc_scan_core/tests/target_policy.rs',['validates_every_answer_and_keeps_host_separate_from_pinned_ip','rejects_entire_mixed_answer_set_not_just_selected_address','literal_ip_bypasses_dns_but_never_policy','nonpublic_and_tunnel_ranges_require_explicit_authorization','broad_allowlist_never_permits_nonunicast_or_unspecified','reduced_limits_only_and_cancelled_resolution_never_calls_resolver','one_budget_cannot_resolve_twice_and_deadline_overrides_resolver_result']),tests('crates/pqc_scan_core/tests/probe_transport.rs',['exact_socket_bytes_are_counted_and_caller_buffers_clipped','cancellation_interrupts_stalled_read_and_closes_socket','protocol_deadline_does_not_extend_on_successful_reads','cancelled_connect_sends_no_connection','target_cannot_be_attached_to_a_fresh_budget','aggregate_deadline_wins_over_protocol_deadline','idle_socket_closes_at_deadline_without_protocol_io'])]
save('network-boundary.json',{'requirement':'Q4-07','staticScan':read(confined/'static-network057.json'),'explicitProbe':networktests,'externalNetwork':'network=none, kernel external connection refusal; no unauthorized remote targets','measurementLimit':'no syscall trace: demonstrates offline scan succeeds, configured dependency URL is not fetched, and external traffic is denied; not a claim of zero attempted socket syscalls','preparation':'immutable prepared image with locked cached dependencies, target execution uses cargo --offline'})
kernel={p.parent.name:read(p) for p in (run/'kernel').glob('*/HOST-RESULTS.json')}
assert len(kernel)==6 and all(v['containerRemoved'] for v in kernel.values())
save('resource-boundary.json',{'requirement':'Q4-02','preparation':'previous immutable tool image; no tool installation in target execution','image':host.get('image'),'targetBoundary':host['container'],'targetSourceUnchanged':True,'targetRemoved':True,'kernelTests':kernel,'supervisor':'per-input process group wall/CPU/core/file limits; descendant kill tested; outer cgroup bounds child aggregate memory/PIDs/scratch; escape from POSIX group is contained by outer container removal','kernelTestLog':'VERIFICATION.tar.gz:kernel-r2.log','kernelTestsPassed':10,'probeByteLimit':networktests[1],'workerLimitControls':read(confined/'failure-controls057.json'),'initialSetupFailure':'IMAGE.json used imageId instead of image; rejected before container work; corrected IMAGE-r2.json; both logs retained'})
paths=read(run/'REVIEW-SOURCE.json'); source={'baseHead':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'files':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths},'sourceBindings':'VERIFICATION.tar.gz:confined/HOST-RESULTS.json','productLogicCargoRulesSchemasChanged':False}
source['scopeSha256']=hashlib.sha256(json.dumps(source['files'],sort_keys=True).encode()).hexdigest();(dest/'SOURCE.json').write_text(json.dumps(source,indent=2)+'\n')
counts={m:{k:sum(int(n) for n in re.findall(r'(\d+) '+label,log)) for k,label in [('passed','passed;'),('failed','failed;'),('ignored','ignored;')]} for m,log in logs.items()}
(dest/'VALIDATION.json').write_text(json.dumps({'source':source,'rust':counts,'commands':commands,'fmt':'exit0 enclosing entry','kernelTestsPassed':10,'hostTargeted':'privacy1/filesystem2/supervisor3','pythonQualityPassed':69,'sourceBeforeAfterMatch':True,'containerRemoved':True,'githubActions':'not executed'},indent=2)+'\n')
with tarfile.open(dest/'VERIFICATION.tar.gz','w:gz') as tar:
 for p in sorted(run.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(run)))
 for path in source['files']:tar.add(path,arcname='source/'+path)
 tar.add(__file__,arcname='finalize.py')
print(counts)
