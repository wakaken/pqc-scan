"""Reuse TASK-044's stable LLVM coverage on a declared subset of TASK-047 inputs."""
import gzip,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
sys.path[:0]=['/source/tests/quality','/source/tests/quality/task047']
from study import generate,trial,digest
from task044.coverage import summarize
root=Path('/scratch/evidence');folder=root/'fuzz-coverage';folder.mkdir();scratch=Path('/scratch')
original=json.loads((root/'worker-binaries.json').read_text())['binaries'];keep={Path(v['path']) for v in original.values()}
# Full tests/clippy/build already finished. Retain every running-campaign binary,
# discard only disposable intermediates to stay within the existing 4GiB tmpfs.
removed=[]
for path in sorted((scratch/'target').rglob('*'),reverse=True):
 if path.is_file() and path not in keep:removed.append({'path':str(path),'bytes':path.stat().st_size});path.unlink()
 elif path.is_dir():
  try:path.rmdir()
  except OSError:pass
(folder/'retired-cache.json').write_text(json.dumps({'reason':'finished verification; active worker binaries retained unchanged','retired':removed},indent=2)+'\n')
assert all(digest(Path(v['path']).read_bytes())==v['sha256'] for v in original.values())
env=dict(os.environ,CARGO_TARGET_DIR='/scratch/profile-target',RUSTFLAGS='-C instrument-coverage');commands=[];artifacts=[]
for i,selection in enumerate([['-p','pqc_scan_detectors','-p','pqc_scan_report','-p','pqc_scan_probe_ssh','--test','quality047'],['-p','pqc_scan_probe_tls','--lib']]):
 command=['cargo','test',*selection,'--all-features','--no-run','--locked','--offline','--message-format=json']
 with (folder/f'build-{i}.jsonl').open('w') as out,(folder/f'build-{i}.log').open('w') as err:
  start=time.monotonic();r=subprocess.run(command,env=env,stdout=out,stderr=err,timeout=700)
 commands.append({'command':command,'environment':env,'exit':r.returncode,'wallSeconds':time.monotonic()-start});(folder/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');assert r.returncode==0
 artifacts += [json.loads(s) for s in (folder/f'build-{i}.jsonl').read_text().splitlines() if s.startswith('{')]
binaries={}
for row in artifacts:
 if row.get('reason')=='compiler-artifact' and row.get('executable'):
  for crate in original:
   if crate in row['package_id'] and ((row['target']['name']=='quality047') if crate!='pqc_scan_probe_tls' else row['target']['kind']==['lib']):binaries[crate]=row['executable']
assert len(binaries)==4
sysroot=subprocess.check_output(['rustc','--print','sysroot'],text=True).strip();llvm=Path(sysroot)/'lib/rustlib/aarch64-unknown-linux-gnu/bin'
(folder/'tools.log').write_text(subprocess.check_output([str(llvm/'llvm-cov'),'--version'],text=True))
raw=scratch/'fuzz-profraw';raw.mkdir();profile=scratch/'fuzz.profdata';pending=scratch/'fuzz-pending.profdata';hashes={};observed=[]
os.environ['LLVM_PROFILE_FILE']=str(raw/'%p-%m.profraw')
# Select all original seeds and the following sixteen deterministic cases per
# short campaign. This is an explicit subset, not coverage of every mutation.
for campaign in sorted((root/'fuzz').glob('short-*')):
 label=campaign.name[len('short-'):];seeds=json.loads((campaign/'seeds.json').read_text());rows=[json.loads(s) for s in (campaign/'executions.jsonl').read_text().splitlines()]
 rows=rows[:len(seeds)+16]
 crate='pqc_scan_report' if label.startswith('output') else 'pqc_scan_probe_ssh' if label=='SSH' else 'pqc_scan_probe_tls' if label=='TLS' else 'pqc_scan_detectors'
 exact='runtime::quality047::quality047_worker' if label=='TLS' else 'quality047_worker';command=[binaries[crate],'--ignored','--exact',exact,'--nocapture']
 for row in rows:
  name,data,_=generate(seeds,row['seed'],row['index']);assert digest(data)==row['sha256']
  result=trial(command,name,data,scratch/'profile-work');assert result['status']=='completed',result
  original_feedback=row['result']['feedback'];assert result['feedback']==original_feedback,(label,row['index'])
  profiles=sorted(raw.glob('*.profraw'));assert profiles
  hashes.update({p.name:digest(p.read_bytes()) for p in profiles})
  merge=[str(llvm/'llvm-profdata'),'merge','-sparse',*([str(profile)] if profile.exists() else []),*[str(p) for p in profiles],'-o',str(pending)]
  subprocess.run(merge,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,timeout=15);pending.replace(profile)
  for path in profiles:path.unlink()
  shutil.rmtree(scratch/'profile-work');observed.append({'campaign':campaign.name,'index':row['index'],'seed':row['seed'],'inputSha256':row['sha256'],'feedbackMatchesOrdinaryBuild':True,'result':result})
objects=[s for path in sorted(binaries.values()) for s in ['-object',path]]
command=[str(llvm/'llvm-cov'),'export','-instr-profile='+str(profile),'-ignore-filename-regex=^(/scratch|/rustc|/usr)|/tests/','-skip-functions','-skip-expansions',*objects]
with (folder/'coverage.json').open('w') as out,(folder/'export.stderr.log').open('w') as err:r=subprocess.run(command,stdout=out,stderr=err,timeout=120)
assert r.returncode==0;summary=summarize(json.loads((folder/'coverage.json').read_text()),branches=False)
# Reused parser includes source-located cfg(test) code; disclose it, don't relabel
# those counters as a pure product-wide score or regions as branches.
summary.update({'profiledInputs':len(observed),'selection':'all saved seeds + following16 short cases per target including populated native supplemental','scope':'linked Rust source only; source-located cfg(test) blocks included; dependencies/FFI C/CLI absent are not covered by this denominator','branchCoverage':'Not Measured on stable; no branch percentage inferred','binaries':{k:{'path':v,'sha256':digest(Path(v).read_bytes())} for k,v in binaries.items()},'rawProfileHashes':hashes,'profdataSha256':digest(profile.read_bytes()),'exportCommand':command,'exportExit':r.returncode})
summary['unmappedSourceFiles']=sorted(str(p.relative_to('/source')) for p in Path('/source/crates').glob('*/src/**/*.rs') if str(p.relative_to('/source')) not in summary['files'])
(folder/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(folder/'profiled-inputs.json').write_text(json.dumps(observed,indent=2)+'\n')
for source,dest in [(folder/'coverage.json',folder/'coverage.json.gz'),(profile,folder/'coverage.profdata.gz')]:
 with source.open('rb') as inp,gzip.open(dest,'wb') as out:shutil.copyfileobj(inp,out)
(folder/'coverage.json').unlink()
assert all(digest(Path(v['path']).read_bytes())==v['sha256'] for v in original.values())
(folder/'COMPLETE.json').write_text(json.dumps({'exit':0,'profiledInputs':len(observed),'ordinaryBinariesUnchanged':True})+'\n')
