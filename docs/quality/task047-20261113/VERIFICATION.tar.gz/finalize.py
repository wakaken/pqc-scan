import hashlib,json,re,subprocess,tarfile
from pathlib import Path
run=Path('target/quality-task-047/run-20261113');confined=run/'confined';dest=Path('docs/quality/task047-20261113');dest.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text())
host=read(confined/'HOST-RESULTS.json');assert host['exit']==0 and host['sourceBeforeAfterMatch'] and host['containerRemoved']
profile_dir=run/'confined-profile';profile_host=read(profile_dir/'HOST-RESULTS.json');assert profile_host['exit']==0 and profile_host['sourceBeforeAfterMatch'] and profile_host['containerRemoved'] and profile_host['image']==host['image']
coverage=read(profile_dir/'summary.json');assert coverage['profiledInputs']==255 and read(profile_dir/'COMPLETE.json')['exit']==0
assert all(row['ordinaryFeedbackMatches'] for row in read(profile_dir/'profiled-inputs.json'))
commands=read(confined/'commands.json');assert all(c['exit']==0 for c in commands)
fuzz=read(confined/'fuzz-results.json');assert len(fuzz['results'])==18 and fuzz['productFailures']==0
fuzz['results'].extend(read(confined/'supplemental-results.json')['results']);assert len(fuzz['results'])==20
distinct=set();distinct_bytes=set()
for result in fuzz['results']:
 assert result['statuses']=={'completed':result['executed']} and result['executed']>result['seedCount'] and not result['failures']
 folder=confined/'fuzz'/f"{result['mode']}-{result['target']}";seeds=read(folder/'seeds.json')
 import sys
 sys.path.insert(0,'tests/quality')
 from task047.study import generate,digest
 rows=[json.loads(line) for line in (folder/'executions.jsonl').read_text().splitlines()]
 assert len(rows)==result['executed']
 for row in rows:
  name,data,selected=generate(seeds,row['seed'],row['index']);distinct.add((result['target'],name,digest(data)));distinct_bytes.add(digest(data));assert (name,digest(data),len(data),selected)==(row['name'],row['sha256'],row['bytes'],row['selectedSeed'])
 assert all(i in {r['selectedSeed'] for r in rows} for i in range(len(seeds)))
for mode in ['short','long']:
 chosen={r['target']:r for r in fuzz['results'] if r['mode']==mode}
 for target,states in {'output':['output:legacy_six_formats_both_languages','output:native_roundtrip_and_cyclonedx17','output:rejected_references','findings:1'],'output-rich':['output:native_roundtrip_and_cyclonedx17','output:rejected_references'],'SSH':['identification:accepted','packet:accepted','kex:accepted'],'TLS':['tls:incomplete','tls:rejected'],'DER':['public_spki_der:accepted:Complete','public_spki_der:accepted:Unsupported','public_certificate_der:accepted:Complete']}.items():
  assert all(chosen[target]['reachedStates'].get(state,0)>0 for state in states),(mode,target,states)
control=read(confined/'reducer-control.json');assert control['statuses']=={'panic':1} and (confined/'reducer-control/failure/minimal.bin').read_bytes()==b'CRASH'
fuzz.update({'totalInputs':sum(r['executed'] for r in fuzz['results']),'distinctTargetNameInputs':len(distinct),'distinctByteInputs':len(distinct_bytes),'preparationImage':host['image'],'sourceBeforeAfterMatch':True,'containerRemoved':True,'replayValidation':'every recorded input regenerated and SHA-256 checked; all saved seeds exercised in each mode','control':control,'supplementalScope':'populated native-v1 golden, broken references and future vocabulary; exact input-only measurement recipe archived','limitAdjustment':'initial short <=30s/256cases and long <=120s/2048cases per target; earlier 30min/target was a planning proposal','lineRegionCoverage':{'profiledInputs':255,'totals':coverage['totals'],'scope':coverage['denominator'],'artifact':'coverage-summary.json'},'branchCoverage':'Not Measured; no percent inferred from regions','processingStates':'reachedStates describe observed processing outcomes; source coverage is a separate255-input replay'})
for p in [Path('target/quality-task-047'),dest]:(p/'fuzz-results.json').write_text(json.dumps(fuzz,ensure_ascii=False,indent=2)+'\n')
ordinary_files=read(run/'REVIEW-SOURCE.json');assert all(hashlib.sha256((run/'ORDINARY-SOURCE'/f).read_bytes()).hexdigest()==h for f,h in ordinary_files.items())
files=read(run/'REVIEW-SOURCE-R2.json');recipe=run/'supplemental-recipe.py';assert recipe.read_bytes()==(confined/'supplemental-recipe.py').read_bytes();files[str(recipe)]=hashlib.sha256(recipe.read_bytes()).hexdigest();assert all(hashlib.sha256(Path(f).read_bytes()).hexdigest()==h for f,h in files.items())
source={'baseHead':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'files':files,'sourceBindings':['VERIFICATION.tar.gz:confined/HOST-RESULTS.json','VERIFICATION.tar.gz:confined-profile/HOST-RESULTS.json'],'ordinaryPhaseFiles':ordinary_files,'phaseDifference':'normal Rust/workers unchanged; final scripts add only profile case, module and replay corpus; original normal sources archived separately','productLogicCargoRulesSchemasChanged':False,'TLSRuntimeDifference':'cfg(test) module registration only','inheritedSourceArchives':['../task045-20261113/VERIFICATION.tar.gz','../task055-20261113/VERIFICATION.tar.gz','../task046-20261113/VERIFICATION.tar.gz','../task057-20261113/VERIFICATION.tar.gz']};source['scopeSha256']=hashlib.sha256(json.dumps(files,sort_keys=True).encode()).hexdigest()
(dest/'SOURCE.json').write_text(json.dumps(source,indent=2)+'\n')
counts={}
for mode in ['default','all-features']:
 text=(confined/f'{mode}-tests.log').read_text();counts[mode]={k:sum(int(n) for n in re.findall(r'(\d+) '+label,text)) for k,label in [('passed','passed;'),('failed','failed;'),('ignored','ignored;')]}
(dest/'VALIDATION.json').write_text(json.dumps({'source':source,'rust':counts,'commands':commands,'fmt':'exit0 enclosing entry','workerBuild':read(confined/'worker-binaries.json'),'pythonQualityPassed':74,'sourceBeforeAfterMatch':True,'containerRemoved':True,'totalInputs':fuzz['totalInputs'],'campaigns':20,'coverageReplay':{'profiledInputs':255,'totals':coverage['totals'],'host':profile_host,'commands':read(profile_dir/'commands.json'),'ordinaryFeedbackMatches':True},'replayedInputs':fuzz['totalInputs'],'productFailures':0,'syntheticControl':control['failures'][0],'githubActions':'not executed'},indent=2)+'\n')
(dest/'coverage-summary.json').write_text(json.dumps(coverage,indent=2)+'\n')
(Path('target/quality-task-047')/'coverage-summary.json').write_bytes((dest/'coverage-summary.json').read_bytes())
with tarfile.open(dest/'VERIFICATION.tar.gz','w:gz') as tar:
 for p in sorted(run.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(run)))
 for path in files:tar.add(path,arcname='source/'+path)
 tar.add(__file__,arcname='finalize.py')
print({'rust':counts,'totalInputs':fuzz['totalInputs'],'source':source['scopeSha256']})
