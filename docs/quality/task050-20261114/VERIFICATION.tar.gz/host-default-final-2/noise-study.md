# Noise and cache

Each scale/thread group has 1 first-measured + 3 warm samples; min/median/max and all values in resources.json. No filesystem cache flush, no true cold claim. Materialization reads input; first-measured may already be cached. 5 ms polling bounds timer resolution, particularly significant on fast runs. Wall includes launch and output. Sequential measurement avoids intentional competing benchmarks; host load is not controlled.

Current date: 2026-11-13T22:15:17.313227+00:00
