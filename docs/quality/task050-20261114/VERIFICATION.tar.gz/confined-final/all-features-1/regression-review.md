# Regression policy

Preserve TASK-023-ACCEPTANCE.md: unchanged eligible truth TP must not decrease and FP/FN must not increase. Same host/profile/config/input wall or RSS >2x previous warm maximum requires investigation, not automatic numeric CI failure. Threshold revision needs measured noise and maintainer approval. No new threshold or product optimization. Current matrix is new input, not directly comparable to historical corpus. See comparison evidence for preceding same-condition runs.
