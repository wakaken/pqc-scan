# PQC Migration Scan Report

Generated: 2026-11-13 22:26:30.881949 UTC

Risk candidates: 17 / Inventory findings: 35 / Scanned files: 41

Cryptographic references found in source code and configuration.

|Severity|Count (all findings)|
|---|---:|
|critical|4|
|high|3|
|info|35|
|low|1|
|medium|9|

## Risk candidate index

|Rule / description|Severity|Risk|Hits|Files|
|---|---|---|---:|---:|
|[CERT_RSA_1024](#rule-0) Certificate subject public key is 1024-bit RSA.|critical|non-quantum-risk|1|1|
|[CERT_RSA_SIGNATURE](#rule-1) Certificate signed with an RSA-based algorithm detected.|critical|quantum-vulnerable|2|2|
|[PRIVATE_KEY_PKCS8_HEADER](#rule-2) PKCS#8 private key header detected.|critical|non-quantum-risk|1|1|
|[API_SIGNATURE_RSA](#rule-3) RSA signature API usage detected.|high|quantum-vulnerable|1|1|
|[CERT_ECDSA_SIGNATURE](#rule-4) ECDSA certificate signature detected.|high|quantum-vulnerable|1|1|
|[TS_JAVA_RSA_API](#rule-5) RSA-related API symbols detected from Java AST.|high|quantum-vulnerable|1|1|
|[CERT_P12_CONTAINER](#rule-6) PKCS#12/PFX container file detected.|medium|quantum-uncertain|1|1|
|[DEP_OPENSSL](#rule-7) OpenSSL dependency detected.|medium|quantum-uncertain|1|1|
|[DEP_RUST_OPENSSL](#rule-8) Rust TLS/crypto dependency detected.|medium|quantum-uncertain|2|2|
|[PQC_DRAFT_ALGORITHM](#rule-9) Pre-standard PQC algorithm name referenced; check compatibility before replacing it.|medium|quantum-uncertain|1|1|
|[PQC_GO_TLS_DISABLED](#rule-10) Go hybrid TLS default explicitly disabled; inspect effective environment and group overrides.|medium|quantum-uncertain|1|1|
|[PQC_JAVA_CLASSICAL_GROUPS](#rule-11) Explicit classical-only Java property intent in assignment, XML entry or static System.setProperty; ...|medium|quantum-uncertain|2|2|
|[PQC_RUBY_CLASSICAL_GROUPS](#rule-12) Ruby-style group assignment explicitly restricts the recognized list to classical groups.|medium|quantum-uncertain|1|1|
|[CERT_PEM_CONTAINER](#rule-13) PEM/DER cryptographic container detected; certificate presence is not established.|low|quantum-uncertain|1|1|

## Informational inventory index

|Rule / description|Severity|Risk|Hits|Files|
|---|---|---|---:|---:|
|[DEP_PQC_CAPABLE_LIBRARY](#rule-14) Library with version-dependent PQC capabilities inventoried; capability is not an enabled-state find...|info|quantum-uncertain|3|3|
|[PQC_GO_API](#rule-15) Standard Go PQC package imported; import alone does not prove negotiated protection.|info|quantum-safe|1|1|
|[PQC_JAVA_API](#rule-16) Standard PQC algorithm requested through Java APIs; runtime success is not established.|info|quantum-safe|3|3|
|[PQC_NODE_API](#rule-17) Node-style PQC key generation call; bindings and actual execution require confirmation.|info|quantum-safe|5|4|
|[PQC_PYTHON_API](#rule-18) Python PQC key generation reference; backend support is not established.|info|quantum-safe|5|4|
|[PQC_RUBY_API](#rule-19) Ruby PQC algorithm literal referenced; key generation or signing success is not established.|info|quantum-safe|2|2|
|[PQC_RUST_API](#rule-20) Rust PQC crate symbol referenced; execution and protocol use require confirmation.|info|quantum-safe|1|1|
|[PQC_STANDARD_REFERENCE](#rule-21) Standard PQC algorithm or hybrid group name referenced; API execution, enabled state and conformance...|info|quantum-safe|13|12|
|[PQC_WEBCRYPTO_API](#rule-22) WebCrypto-style PQC algorithm request; this is not proof of browser support.|info|quantum-safe|2|2|

<a id="rule-0"></a>

## CERT_RSA_1024

Certificate subject public key is 1024-bit RSA.

Check: Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-0"></a>[tuning/rsa1024.der:1:1](#finding-0)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Prepare hybrid certificate issuance and trust-store rollout](#action-0)

<a id="rule-1"></a>

## CERT_RSA_SIGNATURE

Certificate signed with an RSA-based algorithm detected.

Check: Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-1"></a>[tuning/p256-rsa-signed.der:1:1](#finding-1)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-2"></a>[tuning/rsa1024.der:1:1](#finding-2)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-1)
- [Prepare hybrid certificate issuance and trust-store rollout](#action-0)

<a id="rule-2"></a>

## PRIVATE_KEY_PKCS8_HEADER

PKCS#8 private key header detected.

Check: Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-3"></a>[tuning/marker.pem:1:1](#finding-3)|\[masked-private-key\]|Review private-key markers and rotate exposed live credentials / [Review private-key markers and rotate exposed live credentials](#action-2) / [Source](#source-3)|

<a id="source-3"></a>

### tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="rule-3"></a>

## API_SIGNATURE_RSA

RSA signature API usage detected.

Check: Migrate to ML-DSA signing APIs.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-4"></a>[holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-4)|Signatur***thRSA"|Provide BouncyCastle PQC fallback path / [Upgrade Java runtime baseline for standard PQC APIs](#action-3) / [Provide BouncyCastle PQC fallback path](#action-4) / [Source](#source-4)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-1)
- [Verify deployed runtime and protocol PQC capabilities](#action-5)

<a id="source-4"></a>

### holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="rule-4"></a>

## CERT_ECDSA_SIGNATURE

ECDSA certificate signature detected.

Check: Evaluate ML-DSA and SLH-DSA alternatives.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-5"></a>[tuning/p521.der:1:1](#finding-5)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-1)
- [Prepare hybrid certificate issuance and trust-store rollout](#action-0)

<a id="rule-5"></a>

## TS_JAVA_RSA_API

RSA-related API symbols detected from Java AST.

Check: Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-6"></a>[holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-6)|Signatur***ithRSA|Review the cryptographic reference and its actual purpose / [Review the cryptographic reference and its actual purpose](#action-6) / [Source](#source-6)|

<a id="source-6"></a>

### holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="rule-6"></a>

## CERT_P12_CONTAINER

PKCS#12/PFX container file detected.

Check: Audit algorithms used inside PKCS#12/PFX containers.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-7"></a>[holdout/unsupported.p12:1:1](#finding-7)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Prepare hybrid certificate issuance and trust-store rollout](#action-0)

<a id="rule-7"></a>

## DEP_OPENSSL

OpenSSL dependency detected.

Check: Review the OpenSSL PQC roadmap.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-8"></a>[holdout/sbom.json (line unavailable)](#finding-8)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-8)|

Shared checks for these locations (not verified facts about each line):

- [Track PQC readiness of dependent libraries](#action-7)

<a id="source-8"></a>

### holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="rule-8"></a>

## DEP_RUST_OPENSSL

Rust TLS/crypto dependency detected.

Check: Track PQC migration options for Rust openssl/rustls crypto stacks.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-9"></a>[holdout/sbom.json (line unavailable)](#finding-9)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-9)|
|<a id="finding-10"></a>[tuning/Cargo.toml:3:1](#finding-10)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-10)|

Shared checks for these locations (not verified facts about each line):

- [Track PQC readiness of dependent libraries](#action-7)

<a id="source-9"></a>

### holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-10"></a>

### tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="rule-9"></a>

## PQC_DRAFT_ALGORITHM

Pre-standard PQC algorithm name referenced; check compatibility before replacing it.

Check: Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-11"></a>[tuning/variants/draft.js:1:19](#finding-11)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-11)|

<a id="source-11"></a>

### tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="rule-10"></a>

## PQC_GO_TLS_DISABLED

Go hybrid TLS default explicitly disabled; inspect effective environment and group overrides.

Check: Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-12"></a>[tuning/overrides.conf:1:1](#finding-12)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Review the explicit PQC override: GODEBUG=tlsmlkem=0](#action-8) / [Source](#source-12)|

<a id="source-12"></a>

### tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="rule-11"></a>

## PQC_JAVA_CLASSICAL_GROUPS

Explicit classical-only Java property intent in assignment, XML entry or static System.setProperty; effective loading is not established.

Check: Review explicit group restrictions against the deployed JSSE version and peer support.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-13"></a>[holdout/approval-adapter/archive-policy.xml:6:1](#finding-13)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-13)|
|<a id="finding-14"></a>[tuning/overrides.conf:2:1](#finding-14)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-14)|

Shared checks for these locations (not verified facts about each line):

- [Review the explicit PQC override: jdk.tls.namedGroups](#action-9)

<a id="source-13"></a>

### holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-14"></a>

### tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="rule-12"></a>

## PQC_RUBY_CLASSICAL_GROUPS

Ruby-style group assignment explicitly restricts the recognized list to classical groups.

Check: Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-15"></a>[tuning/overrides.conf:3:1](#finding-15)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Review the explicit PQC override: groups= / ecdh_curves=](#action-10) / [Source](#source-15)|

<a id="source-15"></a>

### tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="rule-13"></a>

## CERT_PEM_CONTAINER

PEM/DER cryptographic container detected; certificate presence is not established.

Check: Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-16"></a>[holdout/misleading-rsa1024.der:1:1](#finding-16)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-16)|

Shared checks for these locations (not verified facts about each line):

- [Prepare hybrid certificate issuance and trust-store rollout](#action-0)

<a id="source-16"></a>

### holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="rule-14"></a>

## DEP_PQC_CAPABLE_LIBRARY

Library with version-dependent PQC capabilities inventoried; capability is not an enabled-state finding.

Check: Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-17"></a>[holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-17)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-17)|
|<a id="finding-18"></a>[holdout/sbom.json (line unavailable)](#finding-18)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-18)|
|<a id="finding-19"></a>[tuning/Cargo.toml:2:1](#finding-19)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-19)|

Shared checks for these locations (not verified facts about each line):

- [Track PQC readiness of dependent libraries](#action-7)

<a id="source-17"></a>

### holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-18"></a>

### holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-19"></a>

### tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="rule-15"></a>

## PQC_GO_API

Standard Go PQC package imported; import alone does not prove negotiated protection.

Check: crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-20"></a>[tuning/example.go:3:8](#finding-20)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-20)|

<a id="source-20"></a>

### tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="rule-16"></a>

## PQC_JAVA_API

Standard PQC algorithm requested through Java APIs; runtime success is not established.

Check: JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-21"></a>[holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-21)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-21)|
|<a id="finding-22"></a>[tuning/Example.java:3:9](#finding-22)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-22)|
|<a id="finding-23"></a>[tuning/variants/dead.java:1:55](#finding-23)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-23)|

<a id="source-21"></a>

### holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-22"></a>

### tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-23"></a>

### tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="rule-17"></a>

## PQC_NODE_API

Node-style PQC key generation call; bindings and actual execution require confirmation.

Check: Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-24"></a>[holdout/approval-adapter/rotation_queue.js:6:3](#finding-24)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-24)|
|<a id="finding-25"></a>[tuning/example.js:1:1](#finding-25)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-25)|
|<a id="finding-26"></a>[tuning/variants/alias.js:2:1](#finding-26)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-26)|
|<a id="finding-27"></a>[tuning/variants/twice.js:1:1](#finding-27)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-27)|
|<a id="finding-28"></a>[tuning/variants/twice.js:1:36](#finding-28)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-28)|

<a id="source-24"></a>

### holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-25"></a>

### tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-26"></a>

### tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-27"></a>

### tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-28"></a>

### tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="rule-18"></a>

## PQC_PYTHON_API

Python PQC key generation reference; backend support is not established.

Check: cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-29"></a>[holdout/approval-adapter/approval_backend.py:3:1](#finding-29)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-29)|
|<a id="finding-30"></a>[tuning/example.py:1:1](#finding-30)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-30)|
|<a id="finding-31"></a>[tuning/variants/alias.py:1:1](#finding-31)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-31)|
|<a id="finding-32"></a>[tuning/variants/alias.py:2:1](#finding-32)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-32)|
|<a id="finding-33"></a>[tuning/variants/broken.py:1:1](#finding-33)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-33)|

<a id="source-29"></a>

### holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-30"></a>

### tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-31"></a>

### tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-32"></a>

### tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-33"></a>

### tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="rule-19"></a>

## PQC_RUBY_API

Ruby PQC algorithm literal referenced; key generation or signing success is not established.

Check: Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-34"></a>[tuning/example.rb:1:28](#finding-34)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-34)|
|<a id="finding-35"></a>[tuning/variants/display.rb:1:6](#finding-35)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-35)|

<a id="source-34"></a>

### tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-35"></a>

### tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="rule-20"></a>

## PQC_RUST_API

Rust PQC crate symbol referenced; execution and protocol use require confirmation.

Check: Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-36"></a>[tuning/example.rs:1:5](#finding-36)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-36)|

<a id="source-36"></a>

### tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="rule-21"></a>

## PQC_STANDARD_REFERENCE

Standard PQC algorithm or hybrid group name referenced; API execution, enabled state and conformance are not established.

Check: A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-37"></a>[holdout/approval-adapter/rotation_queue.js:7:6](#finding-37)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-37)|
|<a id="finding-38"></a>[tuning/example.js:1:22](#finding-38)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-38)|
|<a id="finding-39"></a>[tuning/example.rb:1:29](#finding-39)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-39)|
|<a id="finding-40"></a>[tuning/example.rs:1:13](#finding-40)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-40)|
|<a id="finding-41"></a>[tuning/example.ts:1:28](#finding-41)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-41)|
|<a id="finding-42"></a>[tuning/negative.js:3:16](#finding-42)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-42)|
|<a id="finding-43"></a>[tuning/variants/alias.js:2:7](#finding-43)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-43)|
|<a id="finding-44"></a>[tuning/variants/display.rb:1:7](#finding-44)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-44)|
|<a id="finding-45"></a>[tuning/variants/draft.js:2:21](#finding-45)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-45)|
|<a id="finding-46"></a>[tuning/variants/shadow.js:2:22](#finding-46)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-46)|
|<a id="finding-47"></a>[tuning/variants/twice.js:1:22](#finding-47)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-47)|
|<a id="finding-48"></a>[tuning/variants/twice.js:1:57](#finding-48)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-48)|
|<a id="finding-49"></a>[tuning/variants/typed.ts:1:64](#finding-49)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-49)|

<a id="source-37"></a>

### holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-38"></a>

### tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-39"></a>

### tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-40"></a>

### tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-41"></a>

### tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-42"></a>

### tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-43"></a>

### tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-44"></a>

### tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-45"></a>

### tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-46"></a>

### tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-47"></a>

### tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-48"></a>

### tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-49"></a>

### tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="rule-22"></a>

## PQC_WEBCRYPTO_API

WebCrypto-style PQC algorithm request; this is not proof of browser support.

Check: Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-50"></a>[tuning/example.ts:1:8](#finding-50)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-50)|
|<a id="finding-51"></a>[tuning/variants/typed.ts:1:44](#finding-51)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-51)|

<a id="source-50"></a>

### tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-51"></a>

### tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

## Action details

Each location links only to its applicable action. Identical payloads are printed once.

<a id="action-0"></a>


#### Prepare hybrid certificate issuance and trust-store rollout (near-term)

PKI updates require coordinated CA, chain, and relying-party compatibility planning.

1. Inventory certificate signature algorithms and key sizes from CBOM/report output.
2. Pilot hybrid chain issuance in non-production trust stores.
3. Define reissuance plan for quantum-vulnerable roots/intermediates/end-entity certs.

References:

- https://csrc.nist.gov/pubs/fips/204/final
- https://csrc.nist.gov/pubs/fips/205/final
<a id="action-1"></a>


#### Adopt a phased hybrid PQC migration plan (near-term)

The detected primitive is vulnerable to cryptographically relevant quantum attacks. Hybrid rollout minimizes compatibility risk.

1. Inventory all call sites using this algorithm and owner teams.
2. Check for an existing classical + PQC composition; if migration is needed, evaluate compatible staged or hybrid modes before hard cut-over.
3. Define retirement dates for legacy classical algorithms.

References:

- https://www.nist.gov/itl/post-quantum-cryptography
- https://csrc.nist.gov/pubs/fips/203/final
- https://csrc.nist.gov/pubs/fips/204/final
<a id="action-2"></a>


#### Review private-key markers and rotate exposed live credentials (immediate)

A private-key marker was found. Confirm whether complete key material is present and whether it belongs to a live exposed credential; the marker alone does not establish an incident.

1. Check whether the signal is a header reference, a synthetic test key, or complete live key material.
2. If a live credential is exposed, revoke or replace it and invalidate affected sessions/tokens as appropriate.
3. Move keys to a secret manager or HSM and enforce commit scanning in CI.

References:

- https://cheatsheetseries.owasp.org/cheatsheets/Secrets_Management_Cheat_Sheet.html
<a id="action-3"></a>


#### Upgrade Java runtime baseline for standard PQC APIs (planned)

Detected Java version appears older than JDK releases with standardized PQC APIs.

1. Target JDK 24+ for ML-KEM and ML-DSA support planning.
2. Pilot compatibility testing in CI before production migration.

References:

- https://openjdk.org/jeps/496
- https://openjdk.org/jeps/497
<a id="action-4"></a>


#### Provide BouncyCastle PQC fallback path (near-term)

BouncyCastle can be used as a pragmatic transition option when standard runtime support is unavailable or incomplete.

1. Add BC provider initialization at bootstrap.
2. Use BC ML-DSA / ML-KEM parameter specs for migration pilot implementations.
3. Document provider ordering and FIPS/compliance impact.

References:

- https://www.bouncycastle.org/java.html
- https://downloads.bouncycastle.org/java/docs/bcprov-jdk18on-javadoc/

Before (java)

    Security.addProvider(new BouncyCastleProvider());
    Signature sig = Signature.getInstance("SHA256withRSA", "BC");

After

    Security.addProvider(new BouncyCastlePQCProvider());
    Signature sig = Signature.getInstance("ML-DSA", "BCPQC");
    // Configure parameter set (example): MLDSAParameterSpec.ml_dsa_65

<a id="action-5"></a>


#### Verify deployed runtime and protocol PQC capabilities (planned)

Source declarations and primitive availability do not establish deployment or peer support.

1. JDK 24 adds ML-KEM and ML-DSA primitives. Check deployed JSSE hybrid TLS support separately and inspect jdk.tls.namedGroups restrictions.
2. Check resolved versions, provider/features and interoperability before changing production policy.

References:

- https://docs.oracle.com/en/java/javase/27/security/java-secure-socket-extension-jsse-reference-guide.html
<a id="action-6"></a>


#### Review the cryptographic reference and its actual purpose (planned)

A source reference does not establish active signing, JWT issuance, or the absence of an existing PQC/hybrid composition.

1. Identify key generation, signing, verification, encryption or key establishment and separate tests/examples from deployed use.
2. Check existing PQC or hybrid components, provider support and protocol compatibility before selecting a change.

References:

- https://www.nist.gov/itl/post-quantum-cryptography
<a id="action-7"></a>


#### Track PQC readiness of dependent libraries (planned)

Dependency-level crypto libraries strongly influence migration options and operational timelines.

1. Record current versions in dependency-sbom.json and define upgrade targets.
2. Subscribe to release notes for PQC feature availability and API changes.
3. Run integration tests for PQC or hybrid modes before promoting to production.

References:

- https://cyclonedx.org/
- https://spdx.dev/
<a id="action-8"></a>


#### Review the explicit PQC override: GODEBUG=tlsmlkem=0 (near-term)

The detected setting restricts hybrid key exchange. It does not establish RSA usage or the negotiated TLS version.

1. Inspect GODEBUG=tlsmlkem=0 at this location and confirm why the override is required.
2. Verify deployed library and peer support before testing a hybrid group or removing the override.
3. Check key exchange, TLS protocol version and certificate signatures separately; TLS 1.3 alone does not establish PQC protection.

References:

- https://go.dev/doc/godebug
- https://www.rfc-editor.org/rfc/rfc9325.html#section-3.1.1
<a id="action-9"></a>


#### Review the explicit PQC override: jdk.tls.namedGroups (near-term)

The detected setting restricts hybrid key exchange. It does not establish RSA usage or the negotiated TLS version.

1. Inspect jdk.tls.namedGroups at this location and confirm why the override is required.
2. Verify deployed library and peer support before testing a hybrid group or removing the override.
3. Check key exchange, TLS protocol version and certificate signatures separately; TLS 1.3 alone does not establish PQC protection.

References:

- https://go.dev/doc/godebug
- https://www.rfc-editor.org/rfc/rfc9325.html#section-3.1.1
<a id="action-10"></a>


#### Review the explicit PQC override: groups= / ecdh_curves= (near-term)

The detected setting restricts hybrid key exchange. It does not establish RSA usage or the negotiated TLS version.

1. Inspect groups= / ecdh_curves= at this location and confirm why the override is required.
2. Verify deployed library and peer support before testing a hybrid group or removing the override.
3. Check key exchange, TLS protocol version and certificate signatures separately; TLS 1.3 alone does not establish PQC protection.

References:

- https://go.dev/doc/godebug
- https://www.rfc-editor.org/rfc/rfc9325.html#section-3.1.1

## Inventory exports

- [CBOM](cbom.json): 50
- [Dependency SBOM](dependency-sbom.json): 6


## Inspection coverage

Completeness covers supported inspection within the declared scope, after ignore settings, exclusions and size limits. It does not prove runtime use, certificate trust or security. Unenumerated files remain unknown.

|Item|Value|
|---|---|
|Status|Some inspection could not complete (partial)|
|Selected files|41|
|Read successfully|41|
|Read failed|0|
|Analyzed|36|
|Partial|4|
|Analysis failed|0|
|Unsupported|0|
|Not applicable|0|
|Unknown|1|
|Enumerated exclusions|0|
|Enumeration failures|0|
|Unenumerated population|Unknown|

## Inspection diagnostics

Counts and up to three example paths per reason; full records remain in diagnostics JSON.

|Item|Value|
|---|---|
|Detector failed (detector_failed)|1 records; holdout/broken-sbom.json|
|Detector does not report completeness (detector_not_reported)|1 records; |
|Only part of inspection completed (detector_partial)|3 records; holdout/misleading-rsa1024.der; holdout/unsupported.p12; tuning/variants/broken.py|
