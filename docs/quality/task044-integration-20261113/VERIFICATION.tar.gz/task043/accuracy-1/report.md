# PQC Migration Scan Report

Generated: 2026-11-13 06:45:54.433318 UTC

Risk candidates: 102 / Inventory findings: 114 / Scanned files: 206

Cryptographic references found in source code and configuration.

|Severity|Count (all findings)|
|---|---:|
|critical|13|
|high|23|
|info|114|
|low|4|
|medium|62|

## Risk candidate index

|Rule / description|Severity|Risk|Hits|Files|
|---|---|---|---:|---:|
|[CERT_RSA_SIGNATURE](#rule-0) Certificate signed with an RSA-based algorithm detected.|critical|quantum-vulnerable|6|6|
|[JWT_RS256](#rule-1) RS256 algorithm name referenced; active signing and effective policy are not established.|critical|quantum-vulnerable|2|2|
|[PRIVATE_KEY_OPENSSH_HEADER](#rule-2) OpenSSH private key header detected.|critical|non-quantum-risk|1|1|
|[PRIVATE_KEY_PKCS8_HEADER](#rule-3) PKCS#8 private key header detected.|critical|non-quantum-risk|1|1|
|[PRIVATE_KEY_RSA_HEADER](#rule-4) RSA private key header detected.|critical|non-quantum-risk|1|1|
|[TS_JWT_RSA_ALGS](#rule-5) RSA-family JWT signing algorithms detected in AST nodes.|critical|quantum-vulnerable|2|2|
|[API_CIPHER_RSA](#rule-6) RSA cipher API usage detected.|high|quantum-vulnerable|1|1|
|[API_JOSE_RSA_ALG](#rule-7) RSA-family JOSE algorithm detected.|high|quantum-vulnerable|2|2|
|[API_SIGNATURE_RSA](#rule-8) RSA signature API usage detected.|high|quantum-vulnerable|1|1|
|[CERT_ECDSA_SIGNATURE](#rule-9) ECDSA certificate signature detected.|high|quantum-vulnerable|1|1|
|[CERT_RSA_3072](#rule-10) Certificate subject public key is 3072-bit RSA.|high|quantum-vulnerable|6|6|
|[ENVOY_TLS_MIN_VERSION_LEGACY](#rule-11) Envoy configuration allows TLSv1.0/1.1.|high|non-quantum-risk|1|1|
|[HAPROXY_BIND_TLSV1](#rule-12) HAProxy configuration explicitly enables TLSv1.0/1.1.|high|non-quantum-risk|1|1|
|[HTTPD_SSLPROTOCOL_LEGACY](#rule-13) Legacy TLSv1.x is enabled in Apache httpd configuration.|high|non-quantum-risk|1|1|
|[ISTIO_DESTINATIONRULE_TLSV1](#rule-14) Istio configuration permits TLSv1.0/1.1.|high|non-quantum-risk|1|1|
|[ISTIO_GATEWAY_TLSV1](#rule-15) TLSv1.0/1.1 setting detected in Istio Gateway configuration.|high|non-quantum-risk|1|1|
|[K8S_INGRESS_RSA_CIPHERS](#rule-16) RSA or weak cipher suites are configured in a Kubernetes Ingress annotation.|high|quantum-vulnerable|1|1|
|[NGINX_SSL_CIPHERS_RSA](#rule-17) RSA or weak cipher suites detected in nginx configuration.|high|quantum-vulnerable|1|1|
|[SSH_DSS_SIGALG](#rule-18) Deprecated ssh-dss usage detected.|high|non-quantum-risk|1|1|
|[TLS_VERSION_1_0](#rule-19) TLS 1.0 name referenced; effective configuration and runtime use are not established.|high|non-quantum-risk|2|2|
|[TS_JAVA_RSA_API](#rule-20) RSA-related API symbols detected from Java AST.|high|quantum-vulnerable|2|2|
|[API_NODE_CRYPTO_SIGN_RSA](#rule-21) Node.js RSA signing API usage detected.|medium|quantum-vulnerable|4|1|
|[CERT_P12_CONTAINER](#rule-22) PKCS#12/PFX container file detected.|medium|quantum-uncertain|6|6|
|[DEP_BOUNCYCASTLE](#rule-23) BouncyCastle dependency detected.|medium|quantum-uncertain|4|4|
|[DEP_JAVA_BOUNCYCASTLE](#rule-24) Java BouncyCastle dependency detected.|medium|quantum-uncertain|4|4|
|[DEP_OPENSSL](#rule-25) OpenSSL dependency detected.|medium|quantum-uncertain|13|13|
|[DEP_PYCA_CRYPTOGRAPHY](#rule-26) Python cryptography dependency detected.|medium|quantum-uncertain|3|3|
|[DEP_RUBY_OPENSSL](#rule-27) Ruby OpenSSL dependency detected.|medium|quantum-uncertain|5|5|
|[DEP_RUST_OPENSSL](#rule-28) Rust TLS/crypto dependency detected.|medium|quantum-uncertain|1|1|
|[JWT_LIB_JOSE](#rule-29) jose dependency detected.|medium|quantum-uncertain|3|3|
|[PQC_DRAFT_ALGORITHM](#rule-30) Pre-standard PQC algorithm name referenced; check compatibility before replacing it.|medium|quantum-uncertain|1|1|
|[PQC_JAVA_CLASSICAL_GROUPS](#rule-31) Explicit classical-only Java property intent in assignment, XML entry or static System.setProperty; ...|medium|quantum-uncertain|1|1|
|[SSH_DH_GROUP14_SHA1](#rule-32) SHA-1 dependent SSH KEX detected.|medium|non-quantum-risk|1|1|
|[TRAEFIK_TLS_OPTIONS_LEGACY](#rule-33) Traefik configuration contains a low minimum TLS version.|medium|non-quantum-risk|1|1|
|[TS_CLASSICAL_EC_API](#rule-34) Classical elliptic-curve API reference; deployment and effective configuration require confirmation.|medium|quantum-vulnerable|1|1|
|[TS_CLASSICAL_EDDSA_API](#rule-35) Classical EdDSA or curve key-generation API reference.|medium|quantum-vulnerable|1|1|
|[TS_NODE_JOSE_USAGE](#rule-36) JOSE/JWT calls detected from JavaScript/TypeScript AST.|medium|quantum-uncertain|5|2|
|[TS_NODE_RSA_USAGE](#rule-37) RSA-related API symbols detected from JavaScript/TypeScript AST.|medium|quantum-vulnerable|8|4|
|[CERT_PEM_CONTAINER](#rule-38) PEM/DER cryptographic container detected; certificate presence is not established.|low|quantum-uncertain|4|4|

## Informational inventory index

|Rule / description|Severity|Risk|Hits|Files|
|---|---|---|---:|---:|
|[DEP_PQC_CAPABLE_LIBRARY](#rule-39) Library with version-dependent PQC capabilities inventoried; capability is not an enabled-state find...|info|quantum-uncertain|21|21|
|[PQC_GO_API](#rule-40) Standard Go PQC package imported; import alone does not prove negotiated protection.|info|quantum-safe|1|1|
|[PQC_JAVA_API](#rule-41) Standard PQC algorithm requested through Java APIs; runtime success is not established.|info|quantum-safe|5|5|
|[PQC_NODE_API](#rule-42) Node-style PQC key generation call; bindings and actual execution require confirmation.|info|quantum-safe|15|8|
|[PQC_PYTHON_API](#rule-43) Python PQC key generation reference; backend support is not established.|info|quantum-safe|3|2|
|[PQC_RUBY_API](#rule-44) Ruby PQC algorithm literal referenced; key generation or signing success is not established.|info|quantum-safe|2|2|
|[PQC_RUST_API](#rule-45) Rust PQC crate symbol referenced; execution and protocol use require confirmation.|info|quantum-safe|6|3|
|[PQC_STANDARD_REFERENCE](#rule-46) Standard PQC algorithm or hybrid group name referenced; API execution, enabled state and conformance...|info|quantum-safe|59|25|
|[PQC_WEBCRYPTO_API](#rule-47) WebCrypto-style PQC algorithm request; this is not proof of browser support.|info|quantum-safe|2|2|

<a id="rule-0"></a>

## CERT_RSA_SIGNATURE

Certificate signed with an RSA-based algorithm detected.

Check: Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-0"></a>[tuning/certs/public-rsa3072.cer:1:1](#finding-0)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-1"></a>[tuning/certs/public-rsa3072.crt:1:1](#finding-1)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-2"></a>[tuning/certs/public-rsa3072.pem:1:1](#finding-2)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / [Source](#source-2)|
|<a id="finding-3"></a>[tuning/certs/rsa3072.der:1:1](#finding-3)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-4"></a>[tuning/width/public-unencrypted.p12:1:1](#finding-4)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-5"></a>[tuning/width/public-unencrypted.pfx:1:1](#finding-5)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)

<a id="source-2"></a>

### tuning/certs/public-rsa3072.pem:1:1

    > 1 -----BEGIN CERTIFICATE-----
      2 [masked-sensitive-content]
      3 c2Nhbi1wdWJsaWMtdGVzdDAeFw0yNjExMDkwNzU1NTFaFw0zNjExMDYwNzU1NTFa

<a id="rule-1"></a>

## JWT_RS256

RS256 algorithm name referenced; active signing and effective policy are not established.

Check: Confirm whether this reference belongs to active signing, verification, tests or documentation; assess JOSE formats and peer/library support before selecting PQC signatures.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-6"></a>[holdout/jwt-rsa.js:2:64](#finding-6)|RS256|Confirm whether this reference belongs to active signing, verification, tests or documentation; assess JOSE formats and peer/library support before selecting PQC signatures. / [Source](#source-6)|
|<a id="finding-7"></a>[tuning/jwt/sign.js:1:33](#finding-7)|RS256|Confirm whether this reference belongs to active signing, verification, tests or documentation; assess JOSE formats and peer/library support before selecting PQC signatures. / [Source](#source-7)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Review whether the JOSE reference is used for signing, verification, tests or documentation](#action-2)
- [Upgrade Node.js runtime for built-in WebCrypto PQC support](#action-3)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-6"></a>

### holdout/jwt-rsa.js:2:64

      1 var privateKey = fs.readFileSync('private.key');
    > 2 var token = jwt.sign({ foo: 'bar' }, privateKey, { algorithm: 'RS256' });

<a id="source-7"></a>

### tuning/jwt/sign.js:1:33

    > 1 sign(payload, key, {algorithm: "RS256"});

<a id="rule-2"></a>

## PRIVATE_KEY_OPENSSH_HEADER

OpenSSH private key header detected.

Check: Confirm whether this marker belongs to a complete live OpenSSH key. If a live key is exposed, treat it as an urgent incident and rotate it.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-8"></a>[tuning/markers/PRIVATE_KEY_OPENSSH_HEADER/marker.txt:1:1](#finding-8)|\[masked-private-key\]|Review private-key markers and rotate exposed live credentials / [Review private-key markers and rotate exposed live credentials](#action-5) / [Source](#source-8)|

<a id="source-8"></a>

### tuning/markers/PRIVATE_KEY_OPENSSH_HEADER/marker.txt:1:1

    > 1 [masked-private-key-material]

<a id="rule-3"></a>

## PRIVATE_KEY_PKCS8_HEADER

PKCS#8 private key header detected.

Check: Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-9"></a>[tuning/markers/PRIVATE_KEY_PKCS8_HEADER/marker.txt:1:1](#finding-9)|\[masked-private-key\]|Review private-key markers and rotate exposed live credentials / [Review private-key markers and rotate exposed live credentials](#action-5) / [Source](#source-9)|

<a id="source-9"></a>

### tuning/markers/PRIVATE_KEY_PKCS8_HEADER/marker.txt:1:1

    > 1 [masked-private-key-material]

<a id="rule-4"></a>

## PRIVATE_KEY_RSA_HEADER

RSA private key header detected.

Check: Confirm whether this is a header example, test key or complete live key. If a live key is exposed, revoke or rotate it and review key handling.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-10"></a>[tuning/markers/PRIVATE_KEY_RSA_HEADER/marker.txt:1:1](#finding-10)|\[masked-private-key\]|Review private-key markers and rotate exposed live credentials / [Review private-key markers and rotate exposed live credentials](#action-5) / [Source](#source-10)|

<a id="source-10"></a>

### tuning/markers/PRIVATE_KEY_RSA_HEADER/marker.txt:1:1

    > 1 [masked-private-key-material]

<a id="rule-5"></a>

## TS_JWT_RSA_ALGS

RSA-family JWT signing algorithms detected in AST nodes.

Check: Confirm whether this reference belongs to active signing, verification, tests or documentation; assess JOSE formats and peer/library support before selecting PQC signatures.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-11"></a>[holdout/jwt-rsa.js:2:64](#finding-11)|RS256|Confirm whether this reference belongs to active signing, verification, tests or documentation; assess JOSE formats and peer/library support before selecting PQC signatures. / [Source](#source-11)|
|<a id="finding-12"></a>[tuning/jwt/sign.js:1:33](#finding-12)|RS256|Confirm whether this reference belongs to active signing, verification, tests or documentation; assess JOSE formats and peer/library support before selecting PQC signatures. / [Source](#source-12)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Review whether the JOSE reference is used for signing, verification, tests or documentation](#action-2)
- [Upgrade Node.js runtime for built-in WebCrypto PQC support](#action-3)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-11"></a>

### holdout/jwt-rsa.js:2:64

      1 var privateKey = fs.readFileSync('private.key');
    > 2 var token = jwt.sign({ foo: 'bar' }, privateKey, { algorithm: 'RS256' });

<a id="source-12"></a>

### tuning/jwt/sign.js:1:33

    > 1 sign(payload, key, {algorithm: "RS256"});

<a id="rule-6"></a>

## API_CIPHER_RSA

RSA cipher API usage detected.

Check: Review the purpose of this RSA reference and whether it is already a classical component of a hybrid design; assess compatible KEM and AEAD choices.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-13"></a>[tuning/encryption/Encrypt.java:1:1](#finding-13)|Cipher.g***e("RSA|Review the cryptographic reference and its actual purpose / [Review the cryptographic reference and its actual purpose](#action-6) / [Source](#source-13)|

<a id="source-13"></a>

### tuning/encryption/Encrypt.java:1:1

    > 1 Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");

<a id="rule-7"></a>

## API_JOSE_RSA_ALG

RSA-family JOSE algorithm detected.

Check: Update JOSE algorithms to PQC-ready alternatives.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-14"></a>[holdout/jwt-rsa.js:2:64](#finding-14)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-14)|
|<a id="finding-15"></a>[tuning/jwt/sign.js:1:33](#finding-15)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-15)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Introduce crypto abstraction boundary for algorithm agility](#action-7)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-14"></a>

### holdout/jwt-rsa.js:2:64

      1 var privateKey = fs.readFileSync('private.key');
    > 2 var token = jwt.sign({ foo: 'bar' }, privateKey, { algorithm: 'RS256' });

<a id="source-15"></a>

### tuning/jwt/sign.js:1:33

    > 1 sign(payload, key, {algorithm: "RS256"});

<a id="rule-8"></a>

## API_SIGNATURE_RSA

RSA signature API usage detected.

Check: Migrate to ML-DSA signing APIs.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-16"></a>[tuning/java/Neg.java:1:1](#finding-16)|Signatur***thRSA"|Provide BouncyCastle PQC fallback path / [Upgrade Java runtime baseline for standard PQC APIs](#action-8) / [Provide BouncyCastle PQC fallback path](#action-9) / [Source](#source-16)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Verify deployed runtime and protocol PQC capabilities](#action-10)

<a id="source-16"></a>

### tuning/java/Neg.java:1:1

    > 1 Signature.getInstance("SHA256withRSA");

<a id="rule-9"></a>

## CERT_ECDSA_SIGNATURE

ECDSA certificate signature detected.

Check: Evaluate ML-DSA and SLH-DSA alternatives.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-17"></a>[tuning/certs/p256.der:1:1](#finding-17)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)

<a id="rule-10"></a>

## CERT_RSA_3072

Certificate subject public key is 3072-bit RSA.

Check: Evaluate standardized PQC signatures in supported issuance and verification environments.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-18"></a>[tuning/certs/public-rsa3072.cer:1:1](#finding-18)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / Source unavailable|
|<a id="finding-19"></a>[tuning/certs/public-rsa3072.crt:1:1](#finding-19)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / Source unavailable|
|<a id="finding-20"></a>[tuning/certs/public-rsa3072.pem:1:1](#finding-20)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / [Source](#source-20)|
|<a id="finding-21"></a>[tuning/certs/rsa3072.der:1:1](#finding-21)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / Source unavailable|
|<a id="finding-22"></a>[tuning/width/public-unencrypted.p12:1:1](#finding-22)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / Source unavailable|
|<a id="finding-23"></a>[tuning/width/public-unencrypted.pfx:1:1](#finding-23)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)

<a id="source-20"></a>

### tuning/certs/public-rsa3072.pem:1:1

    > 1 -----BEGIN CERTIFICATE-----
      2 [masked-sensitive-content]
      3 c2Nhbi1wdWJsaWMtdGVzdDAeFw0yNjExMDkwNzU1NTFaFw0zNjExMDYwNzU1NTFa

<a id="rule-11"></a>

## ENVOY_TLS_MIN_VERSION_LEGACY

Envoy configuration allows TLSv1.0/1.1.

Check: Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-24"></a>[tuning/width/envoy/selection.conf:1:1](#finding-24)|tls_mini***LSv1_0|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Validate Envoy PQC signature compatibility in control/data planes](#action-11) / [Source](#source-24)|

<a id="source-24"></a>

### tuning/width/envoy/selection.conf:1:1

    > 1 tls_minimum_protocol_version: TLSv1_0

<a id="rule-12"></a>

## HAPROXY_BIND_TLSV1

HAProxy configuration explicitly enables TLSv1.0/1.1.

Check: Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-25"></a>[tuning/width/haproxy/selection.conf:1:1](#finding-25)|bind :44***tlsv10|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Validate HAProxy TLS stack PQC signature readiness before production](#action-12) / [Source](#source-25)|

<a id="source-25"></a>

### tuning/width/haproxy/selection.conf:1:1

    > 1 bind :443 ssl force-tlsv10

<a id="rule-13"></a>

## HTTPD_SSLPROTOCOL_LEGACY

Legacy TLSv1.x is enabled in Apache httpd configuration.

Check: Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-26"></a>[tuning/width/apache/selection.conf:1:1](#finding-26)|SSLProtocol TLSv1.0|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Source](#source-26)|

<a id="source-26"></a>

### tuning/width/apache/selection.conf:1:1

    > 1 SSLProtocol TLSv1.0

<a id="rule-14"></a>

## ISTIO_DESTINATIONRULE_TLSV1

Istio configuration permits TLSv1.0/1.1.

Check: Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-27"></a>[tuning/width/istio/selection.conf:1:1](#finding-27)|minProto***LSV1_0|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Validate Istio mesh-wide PQC signature interoperability before enforcement](#action-13) / [Source](#source-27)|

<a id="source-27"></a>

### tuning/width/istio/selection.conf:1:1

    > 1 minProtocolVersion: TLSV1_0

<a id="rule-15"></a>

## ISTIO_GATEWAY_TLSV1

TLSv1.0/1.1 setting detected in Istio Gateway configuration.

Check: Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-28"></a>[tuning/width/istio/selection.conf:1:1](#finding-28)|minProto***LSV1_0|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Validate Istio mesh-wide PQC signature interoperability before enforcement](#action-13) / [Source](#source-28)|

<a id="source-28"></a>

### tuning/width/istio/selection.conf:1:1

    > 1 minProtocolVersion: TLSV1_0

<a id="rule-16"></a>

## K8S_INGRESS_RSA_CIPHERS

RSA or weak cipher suites are configured in a Kubernetes Ingress annotation.

Check: Remove RSA key-exchange dependency from Ingress cipher suites.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-29"></a>[tuning/width/kubernetes/selection.conf:1:1](#finding-29)|nginx.in***s: RSA|Remove RSA key-exchange dependency from Ingress cipher suites. / [Validate Kubernetes PQC signature readiness before production rollout](#action-14) / [Source](#source-29)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)

<a id="source-29"></a>

### tuning/width/kubernetes/selection.conf:1:1

    > 1 nginx.ingress.kubernetes.io/ssl-ciphers: RSA

<a id="rule-17"></a>

## NGINX_SSL_CIPHERS_RSA

RSA or weak cipher suites detected in nginx configuration.

Check: Refresh nginx cipher suites for PQC-hybrid migration readiness.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-30"></a>[tuning/width/nginx/selection.conf:1:1](#finding-30)|ssl_ciphers RSA|Refresh nginx cipher suites for PQC-hybrid migration readiness. / [Validate nginx/OpenSSL PQC signature interoperability before rollout](#action-15) / [Source](#source-30)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)

<a id="source-30"></a>

### tuning/width/nginx/selection.conf:1:1

    > 1 ssl_ciphers RSA;

<a id="rule-18"></a>

## SSH_DSS_SIGALG

Deprecated ssh-dss usage detected.

Check: Disable ssh-dss.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-31"></a>[tuning/ssh/dsa.conf:1:19](#finding-31)|ssh-dss|Disable ssh-dss. / [Source](#source-31)|

<a id="source-31"></a>

### tuning/ssh/dsa.conf:1:19

    > 1 HostKeyAlgorithms ssh-dss

<a id="rule-19"></a>

## TLS_VERSION_1_0

TLS 1.0 name referenced; effective configuration and runtime use are not established.

Check: First distinguish constants, comments and test references from effective configuration. Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-32"></a>[tuning/width/apache/selection.conf:1:12](#finding-32)|TLSv1.0|First distinguish constants, comments and test references from effective configuration. Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Source](#source-32)|
|<a id="finding-33"></a>[tuning/width/envoy/selection.conf:1:30](#finding-33)|TLSv1_0|First distinguish constants, comments and test references from effective configuration. Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Source](#source-33)|

Shared checks for these locations (not verified facts about each line):

- [Review the TLS reference before changing effective settings](#action-16)

<a id="source-32"></a>

### tuning/width/apache/selection.conf:1:12

    > 1 SSLProtocol TLSv1.0

<a id="source-33"></a>

### tuning/width/envoy/selection.conf:1:30

    > 1 tls_minimum_protocol_version: TLSv1_0

<a id="rule-20"></a>

## TS_JAVA_RSA_API

RSA-related API symbols detected from Java AST.

Check: Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-34"></a>[tuning/encryption/Encrypt.java:1:1](#finding-34)|Cipher.g***e("RSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-34)|
|<a id="finding-35"></a>[tuning/java/Neg.java:1:1](#finding-35)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-35)|

Shared checks for these locations (not verified facts about each line):

- [Review the cryptographic reference and its actual purpose](#action-6)

<a id="source-34"></a>

### tuning/encryption/Encrypt.java:1:1

    > 1 Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");

<a id="source-35"></a>

### tuning/java/Neg.java:1:1

    > 1 Signature.getInstance("SHA256withRSA");

<a id="rule-21"></a>

## API_NODE_CRYPTO_SIGN_RSA

Node.js RSA signing API usage detected.

Check: Plan PQC replacement for node:crypto RSA operations.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-36"></a>[holdout/rsa-sign.js:11:14](#finding-36)|createSign('SHA256'|Plan PQC replacement for node:crypto RSA operations. / [Source](#source-36)|
|<a id="finding-37"></a>[holdout/rsa-sign.js:14:19](#finding-37)|sign.sign(privateKey|Plan PQC replacement for node:crypto RSA operations. / [Source](#source-37)|
|<a id="finding-38"></a>[holdout/rsa-sign.js:16:16](#finding-38)|createVe***HA256'|Plan PQC replacement for node:crypto RSA operations. / [Source](#source-38)|
|<a id="finding-39"></a>[holdout/rsa-sign.js:19:13](#finding-39)|verify.v***licKey|Plan PQC replacement for node:crypto RSA operations. / [Source](#source-39)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Introduce crypto abstraction boundary for algorithm agility](#action-7)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-36"></a>

### holdout/rsa-sign.js:11:14

      9 });
      10 
    > 11 const sign = createSign('SHA256');
      12 sign.update('some data to sign');
      13 sign.end();

<a id="source-37"></a>

### holdout/rsa-sign.js:14:19

      12 sign.update('some data to sign');
      13 sign.end();
    > 14 const signature = sign.sign(privateKey);
      15 
      16 const verify = createVerify('SHA256');

<a id="source-38"></a>

### holdout/rsa-sign.js:16:16

      14 const signature = sign.sign(privateKey);
      15 
    > 16 const verify = createVerify('SHA256');
      17 verify.update('some data to sign');
      18 verify.end();

<a id="source-39"></a>

### holdout/rsa-sign.js:19:13

      17 verify.update('some data to sign');
      18 verify.end();
    > 19 console.log(verify.verify(publicKey, signature));
      20 // Prints: true

<a id="rule-22"></a>

## CERT_P12_CONTAINER

PKCS#12/PFX container file detected.

Check: Audit algorithms used inside PKCS#12/PFX containers.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-40"></a>[tuning/certs/broken.p12:1:1](#finding-40)|broken.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-41"></a>[tuning/certs/broken.pfx:1:1](#finding-41)|broken.pfx|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-42"></a>[tuning/certs/public-only.p12:1:1](#finding-42)|public-only.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-43"></a>[tuning/certs/public-only.pfx:1:1](#finding-43)|public-only.pfx|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-44"></a>[tuning/width/public-unencrypted.p12:1:1](#finding-44)|public-u***ed.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-45"></a>[tuning/width/public-unencrypted.pfx:1:1](#finding-45)|public-u***ed.pfx|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)

<a id="rule-23"></a>

## DEP_BOUNCYCASTLE

BouncyCastle dependency detected.

Check: Verify BouncyCastle PQC support status.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-46"></a>[tuning/manifests/build.gradle.kts/declared/build.gradle.kts:1:1](#finding-46)|org.boun***n@1.80|Verify BouncyCastle PQC support status. / [Source](#source-46)|
|<a id="finding-47"></a>[tuning/manifests/build.gradle/declared/build.gradle:1:1](#finding-47)|org.boun***n@1.80|Verify BouncyCastle PQC support status. / [Source](#source-47)|
|<a id="finding-48"></a>[tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1](#finding-48)|org.boun***n@1.80|Verify BouncyCastle PQC support status. / [Source](#source-48)|
|<a id="finding-49"></a>[tuning/manifests/pom.xml/declared/pom.xml:1:1](#finding-49)|org.boun***n@1.80|Verify BouncyCastle PQC support status. / [Source](#source-49)|

Shared checks for these locations (not verified facts about each line):

- [Track PQC readiness of dependent libraries](#action-17)

<a id="source-46"></a>

### tuning/manifests/build.gradle.kts/declared/build.gradle.kts:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-47"></a>

### tuning/manifests/build.gradle/declared/build.gradle:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-48"></a>

### tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-49"></a>

### tuning/manifests/pom.xml/declared/pom.xml:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-24"></a>

## DEP_JAVA_BOUNCYCASTLE

Java BouncyCastle dependency detected.

Check: Evaluate adoption of BouncyCastle PQC provider modules.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-50"></a>[tuning/manifests/build.gradle.kts/declared/build.gradle.kts:1:1](#finding-50)|org.boun***n@1.80|Evaluate adoption of BouncyCastle PQC provider modules. / [Source](#source-50)|
|<a id="finding-51"></a>[tuning/manifests/build.gradle/declared/build.gradle:1:1](#finding-51)|org.boun***n@1.80|Evaluate adoption of BouncyCastle PQC provider modules. / [Source](#source-51)|
|<a id="finding-52"></a>[tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1](#finding-52)|org.boun***n@1.80|Evaluate adoption of BouncyCastle PQC provider modules. / [Source](#source-52)|
|<a id="finding-53"></a>[tuning/manifests/pom.xml/declared/pom.xml:1:1](#finding-53)|org.boun***n@1.80|Evaluate adoption of BouncyCastle PQC provider modules. / [Source](#source-53)|

Shared checks for these locations (not verified facts about each line):

- [Track PQC readiness of dependent libraries](#action-17)

<a id="source-50"></a>

### tuning/manifests/build.gradle.kts/declared/build.gradle.kts:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-51"></a>

### tuning/manifests/build.gradle/declared/build.gradle:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-52"></a>

### tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-53"></a>

### tuning/manifests/pom.xml/declared/pom.xml:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-25"></a>

## DEP_OPENSSL

OpenSSL dependency detected.

Check: Review the OpenSSL PQC roadmap.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-54"></a>[tuning/manifests/Cargo.lock/declared/Cargo.lock:3:1](#finding-54)|openssl@0.10.75|Review the OpenSSL PQC roadmap. / [Source](#source-54)|
|<a id="finding-55"></a>[tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1](#finding-55)|openssl@0.10.75|Review the OpenSSL PQC roadmap. / [Source](#source-55)|
|<a id="finding-56"></a>[tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1](#finding-56)|openssl@3.3.0|Review the OpenSSL PQC roadmap. / [Source](#source-56)|
|<a id="finding-57"></a>[tuning/manifests/Gemfile/declared/Gemfile:1:1](#finding-57)|openssl@3.3.0|Review the OpenSSL PQC roadmap. / [Source](#source-57)|
|<a id="finding-58"></a>[tuning/manifests/fixture.gemspec/declared/fixture.gemspec:2:1](#finding-58)|openssl@3.3.0|Review the OpenSSL PQC roadmap. / [Source](#source-58)|
|<a id="finding-59"></a>[tuning/manifests/gems.locked/declared/gems.locked:3:1](#finding-59)|openssl@3.3.0|Review the OpenSSL PQC roadmap. / [Source](#source-59)|
|<a id="finding-60"></a>[tuning/manifests/gems.rb/declared/gems.rb:1:1](#finding-60)|openssl@3.3.0|Verify deployed runtime and protocol PQC capabilities / [Verify deployed runtime and protocol PQC capabilities](#action-18) / [Source](#source-60)|
|<a id="finding-61"></a>[tuning/sbom/CycloneDX-1.5/declared/bom.json:1:1](#finding-61)|openssl@3.5.0|Review the OpenSSL PQC roadmap. / [Source](#source-61)|
|<a id="finding-62"></a>[tuning/sbom/SPDX-2.3/declared/bom.json:1:1](#finding-62)|openssl@3.5.0|Review the OpenSSL PQC roadmap. / [Source](#source-62)|
|<a id="finding-63"></a>[tuning/width/cdx-1.4/library/bom.json:1:1](#finding-63)|openssl@3.5.0|Review the OpenSSL PQC roadmap. / [Source](#source-63)|
|<a id="finding-64"></a>[tuning/width/cdx-1.6/library/bom.json:1:1](#finding-64)|openssl@3.5.0|Review the OpenSSL PQC roadmap. / [Source](#source-64)|
|<a id="finding-65"></a>[tuning/width/cdx-1.7/library/bom.json:1:1](#finding-65)|openssl@3.5.0|Review the OpenSSL PQC roadmap. / [Source](#source-65)|
|<a id="finding-66"></a>[tuning/width/spdx-2.2/library/bom.json:1:1](#finding-66)|openssl@3.5.0|Review the OpenSSL PQC roadmap. / [Source](#source-66)|

Shared checks for these locations (not verified facts about each line):

- [Track PQC readiness of dependent libraries](#action-17)

<a id="source-54"></a>

### tuning/manifests/Cargo.lock/declared/Cargo.lock:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-55"></a>

### tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-56"></a>

### tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-57"></a>

### tuning/manifests/Gemfile/declared/Gemfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-58"></a>

### tuning/manifests/fixture.gemspec/declared/fixture.gemspec:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-59"></a>

### tuning/manifests/gems.locked/declared/gems.locked:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-60"></a>

### tuning/manifests/gems.rb/declared/gems.rb:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-61"></a>

### tuning/sbom/CycloneDX-1.5/declared/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-62"></a>

### tuning/sbom/SPDX-2.3/declared/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-63"></a>

### tuning/width/cdx-1.4/library/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-64"></a>

### tuning/width/cdx-1.6/library/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-65"></a>

### tuning/width/cdx-1.7/library/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-66"></a>

### tuning/width/spdx-2.2/library/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-26"></a>

## DEP_PYCA_CRYPTOGRAPHY

Python cryptography dependency detected.

Check: Track PQC support status in the cryptography package.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-67"></a>[tuning/manifests/Pipfile.lock/declared/Pipfile.lock:1:1](#finding-67)|cryptogr***48.0.0|Track PQC support status in the cryptography package. / [Source](#source-67)|
|<a id="finding-68"></a>[tuning/manifests/poetry.lock/declared/poetry.lock:2:1](#finding-68)|cryptography@48.0.0|Track PQC support status in the cryptography package. / [Source](#source-68)|
|<a id="finding-69"></a>[tuning/manifests/requirements.txt/declared/requirements.txt:1:1](#finding-69)|cryptography@48.0.0|Track PQC support status in the cryptography package. / [Source](#source-69)|

Shared checks for these locations (not verified facts about each line):

- [Track PQC readiness of dependent libraries](#action-17)

<a id="source-67"></a>

### tuning/manifests/Pipfile.lock/declared/Pipfile.lock:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-68"></a>

### tuning/manifests/poetry.lock/declared/poetry.lock:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-69"></a>

### tuning/manifests/requirements.txt/declared/requirements.txt:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-27"></a>

## DEP_RUBY_OPENSSL

Ruby OpenSSL dependency detected.

Check: Review OpenSSL usage in Ruby and prepare PQC migration path.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-70"></a>[tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1](#finding-70)|openssl@3.3.0|Review OpenSSL usage in Ruby and prepare PQC migration path. / [Source](#source-70)|
|<a id="finding-71"></a>[tuning/manifests/Gemfile/declared/Gemfile:1:1](#finding-71)|openssl@3.3.0|Review OpenSSL usage in Ruby and prepare PQC migration path. / [Source](#source-71)|
|<a id="finding-72"></a>[tuning/manifests/fixture.gemspec/declared/fixture.gemspec:2:1](#finding-72)|openssl@3.3.0|Review OpenSSL usage in Ruby and prepare PQC migration path. / [Source](#source-72)|
|<a id="finding-73"></a>[tuning/manifests/gems.locked/declared/gems.locked:3:1](#finding-73)|openssl@3.3.0|Review OpenSSL usage in Ruby and prepare PQC migration path. / [Source](#source-73)|
|<a id="finding-74"></a>[tuning/manifests/gems.rb/declared/gems.rb:1:1](#finding-74)|openssl@3.3.0|Verify deployed runtime and protocol PQC capabilities / [Verify deployed runtime and protocol PQC capabilities](#action-18) / [Source](#source-74)|

Shared checks for these locations (not verified facts about each line):

- [Track PQC readiness of dependent libraries](#action-17)

<a id="source-70"></a>

### tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-71"></a>

### tuning/manifests/Gemfile/declared/Gemfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-72"></a>

### tuning/manifests/fixture.gemspec/declared/fixture.gemspec:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-73"></a>

### tuning/manifests/gems.locked/declared/gems.locked:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-74"></a>

### tuning/manifests/gems.rb/declared/gems.rb:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-28"></a>

## DEP_RUST_OPENSSL

Rust TLS/crypto dependency detected.

Check: Track PQC migration options for Rust openssl/rustls crypto stacks.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-75"></a>[tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1](#finding-75)|openssl@0.10.75|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-75)|

Shared checks for these locations (not verified facts about each line):

- [Track PQC readiness of dependent libraries](#action-17)

<a id="source-75"></a>

### tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="rule-29"></a>

## JWT_LIB_JOSE

jose dependency detected.

Check: Verify PQC support in the JOSE implementation.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-76"></a>[tuning/manifests/package-lock.json/declared/package-lock.json:1:1](#finding-76)|jose@6.0.0|Verify PQC support in the JOSE implementation. / [Source](#source-76)|
|<a id="finding-77"></a>[tuning/manifests/package.json/declared/package.json:1:1](#finding-77)|jose@6.0.0|Verify PQC support in the JOSE implementation. / [Source](#source-77)|
|<a id="finding-78"></a>[tuning/manifests/pnpm-lock.yaml/declared/pnpm-lock.yaml:3:1](#finding-78)|jose@6.0.0|Verify PQC support in the JOSE implementation. / [Source](#source-78)|

<a id="source-76"></a>

### tuning/manifests/package-lock.json/declared/package-lock.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-77"></a>

### tuning/manifests/package.json/declared/package.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-78"></a>

### tuning/manifests/pnpm-lock.yaml/declared/pnpm-lock.yaml:3:1

    > 3 [masked-sensitive-file-content]

<a id="rule-30"></a>

## PQC_DRAFT_ALGORITHM

Pre-standard PQC algorithm name referenced; check compatibility before replacing it.

Check: Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-79"></a>[tuning/js/draft.js:1:22](#finding-79)|kyber768|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-79)|

<a id="source-79"></a>

### tuning/js/draft.js:1:22

    > 1 generateKeyPairSync("kyber768");

<a id="rule-31"></a>

## PQC_JAVA_CLASSICAL_GROUPS

Explicit classical-only Java property intent in assignment, XML entry or static System.setProperty; effective loading is not established.

Check: Review explicit group restrictions against the deployed JSSE version and peer support.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-80"></a>[tuning/tls/positive.conf:1:1](#finding-80)|System.s***4r1");|Review explicit group restrictions against the deployed JSSE version and peer support. / [Review the explicit PQC override: jdk.tls.namedGroups](#action-19) / [Source](#source-80)|

<a id="source-80"></a>

### tuning/tls/positive.conf:1:1

    > 1 System.setProperty("jdk.tls.namedGroups", "secp256r1,secp384r1");

<a id="rule-32"></a>

## SSH_DH_GROUP14_SHA1

SHA-1 dependent SSH KEX detected.

Check: Retire SHA-1 based key exchange.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-81"></a>[tuning/ssh/dh.conf:1:15](#finding-81)|diffie-h***4-sha1|Retire SHA-1 based key exchange. / [Source](#source-81)|

<a id="source-81"></a>

### tuning/ssh/dh.conf:1:15

    > 1 KexAlgorithms diffie-hellman-group14-sha1

<a id="rule-33"></a>

## TRAEFIK_TLS_OPTIONS_LEGACY

Traefik configuration contains a low minimum TLS version.

Check: Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-82"></a>[tuning/width/traefik/selection.conf:1:1](#finding-82)|minVersi***nTLS10|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Validate Traefik PQC signature interoperability with all entrypoints](#action-20) / [Source](#source-82)|

<a id="source-82"></a>

### tuning/width/traefik/selection.conf:1:1

    > 1 minVersion: VersionTLS10

<a id="rule-34"></a>

## TS_CLASSICAL_EC_API

Classical elliptic-curve API reference; deployment and effective configuration require confirmation.

Check: Inventory classical elliptic-curve operations and plan a supported PQC or hybrid replacement.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-83"></a>[holdout/ec-sign.js:7:35](#finding-83)|generate***c('ec'|Inventory classical elliptic-curve operations and plan a supported PQC or hybrid replacement. / [Source](#source-83)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Introduce crypto abstraction boundary for algorithm agility](#action-7)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-83"></a>

### holdout/ec-sign.js:7:35

      5 } = await import('node:crypto');
      6 
    > 7 const { privateKey, publicKey } = generateKeyPairSync('ec', {
      8   namedCurve: 'sect239k1',
      9 });

<a id="rule-35"></a>

## TS_CLASSICAL_EDDSA_API

Classical EdDSA or curve key-generation API reference.

Check: Inventory EdDSA and classical curve key operations; Ed25519 is not post-quantum secure.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-84"></a>[tuning/js/eddsa.js:1:1](#finding-84)|generate***25519"|Inventory EdDSA and classical curve key operations; Ed25519 is not post-quantum secure. / [Source](#source-84)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Introduce crypto abstraction boundary for algorithm agility](#action-7)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-84"></a>

### tuning/js/eddsa.js:1:1

    > 1 generateKeyPairSync("ed25519");

<a id="rule-36"></a>

## TS_NODE_JOSE_USAGE

JOSE/JWT calls detected from JavaScript/TypeScript AST.

Check: Confirm whether this reference belongs to active signing, verification, tests or documentation; assess JOSE formats and peer/library support before selecting PQC signatures.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-85"></a>[holdout/jwt-helper.js:65:20](#finding-85)|jwt.verify|Confirm whether this reference belongs to active signing, verification, tests or documentation; assess JOSE formats and peer/library support before selecting PQC signatures. / [Source](#source-85)|
|<a id="finding-86"></a>[holdout/jwt-helper.js:70:3](#finding-86)|jwt.verify|Confirm whether this reference belongs to active signing, verification, tests or documentation; assess JOSE formats and peer/library support before selecting PQC signatures. / [Source](#source-86)|
|<a id="finding-87"></a>[holdout/jwt-helper.js:102:18](#finding-87)|jwt.sign|Confirm whether this reference belongs to active signing, verification, tests or documentation; assess JOSE formats and peer/library support before selecting PQC signatures. / [Source](#source-87)|
|<a id="finding-88"></a>[holdout/jwt-helper.js:107:3](#finding-88)|jwt.sign|Confirm whether this reference belongs to active signing, verification, tests or documentation; assess JOSE formats and peer/library support before selecting PQC signatures. / [Source](#source-88)|
|<a id="finding-89"></a>[holdout/jwt-rsa.js:2:13](#finding-89)|jwt.sign|Confirm whether this reference belongs to active signing, verification, tests or documentation; assess JOSE formats and peer/library support before selecting PQC signatures. / [Source](#source-89)|

Shared checks for these locations (not verified facts about each line):

- [Review whether the JOSE reference is used for signing, verification, tests or documentation](#action-2)
- [Upgrade Node.js runtime for built-in WebCrypto PQC support](#action-3)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-85"></a>

### holdout/jwt-helper.js:65:20

      63   let syncVerified;
      64   try {
    > 65     syncVerified = jwt.verify(jwtString, secretOrPrivateKey, options);
      66   }
      67   catch (err) {

<a id="source-86"></a>

### holdout/jwt-helper.js:70:3

      68     error = err;
      69   }
    > 70   jwt.verify(jwtString, secretOrPrivateKey, options, (err, asyncVerifiedToken) => {
      71     try {
      72       if (error) {

<a id="source-87"></a>

### holdout/jwt-helper.js:102:18

      100   let syncSigned;
      101   try {
    > 102     syncSigned = jwt.sign(payload, secretOrPrivateKey, options);
      103   }
      104   catch (err) {

<a id="source-88"></a>

### holdout/jwt-helper.js:107:3

      105     error = err;
      106   }
    > 107   jwt.sign(payload, secretOrPrivateKey, options, (err, asyncSigned) => {
      108     fakeClock.restore();
      109     if (error) {

<a id="source-89"></a>

### holdout/jwt-rsa.js:2:13

      1 var privateKey = fs.readFileSync('private.key');
    > 2 var token = jwt.sign({ foo: 'bar' }, privateKey, { algorithm: 'RS256' });

<a id="rule-37"></a>

## TS_NODE_RSA_USAGE

RSA-related API symbols detected from JavaScript/TypeScript AST.

Check: Review the RSA reference and its purpose (key generation, signing, verification or encryption); confirm active use and compatible PQC or hybrid options.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-90"></a>[holdout/jwt-rsa.js:2:64](#finding-90)|RS256|Review the RSA reference and its purpose (key generation, signing, verification or encryption); confirm active use and compatible PQC or hybrid options. / [Source](#source-90)|
|<a id="finding-91"></a>[holdout/rsa-sign.js:7:35](#finding-91)|generate***('rsa'|Review the RSA reference and its purpose (key generation, signing, verification or encryption); confirm active use and compatible PQC or hybrid options. / [Source](#source-91)|
|<a id="finding-92"></a>[holdout/rsa-sign.js:11:14](#finding-92)|createSign('SHA256'|Review the RSA reference and its purpose (key generation, signing, verification or encryption); confirm active use and compatible PQC or hybrid options. / [Source](#source-92)|
|<a id="finding-93"></a>[holdout/rsa-sign.js:14:19](#finding-93)|sign.sign(privateKey|Review the RSA reference and its purpose (key generation, signing, verification or encryption); confirm active use and compatible PQC or hybrid options. / [Source](#source-93)|
|<a id="finding-94"></a>[holdout/rsa-sign.js:16:16](#finding-94)|createVe***HA256'|Review the RSA reference and its purpose (key generation, signing, verification or encryption); confirm active use and compatible PQC or hybrid options. / [Source](#source-94)|
|<a id="finding-95"></a>[holdout/rsa-sign.js:19:13](#finding-95)|verify.v***licKey|Review the RSA reference and its purpose (key generation, signing, verification or encryption); confirm active use and compatible PQC or hybrid options. / [Source](#source-95)|
|<a id="finding-96"></a>[tuning/js/mixed.js:1:1](#finding-96)|generate***("rsa"|Review the RSA reference and its purpose (key generation, signing, verification or encryption); confirm active use and compatible PQC or hybrid options. / [Source](#source-96)|
|<a id="finding-97"></a>[tuning/jwt/sign.js:1:33](#finding-97)|RS256|Review the RSA reference and its purpose (key generation, signing, verification or encryption); confirm active use and compatible PQC or hybrid options. / [Source](#source-97)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Introduce crypto abstraction boundary for algorithm agility](#action-7)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-90"></a>

### holdout/jwt-rsa.js:2:64

      1 var privateKey = fs.readFileSync('private.key');
    > 2 var token = jwt.sign({ foo: 'bar' }, privateKey, { algorithm: 'RS256' });

<a id="source-91"></a>

### holdout/rsa-sign.js:7:35

      5 } = await import('node:crypto');
      6 
    > 7 const { privateKey, publicKey } = generateKeyPairSync('rsa', {
      8   modulusLength: 2048,
      9 });

<a id="source-92"></a>

### holdout/rsa-sign.js:11:14

      9 });
      10 
    > 11 const sign = createSign('SHA256');
      12 sign.update('some data to sign');
      13 sign.end();

<a id="source-93"></a>

### holdout/rsa-sign.js:14:19

      12 sign.update('some data to sign');
      13 sign.end();
    > 14 const signature = sign.sign(privateKey);
      15 
      16 const verify = createVerify('SHA256');

<a id="source-94"></a>

### holdout/rsa-sign.js:16:16

      14 const signature = sign.sign(privateKey);
      15 
    > 16 const verify = createVerify('SHA256');
      17 verify.update('some data to sign');
      18 verify.end();

<a id="source-95"></a>

### holdout/rsa-sign.js:19:13

      17 verify.update('some data to sign');
      18 verify.end();
    > 19 console.log(verify.verify(publicKey, signature));
      20 // Prints: true

<a id="source-96"></a>

### tuning/js/mixed.js:1:1

    > 1 generateKeyPairSync("rsa"); generateKeyPairSync("ml-kem-768");

<a id="source-97"></a>

### tuning/jwt/sign.js:1:33

    > 1 sign(payload, key, {algorithm: "RS256"});

<a id="rule-38"></a>

## CERT_PEM_CONTAINER

PEM/DER cryptographic container detected; certificate presence is not established.

Check: Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-98"></a>[tuning/certs/broken.cer:1:1](#finding-98)|broken.cer|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-98)|
|<a id="finding-99"></a>[tuning/certs/broken.crt:1:1](#finding-99)|broken.crt|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-99)|
|<a id="finding-100"></a>[tuning/certs/broken.der:1:1](#finding-100)|broken.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-100)|
|<a id="finding-101"></a>[tuning/certs/broken.pem:1:1](#finding-101)|broken.pem|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-101)|

Shared checks for these locations (not verified facts about each line):

- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)

<a id="source-98"></a>

### tuning/certs/broken.cer:1:1

    > 1 not a certificate

<a id="source-99"></a>

### tuning/certs/broken.crt:1:1

    > 1 not a certificate

<a id="source-100"></a>

### tuning/certs/broken.der:1:1

    > 1 not a certificate

<a id="source-101"></a>

### tuning/certs/broken.pem:1:1

    > 1 not a certificate

<a id="rule-39"></a>

## DEP_PQC_CAPABLE_LIBRARY

Library with version-dependent PQC capabilities inventoried; capability is not an enabled-state finding.

Check: Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-102"></a>[tuning/manifests/Cargo.lock/declared/Cargo.lock:3:1](#finding-102)|openssl@0.10.75|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-102)|
|<a id="finding-103"></a>[tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1](#finding-103)|openssl@0.10.75|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-103)|
|<a id="finding-104"></a>[tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1](#finding-104)|openssl@3.3.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-104)|
|<a id="finding-105"></a>[tuning/manifests/Gemfile/declared/Gemfile:1:1](#finding-105)|openssl@3.3.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-105)|
|<a id="finding-106"></a>[tuning/manifests/Pipfile.lock/declared/Pipfile.lock:1:1](#finding-106)|cryptogr***48.0.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-106)|
|<a id="finding-107"></a>[tuning/manifests/build.gradle.kts/declared/build.gradle.kts:1:1](#finding-107)|org.boun***n@1.80|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-107)|
|<a id="finding-108"></a>[tuning/manifests/build.gradle/declared/build.gradle:1:1](#finding-108)|org.boun***n@1.80|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-108)|
|<a id="finding-109"></a>[tuning/manifests/fixture.gemspec/declared/fixture.gemspec:2:1](#finding-109)|openssl@3.3.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-109)|
|<a id="finding-110"></a>[tuning/manifests/gems.locked/declared/gems.locked:3:1](#finding-110)|openssl@3.3.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-110)|
|<a id="finding-111"></a>[tuning/manifests/gems.rb/declared/gems.rb:1:1](#finding-111)|openssl@3.3.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-111)|
|<a id="finding-112"></a>[tuning/manifests/go.mod/declared/go.mod:3:1](#finding-112)|github.c***v1.6.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-112)|
|<a id="finding-113"></a>[tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1](#finding-113)|org.boun***n@1.80|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-113)|
|<a id="finding-114"></a>[tuning/manifests/poetry.lock/declared/poetry.lock:2:1](#finding-114)|cryptography@48.0.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-114)|
|<a id="finding-115"></a>[tuning/manifests/pom.xml/declared/pom.xml:1:1](#finding-115)|org.boun***n@1.80|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-115)|
|<a id="finding-116"></a>[tuning/manifests/requirements.txt/declared/requirements.txt:1:1](#finding-116)|cryptography@48.0.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-116)|
|<a id="finding-117"></a>[tuning/sbom/CycloneDX-1.5/declared/bom.json:1:1](#finding-117)|openssl@3.5.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-117)|
|<a id="finding-118"></a>[tuning/sbom/SPDX-2.3/declared/bom.json:1:1](#finding-118)|openssl@3.5.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-118)|
|<a id="finding-119"></a>[tuning/width/cdx-1.4/library/bom.json:1:1](#finding-119)|openssl@3.5.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-119)|
|<a id="finding-120"></a>[tuning/width/cdx-1.6/library/bom.json:1:1](#finding-120)|openssl@3.5.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-120)|
|<a id="finding-121"></a>[tuning/width/cdx-1.7/library/bom.json:1:1](#finding-121)|openssl@3.5.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-121)|
|<a id="finding-122"></a>[tuning/width/spdx-2.2/library/bom.json:1:1](#finding-122)|openssl@3.5.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-122)|

Shared checks for these locations (not verified facts about each line):

- [Track PQC readiness of dependent libraries](#action-17)

<a id="source-102"></a>

### tuning/manifests/Cargo.lock/declared/Cargo.lock:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-103"></a>

### tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-104"></a>

### tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-105"></a>

### tuning/manifests/Gemfile/declared/Gemfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-106"></a>

### tuning/manifests/Pipfile.lock/declared/Pipfile.lock:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-107"></a>

### tuning/manifests/build.gradle.kts/declared/build.gradle.kts:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-108"></a>

### tuning/manifests/build.gradle/declared/build.gradle:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-109"></a>

### tuning/manifests/fixture.gemspec/declared/fixture.gemspec:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-110"></a>

### tuning/manifests/gems.locked/declared/gems.locked:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-111"></a>

### tuning/manifests/gems.rb/declared/gems.rb:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-112"></a>

### tuning/manifests/go.mod/declared/go.mod:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-113"></a>

### tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-114"></a>

### tuning/manifests/poetry.lock/declared/poetry.lock:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-115"></a>

### tuning/manifests/pom.xml/declared/pom.xml:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-116"></a>

### tuning/manifests/requirements.txt/declared/requirements.txt:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-117"></a>

### tuning/sbom/CycloneDX-1.5/declared/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-118"></a>

### tuning/sbom/SPDX-2.3/declared/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-119"></a>

### tuning/width/cdx-1.4/library/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-120"></a>

### tuning/width/cdx-1.6/library/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-121"></a>

### tuning/width/cdx-1.7/library/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-122"></a>

### tuning/width/spdx-2.2/library/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-40"></a>

## PQC_GO_API

Standard Go PQC package imported; import alone does not prove negotiated protection.

Check: crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-123"></a>[tuning/go/main.go:2:8](#finding-123)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-123)|

<a id="source-123"></a>

### tuning/go/main.go:2:8

      1 package data
    > 2 import "crypto/mlkem"

<a id="rule-41"></a>

## PQC_JAVA_API

Standard PQC algorithm requested through Java APIs; runtime success is not established.

Check: JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-124"></a>[holdout/MLDSA.java:1:36](#finding-124)|KeyPairG***SA-44"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-124)|
|<a id="finding-125"></a>[tuning/java/Broken.java:1:1](#finding-125)|Signatur***SA-65"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-125)|
|<a id="finding-126"></a>[tuning/java/Kem.java:1:1](#finding-126)|KEM.getI***-1024"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-126)|
|<a id="finding-127"></a>[tuning/java/ML.java:1:1](#finding-127)|Signatur***SA-44"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-127)|
|<a id="finding-128"></a>[tuning/java/Slh.java:1:1](#finding-128)|Signatur***-256s"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-128)|

<a id="source-124"></a>

### holdout/MLDSA.java:1:36

    > 1         KeyPairGenerator kpGen44 = KeyPairGenerator.getInstance("ML-DSA-44");

<a id="source-125"></a>

### tuning/java/Broken.java:1:1

    > 1 Signature.getInstance("ML-DSA-65"

<a id="source-126"></a>

### tuning/java/Kem.java:1:1

    > 1 KEM.getInstance("ML-KEM-1024");

<a id="source-127"></a>

### tuning/java/ML.java:1:1

    > 1 Signature.getInstance("ML-DSA-44");

<a id="source-128"></a>

### tuning/java/Slh.java:1:1

    > 1 Signature.getInstance("SLH-DSA-SHAKE-256s");

<a id="rule-42"></a>

## PQC_NODE_API

Node-style PQC key generation call; bindings and actual execution require confirmation.

Check: Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-129"></a>[holdout/ml-dsa.js:16:25](#finding-129)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-129)|
|<a id="finding-130"></a>[holdout/ml-dsa.js:54:7](#finding-130)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-130)|
|<a id="finding-131"></a>[holdout/ml-dsa.js:66:7](#finding-131)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-131)|
|<a id="finding-132"></a>[holdout/ml-kem.js:16:25](#finding-132)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-132)|
|<a id="finding-133"></a>[holdout/ml-kem.js:32:7](#finding-133)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-133)|
|<a id="finding-134"></a>[holdout/ml-kem.js:43:7](#finding-134)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-134)|
|<a id="finding-135"></a>[holdout/slh-dsa.js:20:25](#finding-135)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-135)|
|<a id="finding-136"></a>[holdout/slh-dsa.js:40:7](#finding-136)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-136)|
|<a id="finding-137"></a>[holdout/slh-dsa.js:51:7](#finding-137)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-137)|
|<a id="finding-138"></a>[tuning/js/alias.js:2:1](#finding-138)|make("ml-dsa-65"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-138)|
|<a id="finding-139"></a>[tuning/js/dead.js:1:12](#finding-139)|generate***m-768"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-139)|
|<a id="finding-140"></a>[tuning/js/direct.js:1:1](#finding-140)|generate***m-512"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-140)|
|<a id="finding-141"></a>[tuning/js/mixed.js:1:29](#finding-141)|generate***m-768"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-141)|
|<a id="finding-142"></a>[tuning/js/same-line.js:1:1](#finding-142)|generate***m-512"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-142)|
|<a id="finding-143"></a>[tuning/js/same-line.js:1:36](#finding-143)|generate***-1024"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-143)|

<a id="source-129"></a>

### holdout/ml-dsa.js:16:25

      14 if (!hasOpenSSL(3, 5)) {
      15   for (const asymmetricKeyType of ['ml-dsa-44', 'ml-dsa-65', 'ml-dsa-87']) {
    > 16     assert.throws(() => generateKeyPair(asymmetricKeyType, common.mustNotCall()), {
      17       code: 'ERR_INVALID_ARG_VALUE',
      18       message: /The argument 'type' must be a supported key type/

<a id="source-130"></a>

### holdout/ml-dsa.js:54:7

      52       [{ format: 'der', type: 'spki' }, (publicKey) => assert.strictEqual(Buffer.isBuffer(publicKey), true)],
      53     ]) {
    > 54       generateKeyPair(asymmetricKeyType, { publicKeyEncoding }, common.mustSucceed(validate));
      55     }
      56     for (const [privateKeyEncoding, validate] of [

<a id="source-131"></a>

### holdout/ml-dsa.js:66:7

      64       [{ format: 'der', type: 'pkcs8' }, (_, privateKey) => assert.strictEqual(Buffer.isBuffer(privateKey), true)],
      65     ]) {
    > 66       generateKeyPair(asymmetricKeyType, { privateKeyEncoding }, common.mustSucceed(validate));
      67     }
      68   }

<a id="source-132"></a>

### holdout/ml-kem.js:16:25

      14 if (!hasOpenSSL(3, 5)) {
      15   for (const asymmetricKeyType of ['ml-kem-512', 'ml-kem-768', 'ml-kem-1024']) {
    > 16     assert.throws(() => generateKeyPair(asymmetricKeyType, common.mustNotCall()), {
      17       code: 'ERR_INVALID_ARG_VALUE',
      18       message: /The argument 'type' must be a supported key type/

<a id="source-133"></a>

### holdout/ml-kem.js:32:7

      30       [{ format: 'der', type: 'spki' }, (publicKey) => assert.strictEqual(Buffer.isBuffer(publicKey), true)],
      31     ]) {
    > 32       generateKeyPair(asymmetricKeyType, { publicKeyEncoding }, common.mustSucceed(validate));
      33     }
      34     for (const [privateKeyEncoding, validate] of [

<a id="source-134"></a>

### holdout/ml-kem.js:43:7

      41       [{ format: 'der', type: 'pkcs8' }, (_, privateKey) => assert.strictEqual(Buffer.isBuffer(privateKey), true)],
      42     ]) {
    > 43       generateKeyPair(asymmetricKeyType, { privateKeyEncoding }, common.mustSucceed(validate));
      44     }
      45   }

<a id="source-135"></a>

### holdout/slh-dsa.js:20:25

      18     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',
      19   ]) {
    > 20     assert.throws(() => generateKeyPair(asymmetricKeyType, common.mustNotCall()), {
      21       code: 'ERR_INVALID_ARG_VALUE',
      22       message: /The argument 'type' must be a supported key type/

<a id="source-136"></a>

### holdout/slh-dsa.js:40:7

      38       [{ format: 'der', type: 'spki' }, (publicKey) => assert.strictEqual(Buffer.isBuffer(publicKey), true)],
      39     ]) {
    > 40       generateKeyPair(asymmetricKeyType, { publicKeyEncoding }, common.mustSucceed(validate));
      41     }
      42     for (const [privateKeyEncoding, validate] of [

<a id="source-137"></a>

### holdout/slh-dsa.js:51:7

      49       [{ format: 'der', type: 'pkcs8' }, (_, privateKey) => assert.strictEqual(Buffer.isBuffer(privateKey), true)],
      50     ]) {
    > 51       generateKeyPair(asymmetricKeyType, { privateKeyEncoding }, common.mustSucceed(validate));
      52     }
      53   }

<a id="source-138"></a>

### tuning/js/alias.js:2:1

      1 import {generateKeyPairSync as make} from "node:crypto";
    > 2 make("ml-dsa-65");

<a id="source-139"></a>

### tuning/js/dead.js:1:12

    > 1 if (false) generateKeyPairSync("ml-kem-768");

<a id="source-140"></a>

### tuning/js/direct.js:1:1

    > 1 generateKeyPairSync("ml-kem-512");

<a id="source-141"></a>

### tuning/js/mixed.js:1:29

    > 1 generateKeyPairSync("rsa"); generateKeyPairSync("ml-kem-768");

<a id="source-142"></a>

### tuning/js/same-line.js:1:1

    > 1 generateKeyPairSync("ml-kem-512"); generateKeyPairSync("ml-kem-1024");

<a id="source-143"></a>

### tuning/js/same-line.js:1:36

    > 1 generateKeyPairSync("ml-kem-512"); generateKeyPairSync("ml-kem-1024");

<a id="rule-43"></a>

## PQC_PYTHON_API

Python PQC key generation reference; backend support is not established.

Check: cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-144"></a>[tuning/python/broken.py:1:7](#finding-144)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-144)|
|<a id="finding-145"></a>[tuning/python/pqc.py:1:1](#finding-145)|from cry*** mlkem|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-145)|
|<a id="finding-146"></a>[tuning/python/pqc.py:2:5](#finding-146)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-146)|

<a id="source-144"></a>

### tuning/python/broken.py:1:7

    > 1 key = mlkem.MLKEM768PrivateKey.generate(

<a id="source-145"></a>

### tuning/python/pqc.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric import mlkem
      2 k = mlkem.MLKEM768PrivateKey.generate()

<a id="source-146"></a>

### tuning/python/pqc.py:2:5

      1 from cryptography.hazmat.primitives.asymmetric import mlkem
    > 2 k = mlkem.MLKEM768PrivateKey.generate()

<a id="rule-44"></a>

## PQC_RUBY_API

Ruby PQC algorithm literal referenced; key generation or signing success is not established.

Check: Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-147"></a>[tuning/ruby/negative.rb:1:6](#finding-147)|"SLH-DSA-SHA2-128s"|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-147)|
|<a id="finding-148"></a>[tuning/ruby/pqc.rb:1:28](#finding-148)|"ML-DSA-87"|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-148)|

<a id="source-147"></a>

### tuning/ruby/negative.rb:1:6

    > 1 puts "SLH-DSA-SHA2-128s"

<a id="source-148"></a>

### tuning/ruby/pqc.rb:1:28

    > 1 OpenSSL::PKey.generate_key("ML-DSA-87")

<a id="rule-45"></a>

## PQC_RUST_API

Rust PQC crate symbol referenced; execution and protocol use require confirmation.

Check: Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-149"></a>[holdout/rustcrypto-usage.rs:1:5](#finding-149)|ml_kem::*|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-149)|
|<a id="finding-150"></a>[holdout/rustcrypto-usage.rs:6:16](#finding-150)|MlKem768::generate|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-150)|
|<a id="finding-151"></a>[holdout/rustcrypto-usage.rs:10:20](#finding-151)|ek.encapsulate|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-151)|
|<a id="finding-152"></a>[holdout/rustcrypto-usage.rs:13:14](#finding-152)|dk.decapsulate|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-152)|
|<a id="finding-153"></a>[tuning/rust/broken.rs:1:5](#finding-153)|ml_kem::|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-153)|
|<a id="finding-154"></a>[tuning/rust/pqc.rs:1:5](#finding-154)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-154)|

<a id="source-149"></a>

### holdout/rustcrypto-usage.rs:1:5

    > 1 use ml_kem::*;
      2 use ::kem::{Decapsulate, Encapsulate};
      3 let mut rng = rand::thread_rng();

<a id="source-150"></a>

### holdout/rustcrypto-usage.rs:6:16

      4 
      5 // Generate a (decapsulation key, encapsulation key) pair
    > 6 let (dk, ek) = MlKem768::generate(&mut rng);
      7 
      8 // Encapsulate a shared key to the holder of the decapsulation key, receive the shared

<a id="source-151"></a>

### holdout/rustcrypto-usage.rs:10:20

      8 // Encapsulate a shared key to the holder of the decapsulation key, receive the shared
      9 // secret `k_send` and the encapsulated form `ct`.
    > 10 let (ct, k_send) = ek.encapsulate(&mut rng).unwrap();
      11 
      12 // Decapsulate the shared key and verify that it was faithfully received.

<a id="source-152"></a>

### holdout/rustcrypto-usage.rs:13:14

      11 
      12 // Decapsulate the shared key and verify that it was faithfully received.
    > 13 let k_recv = dk.decapsulate(&ct).unwrap();
      14 assert_eq!(k_send, k_recv);

<a id="source-153"></a>

### tuning/rust/broken.rs:1:5

    > 1 use ml_kem::

<a id="source-154"></a>

### tuning/rust/pqc.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="rule-46"></a>

## PQC_STANDARD_REFERENCE

Standard PQC algorithm or hybrid group name referenced; API execution, enabled state and conformance are not established.

Check: A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-155"></a>[holdout/MLDSA.java:1:66](#finding-155)|ML-DSA-44|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-155)|
|<a id="finding-156"></a>[holdout/ml-dsa.js:15:37](#finding-156)|ml-dsa-44|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-156)|
|<a id="finding-157"></a>[holdout/ml-dsa.js:15:50](#finding-157)|ml-dsa-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-157)|
|<a id="finding-158"></a>[holdout/ml-dsa.js:15:63](#finding-158)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-158)|
|<a id="finding-159"></a>[holdout/ml-dsa.js:23:7](#finding-159)|ml-dsa-44|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-159)|
|<a id="finding-160"></a>[holdout/ml-dsa.js:23:28](#finding-160)|ml-dsa-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-160)|
|<a id="finding-161"></a>[holdout/ml-dsa.js:23:49](#finding-161)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-161)|
|<a id="finding-162"></a>[holdout/ml-kem.js:15:37](#finding-162)|ml-kem-512|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-162)|
|<a id="finding-163"></a>[holdout/ml-kem.js:15:51](#finding-163)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-163)|
|<a id="finding-164"></a>[holdout/ml-kem.js:15:65](#finding-164)|ml-kem-1024|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-164)|
|<a id="finding-165"></a>[holdout/ml-kem.js:22:37](#finding-165)|ml-kem-512|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-165)|
|<a id="finding-166"></a>[holdout/ml-kem.js:22:51](#finding-166)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-166)|
|<a id="finding-167"></a>[holdout/ml-kem.js:22:65](#finding-167)|ml-kem-1024|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-167)|
|<a id="finding-168"></a>[holdout/rustcrypto-usage.rs:6:16](#finding-168)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-168)|
|<a id="finding-169"></a>[holdout/slh-dsa.js:16:6](#finding-169)|slh-dsa-sha2-128f|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-169)|
|<a id="finding-170"></a>[holdout/slh-dsa.js:16:27](#finding-170)|slh-dsa-sha2-128s|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-170)|
|<a id="finding-171"></a>[holdout/slh-dsa.js:16:48](#finding-171)|slh-dsa-sha2-192f|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-171)|
|<a id="finding-172"></a>[holdout/slh-dsa.js:16:69](#finding-172)|slh-dsa-sha2-192s|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-172)|
|<a id="finding-173"></a>[holdout/slh-dsa.js:17:6](#finding-173)|slh-dsa-sha2-256f|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-173)|
|<a id="finding-174"></a>[holdout/slh-dsa.js:17:27](#finding-174)|slh-dsa-sha2-256s|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-174)|
|<a id="finding-175"></a>[holdout/slh-dsa.js:17:48](#finding-175)|slh-dsa-shake-128f|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-175)|
|<a id="finding-176"></a>[holdout/slh-dsa.js:17:70](#finding-176)|slh-dsa-shake-128s|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-176)|
|<a id="finding-177"></a>[holdout/slh-dsa.js:18:6](#finding-177)|slh-dsa-shake-192f|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-177)|
|<a id="finding-178"></a>[holdout/slh-dsa.js:18:28](#finding-178)|slh-dsa-shake-192s|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-178)|
|<a id="finding-179"></a>[holdout/slh-dsa.js:18:50](#finding-179)|slh-dsa-shake-256f|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-179)|
|<a id="finding-180"></a>[holdout/slh-dsa.js:18:72](#finding-180)|slh-dsa-shake-256s|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-180)|
|<a id="finding-181"></a>[holdout/slh-dsa.js:27:6](#finding-181)|slh-dsa-sha2-128f|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-181)|
|<a id="finding-182"></a>[holdout/slh-dsa.js:27:27](#finding-182)|slh-dsa-sha2-128s|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-182)|
|<a id="finding-183"></a>[holdout/slh-dsa.js:27:48](#finding-183)|slh-dsa-sha2-192f|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-183)|
|<a id="finding-184"></a>[holdout/slh-dsa.js:27:69](#finding-184)|slh-dsa-sha2-192s|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-184)|
|<a id="finding-185"></a>[holdout/slh-dsa.js:28:6](#finding-185)|slh-dsa-sha2-256f|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-185)|
|<a id="finding-186"></a>[holdout/slh-dsa.js:28:27](#finding-186)|slh-dsa-sha2-256s|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-186)|
|<a id="finding-187"></a>[holdout/slh-dsa.js:28:48](#finding-187)|slh-dsa-shake-128f|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-187)|
|<a id="finding-188"></a>[holdout/slh-dsa.js:28:70](#finding-188)|slh-dsa-shake-128s|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-188)|
|<a id="finding-189"></a>[holdout/slh-dsa.js:29:6](#finding-189)|slh-dsa-shake-192f|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-189)|
|<a id="finding-190"></a>[holdout/slh-dsa.js:29:28](#finding-190)|slh-dsa-shake-192s|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-190)|
|<a id="finding-191"></a>[holdout/slh-dsa.js:29:50](#finding-191)|slh-dsa-shake-256f|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-191)|
|<a id="finding-192"></a>[holdout/slh-dsa.js:29:72](#finding-192)|slh-dsa-shake-256s|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-192)|
|<a id="finding-193"></a>[tuning/java/Broken.java:1:24](#finding-193)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-193)|
|<a id="finding-194"></a>[tuning/java/Kem.java:1:18](#finding-194)|ML-KEM-1024|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-194)|
|<a id="finding-195"></a>[tuning/java/ML.java:1:24](#finding-195)|ML-DSA-44|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-195)|
|<a id="finding-196"></a>[tuning/java/Slh.java:1:24](#finding-196)|SLH-DSA-SHAKE-256s|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-196)|
|<a id="finding-197"></a>[tuning/js/alias.js:2:7](#finding-197)|ml-dsa-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-197)|
|<a id="finding-198"></a>[tuning/js/dead.js:1:33](#finding-198)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-198)|
|<a id="finding-199"></a>[tuning/js/direct.js:1:22](#finding-199)|ml-kem-512|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-199)|
|<a id="finding-200"></a>[tuning/js/hybrid.js:1:16](#finding-200)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-200)|
|<a id="finding-201"></a>[tuning/js/mixed.js:1:50](#finding-201)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-201)|
|<a id="finding-202"></a>[tuning/js/namesake.js:2:22](#finding-202)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-202)|
|<a id="finding-203"></a>[tuning/js/same-line.js:1:22](#finding-203)|ml-kem-512|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-203)|
|<a id="finding-204"></a>[tuning/js/same-line.js:1:57](#finding-204)|ml-kem-1024|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-204)|
|<a id="finding-205"></a>[tuning/js/shadow.js:2:68](#finding-205)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-205)|
|<a id="finding-206"></a>[tuning/js/string.js:1:36](#finding-206)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-206)|
|<a id="finding-207"></a>[tuning/js/typed.js:1:29](#finding-207)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-207)|
|<a id="finding-208"></a>[tuning/python/negative.py:1:8](#finding-208)|ML-KEM-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-208)|
|<a id="finding-209"></a>[tuning/ruby/negative.rb:1:7](#finding-209)|SLH-DSA-SHA2-128s|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-209)|
|<a id="finding-210"></a>[tuning/ruby/pqc.rb:1:29](#finding-210)|ML-DSA-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-210)|
|<a id="finding-211"></a>[tuning/rust/pqc.rs:1:13](#finding-211)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-211)|
|<a id="finding-212"></a>[tuning/typescript/web.ts:1:35](#finding-212)|ML-KEM-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-212)|
|<a id="finding-213"></a>[tuning/width/tsx/standard.tsx:2:35](#finding-213)|ML-KEM-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-213)|

<a id="source-155"></a>

### holdout/MLDSA.java:1:66

    > 1         KeyPairGenerator kpGen44 = KeyPairGenerator.getInstance("ML-DSA-44");

<a id="source-156"></a>

### holdout/ml-dsa.js:15:37

      13 
      14 if (!hasOpenSSL(3, 5)) {
    > 15   for (const asymmetricKeyType of ['ml-dsa-44', 'ml-dsa-65', 'ml-dsa-87']) {
      16     assert.throws(() => generateKeyPair(asymmetricKeyType, common.mustNotCall()), {
      17       code: 'ERR_INVALID_ARG_VALUE',

<a id="source-157"></a>

### holdout/ml-dsa.js:15:50

      13 
      14 if (!hasOpenSSL(3, 5)) {
    > 15   for (const asymmetricKeyType of ['ml-dsa-44', 'ml-dsa-65', 'ml-dsa-87']) {
      16     assert.throws(() => generateKeyPair(asymmetricKeyType, common.mustNotCall()), {
      17       code: 'ERR_INVALID_ARG_VALUE',

<a id="source-158"></a>

### holdout/ml-dsa.js:15:63

      13 
      14 if (!hasOpenSSL(3, 5)) {
    > 15   for (const asymmetricKeyType of ['ml-dsa-44', 'ml-dsa-65', 'ml-dsa-87']) {
      16     assert.throws(() => generateKeyPair(asymmetricKeyType, common.mustNotCall()), {
      17       code: 'ERR_INVALID_ARG_VALUE',

<a id="source-159"></a>

### holdout/ml-dsa.js:23:7

      21 } else {
      22   for (const [asymmetricKeyType, pubLen] of [
    > 23     ['ml-dsa-44', 1312], ['ml-dsa-65', 1952], ['ml-dsa-87', 2592],
      24   ]) {
      25 

<a id="source-160"></a>

### holdout/ml-dsa.js:23:28

      21 } else {
      22   for (const [asymmetricKeyType, pubLen] of [
    > 23     ['ml-dsa-44', 1312], ['ml-dsa-65', 1952], ['ml-dsa-87', 2592],
      24   ]) {
      25 

<a id="source-161"></a>

### holdout/ml-dsa.js:23:49

      21 } else {
      22   for (const [asymmetricKeyType, pubLen] of [
    > 23     ['ml-dsa-44', 1312], ['ml-dsa-65', 1952], ['ml-dsa-87', 2592],
      24   ]) {
      25 

<a id="source-162"></a>

### holdout/ml-kem.js:15:37

      13 
      14 if (!hasOpenSSL(3, 5)) {
    > 15   for (const asymmetricKeyType of ['ml-kem-512', 'ml-kem-768', 'ml-kem-1024']) {
      16     assert.throws(() => generateKeyPair(asymmetricKeyType, common.mustNotCall()), {
      17       code: 'ERR_INVALID_ARG_VALUE',

<a id="source-163"></a>

### holdout/ml-kem.js:15:51

      13 
      14 if (!hasOpenSSL(3, 5)) {
    > 15   for (const asymmetricKeyType of ['ml-kem-512', 'ml-kem-768', 'ml-kem-1024']) {
      16     assert.throws(() => generateKeyPair(asymmetricKeyType, common.mustNotCall()), {
      17       code: 'ERR_INVALID_ARG_VALUE',

<a id="source-164"></a>

### holdout/ml-kem.js:15:65

      13 
      14 if (!hasOpenSSL(3, 5)) {
    > 15   for (const asymmetricKeyType of ['ml-kem-512', 'ml-kem-768', 'ml-kem-1024']) {
      16     assert.throws(() => generateKeyPair(asymmetricKeyType, common.mustNotCall()), {
      17       code: 'ERR_INVALID_ARG_VALUE',

<a id="source-165"></a>

### holdout/ml-kem.js:22:37

      20   }
      21 } else {
    > 22   for (const asymmetricKeyType of ['ml-kem-512', 'ml-kem-768', 'ml-kem-1024']) {
      23     for (const [publicKeyEncoding, validate] of [
      24       [undefined, (publicKey) => {

<a id="source-166"></a>

### holdout/ml-kem.js:22:51

      20   }
      21 } else {
    > 22   for (const asymmetricKeyType of ['ml-kem-512', 'ml-kem-768', 'ml-kem-1024']) {
      23     for (const [publicKeyEncoding, validate] of [
      24       [undefined, (publicKey) => {

<a id="source-167"></a>

### holdout/ml-kem.js:22:65

      20   }
      21 } else {
    > 22   for (const asymmetricKeyType of ['ml-kem-512', 'ml-kem-768', 'ml-kem-1024']) {
      23     for (const [publicKeyEncoding, validate] of [
      24       [undefined, (publicKey) => {

<a id="source-168"></a>

### holdout/rustcrypto-usage.rs:6:16

      4 
      5 // Generate a (decapsulation key, encapsulation key) pair
    > 6 let (dk, ek) = MlKem768::generate(&mut rng);
      7 
      8 // Encapsulate a shared key to the holder of the decapsulation key, receive the shared

<a id="source-169"></a>

### holdout/slh-dsa.js:16:6

      14 if (!hasOpenSSL(3, 5)) {
      15   for (const asymmetricKeyType of [
    > 16     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
      17     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
      18     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',

<a id="source-170"></a>

### holdout/slh-dsa.js:16:27

      14 if (!hasOpenSSL(3, 5)) {
      15   for (const asymmetricKeyType of [
    > 16     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
      17     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
      18     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',

<a id="source-171"></a>

### holdout/slh-dsa.js:16:48

      14 if (!hasOpenSSL(3, 5)) {
      15   for (const asymmetricKeyType of [
    > 16     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
      17     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
      18     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',

<a id="source-172"></a>

### holdout/slh-dsa.js:16:69

      14 if (!hasOpenSSL(3, 5)) {
      15   for (const asymmetricKeyType of [
    > 16     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
      17     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
      18     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',

<a id="source-173"></a>

### holdout/slh-dsa.js:17:6

      15   for (const asymmetricKeyType of [
      16     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
    > 17     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
      18     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',
      19   ]) {

<a id="source-174"></a>

### holdout/slh-dsa.js:17:27

      15   for (const asymmetricKeyType of [
      16     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
    > 17     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
      18     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',
      19   ]) {

<a id="source-175"></a>

### holdout/slh-dsa.js:17:48

      15   for (const asymmetricKeyType of [
      16     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
    > 17     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
      18     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',
      19   ]) {

<a id="source-176"></a>

### holdout/slh-dsa.js:17:70

      15   for (const asymmetricKeyType of [
      16     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
    > 17     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
      18     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',
      19   ]) {

<a id="source-177"></a>

### holdout/slh-dsa.js:18:6

      16     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
      17     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
    > 18     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',
      19   ]) {
      20     assert.throws(() => generateKeyPair(asymmetricKeyType, common.mustNotCall()), {

<a id="source-178"></a>

### holdout/slh-dsa.js:18:28

      16     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
      17     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
    > 18     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',
      19   ]) {
      20     assert.throws(() => generateKeyPair(asymmetricKeyType, common.mustNotCall()), {

<a id="source-179"></a>

### holdout/slh-dsa.js:18:50

      16     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
      17     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
    > 18     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',
      19   ]) {
      20     assert.throws(() => generateKeyPair(asymmetricKeyType, common.mustNotCall()), {

<a id="source-180"></a>

### holdout/slh-dsa.js:18:72

      16     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
      17     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
    > 18     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',
      19   ]) {
      20     assert.throws(() => generateKeyPair(asymmetricKeyType, common.mustNotCall()), {

<a id="source-181"></a>

### holdout/slh-dsa.js:27:6

      25 } else {
      26   for (const asymmetricKeyType of [
    > 27     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
      28     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
      29     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',

<a id="source-182"></a>

### holdout/slh-dsa.js:27:27

      25 } else {
      26   for (const asymmetricKeyType of [
    > 27     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
      28     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
      29     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',

<a id="source-183"></a>

### holdout/slh-dsa.js:27:48

      25 } else {
      26   for (const asymmetricKeyType of [
    > 27     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
      28     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
      29     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',

<a id="source-184"></a>

### holdout/slh-dsa.js:27:69

      25 } else {
      26   for (const asymmetricKeyType of [
    > 27     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
      28     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
      29     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',

<a id="source-185"></a>

### holdout/slh-dsa.js:28:6

      26   for (const asymmetricKeyType of [
      27     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
    > 28     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
      29     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',
      30   ]) {

<a id="source-186"></a>

### holdout/slh-dsa.js:28:27

      26   for (const asymmetricKeyType of [
      27     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
    > 28     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
      29     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',
      30   ]) {

<a id="source-187"></a>

### holdout/slh-dsa.js:28:48

      26   for (const asymmetricKeyType of [
      27     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
    > 28     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
      29     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',
      30   ]) {

<a id="source-188"></a>

### holdout/slh-dsa.js:28:70

      26   for (const asymmetricKeyType of [
      27     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
    > 28     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
      29     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',
      30   ]) {

<a id="source-189"></a>

### holdout/slh-dsa.js:29:6

      27     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
      28     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
    > 29     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',
      30   ]) {
      31     for (const [publicKeyEncoding, validate] of [

<a id="source-190"></a>

### holdout/slh-dsa.js:29:28

      27     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
      28     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
    > 29     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',
      30   ]) {
      31     for (const [publicKeyEncoding, validate] of [

<a id="source-191"></a>

### holdout/slh-dsa.js:29:50

      27     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
      28     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
    > 29     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',
      30   ]) {
      31     for (const [publicKeyEncoding, validate] of [

<a id="source-192"></a>

### holdout/slh-dsa.js:29:72

      27     'slh-dsa-sha2-128f', 'slh-dsa-sha2-128s', 'slh-dsa-sha2-192f', 'slh-dsa-sha2-192s',
      28     'slh-dsa-sha2-256f', 'slh-dsa-sha2-256s', 'slh-dsa-shake-128f', 'slh-dsa-shake-128s',
    > 29     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',
      30   ]) {
      31     for (const [publicKeyEncoding, validate] of [

<a id="source-193"></a>

### tuning/java/Broken.java:1:24

    > 1 Signature.getInstance("ML-DSA-65"

<a id="source-194"></a>

### tuning/java/Kem.java:1:18

    > 1 KEM.getInstance("ML-KEM-1024");

<a id="source-195"></a>

### tuning/java/ML.java:1:24

    > 1 Signature.getInstance("ML-DSA-44");

<a id="source-196"></a>

### tuning/java/Slh.java:1:24

    > 1 Signature.getInstance("SLH-DSA-SHAKE-256s");

<a id="source-197"></a>

### tuning/js/alias.js:2:7

      1 import {generateKeyPairSync as make} from "node:crypto";
    > 2 make("ml-dsa-65");

<a id="source-198"></a>

### tuning/js/dead.js:1:33

    > 1 if (false) generateKeyPairSync("ml-kem-768");

<a id="source-199"></a>

### tuning/js/direct.js:1:22

    > 1 generateKeyPairSync("ml-kem-512");

<a id="source-200"></a>

### tuning/js/hybrid.js:1:16

    > 1 const group = "X25519MLKEM768";

<a id="source-201"></a>

### tuning/js/mixed.js:1:50

    > 1 generateKeyPairSync("rsa"); generateKeyPairSync("ml-kem-768");

<a id="source-202"></a>

### tuning/js/namesake.js:2:22

      1 function generateKeyPairSync(x) { return x; }
    > 2 generateKeyPairSync("ml-kem-768");

<a id="source-203"></a>

### tuning/js/same-line.js:1:22

    > 1 generateKeyPairSync("ml-kem-512"); generateKeyPairSync("ml-kem-1024");

<a id="source-204"></a>

### tuning/js/same-line.js:1:57

    > 1 generateKeyPairSync("ml-kem-512"); generateKeyPairSync("ml-kem-1024");

<a id="source-205"></a>

### tuning/js/shadow.js:2:68

      1 import {generateKeyPairSync} from "node:crypto";
    > 2 function render(generateKeyPairSync) { return generateKeyPairSync("ml-kem-768"); }

<a id="source-206"></a>

### tuning/js/string.js:1:36

    > 1 const help = 'generateKeyPairSync("ml-kem-768")';

<a id="source-207"></a>

### tuning/js/typed.js:1:29

    > 1 generateKeyPairSync({name: "ml-kem-768"});

<a id="source-208"></a>

### tuning/python/negative.py:1:8

    > 1 print("ML-KEM-768")

<a id="source-209"></a>

### tuning/ruby/negative.rb:1:7

    > 1 puts "SLH-DSA-SHA2-128s"

<a id="source-210"></a>

### tuning/ruby/pqc.rb:1:29

    > 1 OpenSSL::PKey.generate_key("ML-DSA-87")

<a id="source-211"></a>

### tuning/rust/pqc.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-212"></a>

### tuning/typescript/web.ts:1:35

    > 1 crypto.subtle.generateKey({name: "ML-KEM-768"}, true, ["encapsulateBits"]);

<a id="source-213"></a>

### tuning/width/tsx/standard.tsx:2:35

      1 const enabled: boolean = true;
    > 2 crypto.subtle.generateKey({name: "ML-KEM-768"}, true, []);

<a id="rule-47"></a>

## PQC_WEBCRYPTO_API

WebCrypto-style PQC algorithm request; this is not proof of browser support.

Check: Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-214"></a>[tuning/typescript/web.ts:1:15](#finding-214)|generate***M-768"|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-214)|
|<a id="finding-215"></a>[tuning/width/tsx/standard.tsx:2:15](#finding-215)|generate***M-768"|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-215)|

<a id="source-214"></a>

### tuning/typescript/web.ts:1:15

    > 1 crypto.subtle.generateKey({name: "ML-KEM-768"}, true, ["encapsulateBits"]);

<a id="source-215"></a>

### tuning/width/tsx/standard.tsx:2:15

      1 const enabled: boolean = true;
    > 2 crypto.subtle.generateKey({name: "ML-KEM-768"}, true, []);

## Action details

Each location links only to its applicable action. Identical payloads are printed once.

<a id="action-0"></a>


#### Adopt a phased hybrid PQC migration plan (near-term)

The detected primitive is vulnerable to cryptographically relevant quantum attacks. Hybrid rollout minimizes compatibility risk.

1. Inventory all call sites using this algorithm and owner teams.
2. Check for an existing classical + PQC composition; if migration is needed, evaluate compatible staged or hybrid modes before hard cut-over.
3. Define retirement dates for legacy classical algorithms.

References:

- https://www.nist.gov/itl/post-quantum-cryptography
- https://csrc.nist.gov/pubs/fips/203/final
- https://csrc.nist.gov/pubs/fips/204/final
<a id="action-1"></a>


#### Prepare hybrid certificate issuance and trust-store rollout (near-term)

PKI updates require coordinated CA, chain, and relying-party compatibility planning.

1. Inventory certificate signature algorithms and key sizes from CBOM/report output.
2. Pilot hybrid chain issuance in non-production trust stores.
3. Define reissuance plan for quantum-vulnerable roots/intermediates/end-entity certs.

References:

- https://csrc.nist.gov/pubs/fips/204/final
- https://csrc.nist.gov/pubs/fips/205/final
<a id="action-2"></a>


#### Review whether the JOSE reference is used for signing, verification, tests or documentation (near-term)

JWT signatures using classical public-key algorithms become long-term high risk under quantum adversaries.

1. Restrict accepted alg values and explicitly deny weak/legacy defaults.
2. Introduce short-lived tokens during the migration phase.
3. Prepare verifier rollout before signer rollout to avoid compatibility outages.
4. Confirm JOSE algorithm identifiers, key encoding, JWT library support and all verifiers before changing token signatures; primitive support alone is insufficient.

References:

- https://www.rfc-editor.org/rfc/rfc7519
<a id="action-3"></a>


#### Upgrade Node.js runtime for built-in WebCrypto PQC support (planned)

Node.js runtime level determines whether built-in PQC APIs are available for direct migration.

1. Node crypto: ML-DSA 24.6+, ML-KEM 24.7+, SLH-DSA 24.8+; WebCrypto ML-DSA/ML-KEM 24.7+. Check exact runtime and algorithm support.
2. Distinguish Node.js from browser execution; TypeScript types do not establish runtime capabilities. ML-KEM key exchange does not replace JWT signatures.

References:

- https://nodejs.org/api/webcrypto.html

Before (javascript)

    import jwt from "jsonwebtoken";
    const token = jwt.sign(payload, privateKey, { algorithm: "RS256" });

After

    // Replace RS256 token-signing path with a PQC-capable signing service
    // or WebCrypto ML-DSA workflow once runtime support is enabled.
    const token = await signWithPqc(payload);

<a id="action-4"></a>


#### Verify deployed runtime and protocol PQC capabilities (planned)

Source declarations and primitive availability do not establish deployment or peer support.

1. Node crypto ML-DSA requires 24.6+, ML-KEM 24.7+, SLH-DSA 24.8+; WebCrypto ML-DSA/ML-KEM requires 24.7+. Verify browser support independently of TypeScript declarations.
2. Check resolved versions, provider/features and interoperability before changing production policy.

References:

- https://nodejs.org/api/webcrypto.html
<a id="action-5"></a>


#### Review private-key markers and rotate exposed live credentials (immediate)

A private-key marker was found. Confirm whether complete key material is present and whether it belongs to a live exposed credential; the marker alone does not establish an incident.

1. Check whether the signal is a header reference, a synthetic test key, or complete live key material.
2. If a live credential is exposed, revoke or replace it and invalidate affected sessions/tokens as appropriate.
3. Move keys to a secret manager or HSM and enforce commit scanning in CI.

References:

- https://cheatsheetseries.owasp.org/cheatsheets/Secrets_Management_Cheat_Sheet.html
<a id="action-6"></a>


#### Review the cryptographic reference and its actual purpose (planned)

A source reference does not establish active signing, JWT issuance, or the absence of an existing PQC/hybrid composition.

1. Identify key generation, signing, verification, encryption or key establishment and separate tests/examples from deployed use.
2. Check existing PQC or hybrid components, provider support and protocol compatibility before selecting a change.

References:

- https://www.nist.gov/itl/post-quantum-cryptography
<a id="action-7"></a>


#### Introduce crypto abstraction boundary for algorithm agility (near-term)

Direct algorithm calls create high migration cost. A boundary layer enables staged classical-to-PQC transitions.

1. Wrap signing, verification, keygen, and key exchange behind stable interfaces.
2. Add policy controls to select classical, hybrid, or PQC paths at runtime.

References:

- https://www.nist.gov/itl/post-quantum-cryptography
<a id="action-8"></a>


#### Upgrade Java runtime baseline for standard PQC APIs (planned)

Detected Java version appears older than JDK releases with standardized PQC APIs.

1. Target JDK 24+ for ML-KEM and ML-DSA support planning.
2. Pilot compatibility testing in CI before production migration.

References:

- https://openjdk.org/jeps/496
- https://openjdk.org/jeps/497
<a id="action-9"></a>


#### Provide BouncyCastle PQC fallback path (near-term)

BouncyCastle can be used as a pragmatic transition option when standard runtime support is unavailable or incomplete.

1. Add BC provider initialization at bootstrap.
2. Use BC ML-DSA / ML-KEM parameter specs for migration pilot implementations.
3. Document provider ordering and FIPS/compliance impact.

References:

- https://www.bouncycastle.org/java.html
- https://downloads.bouncycastle.org/java/docs/bcprov-jdk18on-javadoc/

Before (java)

    Security.addProvider(new BouncyCastleProvider());
    Signature sig = Signature.getInstance("SHA256withRSA", "BC");

After

    Security.addProvider(new BouncyCastlePQCProvider());
    Signature sig = Signature.getInstance("ML-DSA", "BCPQC");
    // Configure parameter set (example): MLDSAParameterSpec.ml_dsa_65

<a id="action-10"></a>


#### Verify deployed runtime and protocol PQC capabilities (planned)

Source declarations and primitive availability do not establish deployment or peer support.

1. JDK 24 adds ML-KEM and ML-DSA primitives. Check deployed JSSE hybrid TLS support separately and inspect jdk.tls.namedGroups restrictions.
2. Check resolved versions, provider/features and interoperability before changing production policy.

References:

- https://docs.oracle.com/en/java/javase/27/security/java-secure-socket-extension-jsse-reference-guide.html
<a id="action-11"></a>


#### Validate Envoy PQC signature compatibility in control/data planes (advisory)

Envoy TLS behavior depends on configured providers and peer capabilities; PQC signature readiness can vary between mesh edges, sidecars, and external clients.

1. Harden min/max TLS versions and remove legacy RSA suites first.
2. Verify PQC certificate-signature compatibility in both downstream and upstream clusters.
3. Gate production rollout with staged canary tests and explicit fallback paths.

References:

- https://www.envoyproxy.io/docs/envoy/latest/intro/arch_overview/security/ssl.html
- https://www.envoyproxy.io/docs/envoy/latest/api-v3/extensions/transport_sockets/tls/v3/tls.proto
<a id="action-12"></a>


#### Validate HAProxy TLS stack PQC signature readiness before production (advisory)

HAProxy TLS capabilities are tied to the linked TLS stack and runtime policy; PQC signature behavior may differ by build and client compatibility.

1. Keep TLS 1.2+/1.3 policy and remove legacy protocol/cipher options first.
2. Run interoperability tests for PQC certificate signatures with all major client types.
3. Use phased rollout with rollback/fallback controls while collecting compatibility evidence.

References:

- https://www.haproxy.com/documentation/haproxy-configuration-tutorials/security/ssl-tls/
<a id="action-13"></a>


#### Validate Istio mesh-wide PQC signature interoperability before enforcement (advisory)

Istio rollout spans gateways, sidecars, and service-to-service traffic; mesh-wide certificate-signature interoperability must be validated end-to-end.

1. Standardize TLS modernization policy in DestinationRule/Gateway resources.
2. Test PQC signature compatibility across ingress gateway, sidecars, and external clients.
3. Roll out with progressive policies and keep compatibility fallbacks during migration.

References:

- https://istio.io/latest/docs/reference/config/networking/destination-rule/
- https://istio.io/latest/docs/reference/config/networking/gateway/
<a id="action-14"></a>


#### Validate Kubernetes PQC signature readiness before production rollout (advisory)

As described in Kubernetes guidance dated July 18, 2025, ecosystem readiness is currently stronger for hybrid key exchange than for end-to-end PQC certificate signatures.

1. Treat TLS modernization (TLS 1.2+/1.3) and hybrid KEM pilots as the immediate baseline.
2. Do not assume ML-DSA/SLH-DSA certificate signatures are natively interoperable across ingress/controller/mesh/CA/client paths.
3. Run staged compatibility tests before enforcing PQC signatures in production.

References:

- https://kubernetes.io/blog/2025/07/18/pqc-in-k8s/
- https://go.dev/doc/go1.26
<a id="action-15"></a>


#### Validate nginx/OpenSSL PQC signature interoperability before rollout (advisory)

nginx relies on TLS library behavior; hybrid KEM support and PQC certificate-signature interoperability can differ by OpenSSL/provider build and client ecosystem.

1. Keep TLS 1.2+/1.3 hardening as baseline and pilot hybrid KEM first.
2. Test ML-DSA/SLH-DSA certificate-chain interoperability across nginx, upstream TLS endpoints, and client stacks.
3. Roll out behind canary and keep fallback policy until interoperability evidence is complete.

References:

- https://nginx.org/en/docs/http/ngx_http_ssl_module.html
- https://openssl-library.org/post/2025-04-08-openssl-3.5-final/
<a id="action-16"></a>


#### Review the TLS reference before changing effective settings (planned)

A source name or token does not prove enabled configuration or a negotiated connection. ECDHE_RSA/DHE_RSA use RSA authentication, not static RSA key exchange.

1. Distinguish constants, comments, tests and active settings.
2. Inspect key agreement, authentication and protocol version separately; confirm existing hybrid support and peer compatibility before migration.

References:

- https://www.rfc-editor.org/rfc/rfc8422.html#section-2.2
<a id="action-17"></a>


#### Track PQC readiness of dependent libraries (planned)

Dependency-level crypto libraries strongly influence migration options and operational timelines.

1. Record current versions in dependency-sbom.json and define upgrade targets.
2. Subscribe to release notes for PQC feature availability and API changes.
3. Run integration tests for PQC or hybrid modes before promoting to production.

References:

- https://cyclonedx.org/
- https://spdx.dev/
<a id="action-18"></a>


#### Verify deployed runtime and protocol PQC capabilities (planned)

Source declarations and primitive availability do not establish deployment or peer support.

1. Check openssl gem and linked library/provider versions. gem 4 adds groups=, sigalgs= and negotiated group inspection; Ruby version alone is insufficient.
2. Check resolved versions, provider/features and interoperability before changing production policy.

References:

- https://ruby.github.io/openssl/History_md.html
<a id="action-19"></a>


#### Review the explicit PQC override: jdk.tls.namedGroups (near-term)

The detected setting restricts hybrid key exchange. It does not establish RSA usage or the negotiated TLS version.

1. Inspect jdk.tls.namedGroups at this location and confirm why the override is required.
2. Verify deployed library and peer support before testing a hybrid group or removing the override.
3. Check key exchange, TLS protocol version and certificate signatures separately; TLS 1.3 alone does not establish PQC protection.

References:

- https://go.dev/doc/godebug
- https://www.rfc-editor.org/rfc/rfc9325.html#section-3.1.1
<a id="action-20"></a>


#### Validate Traefik PQC signature interoperability with all entrypoints (advisory)

Traefik TLS options and provider integrations can produce environment-specific PQC signature behavior that must be validated before strict enforcement.

1. Raise minimum TLS version and remove legacy suites/options as baseline.
2. Test PQC certificate-signature compatibility for edge traffic, internal services, and automation clients.
3. Apply staged rollout with explicit compatibility fallback configuration.

References:

- https://doc.traefik.io/traefik/https/tls/
- https://doc.traefik.io/traefik/routing/routers/#tls

## Inventory exports

- [CBOM](cbom.json): 216
- [Dependency SBOM](dependency-sbom.json): 46


## Inspection coverage

Completeness covers supported inspection within the declared scope, after ignore settings, exclusions and size limits. It does not prove runtime use, certificate trust or security. Unenumerated files remain unknown.

|Item|Value|
|---|---|
|Status|Some inspection could not complete (partial)|
|Selected files|206|
|Read successfully|206|
|Read failed|0|
|Analyzed|155|
|Partial|34|
|Analysis failed|0|
|Unsupported|0|
|Not applicable|0|
|Unknown|17|
|Enumerated exclusions|0|
|Enumeration failures|0|
|Unenumerated population|Unknown|

## Inspection diagnostics

Counts and up to three example paths per reason; full records remain in diagnostics JSON.

|Item|Value|
|---|---|
|Detector failed (detector_failed)|14 records; tuning/manifests/Cargo.lock/malformed/Cargo.lock; tuning/manifests/Cargo.toml/malformed/Cargo.toml; tuning/manifests/Pipfile.lock/malformed/Pipfile.lock|
|Detector does not report completeness (detector_not_reported)|1 records; |
|Inspection unsupported (detector_unsupported)|2 records; tuning/certs/public-only.p12; tuning/certs/public-only.pfx|
|Only part of inspection completed (detector_partial)|23 records; tuning/certs/broken.cer; tuning/certs/broken.crt; tuning/certs/broken.der|
