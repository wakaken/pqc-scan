# PQS-QAM 品質測定レポート

測定対象: `1bb45f891c3b39f5e784e9b10cff23a1ee94ab0c`。
コーパス: `042-v1`。リリース判定: **Unknown**。
検出参照の有限データ評価です。安全性・実利用・PQC移行完了の認定ではありません。

| 軸 | 状態 | 範囲 |
|---|---|---|
| Q1 | Partial | Reviewed algorithm/use annotations; empty strata retained; correlated finite data, not population accuracy |
| Q2 | Partial | File partitions only; unenumerated population unknown, per-detector applicability not aggregated |
| Q3 | Not Tested | Detection labels do not validate risk/severity/recommendations or cryptography |
| Q4 | Not Tested | Separate safety tests required; successful scans do not prove robustness/security |
| Q5 | Partial | Repeated semantics; performance Not Tested; cold cache/multi-host/real product unmeasured |
| Q6 | Not Tested | Separate CI/process/platform/Scorecard evidence required |

FPは所見数、FPRは誤報があったnegative単位数/negative単位数です。母数ゼロはundefined。

| split/family | TP | FP | FN | TN | eligible | precision | recall | F1 | FPR | FNR |
|---|---:|---:|---:|---:|---:|---|---|---|---|---|
| holdout/source_api | 11 | 7 | 0 | 5 | 16 | 0.611111 | 1.000000 | 0.758621 | 0.000000 | 0.000000 |
| holdout/draft | 0 | 0 | 0 | 0 | 0 | undefined | undefined | undefined | undefined | undefined |
| holdout/config | 0 | 0 | 0 | 0 | 0 | undefined | undefined | undefined | undefined | undefined |
| holdout/dependency | 0 | 0 | 0 | 0 | 0 | undefined | undefined | undefined | undefined | undefined |
| holdout/key | 0 | 0 | 0 | 0 | 0 | undefined | undefined | undefined | undefined | undefined |
| holdout/certificate | 0 | 0 | 0 | 0 | 0 | undefined | undefined | undefined | undefined | undefined |
| tuning/source_api | 18 | 4 | 0 | 15 | 34 | 0.818182 | 1.000000 | 0.900000 | 0.062500 | 0.000000 |
| tuning/draft | 1 | 0 | 0 | 0 | 1 | 1.000000 | 1.000000 | 1.000000 | undefined | 0.000000 |
| tuning/config | 3 | 0 | 0 | 4 | 7 | 1.000000 | 1.000000 | 1.000000 | 0.000000 | 0.000000 |
| tuning/dependency | 17 | 0 | 0 | 20 | 37 | 1.000000 | 1.000000 | 1.000000 | 0.000000 | 0.000000 |
| tuning/key | 3 | 0 | 0 | 6 | 9 | 1.000000 | 1.000000 | 1.000000 | 0.000000 | 0.000000 |
| tuning/certificate | 7 | 6 | 0 | 7 | 14 | 0.538462 | 1.000000 | 0.700000 | 0.000000 | 0.000000 |

未評価の他ルール所見: 95。
言語・ルール・検出器・入力種別の分母、FP/FN、coverage、環境、反復、性能の全値はquality.jsonを参照。
方式別・用途別はquality.jsonを参照。暗号分類や実行の正しさは未検証です。
品質モデル・式・限界はdocs/quality/QUALITY-MODEL.mdとQUALITY-METRICS.mdを参照。

指定した規則と入力の範囲での注釈確認: **Partial**。負例に対応したFP所見1件、positiveへの重複0件、帰属不能16件。
帰属不能には正しい未注釈の事実が含まれ得ます。製品の誤検出とは断定できません。Precision/F1は固定注釈への一致成績です。
注釈不足はソースから調査します。正解を結果に合わせて変更せず、修正版を事後の調整用評価として区別します。
