# PQS-QAM 品質測定レポート

測定対象: `1bb45f891c3b39f5e784e9b10cff23a1ee94ab0c`。
コーパス: `023-v2`。リリース判定: **Unknown**。
検出参照の有限データ評価です。安全性・実利用・PQC移行完了の認定ではありません。

| 軸 | 状態 | 範囲 |
|---|---|---|
| Q1 | Partial | Frozen nominated reference detection only; per-algorithm truth and population generalization absent |
| Q2 | Partial | File partitions only; unenumerated population unknown, per-detector applicability not aggregated |
| Q3 | Not Tested | Detection labels do not validate risk/severity/recommendations or cryptography |
| Q4 | Not Tested | Separate safety tests required; successful scans do not prove robustness/security |
| Q5 | Partial | Repeated semantics; performance Not Tested; cold cache/multi-host/real product unmeasured |
| Q6 | Not Tested | Separate CI/process/platform/Scorecard evidence required |

FPは所見数、FPRは誤報があったnegative単位数/negative単位数です。母数ゼロはundefined。

| split/family | TP | FP | FN | TN | eligible | precision | recall | F1 | FPR | FNR |
|---|---:|---:|---:|---:|---:|---|---|---|---|---|
| holdout/source_api | 2 | 1 | 1 | 2 | 5 | 0.666667 | 0.666667 | 0.666667 | 0.000000 | 0.333333 |
| holdout/draft | 0 | 0 | 0 | 0 | 0 | undefined | undefined | undefined | undefined | undefined |
| holdout/config | 0 | 1 | 1 | 1 | 2 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 1.000000 |
| holdout/dependency | 2 | 0 | 0 | 2 | 4 | 1.000000 | 1.000000 | 1.000000 | 0.000000 | 0.000000 |
| holdout/certificate | 0 | 0 | 0 | 0 | 0 | undefined | undefined | undefined | undefined | undefined |
| holdout/key | 0 | 0 | 0 | 0 | 0 | undefined | undefined | undefined | undefined | undefined |
| tuning/source_api | 14 | 2 | 0 | 5 | 20 | 0.875000 | 1.000000 | 0.933333 | 0.166667 | 0.000000 |
| tuning/draft | 1 | 0 | 0 | 2 | 3 | 1.000000 | 1.000000 | 1.000000 | 0.000000 | 0.000000 |
| tuning/config | 3 | 0 | 0 | 3 | 6 | 1.000000 | 1.000000 | 1.000000 | 0.000000 | 0.000000 |
| tuning/dependency | 1 | 0 | 0 | 1 | 2 | 1.000000 | 1.000000 | 1.000000 | 0.000000 | 0.000000 |
| tuning/certificate | 4 | 0 | 0 | 2 | 6 | 1.000000 | 1.000000 | 1.000000 | 0.000000 | 0.000000 |
| tuning/key | 1 | 0 | 0 | 1 | 2 | 1.000000 | 1.000000 | 1.000000 | 0.000000 | 0.000000 |

未評価の他ルール所見: 20。
言語・ルール・検出器・入力種別の分母、FP/FN、coverage、環境、反復、性能の全値はquality.jsonを参照。
アルゴリズム別: Not Tested。未列挙母数はunknownであり、0ではありません。
品質モデル・式・限界はdocs/quality/QUALITY-MODEL.mdとQUALITY-METRICS.mdを参照。
