# PQC Migration Scan Report

Generated: 2026-11-12 02:08:16.001537 UTC

Risk candidates: 103 / Inventory findings: 55 / Scanned files: 206

Static evidence does not prove runtime use or completed PQC migration.

|Severity|Count (all findings)|
|---|---:|
|critical|13|
|high|26|
|info|55|
|low|4|
|medium|60|

## Risk candidate index

|Rule / description|Severity|Risk|Hits|Files|
|---|---|---|---:|---:|
|[CERT_RSA_SIGNATURE](#rule-0) Certificate signed with an RSA-based algorithm detected.|critical|quantum-vulnerable|6|6|
|[JWT_RS256](#rule-1) RS256 (RSA-based JWT signing) is in use.|critical|quantum-vulnerable|2|2|
|[PRIVATE_KEY_OPENSSH_HEADER](#rule-2) OpenSSH private key header detected.|critical|non-quantum-risk|1|1|
|[PRIVATE_KEY_PKCS8_HEADER](#rule-3) PKCS#8 private key header detected.|critical|non-quantum-risk|1|1|
|[PRIVATE_KEY_RSA_HEADER](#rule-4) RSA private key header detected.|critical|non-quantum-risk|1|1|
|[TS_JWT_RSA_ALGS](#rule-5) RSA-family JWT signing algorithms detected in AST nodes.|critical|quantum-vulnerable|2|2|
|[API_CIPHER_RSA](#rule-6) RSA cipher API usage detected.|high|quantum-vulnerable|1|1|
|[API_JOSE_RSA_ALG](#rule-7) RSA-family JOSE algorithm detected.|high|quantum-vulnerable|2|2|
|[API_SIGNATURE_RSA](#rule-8) RSA signature API usage detected.|high|quantum-vulnerable|1|1|
|[CERT_ECDSA_SIGNATURE](#rule-9) ECDSA certificate signature detected.|high|quantum-vulnerable|1|1|
|[CERT_RSA_3072](#rule-10) Certificate subject public key is 3072-bit RSA.|high|quantum-vulnerable|6|6|
|[ENVOY_TLS_MIN_VERSION_LEGACY](#rule-11) Envoy configuration allows TLSv1.0/1.1.|high|non-quantum-risk|1|1|
|[HAPROXY_BIND_TLSV1](#rule-12) HAProxy configuration explicitly enables TLSv1.0/1.1.|high|non-quantum-risk|1|1|
|[HTTPD_SSLPROTOCOL_LEGACY](#rule-13) Legacy TLSv1.x is enabled in Apache httpd configuration.|high|non-quantum-risk|1|1|
|[ISTIO_DESTINATIONRULE_TLSV1](#rule-14) Istio configuration permits TLSv1.0/1.1.|high|non-quantum-risk|1|1|
|[ISTIO_GATEWAY_TLSV1](#rule-15) TLSv1.0/1.1 setting detected in Istio Gateway configuration.|high|non-quantum-risk|1|1|
|[K8S_INGRESS_RSA_CIPHERS](#rule-16) RSA or weak cipher suites are configured in a Kubernetes Ingress annotation.|high|quantum-vulnerable|1|1|
|[NGINX_SSL_CIPHERS_RSA](#rule-17) RSA or weak cipher suites detected in nginx configuration.|high|quantum-vulnerable|1|1|
|[SSH_DSS_SIGALG](#rule-18) Deprecated ssh-dss usage detected.|high|non-quantum-risk|1|1|
|[TLS_VERSION_1_0](#rule-19) Legacy TLS 1.0 configuration detected.|high|non-quantum-risk|3|3|
|[TS_JAVA_RSA_API](#rule-20) RSA-related API symbols detected from Java AST.|high|quantum-vulnerable|2|2|
|[TS_RSA_KEY_SIZE_LITERAL](#rule-21) Classical public-key size literals detected in AST nodes.|high|quantum-vulnerable|2|2|
|[API_NODE_CRYPTO_SIGN_RSA](#rule-22) Node.js RSA signing API usage detected.|medium|quantum-vulnerable|4|1|
|[CERT_P12_CONTAINER](#rule-23) PKCS#12/PFX container file detected.|medium|quantum-uncertain|6|6|
|[DEP_BOUNCYCASTLE](#rule-24) BouncyCastle dependency detected.|medium|quantum-uncertain|4|4|
|[DEP_JAVA_BOUNCYCASTLE](#rule-25) Java BouncyCastle dependency detected.|medium|quantum-uncertain|4|4|
|[DEP_OPENSSL](#rule-26) OpenSSL dependency detected.|medium|quantum-uncertain|13|13|
|[DEP_PYCA_CRYPTOGRAPHY](#rule-27) Python cryptography dependency detected.|medium|quantum-uncertain|3|3|
|[DEP_RUBY_OPENSSL](#rule-28) Ruby OpenSSL dependency detected.|medium|quantum-uncertain|5|5|
|[DEP_RUST_OPENSSL](#rule-29) Rust TLS/crypto dependency detected.|medium|quantum-uncertain|1|1|
|[JWT_LIB_JOSE](#rule-30) jose dependency detected.|medium|quantum-uncertain|3|3|
|[PQC_DRAFT_ALGORITHM](#rule-31) Pre-standard PQC algorithm name referenced; check compatibility before replacing it.|medium|quantum-uncertain|1|1|
|[PQC_JAVA_CLASSICAL_GROUPS](#rule-32) Explicit classical-only Java property intent in assignment, XML entry or static System.setProperty; ...|medium|quantum-uncertain|1|1|
|[SSH_DH_GROUP14_SHA1](#rule-33) SHA-1 dependent SSH KEX detected.|medium|non-quantum-risk|1|1|
|[TRAEFIK_TLS_OPTIONS_LEGACY](#rule-34) Traefik configuration contains a low minimum TLS version.|medium|non-quantum-risk|1|1|
|[TS_NODE_JOSE_USAGE](#rule-35) JOSE/JWT calls detected from JavaScript/TypeScript AST.|medium|quantum-uncertain|5|2|
|[TS_NODE_RSA_USAGE](#rule-36) RSA-related API symbols detected from JavaScript/TypeScript AST.|medium|quantum-vulnerable|8|4|
|[CERT_PEM_CONTAINER](#rule-37) Certificate container file detected.|low|quantum-uncertain|4|4|

## Informational inventory index

|Rule / description|Severity|Risk|Hits|Files|
|---|---|---|---:|---:|
|[DEP_PQC_CAPABLE_LIBRARY](#rule-38) Library with version-dependent PQC capabilities inventoried; capability is not an enabled-state find...|info|quantum-uncertain|21|21|
|[PQC_GO_API](#rule-39) Standard Go PQC package imported; import alone does not prove negotiated protection.|info|quantum-safe|1|1|
|[PQC_JAVA_API](#rule-40) Standard PQC algorithm requested through Java APIs; runtime success is not established.|info|quantum-safe|5|5|
|[PQC_NODE_API](#rule-41) Node-style PQC key generation call; bindings and actual execution require confirmation.|info|quantum-safe|15|8|
|[PQC_PYTHON_API](#rule-42) Python PQC key generation reference; backend support is not established.|info|quantum-safe|3|2|
|[PQC_RUBY_API](#rule-43) Ruby PQC algorithm literal referenced; key generation or signing success is not established.|info|quantum-safe|2|2|
|[PQC_RUST_API](#rule-44) Rust PQC crate symbol referenced; execution and protocol use require confirmation.|info|quantum-safe|6|3|
|[PQC_WEBCRYPTO_API](#rule-45) WebCrypto-style PQC algorithm request; this is not proof of browser support.|info|quantum-safe|2|2|

<a id="rule-0"></a>

## CERT_RSA_SIGNATURE

Certificate signed with an RSA-based algorithm detected.

Check: Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-0"></a>[tuning/certs/public-rsa3072.cer:1:1](#finding-0)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-1"></a>[tuning/certs/public-rsa3072.crt:1:1](#finding-1)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-2"></a>[tuning/certs/public-rsa3072.pem:1:1](#finding-2)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / [Source](#source-2)|
|<a id="finding-3"></a>[tuning/certs/rsa3072.der:1:1](#finding-3)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-4"></a>[tuning/width/public-unencrypted.p12:1:1](#finding-4)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-5"></a>[tuning/width/public-unencrypted.pfx:1:1](#finding-5)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)

<a id="source-2"></a>

### tuning/certs/public-rsa3072.pem:1:1

    > 1 -----BEGIN CERTIFICATE-----
      2 [masked-sensitive-content]
      3 c2Nhbi1wdWJsaWMtdGVzdDAeFw0yNjExMDkwNzU1NTFaFw0zNjExMDYwNzU1NTFa

<a id="rule-1"></a>

## JWT_RS256

RS256 (RSA-based JWT signing) is in use.

Check: Migrate to ML-DSA signatures.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-6"></a>[holdout/jwt-rsa.js:2:64](#finding-6)|RS256|Migrate to ML-DSA signatures. / [Source](#source-6)|
|<a id="finding-7"></a>[tuning/jwt/sign.js:1:33](#finding-7)|RS256|Migrate to ML-DSA signatures. / [Source](#source-7)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Stop issuing new JWTs with RSA/PKCS#1/ECDSA-only algorithms](#action-2)
- [Upgrade Node.js runtime for built-in WebCrypto PQC support](#action-3)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-6"></a>

### holdout/jwt-rsa.js:2:64

      1 var privateKey = fs.readFileSync('private.key');
    > 2 var token = jwt.sign({ foo: 'bar' }, privateKey, { algorithm: 'RS256' });

<a id="source-7"></a>

### tuning/jwt/sign.js:1:33

    > 1 sign(payload, key, {algorithm: "RS256"});

<a id="rule-2"></a>

## PRIVATE_KEY_OPENSSH_HEADER

OpenSSH private key header detected.

Check: Treat OpenSSH private-key exposure as an urgent incident.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-8"></a>[tuning/markers/PRIVATE_KEY_OPENSSH_HEADER/marker.txt:1:1](#finding-8)|\[masked-private-key\]|Rotate exposed private keys and revoke affected credentials / [Rotate exposed private keys and revoke affected credentials](#action-5) / [Source](#source-8)|

<a id="source-8"></a>

### tuning/markers/PRIVATE_KEY_OPENSSH_HEADER/marker.txt:1:1

    > 1 [masked-private-key-material]

<a id="rule-3"></a>

## PRIVATE_KEY_PKCS8_HEADER

PKCS#8 private key header detected.

Check: Investigate private-key exposure and rotate credentials.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-9"></a>[tuning/markers/PRIVATE_KEY_PKCS8_HEADER/marker.txt:1:1](#finding-9)|\[masked-private-key\]|Rotate exposed private keys and revoke affected credentials / [Rotate exposed private keys and revoke affected credentials](#action-5) / [Source](#source-9)|

<a id="source-9"></a>

### tuning/markers/PRIVATE_KEY_PKCS8_HEADER/marker.txt:1:1

    > 1 [masked-private-key-material]

<a id="rule-4"></a>

## PRIVATE_KEY_RSA_HEADER

RSA private key header detected.

Check: Rotate exposed private keys immediately and strengthen key handling.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-10"></a>[tuning/markers/PRIVATE_KEY_RSA_HEADER/marker.txt:1:1](#finding-10)|\[masked-private-key\]|Rotate exposed private keys and revoke affected credentials / [Rotate exposed private keys and revoke affected credentials](#action-5) / [Source](#source-10)|

<a id="source-10"></a>

### tuning/markers/PRIVATE_KEY_RSA_HEADER/marker.txt:1:1

    > 1 [masked-private-key-material]

<a id="rule-5"></a>

## TS_JWT_RSA_ALGS

RSA-family JWT signing algorithms detected in AST nodes.

Check: Migrate JWT signing to ML-DSA or hybrid signatures.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-11"></a>[holdout/jwt-rsa.js:2:64](#finding-11)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-11)|
|<a id="finding-12"></a>[tuning/jwt/sign.js:1:33](#finding-12)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-12)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Stop issuing new JWTs with RSA/PKCS#1/ECDSA-only algorithms](#action-2)
- [Upgrade Node.js runtime for built-in WebCrypto PQC support](#action-3)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-11"></a>

### holdout/jwt-rsa.js:2:64

      1 var privateKey = fs.readFileSync('private.key');
    > 2 var token = jwt.sign({ foo: 'bar' }, privateKey, { algorithm: 'RS256' });

<a id="source-12"></a>

### tuning/jwt/sign.js:1:33

    > 1 sign(payload, key, {algorithm: "RS256"});

<a id="rule-6"></a>

## API_CIPHER_RSA

RSA cipher API usage detected.

Check: Migrate to hybrid KEM+AEAD cryptographic design.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-13"></a>[tuning/encryption/Encrypt.java:1:1](#finding-13)|Cipher.g***e("RSA|Provide BouncyCastle PQC fallback path / [Upgrade Java runtime baseline for standard PQC APIs](#action-6) / [Provide BouncyCastle PQC fallback path](#action-7) / [Source](#source-13)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Verify deployed runtime and protocol PQC capabilities](#action-8)

<a id="source-13"></a>

### tuning/encryption/Encrypt.java:1:1

    > 1 Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");

<a id="rule-7"></a>

## API_JOSE_RSA_ALG

RSA-family JOSE algorithm detected.

Check: Update JOSE algorithms to PQC-ready alternatives.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-14"></a>[holdout/jwt-rsa.js:2:64](#finding-14)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-14)|
|<a id="finding-15"></a>[tuning/jwt/sign.js:1:33](#finding-15)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-15)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Introduce crypto abstraction boundary for algorithm agility](#action-9)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-14"></a>

### holdout/jwt-rsa.js:2:64

      1 var privateKey = fs.readFileSync('private.key');
    > 2 var token = jwt.sign({ foo: 'bar' }, privateKey, { algorithm: 'RS256' });

<a id="source-15"></a>

### tuning/jwt/sign.js:1:33

    > 1 sign(payload, key, {algorithm: "RS256"});

<a id="rule-8"></a>

## API_SIGNATURE_RSA

RSA signature API usage detected.

Check: Migrate to ML-DSA signing APIs.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-16"></a>[tuning/java/Neg.java:1:1](#finding-16)|Signatur***thRSA"|Provide BouncyCastle PQC fallback path / [Upgrade Java runtime baseline for standard PQC APIs](#action-6) / [Provide BouncyCastle PQC fallback path](#action-7) / [Source](#source-16)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Verify deployed runtime and protocol PQC capabilities](#action-8)

<a id="source-16"></a>

### tuning/java/Neg.java:1:1

    > 1 Signature.getInstance("SHA256withRSA");

<a id="rule-9"></a>

## CERT_ECDSA_SIGNATURE

ECDSA certificate signature detected.

Check: Evaluate ML-DSA and SLH-DSA alternatives.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-17"></a>[tuning/certs/p256.der:1:1](#finding-17)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)

<a id="rule-10"></a>

## CERT_RSA_3072

Certificate subject public key is 3072-bit RSA.

Check: Evaluate standardized PQC signatures in supported issuance and verification environments.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-18"></a>[tuning/certs/public-rsa3072.cer:1:1](#finding-18)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / Source unavailable|
|<a id="finding-19"></a>[tuning/certs/public-rsa3072.crt:1:1](#finding-19)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / Source unavailable|
|<a id="finding-20"></a>[tuning/certs/public-rsa3072.pem:1:1](#finding-20)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / [Source](#source-20)|
|<a id="finding-21"></a>[tuning/certs/rsa3072.der:1:1](#finding-21)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / Source unavailable|
|<a id="finding-22"></a>[tuning/width/public-unencrypted.p12:1:1](#finding-22)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / Source unavailable|
|<a id="finding-23"></a>[tuning/width/public-unencrypted.pfx:1:1](#finding-23)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)

<a id="source-20"></a>

### tuning/certs/public-rsa3072.pem:1:1

    > 1 -----BEGIN CERTIFICATE-----
      2 [masked-sensitive-content]
      3 c2Nhbi1wdWJsaWMtdGVzdDAeFw0yNjExMDkwNzU1NTFaFw0zNjExMDYwNzU1NTFa

<a id="rule-11"></a>

## ENVOY_TLS_MIN_VERSION_LEGACY

Envoy configuration allows TLSv1.0/1.1.

Check: Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-24"></a>[tuning/width/envoy/selection.conf:1:1](#finding-24)|tls_mini***LSv1_0|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Validate Envoy PQC signature compatibility in control/data planes](#action-10) / [Source](#source-24)|

<a id="source-24"></a>

### tuning/width/envoy/selection.conf:1:1

    > 1 tls_minimum_protocol_version: TLSv1_0

<a id="rule-12"></a>

## HAPROXY_BIND_TLSV1

HAProxy configuration explicitly enables TLSv1.0/1.1.

Check: Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-25"></a>[tuning/width/haproxy/selection.conf:1:1](#finding-25)|bind :44***tlsv10|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Validate HAProxy TLS stack PQC signature readiness before production](#action-11) / [Source](#source-25)|

<a id="source-25"></a>

### tuning/width/haproxy/selection.conf:1:1

    > 1 bind :443 ssl force-tlsv10

<a id="rule-13"></a>

## HTTPD_SSLPROTOCOL_LEGACY

Legacy TLSv1.x is enabled in Apache httpd configuration.

Check: Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-26"></a>[tuning/width/apache/selection.conf:1:1](#finding-26)|SSLProtocol TLSv1.0|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Source](#source-26)|

<a id="source-26"></a>

### tuning/width/apache/selection.conf:1:1

    > 1 SSLProtocol TLSv1.0

<a id="rule-14"></a>

## ISTIO_DESTINATIONRULE_TLSV1

Istio configuration permits TLSv1.0/1.1.

Check: Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-27"></a>[tuning/width/istio/selection.conf:1:1](#finding-27)|minProto***LSV1_0|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Validate Istio mesh-wide PQC signature interoperability before enforcement](#action-12) / [Source](#source-27)|

<a id="source-27"></a>

### tuning/width/istio/selection.conf:1:1

    > 1 minProtocolVersion: TLSV1_0

<a id="rule-15"></a>

## ISTIO_GATEWAY_TLSV1

TLSv1.0/1.1 setting detected in Istio Gateway configuration.

Check: Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-28"></a>[tuning/width/istio/selection.conf:1:1](#finding-28)|minProto***LSV1_0|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Validate Istio mesh-wide PQC signature interoperability before enforcement](#action-12) / [Source](#source-28)|

<a id="source-28"></a>

### tuning/width/istio/selection.conf:1:1

    > 1 minProtocolVersion: TLSV1_0

<a id="rule-16"></a>

## K8S_INGRESS_RSA_CIPHERS

RSA or weak cipher suites are configured in a Kubernetes Ingress annotation.

Check: Remove RSA key-exchange dependency from Ingress cipher suites.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-29"></a>[tuning/width/kubernetes/selection.conf:1:1](#finding-29)|nginx.in***s: RSA|Remove RSA key-exchange dependency from Ingress cipher suites. / [Validate Kubernetes PQC signature readiness before production rollout](#action-13) / [Source](#source-29)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)

<a id="source-29"></a>

### tuning/width/kubernetes/selection.conf:1:1

    > 1 nginx.ingress.kubernetes.io/ssl-ciphers: RSA

<a id="rule-17"></a>

## NGINX_SSL_CIPHERS_RSA

RSA or weak cipher suites detected in nginx configuration.

Check: Refresh nginx cipher suites for PQC-hybrid migration readiness.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-30"></a>[tuning/width/nginx/selection.conf:1:1](#finding-30)|ssl_ciphers RSA|Refresh nginx cipher suites for PQC-hybrid migration readiness. / [Validate nginx/OpenSSL PQC signature interoperability before rollout](#action-14) / [Source](#source-30)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)

<a id="source-30"></a>

### tuning/width/nginx/selection.conf:1:1

    > 1 ssl_ciphers RSA;

<a id="rule-18"></a>

## SSH_DSS_SIGALG

Deprecated ssh-dss usage detected.

Check: Disable ssh-dss.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-31"></a>[tuning/ssh/dsa.conf:1:19](#finding-31)|ssh-dss|Disable ssh-dss. / [Source](#source-31)|

<a id="source-31"></a>

### tuning/ssh/dsa.conf:1:19

    > 1 HostKeyAlgorithms ssh-dss

<a id="rule-19"></a>

## TLS_VERSION_1_0

Legacy TLS 1.0 configuration detected.

Check: Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-32"></a>[tuning/width/apache/selection.conf:1:12](#finding-32)|TLSv1.0|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Harden Apache httpd SSL/TLS directives](#action-16) / [Source](#source-32)|
|<a id="finding-33"></a>[tuning/width/envoy/alternative.conf:1:30](#finding-33)|TLSv1_|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Validate Envoy PQC signature compatibility in control/data planes](#action-10) / [Set modern TLS policy in Envoy](#action-17) / [Source](#source-33)|
|<a id="finding-34"></a>[tuning/width/envoy/selection.conf:1:30](#finding-34)|TLSv1_|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Validate Envoy PQC signature compatibility in control/data planes](#action-10) / [Set modern TLS policy in Envoy](#action-17) / [Source](#source-34)|

Shared checks for these locations (not verified facts about each line):

- [Prefer TLS 1.3 and review legacy key exchange](#action-15)

<a id="source-32"></a>

### tuning/width/apache/selection.conf:1:12

    > 1 SSLProtocol TLSv1.0

<a id="source-33"></a>

### tuning/width/envoy/alternative.conf:1:30

    > 1 tls_minimum_protocol_version: TLSv1_3

<a id="source-34"></a>

### tuning/width/envoy/selection.conf:1:30

    > 1 tls_minimum_protocol_version: TLSv1_0

<a id="rule-20"></a>

## TS_JAVA_RSA_API

RSA-related API symbols detected from Java AST.

Check: Replace Java RSA API usage with PQC-capable libraries.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-35"></a>[tuning/encryption/Encrypt.java:1:1](#finding-35)|Cipher.g***e("RSA|Replace Java RSA API usage with PQC-capable libraries. / [Source](#source-35)|
|<a id="finding-36"></a>[tuning/java/Neg.java:1:1](#finding-36)|Signatur***ithRSA|Replace Java RSA API usage with PQC-capable libraries. / [Source](#source-36)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Upgrade Java runtime baseline for standard PQC APIs](#action-6)
- [Provide BouncyCastle PQC fallback path](#action-7)
- [Verify deployed runtime and protocol PQC capabilities](#action-8)

<a id="source-35"></a>

### tuning/encryption/Encrypt.java:1:1

    > 1 Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");

<a id="source-36"></a>

### tuning/java/Neg.java:1:1

    > 1 Signature.getInstance("SHA256withRSA");

<a id="rule-21"></a>

## TS_RSA_KEY_SIZE_LITERAL

Classical public-key size literals detected in AST nodes.

Check: Shift from key-length based planning to PQC signatures/key exchange.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-37"></a>[holdout/rsa-sign.js:8:3](#finding-37)|modulusLength: 2048|Shift from key-length based planning to PQC signatures/key exchange. / [Source](#source-37)|
|<a id="finding-38"></a>[tuning/js/same-line.js:1:44](#finding-38)|KeyPairS***m-1024|Shift from key-length based planning to PQC signatures/key exchange. / [Source](#source-38)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-37"></a>

### holdout/rsa-sign.js:8:3

      6 
      7 const { privateKey, publicKey } = generateKeyPairSync('rsa', {
    > 8   modulusLength: 2048,
      9 });
      10 

<a id="source-38"></a>

### tuning/js/same-line.js:1:44

    > 1 generateKeyPairSync("ml-kem-512"); generateKeyPairSync("ml-kem-1024");

<a id="rule-22"></a>

## API_NODE_CRYPTO_SIGN_RSA

Node.js RSA signing API usage detected.

Check: Plan PQC replacement for node:crypto RSA operations.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-39"></a>[holdout/rsa-sign.js:11:14](#finding-39)|createSign('SHA256'|Plan PQC replacement for node:crypto RSA operations. / [Source](#source-39)|
|<a id="finding-40"></a>[holdout/rsa-sign.js:14:19](#finding-40)|sign.sign(privateKey|Plan PQC replacement for node:crypto RSA operations. / [Source](#source-40)|
|<a id="finding-41"></a>[holdout/rsa-sign.js:16:16](#finding-41)|createVe***HA256'|Plan PQC replacement for node:crypto RSA operations. / [Source](#source-41)|
|<a id="finding-42"></a>[holdout/rsa-sign.js:19:13](#finding-42)|verify.v***licKey|Plan PQC replacement for node:crypto RSA operations. / [Source](#source-42)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Introduce crypto abstraction boundary for algorithm agility](#action-9)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-39"></a>

### holdout/rsa-sign.js:11:14

      9 });
      10 
    > 11 const sign = createSign('SHA256');
      12 sign.update('some data to sign');
      13 sign.end();

<a id="source-40"></a>

### holdout/rsa-sign.js:14:19

      12 sign.update('some data to sign');
      13 sign.end();
    > 14 const signature = sign.sign(privateKey);
      15 
      16 const verify = createVerify('SHA256');

<a id="source-41"></a>

### holdout/rsa-sign.js:16:16

      14 const signature = sign.sign(privateKey);
      15 
    > 16 const verify = createVerify('SHA256');
      17 verify.update('some data to sign');
      18 verify.end();

<a id="source-42"></a>

### holdout/rsa-sign.js:19:13

      17 verify.update('some data to sign');
      18 verify.end();
    > 19 console.log(verify.verify(publicKey, signature));
      20 // Prints: true

<a id="rule-23"></a>

## CERT_P12_CONTAINER

PKCS#12/PFX container file detected.

Check: Audit algorithms used inside PKCS#12/PFX containers.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-43"></a>[tuning/certs/broken.p12:1:1](#finding-43)|broken.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-44"></a>[tuning/certs/broken.pfx:1:1](#finding-44)|broken.pfx|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-45"></a>[tuning/certs/public-only.p12:1:1](#finding-45)|public-only.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-46"></a>[tuning/certs/public-only.pfx:1:1](#finding-46)|public-only.pfx|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-47"></a>[tuning/width/public-unencrypted.p12:1:1](#finding-47)|public-u***ed.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-48"></a>[tuning/width/public-unencrypted.pfx:1:1](#finding-48)|public-u***ed.pfx|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)

<a id="rule-24"></a>

## DEP_BOUNCYCASTLE

BouncyCastle dependency detected.

Check: Verify BouncyCastle PQC support status.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-49"></a>[tuning/manifests/build.gradle.kts/declared/build.gradle.kts:1:1](#finding-49)|org.boun***n@1.80|Verify BouncyCastle PQC support status. / [Source](#source-49)|
|<a id="finding-50"></a>[tuning/manifests/build.gradle/declared/build.gradle:1:1](#finding-50)|org.boun***n@1.80|Verify BouncyCastle PQC support status. / [Source](#source-50)|
|<a id="finding-51"></a>[tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1](#finding-51)|org.boun***n@1.80|Verify BouncyCastle PQC support status. / [Source](#source-51)|
|<a id="finding-52"></a>[tuning/manifests/pom.xml/declared/pom.xml:1:1](#finding-52)|org.boun***n@1.80|Verify BouncyCastle PQC support status. / [Source](#source-52)|

Shared checks for these locations (not verified facts about each line):

- [Prefer TLS 1.3 and review legacy key exchange](#action-15)
- [Track PQC readiness of dependent libraries](#action-18)

<a id="source-49"></a>

### tuning/manifests/build.gradle.kts/declared/build.gradle.kts:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-50"></a>

### tuning/manifests/build.gradle/declared/build.gradle:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-51"></a>

### tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-52"></a>

### tuning/manifests/pom.xml/declared/pom.xml:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-25"></a>

## DEP_JAVA_BOUNCYCASTLE

Java BouncyCastle dependency detected.

Check: Evaluate adoption of BouncyCastle PQC provider modules.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-53"></a>[tuning/manifests/build.gradle.kts/declared/build.gradle.kts:1:1](#finding-53)|org.boun***n@1.80|Evaluate adoption of BouncyCastle PQC provider modules. / [Source](#source-53)|
|<a id="finding-54"></a>[tuning/manifests/build.gradle/declared/build.gradle:1:1](#finding-54)|org.boun***n@1.80|Evaluate adoption of BouncyCastle PQC provider modules. / [Source](#source-54)|
|<a id="finding-55"></a>[tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1](#finding-55)|org.boun***n@1.80|Evaluate adoption of BouncyCastle PQC provider modules. / [Source](#source-55)|
|<a id="finding-56"></a>[tuning/manifests/pom.xml/declared/pom.xml:1:1](#finding-56)|org.boun***n@1.80|Evaluate adoption of BouncyCastle PQC provider modules. / [Source](#source-56)|

Shared checks for these locations (not verified facts about each line):

- [Introduce crypto abstraction boundary for algorithm agility](#action-9)
- [Track PQC readiness of dependent libraries](#action-18)

<a id="source-53"></a>

### tuning/manifests/build.gradle.kts/declared/build.gradle.kts:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-54"></a>

### tuning/manifests/build.gradle/declared/build.gradle:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-55"></a>

### tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-56"></a>

### tuning/manifests/pom.xml/declared/pom.xml:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-26"></a>

## DEP_OPENSSL

OpenSSL dependency detected.

Check: Review the OpenSSL PQC roadmap.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-57"></a>[tuning/manifests/Cargo.lock/declared/Cargo.lock:3:1](#finding-57)|openssl@0.10.75|Review the OpenSSL PQC roadmap. / [Source](#source-57)|
|<a id="finding-58"></a>[tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1](#finding-58)|openssl@0.10.75|Review the OpenSSL PQC roadmap. / [Source](#source-58)|
|<a id="finding-59"></a>[tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1](#finding-59)|openssl@3.3.0|Review the OpenSSL PQC roadmap. / [Source](#source-59)|
|<a id="finding-60"></a>[tuning/manifests/Gemfile/declared/Gemfile:1:1](#finding-60)|openssl@3.3.0|Review the OpenSSL PQC roadmap. / [Source](#source-60)|
|<a id="finding-61"></a>[tuning/manifests/fixture.gemspec/declared/fixture.gemspec:2:1](#finding-61)|openssl@3.3.0|Review the OpenSSL PQC roadmap. / [Source](#source-61)|
|<a id="finding-62"></a>[tuning/manifests/gems.locked/declared/gems.locked:3:1](#finding-62)|openssl@3.3.0|Review the OpenSSL PQC roadmap. / [Source](#source-62)|
|<a id="finding-63"></a>[tuning/manifests/gems.rb/declared/gems.rb:1:1](#finding-63)|openssl@3.3.0|Verify deployed runtime and protocol PQC capabilities / [Verify deployed runtime and protocol PQC capabilities](#action-19) / [Source](#source-63)|
|<a id="finding-64"></a>[tuning/sbom/CycloneDX-1.5/declared/bom.json:1:1](#finding-64)|openssl@3.5.0|Review the OpenSSL PQC roadmap. / [Source](#source-64)|
|<a id="finding-65"></a>[tuning/sbom/SPDX-2.3/declared/bom.json:1:1](#finding-65)|openssl@3.5.0|Review the OpenSSL PQC roadmap. / [Source](#source-65)|
|<a id="finding-66"></a>[tuning/width/cdx-1.4/library/bom.json:1:1](#finding-66)|openssl@3.5.0|Review the OpenSSL PQC roadmap. / [Source](#source-66)|
|<a id="finding-67"></a>[tuning/width/cdx-1.6/library/bom.json:1:1](#finding-67)|openssl@3.5.0|Review the OpenSSL PQC roadmap. / [Source](#source-67)|
|<a id="finding-68"></a>[tuning/width/cdx-1.7/library/bom.json:1:1](#finding-68)|openssl@3.5.0|Review the OpenSSL PQC roadmap. / [Source](#source-68)|
|<a id="finding-69"></a>[tuning/width/spdx-2.2/library/bom.json:1:1](#finding-69)|openssl@3.5.0|Review the OpenSSL PQC roadmap. / [Source](#source-69)|

Shared checks for these locations (not verified facts about each line):

- [Prefer TLS 1.3 and review legacy key exchange](#action-15)
- [Track PQC readiness of dependent libraries](#action-18)

<a id="source-57"></a>

### tuning/manifests/Cargo.lock/declared/Cargo.lock:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-58"></a>

### tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-59"></a>

### tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-60"></a>

### tuning/manifests/Gemfile/declared/Gemfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-61"></a>

### tuning/manifests/fixture.gemspec/declared/fixture.gemspec:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-62"></a>

### tuning/manifests/gems.locked/declared/gems.locked:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-63"></a>

### tuning/manifests/gems.rb/declared/gems.rb:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-64"></a>

### tuning/sbom/CycloneDX-1.5/declared/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-65"></a>

### tuning/sbom/SPDX-2.3/declared/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-66"></a>

### tuning/width/cdx-1.4/library/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-67"></a>

### tuning/width/cdx-1.6/library/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-68"></a>

### tuning/width/cdx-1.7/library/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-69"></a>

### tuning/width/spdx-2.2/library/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-27"></a>

## DEP_PYCA_CRYPTOGRAPHY

Python cryptography dependency detected.

Check: Track PQC support status in the cryptography package.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-70"></a>[tuning/manifests/Pipfile.lock/declared/Pipfile.lock:1:1](#finding-70)|cryptogr***48.0.0|Track PQC support status in the cryptography package. / [Source](#source-70)|
|<a id="finding-71"></a>[tuning/manifests/poetry.lock/declared/poetry.lock:2:1](#finding-71)|cryptography@48.0.0|Track PQC support status in the cryptography package. / [Source](#source-71)|
|<a id="finding-72"></a>[tuning/manifests/requirements.txt/declared/requirements.txt:1:1](#finding-72)|cryptography@48.0.0|Track PQC support status in the cryptography package. / [Source](#source-72)|

Shared checks for these locations (not verified facts about each line):

- [Introduce crypto abstraction boundary for algorithm agility](#action-9)
- [Track PQC readiness of dependent libraries](#action-18)

<a id="source-70"></a>

### tuning/manifests/Pipfile.lock/declared/Pipfile.lock:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-71"></a>

### tuning/manifests/poetry.lock/declared/poetry.lock:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-72"></a>

### tuning/manifests/requirements.txt/declared/requirements.txt:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-28"></a>

## DEP_RUBY_OPENSSL

Ruby OpenSSL dependency detected.

Check: Review OpenSSL usage in Ruby and prepare PQC migration path.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-73"></a>[tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1](#finding-73)|openssl@3.3.0|Review OpenSSL usage in Ruby and prepare PQC migration path. / [Source](#source-73)|
|<a id="finding-74"></a>[tuning/manifests/Gemfile/declared/Gemfile:1:1](#finding-74)|openssl@3.3.0|Review OpenSSL usage in Ruby and prepare PQC migration path. / [Source](#source-74)|
|<a id="finding-75"></a>[tuning/manifests/fixture.gemspec/declared/fixture.gemspec:2:1](#finding-75)|openssl@3.3.0|Review OpenSSL usage in Ruby and prepare PQC migration path. / [Source](#source-75)|
|<a id="finding-76"></a>[tuning/manifests/gems.locked/declared/gems.locked:3:1](#finding-76)|openssl@3.3.0|Review OpenSSL usage in Ruby and prepare PQC migration path. / [Source](#source-76)|
|<a id="finding-77"></a>[tuning/manifests/gems.rb/declared/gems.rb:1:1](#finding-77)|openssl@3.3.0|Verify deployed runtime and protocol PQC capabilities / [Verify deployed runtime and protocol PQC capabilities](#action-19) / [Source](#source-77)|

Shared checks for these locations (not verified facts about each line):

- [Introduce crypto abstraction boundary for algorithm agility](#action-9)
- [Track PQC readiness of dependent libraries](#action-18)

<a id="source-73"></a>

### tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-74"></a>

### tuning/manifests/Gemfile/declared/Gemfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-75"></a>

### tuning/manifests/fixture.gemspec/declared/fixture.gemspec:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-76"></a>

### tuning/manifests/gems.locked/declared/gems.locked:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-77"></a>

### tuning/manifests/gems.rb/declared/gems.rb:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-29"></a>

## DEP_RUST_OPENSSL

Rust TLS/crypto dependency detected.

Check: Track PQC migration options for Rust openssl/rustls crypto stacks.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-78"></a>[tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1](#finding-78)|openssl@0.10.75|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-78)|

Shared checks for these locations (not verified facts about each line):

- [Introduce crypto abstraction boundary for algorithm agility](#action-9)
- [Track PQC readiness of dependent libraries](#action-18)

<a id="source-78"></a>

### tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="rule-30"></a>

## JWT_LIB_JOSE

jose dependency detected.

Check: Verify PQC support in the JOSE implementation.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-79"></a>[tuning/manifests/package-lock.json/declared/package-lock.json:1:1](#finding-79)|jose@6.0.0|Verify PQC support in the JOSE implementation. / [Source](#source-79)|
|<a id="finding-80"></a>[tuning/manifests/package.json/declared/package.json:1:1](#finding-80)|jose@6.0.0|Verify PQC support in the JOSE implementation. / [Source](#source-80)|
|<a id="finding-81"></a>[tuning/manifests/pnpm-lock.yaml/declared/pnpm-lock.yaml:3:1](#finding-81)|jose@6.0.0|Verify PQC support in the JOSE implementation. / [Source](#source-81)|

Shared checks for these locations (not verified facts about each line):

- [Stop issuing new JWTs with RSA/PKCS#1/ECDSA-only algorithms](#action-2)

<a id="source-79"></a>

### tuning/manifests/package-lock.json/declared/package-lock.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-80"></a>

### tuning/manifests/package.json/declared/package.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-81"></a>

### tuning/manifests/pnpm-lock.yaml/declared/pnpm-lock.yaml:3:1

    > 3 [masked-sensitive-file-content]

<a id="rule-31"></a>

## PQC_DRAFT_ALGORITHM

Pre-standard PQC algorithm name referenced; check compatibility before replacing it.

Check: Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-82"></a>[tuning/js/draft.js:1:22](#finding-82)|kyber768|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-82)|

<a id="source-82"></a>

### tuning/js/draft.js:1:22

    > 1 generateKeyPairSync("kyber768");

<a id="rule-32"></a>

## PQC_JAVA_CLASSICAL_GROUPS

Explicit classical-only Java property intent in assignment, XML entry or static System.setProperty; effective loading is not established.

Check: Review explicit group restrictions against the deployed JSSE version and peer support.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-83"></a>[tuning/tls/positive.conf:1:1](#finding-83)|System.s***4r1");|Review explicit group restrictions against the deployed JSSE version and peer support. / [Review the explicit PQC override: jdk.tls.namedGroups](#action-20) / [Source](#source-83)|

<a id="source-83"></a>

### tuning/tls/positive.conf:1:1

    > 1 System.setProperty("jdk.tls.namedGroups", "secp256r1,secp384r1");

<a id="rule-33"></a>

## SSH_DH_GROUP14_SHA1

SHA-1 dependent SSH KEX detected.

Check: Retire SHA-1 based key exchange.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-84"></a>[tuning/ssh/dh.conf:1:15](#finding-84)|diffie-h***4-sha1|Retire SHA-1 based key exchange. / [Source](#source-84)|

<a id="source-84"></a>

### tuning/ssh/dh.conf:1:15

    > 1 KexAlgorithms diffie-hellman-group14-sha1

<a id="rule-34"></a>

## TRAEFIK_TLS_OPTIONS_LEGACY

Traefik configuration contains a low minimum TLS version.

Check: Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-85"></a>[tuning/width/traefik/selection.conf:1:1](#finding-85)|minVersi***nTLS10|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Validate Traefik PQC signature interoperability with all entrypoints](#action-21) / [Source](#source-85)|

<a id="source-85"></a>

### tuning/width/traefik/selection.conf:1:1

    > 1 minVersion: VersionTLS10

<a id="rule-35"></a>

## TS_NODE_JOSE_USAGE

JOSE/JWT calls detected from JavaScript/TypeScript AST.

Check: Evaluate PQC-capable options in JOSE/JWT implementations.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-86"></a>[holdout/jwt-helper.js:65:20](#finding-86)|jwt.verify|Evaluate PQC-capable options in JOSE/JWT implementations. / [Source](#source-86)|
|<a id="finding-87"></a>[holdout/jwt-helper.js:70:3](#finding-87)|jwt.verify|Evaluate PQC-capable options in JOSE/JWT implementations. / [Source](#source-87)|
|<a id="finding-88"></a>[holdout/jwt-helper.js:102:18](#finding-88)|jwt.sign|Evaluate PQC-capable options in JOSE/JWT implementations. / [Source](#source-88)|
|<a id="finding-89"></a>[holdout/jwt-helper.js:107:3](#finding-89)|jwt.sign|Evaluate PQC-capable options in JOSE/JWT implementations. / [Source](#source-89)|
|<a id="finding-90"></a>[holdout/jwt-rsa.js:2:13](#finding-90)|jwt.sign|Evaluate PQC-capable options in JOSE/JWT implementations. / [Source](#source-90)|

Shared checks for these locations (not verified facts about each line):

- [Stop issuing new JWTs with RSA/PKCS#1/ECDSA-only algorithms](#action-2)
- [Upgrade Node.js runtime for built-in WebCrypto PQC support](#action-3)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-86"></a>

### holdout/jwt-helper.js:65:20

      63   let syncVerified;
      64   try {
    > 65     syncVerified = jwt.verify(jwtString, secretOrPrivateKey, options);
      66   }
      67   catch (err) {

<a id="source-87"></a>

### holdout/jwt-helper.js:70:3

      68     error = err;
      69   }
    > 70   jwt.verify(jwtString, secretOrPrivateKey, options, (err, asyncVerifiedToken) => {
      71     try {
      72       if (error) {

<a id="source-88"></a>

### holdout/jwt-helper.js:102:18

      100   let syncSigned;
      101   try {
    > 102     syncSigned = jwt.sign(payload, secretOrPrivateKey, options);
      103   }
      104   catch (err) {

<a id="source-89"></a>

### holdout/jwt-helper.js:107:3

      105     error = err;
      106   }
    > 107   jwt.sign(payload, secretOrPrivateKey, options, (err, asyncSigned) => {
      108     fakeClock.restore();
      109     if (error) {

<a id="source-90"></a>

### holdout/jwt-rsa.js:2:13

      1 var privateKey = fs.readFileSync('private.key');
    > 2 var token = jwt.sign({ foo: 'bar' }, privateKey, { algorithm: 'RS256' });

<a id="rule-36"></a>

## TS_NODE_RSA_USAGE

RSA-related API symbols detected from JavaScript/TypeScript AST.

Check: Migrate Node.js RSA signing/verification logic to a PQC-ready design.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-91"></a>[holdout/jwt-rsa.js:2:64](#finding-91)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-91)|
|<a id="finding-92"></a>[holdout/rsa-sign.js:7:35](#finding-92)|generate***('rsa'|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-92)|
|<a id="finding-93"></a>[holdout/rsa-sign.js:11:14](#finding-93)|createSign('SHA256'|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-93)|
|<a id="finding-94"></a>[holdout/rsa-sign.js:14:19](#finding-94)|sign.sign(privateKey|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-94)|
|<a id="finding-95"></a>[holdout/rsa-sign.js:16:16](#finding-95)|createVe***HA256'|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-95)|
|<a id="finding-96"></a>[holdout/rsa-sign.js:19:13](#finding-96)|verify.v***licKey|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-96)|
|<a id="finding-97"></a>[tuning/js/mixed.js:1:1](#finding-97)|generate***("rsa"|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-97)|
|<a id="finding-98"></a>[tuning/jwt/sign.js:1:33](#finding-98)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-98)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Introduce crypto abstraction boundary for algorithm agility](#action-9)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-91"></a>

### holdout/jwt-rsa.js:2:64

      1 var privateKey = fs.readFileSync('private.key');
    > 2 var token = jwt.sign({ foo: 'bar' }, privateKey, { algorithm: 'RS256' });

<a id="source-92"></a>

### holdout/rsa-sign.js:7:35

      5 } = await import('node:crypto');
      6 
    > 7 const { privateKey, publicKey } = generateKeyPairSync('rsa', {
      8   modulusLength: 2048,
      9 });

<a id="source-93"></a>

### holdout/rsa-sign.js:11:14

      9 });
      10 
    > 11 const sign = createSign('SHA256');
      12 sign.update('some data to sign');
      13 sign.end();

<a id="source-94"></a>

### holdout/rsa-sign.js:14:19

      12 sign.update('some data to sign');
      13 sign.end();
    > 14 const signature = sign.sign(privateKey);
      15 
      16 const verify = createVerify('SHA256');

<a id="source-95"></a>

### holdout/rsa-sign.js:16:16

      14 const signature = sign.sign(privateKey);
      15 
    > 16 const verify = createVerify('SHA256');
      17 verify.update('some data to sign');
      18 verify.end();

<a id="source-96"></a>

### holdout/rsa-sign.js:19:13

      17 verify.update('some data to sign');
      18 verify.end();
    > 19 console.log(verify.verify(publicKey, signature));
      20 // Prints: true

<a id="source-97"></a>

### tuning/js/mixed.js:1:1

    > 1 generateKeyPairSync("rsa"); generateKeyPairSync("ml-kem-768");

<a id="source-98"></a>

### tuning/jwt/sign.js:1:33

    > 1 sign(payload, key, {algorithm: "RS256"});

<a id="rule-37"></a>

## CERT_PEM_CONTAINER

Certificate container file detected.

Check: Validate signing algorithms in PEM-based certificates.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-99"></a>[tuning/certs/broken.cer:1:1](#finding-99)|broken.cer|Validate signing algorithms in PEM-based certificates. / [Source](#source-99)|
|<a id="finding-100"></a>[tuning/certs/broken.crt:1:1](#finding-100)|broken.crt|Validate signing algorithms in PEM-based certificates. / [Source](#source-100)|
|<a id="finding-101"></a>[tuning/certs/broken.der:1:1](#finding-101)|broken.der|Validate signing algorithms in PEM-based certificates. / [Source](#source-101)|
|<a id="finding-102"></a>[tuning/certs/broken.pem:1:1](#finding-102)|broken.pem|Validate signing algorithms in PEM-based certificates. / [Source](#source-102)|

Shared checks for these locations (not verified facts about each line):

- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)

<a id="source-99"></a>

### tuning/certs/broken.cer:1:1

    > 1 not a certificate

<a id="source-100"></a>

### tuning/certs/broken.crt:1:1

    > 1 not a certificate

<a id="source-101"></a>

### tuning/certs/broken.der:1:1

    > 1 not a certificate

<a id="source-102"></a>

### tuning/certs/broken.pem:1:1

    > 1 not a certificate

<a id="rule-38"></a>

## DEP_PQC_CAPABLE_LIBRARY

Library with version-dependent PQC capabilities inventoried; capability is not an enabled-state finding.

Check: Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-103"></a>[tuning/manifests/Cargo.lock/declared/Cargo.lock:3:1](#finding-103)|openssl@0.10.75|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-103)|
|<a id="finding-104"></a>[tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1](#finding-104)|openssl@0.10.75|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-104)|
|<a id="finding-105"></a>[tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1](#finding-105)|openssl@3.3.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-105)|
|<a id="finding-106"></a>[tuning/manifests/Gemfile/declared/Gemfile:1:1](#finding-106)|openssl@3.3.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-106)|
|<a id="finding-107"></a>[tuning/manifests/Pipfile.lock/declared/Pipfile.lock:1:1](#finding-107)|cryptogr***48.0.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-107)|
|<a id="finding-108"></a>[tuning/manifests/build.gradle.kts/declared/build.gradle.kts:1:1](#finding-108)|org.boun***n@1.80|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-108)|
|<a id="finding-109"></a>[tuning/manifests/build.gradle/declared/build.gradle:1:1](#finding-109)|org.boun***n@1.80|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-109)|
|<a id="finding-110"></a>[tuning/manifests/fixture.gemspec/declared/fixture.gemspec:2:1](#finding-110)|openssl@3.3.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-110)|
|<a id="finding-111"></a>[tuning/manifests/gems.locked/declared/gems.locked:3:1](#finding-111)|openssl@3.3.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-111)|
|<a id="finding-112"></a>[tuning/manifests/gems.rb/declared/gems.rb:1:1](#finding-112)|openssl@3.3.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-112)|
|<a id="finding-113"></a>[tuning/manifests/go.mod/declared/go.mod:3:1](#finding-113)|github.c***v1.6.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-113)|
|<a id="finding-114"></a>[tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1](#finding-114)|org.boun***n@1.80|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-114)|
|<a id="finding-115"></a>[tuning/manifests/poetry.lock/declared/poetry.lock:2:1](#finding-115)|cryptography@48.0.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-115)|
|<a id="finding-116"></a>[tuning/manifests/pom.xml/declared/pom.xml:1:1](#finding-116)|org.boun***n@1.80|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-116)|
|<a id="finding-117"></a>[tuning/manifests/requirements.txt/declared/requirements.txt:1:1](#finding-117)|cryptography@48.0.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-117)|
|<a id="finding-118"></a>[tuning/sbom/CycloneDX-1.5/declared/bom.json:1:1](#finding-118)|openssl@3.5.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-118)|
|<a id="finding-119"></a>[tuning/sbom/SPDX-2.3/declared/bom.json:1:1](#finding-119)|openssl@3.5.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-119)|
|<a id="finding-120"></a>[tuning/width/cdx-1.4/library/bom.json:1:1](#finding-120)|openssl@3.5.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-120)|
|<a id="finding-121"></a>[tuning/width/cdx-1.6/library/bom.json:1:1](#finding-121)|openssl@3.5.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-121)|
|<a id="finding-122"></a>[tuning/width/cdx-1.7/library/bom.json:1:1](#finding-122)|openssl@3.5.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-122)|
|<a id="finding-123"></a>[tuning/width/spdx-2.2/library/bom.json:1:1](#finding-123)|openssl@3.5.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-123)|

Shared checks for these locations (not verified facts about each line):

- [Track PQC readiness of dependent libraries](#action-18)

<a id="source-103"></a>

### tuning/manifests/Cargo.lock/declared/Cargo.lock:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-104"></a>

### tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-105"></a>

### tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-106"></a>

### tuning/manifests/Gemfile/declared/Gemfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-107"></a>

### tuning/manifests/Pipfile.lock/declared/Pipfile.lock:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-108"></a>

### tuning/manifests/build.gradle.kts/declared/build.gradle.kts:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-109"></a>

### tuning/manifests/build.gradle/declared/build.gradle:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-110"></a>

### tuning/manifests/fixture.gemspec/declared/fixture.gemspec:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-111"></a>

### tuning/manifests/gems.locked/declared/gems.locked:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-112"></a>

### tuning/manifests/gems.rb/declared/gems.rb:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-113"></a>

### tuning/manifests/go.mod/declared/go.mod:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-114"></a>

### tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-115"></a>

### tuning/manifests/poetry.lock/declared/poetry.lock:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-116"></a>

### tuning/manifests/pom.xml/declared/pom.xml:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-117"></a>

### tuning/manifests/requirements.txt/declared/requirements.txt:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-118"></a>

### tuning/sbom/CycloneDX-1.5/declared/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-119"></a>

### tuning/sbom/SPDX-2.3/declared/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-120"></a>

### tuning/width/cdx-1.4/library/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-121"></a>

### tuning/width/cdx-1.6/library/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-122"></a>

### tuning/width/cdx-1.7/library/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-123"></a>

### tuning/width/spdx-2.2/library/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-39"></a>

## PQC_GO_API

Standard Go PQC package imported; import alone does not prove negotiated protection.

Check: crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-124"></a>[tuning/go/main.go:2:8](#finding-124)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-124)|

<a id="source-124"></a>

### tuning/go/main.go:2:8

      1 package data
    > 2 import "crypto/mlkem"

<a id="rule-40"></a>

## PQC_JAVA_API

Standard PQC algorithm requested through Java APIs; runtime success is not established.

Check: JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-125"></a>[holdout/MLDSA.java:1:36](#finding-125)|KeyPairG***SA-44"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-125)|
|<a id="finding-126"></a>[tuning/java/Broken.java:1:1](#finding-126)|Signatur***SA-65"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-126)|
|<a id="finding-127"></a>[tuning/java/Kem.java:1:1](#finding-127)|KEM.getI***-1024"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-127)|
|<a id="finding-128"></a>[tuning/java/ML.java:1:1](#finding-128)|Signatur***SA-44"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-128)|
|<a id="finding-129"></a>[tuning/java/Slh.java:1:1](#finding-129)|Signatur***-256s"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-129)|

<a id="source-125"></a>

### holdout/MLDSA.java:1:36

    > 1         KeyPairGenerator kpGen44 = KeyPairGenerator.getInstance("ML-DSA-44");

<a id="source-126"></a>

### tuning/java/Broken.java:1:1

    > 1 Signature.getInstance("ML-DSA-65"

<a id="source-127"></a>

### tuning/java/Kem.java:1:1

    > 1 KEM.getInstance("ML-KEM-1024");

<a id="source-128"></a>

### tuning/java/ML.java:1:1

    > 1 Signature.getInstance("ML-DSA-44");

<a id="source-129"></a>

### tuning/java/Slh.java:1:1

    > 1 Signature.getInstance("SLH-DSA-SHAKE-256s");

<a id="rule-41"></a>

## PQC_NODE_API

Node-style PQC key generation call; bindings and actual execution require confirmation.

Check: Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-130"></a>[holdout/ml-dsa.js:16:25](#finding-130)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-130)|
|<a id="finding-131"></a>[holdout/ml-dsa.js:54:7](#finding-131)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-131)|
|<a id="finding-132"></a>[holdout/ml-dsa.js:66:7](#finding-132)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-132)|
|<a id="finding-133"></a>[holdout/ml-kem.js:16:25](#finding-133)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-133)|
|<a id="finding-134"></a>[holdout/ml-kem.js:32:7](#finding-134)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-134)|
|<a id="finding-135"></a>[holdout/ml-kem.js:43:7](#finding-135)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-135)|
|<a id="finding-136"></a>[holdout/slh-dsa.js:20:25](#finding-136)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-136)|
|<a id="finding-137"></a>[holdout/slh-dsa.js:40:7](#finding-137)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-137)|
|<a id="finding-138"></a>[holdout/slh-dsa.js:51:7](#finding-138)|generate***eyType|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-138)|
|<a id="finding-139"></a>[tuning/js/alias.js:2:1](#finding-139)|make("ml-dsa-65"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-139)|
|<a id="finding-140"></a>[tuning/js/dead.js:1:12](#finding-140)|generate***m-768"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-140)|
|<a id="finding-141"></a>[tuning/js/direct.js:1:1](#finding-141)|generate***m-512"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-141)|
|<a id="finding-142"></a>[tuning/js/mixed.js:1:29](#finding-142)|generate***m-768"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-142)|
|<a id="finding-143"></a>[tuning/js/same-line.js:1:1](#finding-143)|generate***m-512"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-143)|
|<a id="finding-144"></a>[tuning/js/same-line.js:1:36](#finding-144)|generate***-1024"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-144)|

<a id="source-130"></a>

### holdout/ml-dsa.js:16:25

      14 if (!hasOpenSSL(3, 5)) {
      15   for (const asymmetricKeyType of ['ml-dsa-44', 'ml-dsa-65', 'ml-dsa-87']) {
    > 16     assert.throws(() => generateKeyPair(asymmetricKeyType, common.mustNotCall()), {
      17       code: 'ERR_INVALID_ARG_VALUE',
      18       message: /The argument 'type' must be a supported key type/

<a id="source-131"></a>

### holdout/ml-dsa.js:54:7

      52       [{ format: 'der', type: 'spki' }, (publicKey) => assert.strictEqual(Buffer.isBuffer(publicKey), true)],
      53     ]) {
    > 54       generateKeyPair(asymmetricKeyType, { publicKeyEncoding }, common.mustSucceed(validate));
      55     }
      56     for (const [privateKeyEncoding, validate] of [

<a id="source-132"></a>

### holdout/ml-dsa.js:66:7

      64       [{ format: 'der', type: 'pkcs8' }, (_, privateKey) => assert.strictEqual(Buffer.isBuffer(privateKey), true)],
      65     ]) {
    > 66       generateKeyPair(asymmetricKeyType, { privateKeyEncoding }, common.mustSucceed(validate));
      67     }
      68   }

<a id="source-133"></a>

### holdout/ml-kem.js:16:25

      14 if (!hasOpenSSL(3, 5)) {
      15   for (const asymmetricKeyType of ['ml-kem-512', 'ml-kem-768', 'ml-kem-1024']) {
    > 16     assert.throws(() => generateKeyPair(asymmetricKeyType, common.mustNotCall()), {
      17       code: 'ERR_INVALID_ARG_VALUE',
      18       message: /The argument 'type' must be a supported key type/

<a id="source-134"></a>

### holdout/ml-kem.js:32:7

      30       [{ format: 'der', type: 'spki' }, (publicKey) => assert.strictEqual(Buffer.isBuffer(publicKey), true)],
      31     ]) {
    > 32       generateKeyPair(asymmetricKeyType, { publicKeyEncoding }, common.mustSucceed(validate));
      33     }
      34     for (const [privateKeyEncoding, validate] of [

<a id="source-135"></a>

### holdout/ml-kem.js:43:7

      41       [{ format: 'der', type: 'pkcs8' }, (_, privateKey) => assert.strictEqual(Buffer.isBuffer(privateKey), true)],
      42     ]) {
    > 43       generateKeyPair(asymmetricKeyType, { privateKeyEncoding }, common.mustSucceed(validate));
      44     }
      45   }

<a id="source-136"></a>

### holdout/slh-dsa.js:20:25

      18     'slh-dsa-shake-192f', 'slh-dsa-shake-192s', 'slh-dsa-shake-256f', 'slh-dsa-shake-256s',
      19   ]) {
    > 20     assert.throws(() => generateKeyPair(asymmetricKeyType, common.mustNotCall()), {
      21       code: 'ERR_INVALID_ARG_VALUE',
      22       message: /The argument 'type' must be a supported key type/

<a id="source-137"></a>

### holdout/slh-dsa.js:40:7

      38       [{ format: 'der', type: 'spki' }, (publicKey) => assert.strictEqual(Buffer.isBuffer(publicKey), true)],
      39     ]) {
    > 40       generateKeyPair(asymmetricKeyType, { publicKeyEncoding }, common.mustSucceed(validate));
      41     }
      42     for (const [privateKeyEncoding, validate] of [

<a id="source-138"></a>

### holdout/slh-dsa.js:51:7

      49       [{ format: 'der', type: 'pkcs8' }, (_, privateKey) => assert.strictEqual(Buffer.isBuffer(privateKey), true)],
      50     ]) {
    > 51       generateKeyPair(asymmetricKeyType, { privateKeyEncoding }, common.mustSucceed(validate));
      52     }
      53   }

<a id="source-139"></a>

### tuning/js/alias.js:2:1

      1 import {generateKeyPairSync as make} from "node:crypto";
    > 2 make("ml-dsa-65");

<a id="source-140"></a>

### tuning/js/dead.js:1:12

    > 1 if (false) generateKeyPairSync("ml-kem-768");

<a id="source-141"></a>

### tuning/js/direct.js:1:1

    > 1 generateKeyPairSync("ml-kem-512");

<a id="source-142"></a>

### tuning/js/mixed.js:1:29

    > 1 generateKeyPairSync("rsa"); generateKeyPairSync("ml-kem-768");

<a id="source-143"></a>

### tuning/js/same-line.js:1:1

    > 1 generateKeyPairSync("ml-kem-512"); generateKeyPairSync("ml-kem-1024");

<a id="source-144"></a>

### tuning/js/same-line.js:1:36

    > 1 generateKeyPairSync("ml-kem-512"); generateKeyPairSync("ml-kem-1024");

<a id="rule-42"></a>

## PQC_PYTHON_API

Python PQC key generation reference; backend support is not established.

Check: cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-145"></a>[tuning/python/broken.py:1:7](#finding-145)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-145)|
|<a id="finding-146"></a>[tuning/python/pqc.py:1:1](#finding-146)|from cry*** mlkem|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-146)|
|<a id="finding-147"></a>[tuning/python/pqc.py:2:5](#finding-147)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-147)|

<a id="source-145"></a>

### tuning/python/broken.py:1:7

    > 1 key = mlkem.MLKEM768PrivateKey.generate(

<a id="source-146"></a>

### tuning/python/pqc.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric import mlkem
      2 k = mlkem.MLKEM768PrivateKey.generate()

<a id="source-147"></a>

### tuning/python/pqc.py:2:5

      1 from cryptography.hazmat.primitives.asymmetric import mlkem
    > 2 k = mlkem.MLKEM768PrivateKey.generate()

<a id="rule-43"></a>

## PQC_RUBY_API

Ruby PQC algorithm literal referenced; key generation or signing success is not established.

Check: Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-148"></a>[tuning/ruby/negative.rb:1:6](#finding-148)|"SLH-DSA-SHA2-128s"|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-148)|
|<a id="finding-149"></a>[tuning/ruby/pqc.rb:1:28](#finding-149)|"ML-DSA-87"|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-149)|

<a id="source-148"></a>

### tuning/ruby/negative.rb:1:6

    > 1 puts "SLH-DSA-SHA2-128s"

<a id="source-149"></a>

### tuning/ruby/pqc.rb:1:28

    > 1 OpenSSL::PKey.generate_key("ML-DSA-87")

<a id="rule-44"></a>

## PQC_RUST_API

Rust PQC crate symbol referenced; execution and protocol use require confirmation.

Check: Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-150"></a>[holdout/rustcrypto-usage.rs:1:5](#finding-150)|ml_kem::*|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-150)|
|<a id="finding-151"></a>[holdout/rustcrypto-usage.rs:6:16](#finding-151)|MlKem768::generate|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-151)|
|<a id="finding-152"></a>[holdout/rustcrypto-usage.rs:10:20](#finding-152)|ek.encapsulate|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-152)|
|<a id="finding-153"></a>[holdout/rustcrypto-usage.rs:13:14](#finding-153)|dk.decapsulate|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-153)|
|<a id="finding-154"></a>[tuning/rust/broken.rs:1:5](#finding-154)|ml_kem::|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-154)|
|<a id="finding-155"></a>[tuning/rust/pqc.rs:1:5](#finding-155)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-155)|

<a id="source-150"></a>

### holdout/rustcrypto-usage.rs:1:5

    > 1 use ml_kem::*;
      2 use ::kem::{Decapsulate, Encapsulate};
      3 let mut rng = rand::thread_rng();

<a id="source-151"></a>

### holdout/rustcrypto-usage.rs:6:16

      4 
      5 // Generate a (decapsulation key, encapsulation key) pair
    > 6 let (dk, ek) = MlKem768::generate(&mut rng);
      7 
      8 // Encapsulate a shared key to the holder of the decapsulation key, receive the shared

<a id="source-152"></a>

### holdout/rustcrypto-usage.rs:10:20

      8 // Encapsulate a shared key to the holder of the decapsulation key, receive the shared
      9 // secret `k_send` and the encapsulated form `ct`.
    > 10 let (ct, k_send) = ek.encapsulate(&mut rng).unwrap();
      11 
      12 // Decapsulate the shared key and verify that it was faithfully received.

<a id="source-153"></a>

### holdout/rustcrypto-usage.rs:13:14

      11 
      12 // Decapsulate the shared key and verify that it was faithfully received.
    > 13 let k_recv = dk.decapsulate(&ct).unwrap();
      14 assert_eq!(k_send, k_recv);

<a id="source-154"></a>

### tuning/rust/broken.rs:1:5

    > 1 use ml_kem::

<a id="source-155"></a>

### tuning/rust/pqc.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="rule-45"></a>

## PQC_WEBCRYPTO_API

WebCrypto-style PQC algorithm request; this is not proof of browser support.

Check: Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-156"></a>[tuning/typescript/web.ts:1:15](#finding-156)|generate***M-768"|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-156)|
|<a id="finding-157"></a>[tuning/width/tsx/standard.tsx:2:15](#finding-157)|generate***M-768"|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-157)|

<a id="source-156"></a>

### tuning/typescript/web.ts:1:15

    > 1 crypto.subtle.generateKey({name: "ML-KEM-768"}, true, ["encapsulateBits"]);

<a id="source-157"></a>

### tuning/width/tsx/standard.tsx:2:15

      1 const enabled: boolean = true;
    > 2 crypto.subtle.generateKey({name: "ML-KEM-768"}, true, []);

## Action details

Each location links only to its applicable action. Identical payloads are printed once.

<a id="action-0"></a>


#### Adopt a phased hybrid PQC migration plan (near-term)

The detected primitive is vulnerable to cryptographically relevant quantum attacks. Hybrid rollout minimizes compatibility risk.

1. Inventory all call sites using this algorithm and owner teams.
2. Introduce dual-stack or hybrid mode (classical + PQC) before hard cut-over.
3. Define retirement dates for legacy classical algorithms.

References:

- https://www.nist.gov/itl/post-quantum-cryptography
- https://csrc.nist.gov/pubs/fips/203/final
- https://csrc.nist.gov/pubs/fips/204/final
<a id="action-1"></a>


#### Prepare hybrid certificate issuance and trust-store rollout (near-term)

PKI updates require coordinated CA, chain, and relying-party compatibility planning.

1. Inventory certificate signature algorithms and key sizes from CBOM/report output.
2. Pilot hybrid chain issuance in non-production trust stores.
3. Define reissuance plan for quantum-vulnerable roots/intermediates/end-entity certs.

References:

- https://csrc.nist.gov/pubs/fips/204/final
- https://csrc.nist.gov/pubs/fips/205/final
<a id="action-2"></a>


#### Stop issuing new JWTs with RSA/PKCS#1/ECDSA-only algorithms (near-term)

JWT signatures using classical public-key algorithms become long-term high risk under quantum adversaries.

1. Restrict accepted alg values and explicitly deny weak/legacy defaults.
2. Introduce short-lived tokens during the migration phase.
3. Prepare verifier rollout before signer rollout to avoid compatibility outages.
4. Confirm JOSE algorithm identifiers, key encoding, JWT library support and all verifiers before changing token signatures; primitive support alone is insufficient.

References:

- https://www.rfc-editor.org/rfc/rfc7519
<a id="action-3"></a>


#### Upgrade Node.js runtime for built-in WebCrypto PQC support (planned)

Node.js runtime level determines whether built-in PQC APIs are available for direct migration.

1. Node crypto: ML-DSA 24.6+, ML-KEM 24.7+, SLH-DSA 24.8+; WebCrypto ML-DSA/ML-KEM 24.7+. Check exact runtime and algorithm support.
2. Distinguish Node.js from browser execution; TypeScript types do not establish runtime capabilities. ML-KEM key exchange does not replace JWT signatures.

References:

- https://nodejs.org/api/webcrypto.html

Before (javascript)

    import jwt from "jsonwebtoken";
    const token = jwt.sign(payload, privateKey, { algorithm: "RS256" });

After

    // Replace RS256 token-signing path with a PQC-capable signing service
    // or WebCrypto ML-DSA workflow once runtime support is enabled.
    const token = await signWithPqc(payload);

<a id="action-4"></a>


#### Verify deployed runtime and protocol PQC capabilities (planned)

Source declarations and primitive availability do not establish deployment or peer support.

1. Node crypto ML-DSA requires 24.6+, ML-KEM 24.7+, SLH-DSA 24.8+; WebCrypto ML-DSA/ML-KEM requires 24.7+. Verify browser support independently of TypeScript declarations.
2. Check resolved versions, provider/features and interoperability before changing production policy.

References:

- https://nodejs.org/api/webcrypto.html
<a id="action-5"></a>


#### Rotate exposed private keys and revoke affected credentials (immediate)

Private key material was detected. This is an active key-management incident and must be remediated immediately.

1. Revoke/disable the exposed key and issue a replacement key pair.
2. Invalidate sessions/tokens signed by the compromised key if applicable.
3. Move keys to a secret manager or HSM and enforce commit scanning in CI.

References:

- https://cheatsheetseries.owasp.org/cheatsheets/Secrets_Management_Cheat_Sheet.html
<a id="action-6"></a>


#### Upgrade Java runtime baseline for standard PQC APIs (planned)

Detected Java version appears older than JDK releases with standardized PQC APIs.

1. Target JDK 24+ for ML-KEM and ML-DSA support planning.
2. Pilot compatibility testing in CI before production migration.

References:

- https://openjdk.org/jeps/496
- https://openjdk.org/jeps/497
<a id="action-7"></a>


#### Provide BouncyCastle PQC fallback path (near-term)

BouncyCastle can be used as a pragmatic transition option when standard runtime support is unavailable or incomplete.

1. Add BC provider initialization at bootstrap.
2. Use BC ML-DSA / ML-KEM parameter specs for migration pilot implementations.
3. Document provider ordering and FIPS/compliance impact.

References:

- https://www.bouncycastle.org/java.html
- https://downloads.bouncycastle.org/java/docs/bcprov-jdk18on-javadoc/

Before (java)

    Security.addProvider(new BouncyCastleProvider());
    Signature sig = Signature.getInstance("SHA256withRSA", "BC");

After

    Security.addProvider(new BouncyCastlePQCProvider());
    Signature sig = Signature.getInstance("ML-DSA", "BCPQC");
    // Configure parameter set (example): MLDSAParameterSpec.ml_dsa_65

<a id="action-8"></a>


#### Verify deployed runtime and protocol PQC capabilities (planned)

Source declarations and primitive availability do not establish deployment or peer support.

1. JDK 24 adds ML-KEM and ML-DSA primitives. Check deployed JSSE hybrid TLS support separately and inspect jdk.tls.namedGroups restrictions.
2. Check resolved versions, provider/features and interoperability before changing production policy.

References:

- https://docs.oracle.com/en/java/javase/27/security/java-secure-socket-extension-jsse-reference-guide.html
<a id="action-9"></a>


#### Introduce crypto abstraction boundary for algorithm agility (near-term)

Direct algorithm calls create high migration cost. A boundary layer enables staged classical-to-PQC transitions.

1. Wrap signing, verification, keygen, and key exchange behind stable interfaces.
2. Add policy controls to select classical, hybrid, or PQC paths at runtime.

References:

- https://www.nist.gov/itl/post-quantum-cryptography
<a id="action-10"></a>


#### Validate Envoy PQC signature compatibility in control/data planes (advisory)

Envoy TLS behavior depends on configured providers and peer capabilities; PQC signature readiness can vary between mesh edges, sidecars, and external clients.

1. Harden min/max TLS versions and remove legacy RSA suites first.
2. Verify PQC certificate-signature compatibility in both downstream and upstream clusters.
3. Gate production rollout with staged canary tests and explicit fallback paths.

References:

- https://www.envoyproxy.io/docs/envoy/latest/intro/arch_overview/security/ssl.html
- https://www.envoyproxy.io/docs/envoy/latest/api-v3/extensions/transport_sockets/tls/v3/tls.proto
<a id="action-11"></a>


#### Validate HAProxy TLS stack PQC signature readiness before production (advisory)

HAProxy TLS capabilities are tied to the linked TLS stack and runtime policy; PQC signature behavior may differ by build and client compatibility.

1. Keep TLS 1.2+/1.3 policy and remove legacy protocol/cipher options first.
2. Run interoperability tests for PQC certificate signatures with all major client types.
3. Use phased rollout with rollback/fallback controls while collecting compatibility evidence.

References:

- https://www.haproxy.com/documentation/haproxy-configuration-tutorials/security/ssl-tls/
<a id="action-12"></a>


#### Validate Istio mesh-wide PQC signature interoperability before enforcement (advisory)

Istio rollout spans gateways, sidecars, and service-to-service traffic; mesh-wide certificate-signature interoperability must be validated end-to-end.

1. Standardize TLS modernization policy in DestinationRule/Gateway resources.
2. Test PQC signature compatibility across ingress gateway, sidecars, and external clients.
3. Roll out with progressive policies and keep compatibility fallbacks during migration.

References:

- https://istio.io/latest/docs/reference/config/networking/destination-rule/
- https://istio.io/latest/docs/reference/config/networking/gateway/
<a id="action-13"></a>


#### Validate Kubernetes PQC signature readiness before production rollout (advisory)

As described in Kubernetes guidance dated July 18, 2025, ecosystem readiness is currently stronger for hybrid key exchange than for end-to-end PQC certificate signatures.

1. Treat TLS modernization (TLS 1.2+/1.3) and hybrid KEM pilots as the immediate baseline.
2. Do not assume ML-DSA/SLH-DSA certificate signatures are natively interoperable across ingress/controller/mesh/CA/client paths.
3. Run staged compatibility tests before enforcing PQC signatures in production.

References:

- https://kubernetes.io/blog/2025/07/18/pqc-in-k8s/
- https://go.dev/doc/go1.26
<a id="action-14"></a>


#### Validate nginx/OpenSSL PQC signature interoperability before rollout (advisory)

nginx relies on TLS library behavior; hybrid KEM support and PQC certificate-signature interoperability can differ by OpenSSL/provider build and client ecosystem.

1. Keep TLS 1.2+/1.3 hardening as baseline and pilot hybrid KEM first.
2. Test ML-DSA/SLH-DSA certificate-chain interoperability across nginx, upstream TLS endpoints, and client stacks.
3. Roll out behind canary and keep fallback policy until interoperability evidence is complete.

References:

- https://nginx.org/en/docs/http/ngx_http_ssl_module.html
- https://openssl-library.org/post/2025-04-08-openssl-3.5-final/
<a id="action-15"></a>


#### Prefer TLS 1.3 and review legacy key exchange (near-term)

RSA key exchange and legacy protocol versions are high-priority migration blockers for PQC readiness.

1. Prefer TLS 1.3; restrict connections to TLS 1.3 when all peers support it. Disable TLS 1.0 and 1.1.
2. Retain securely configured TLS 1.2 only where interoperability requires it, and record the compatibility reason.
3. Prefer ECDHE today and plan hybrid KEM suites for next phase.
4. Continuously test interoperability across clients and load balancers.

References:

- https://www.rfc-editor.org/rfc/rfc8446
<a id="action-16"></a>


#### Harden Apache httpd SSL/TLS directives (near-term)

Apache TLS settings can be migrated safely via explicit protocol and cipher controls.

1. Prefer \`SSLProtocol -all +TLSv1.3\` when all peers support it; retain TLSv1.2 only for a documented interoperability need.
2. Review \`SSLCipherSuite\` and remove RSA key-exchange suites.

References:

- https://httpd.apache.org/docs/trunk/mod/mod_ssl.html
<a id="action-17"></a>


#### Set modern TLS policy in Envoy (near-term)

Envoy control-plane config supports strict min/max protocol and cipher suite policy.

1. Prefer \`tls_minimum_protocol_version: TLSv1_3\`; use TLSv1_2 only when interoperability requires it.
2. Remove RSA-dependent suites from \`cipher_suites\`.

References:

- https://www.envoyproxy.io/docs/envoy/latest/api-v3/extensions/transport_sockets/tls/v3/tls.proto
<a id="action-18"></a>


#### Track PQC readiness of dependent libraries (planned)

Dependency-level crypto libraries strongly influence migration options and operational timelines.

1. Record current versions in dependency-sbom.json and define upgrade targets.
2. Subscribe to release notes for PQC feature availability and API changes.
3. Run integration tests for PQC or hybrid modes before promoting to production.

References:

- https://cyclonedx.org/
- https://spdx.dev/
<a id="action-19"></a>


#### Verify deployed runtime and protocol PQC capabilities (planned)

Source declarations and primitive availability do not establish deployment or peer support.

1. Check openssl gem and linked library/provider versions. gem 4 adds groups=, sigalgs= and negotiated group inspection; Ruby version alone is insufficient.
2. Check resolved versions, provider/features and interoperability before changing production policy.

References:

- https://ruby.github.io/openssl/History_md.html
<a id="action-20"></a>


#### Review the explicit PQC override: jdk.tls.namedGroups (near-term)

The detected setting restricts hybrid key exchange. It does not establish RSA usage or the negotiated TLS version.

1. Inspect jdk.tls.namedGroups at this location and confirm why the override is required.
2. Verify deployed library and peer support before testing a hybrid group or removing the override.
3. Check key exchange, TLS protocol version and certificate signatures separately; TLS 1.3 alone does not establish PQC protection.

References:

- https://go.dev/doc/godebug
- https://www.rfc-editor.org/rfc/rfc9325.html#section-3.1.1
<a id="action-21"></a>


#### Validate Traefik PQC signature interoperability with all entrypoints (advisory)

Traefik TLS options and provider integrations can produce environment-specific PQC signature behavior that must be validated before strict enforcement.

1. Raise minimum TLS version and remove legacy suites/options as baseline.
2. Test PQC certificate-signature compatibility for edge traffic, internal services, and automation clients.
3. Apply staged rollout with explicit compatibility fallback configuration.

References:

- https://doc.traefik.io/traefik/https/tls/
- https://doc.traefik.io/traefik/routing/routers/#tls

## Inventory exports

- [CBOM](cbom.json): 158
- [Dependency SBOM](dependency-sbom.json): 46


## Inspection coverage

Completeness covers supported inspection within the declared scope, after ignore settings, exclusions and size limits. It does not prove runtime use, certificate trust or security. Unenumerated files remain unknown.

|Item|Value|
|---|---|
|Status|Some inspection could not complete (partial)|
|Selected files|206|
|Read successfully|206|
|Read failed|0|
|Analyzed|153|
|Partial|32|
|Analysis failed|0|
|Unsupported|0|
|Not applicable|0|
|Unknown|21|
|Enumerated exclusions|0|
|Enumeration failures|0|
|Unenumerated population|Unknown|

## Inspection diagnostics

Safe reason codes, paths and detector names; file contents and arbitrary error messages are omitted.

|Item|Value|
|---|---|
|Detector does not report completeness (detector_not_reported)|- / dependency_detector|
|Only part of inspection completed (detector_partial)|tuning/certs/broken.cer / certificate_detector|
|Only part of inspection completed (detector_partial)|tuning/certs/broken.crt / certificate_detector|
|Only part of inspection completed (detector_partial)|tuning/certs/broken.der / certificate_detector|
|Only part of inspection completed (detector_partial)|tuning/certs/broken.p12 / certificate_detector|
|Only part of inspection completed (detector_partial)|tuning/certs/broken.pem / certificate_detector|
|Only part of inspection completed (detector_partial)|tuning/certs/broken.pfx / certificate_detector|
|Inspection unsupported (detector_unsupported)|tuning/certs/public-only.p12 / certificate_detector|
|Inspection unsupported (detector_unsupported)|tuning/certs/public-only.pfx / certificate_detector|
|Only part of inspection completed (detector_partial)|tuning/encryption/BrokenCipher.java / tree_sitter_detector|
|Only part of inspection completed (detector_partial)|tuning/go/broken.go / tree_sitter_detector|
|Only part of inspection completed (detector_partial)|tuning/java/Broken.java / tree_sitter_detector|
|Only part of inspection completed (detector_partial)|tuning/jwt/broken.js / regex_detector|
|Only part of inspection completed (detector_partial)|tuning/jwt/broken.js / tree_sitter_detector|
|Detector failed (detector_failed)|tuning/manifests/Cargo.lock/malformed/Cargo.lock / dependency_detector|
|Detector failed (detector_failed)|tuning/manifests/Cargo.toml/malformed/Cargo.toml / dependency_detector|
|Detector failed (detector_failed)|tuning/manifests/Pipfile.lock/malformed/Pipfile.lock / dependency_detector|
|Only part of inspection completed (detector_partial)|tuning/manifests/gems.rb/malformed/gems.rb / tree_sitter_detector|
|Detector failed (detector_failed)|tuning/manifests/package-lock.json/malformed/package-lock.json / dependency_detector|
|Detector failed (detector_failed)|tuning/manifests/package.json/malformed/package.json / dependency_detector|
|Inspection unsupported (detector_unsupported)|tuning/manifests/pnpm-lock.yaml/malformed/pnpm-lock.yaml / dependency_detector|
|Detector failed (detector_failed)|tuning/manifests/poetry.lock/malformed/poetry.lock / dependency_detector|
|Detector failed (detector_failed)|tuning/manifests/pom.xml/malformed/pom.xml / dependency_detector|
|Only part of inspection completed (detector_partial)|tuning/python/broken.py / tree_sitter_detector|
|Only part of inspection completed (detector_partial)|tuning/ruby/broken.rb / tree_sitter_detector|
|Only part of inspection completed (detector_partial)|tuning/rust/broken.rs / tree_sitter_detector|
|Detector failed (detector_failed)|tuning/sbom/CycloneDX-1.5/malformed/bom.json / dependency_detector|
|Detector failed (detector_failed)|tuning/sbom/SPDX-2.3/malformed/bom.json / dependency_detector|
|Only part of inspection completed (detector_partial)|tuning/typescript/broken.ts / regex_detector|
|Only part of inspection completed (detector_partial)|tuning/typescript/broken.ts / tree_sitter_detector|
|Detector failed (detector_failed)|tuning/width/cdx-1.4/broken/bom.json / dependency_detector|
|Detector failed (detector_failed)|tuning/width/cdx-1.6/broken/bom.json / dependency_detector|
|Detector failed (detector_failed)|tuning/width/cdx-1.7/broken/bom.json / dependency_detector|
|Detector failed (detector_failed)|tuning/width/spdx-2.2/broken/bom.json / dependency_detector|
|Only part of inspection completed (detector_partial)|tuning/width/tsx/broken.tsx / regex_detector|
|Only part of inspection completed (detector_partial)|tuning/width/tsx/broken.tsx / tree_sitter_detector|
