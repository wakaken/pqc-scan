# PQC Migration Scan Report

Generated: 2026-11-12 02:08:14.554848 UTC

Risk candidates: 86 / Inventory findings: 28 / Scanned files: 206

Static evidence does not prove runtime use or completed PQC migration.

|Severity|Count (all findings)|
|---|---:|
|critical|13|
|high|27|
|info|28|
|low|4|
|medium|42|

## Risk candidate index

|Rule / description|Severity|Risk|Hits|Files|
|---|---|---|---:|---:|
|[CERT_RSA_SIGNATURE](#rule-0) Certificate signed with an RSA-based algorithm detected.|critical|quantum-vulnerable|6|6|
|[JWT_RS256](#rule-1) RS256 (RSA-based JWT signing) is in use.|critical|quantum-vulnerable|2|2|
|[PRIVATE_KEY_OPENSSH_HEADER](#rule-2) OpenSSH private key header detected.|critical|non-quantum-risk|1|1|
|[PRIVATE_KEY_PKCS8_HEADER](#rule-3) PKCS#8 private key header detected.|critical|non-quantum-risk|1|1|
|[PRIVATE_KEY_RSA_HEADER](#rule-4) RSA private key header detected.|critical|non-quantum-risk|1|1|
|[TS_JWT_RSA_ALGS](#rule-5) RSA-family JWT signing algorithms detected in AST nodes.|critical|quantum-vulnerable|2|2|
|[API_CIPHER_RSA](#rule-6) RSA cipher API usage detected.|high|quantum-vulnerable|1|1|
|[API_JOSE_RSA_ALG](#rule-7) RSA-family JOSE algorithm detected.|high|quantum-vulnerable|2|2|
|[API_SIGNATURE_RSA](#rule-8) RSA signature API usage detected.|high|quantum-vulnerable|1|1|
|[CERT_ECDSA_SIGNATURE](#rule-9) ECDSA certificate signature detected.|high|quantum-vulnerable|1|1|
|[CERT_RSA_3072](#rule-10) Certificate subject public key is 3072-bit RSA.|high|quantum-vulnerable|6|6|
|[ENVOY_TLS_MIN_VERSION_LEGACY](#rule-11) Envoy configuration allows TLSv1.0/1.1.|high|non-quantum-risk|1|1|
|[HAPROXY_BIND_TLSV1](#rule-12) HAProxy configuration explicitly enables TLSv1.0/1.1.|high|non-quantum-risk|1|1|
|[HTTPD_SSLPROTOCOL_LEGACY](#rule-13) Legacy TLSv1.x is enabled in Apache httpd configuration.|high|non-quantum-risk|1|1|
|[ISTIO_DESTINATIONRULE_TLSV1](#rule-14) Istio configuration permits TLSv1.0/1.1.|high|non-quantum-risk|1|1|
|[ISTIO_GATEWAY_TLSV1](#rule-15) TLSv1.0/1.1 setting detected in Istio Gateway configuration.|high|non-quantum-risk|1|1|
|[K8S_INGRESS_RSA_CIPHERS](#rule-16) RSA or weak cipher suites are configured in a Kubernetes Ingress annotation.|high|quantum-vulnerable|1|1|
|[NGINX_SSL_CIPHERS_RSA](#rule-17) RSA or weak cipher suites detected in nginx configuration.|high|quantum-vulnerable|1|1|
|[SSH_DSS_SIGALG](#rule-18) Deprecated ssh-dss usage detected.|high|non-quantum-risk|2|2|
|[TLS_VERSION_1_0](#rule-19) Legacy TLS 1.0 configuration detected.|high|non-quantum-risk|3|3|
|[TS_JAVA_RSA_API](#rule-20) RSA-related API symbols detected from Java AST.|high|quantum-vulnerable|2|2|
|[TS_RSA_KEY_SIZE_LITERAL](#rule-21) Classical public-key size literals detected in AST nodes.|high|quantum-vulnerable|2|2|
|[CERT_P12_CONTAINER](#rule-22) PKCS#12/PFX container file detected.|medium|quantum-uncertain|6|6|
|[DEP_BOUNCYCASTLE](#rule-23) BouncyCastle dependency detected.|medium|quantum-uncertain|2|2|
|[DEP_JAVA_BOUNCYCASTLE](#rule-24) Java BouncyCastle dependency detected.|medium|quantum-uncertain|2|2|
|[DEP_OPENSSL](#rule-25) OpenSSL dependency detected.|medium|quantum-uncertain|12|12|
|[DEP_PYCA_CRYPTOGRAPHY](#rule-26) Python cryptography dependency detected.|medium|quantum-uncertain|3|3|
|[DEP_RUBY_OPENSSL](#rule-27) Ruby OpenSSL dependency detected.|medium|quantum-uncertain|4|4|
|[DEP_RUST_OPENSSL](#rule-28) Rust TLS/crypto dependency detected.|medium|quantum-uncertain|1|1|
|[JWT_LIB_JOSE](#rule-29) jose dependency detected.|medium|quantum-uncertain|3|3|
|[SSH_DH_GROUP14_SHA1](#rule-30) SHA-1 dependent SSH KEX detected.|medium|non-quantum-risk|1|1|
|[TRAEFIK_TLS_OPTIONS_LEGACY](#rule-31) Traefik configuration contains a low minimum TLS version.|medium|non-quantum-risk|1|1|
|[TS_NODE_JOSE_USAGE](#rule-32) JOSE/JWT calls detected from JavaScript/TypeScript AST.|medium|quantum-uncertain|5|2|
|[TS_NODE_RSA_USAGE](#rule-33) RSA-related API symbols detected from JavaScript/TypeScript AST.|medium|quantum-vulnerable|2|2|
|[CERT_PEM_CONTAINER](#rule-34) Certificate container file detected.|low|quantum-uncertain|4|4|

## Informational inventory index

|Rule / description|Severity|Risk|Hits|Files|
|---|---|---|---:|---:|
|[DEP_PQC_CAPABLE_LIBRARY](#rule-35) Library with version-dependent PQC capabilities inventoried; capability is not an enabled-state find...|info|quantum-uncertain|11|11|
|[PQC_GO_API](#rule-36) Standard Go PQC package imported; import alone does not prove negotiated protection.|info|quantum-safe|1|1|
|[PQC_JAVA_API](#rule-37) Standard PQC algorithm requested through Java APIs; runtime success is not established.|info|quantum-safe|3|3|
|[PQC_NODE_API](#rule-38) Node-style PQC key generation call; bindings and actual execution require confirmation.|info|quantum-safe|8|7|
|[PQC_PYTHON_API](#rule-39) Python PQC key generation reference; backend support is not established.|info|quantum-safe|1|1|
|[PQC_RUBY_API](#rule-40) Ruby PQC algorithm literal referenced; key generation or signing success is not established.|info|quantum-safe|1|1|
|[PQC_RUST_API](#rule-41) Rust PQC crate symbol referenced; execution and protocol use require confirmation.|info|quantum-safe|1|1|
|[PQC_WEBCRYPTO_API](#rule-42) WebCrypto-style PQC algorithm request; this is not proof of browser support.|info|quantum-safe|2|2|

<a id="rule-0"></a>

## CERT_RSA_SIGNATURE

Certificate signed with an RSA-based algorithm detected.

Check: Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-0"></a>[tuning/certs/public-rsa3072.cer:1:1](#finding-0)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-1"></a>[tuning/certs/public-rsa3072.crt:1:1](#finding-1)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-2"></a>[tuning/certs/public-rsa3072.pem:1:1](#finding-2)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / [Source](#source-2)|
|<a id="finding-3"></a>[tuning/certs/rsa3072.der:1:1](#finding-3)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-4"></a>[tuning/width/public-unencrypted.p12:1:1](#finding-4)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-5"></a>[tuning/width/public-unencrypted.pfx:1:1](#finding-5)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)

<a id="source-2"></a>

### tuning/certs/public-rsa3072.pem:1:1

    > 1 -----BEGIN CERTIFICATE-----
      2 [masked-sensitive-content]
      3 c2Nhbi1wdWJsaWMtdGVzdDAeFw0yNjExMDkwNzU1NTFaFw0zNjExMDYwNzU1NTFa

<a id="rule-1"></a>

## JWT_RS256

RS256 (RSA-based JWT signing) is in use.

Check: Migrate to ML-DSA signatures.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-6"></a>[holdout/jwt-rsa.js:2:64](#finding-6)|RS256|Migrate to ML-DSA signatures. / [Source](#source-6)|
|<a id="finding-7"></a>[tuning/jwt/sign.js:1:33](#finding-7)|RS256|Migrate to ML-DSA signatures. / [Source](#source-7)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Stop issuing new JWTs with RSA/PKCS#1/ECDSA-only algorithms](#action-2)
- [Upgrade Node.js runtime for built-in WebCrypto PQC support](#action-3)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-6"></a>

### holdout/jwt-rsa.js:2:64

      1 var privateKey = fs.readFileSync('private.key');
    > 2 var token = jwt.sign({ foo: 'bar' }, privateKey, { algorithm: 'RS256' });

<a id="source-7"></a>

### tuning/jwt/sign.js:1:33

    > 1 sign(payload, key, {algorithm: "RS256"});

<a id="rule-2"></a>

## PRIVATE_KEY_OPENSSH_HEADER

OpenSSH private key header detected.

Check: Treat OpenSSH private-key exposure as an urgent incident.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-8"></a>[tuning/markers/PRIVATE_KEY_OPENSSH_HEADER/marker.txt:1:1](#finding-8)|\[masked-private-key\]|Rotate exposed private keys and revoke affected credentials / [Rotate exposed private keys and revoke affected credentials](#action-5) / [Source](#source-8)|

<a id="source-8"></a>

### tuning/markers/PRIVATE_KEY_OPENSSH_HEADER/marker.txt:1:1

    > 1 [masked-private-key-material]

<a id="rule-3"></a>

## PRIVATE_KEY_PKCS8_HEADER

PKCS#8 private key header detected.

Check: Investigate private-key exposure and rotate credentials.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-9"></a>[tuning/markers/PRIVATE_KEY_PKCS8_HEADER/marker.txt:1:1](#finding-9)|\[masked-private-key\]|Rotate exposed private keys and revoke affected credentials / [Rotate exposed private keys and revoke affected credentials](#action-5) / [Source](#source-9)|

<a id="source-9"></a>

### tuning/markers/PRIVATE_KEY_PKCS8_HEADER/marker.txt:1:1

    > 1 [masked-private-key-material]

<a id="rule-4"></a>

## PRIVATE_KEY_RSA_HEADER

RSA private key header detected.

Check: Rotate exposed private keys immediately and strengthen key handling.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-10"></a>[tuning/markers/PRIVATE_KEY_RSA_HEADER/marker.txt:1:1](#finding-10)|\[masked-private-key\]|Rotate exposed private keys and revoke affected credentials / [Rotate exposed private keys and revoke affected credentials](#action-5) / [Source](#source-10)|

<a id="source-10"></a>

### tuning/markers/PRIVATE_KEY_RSA_HEADER/marker.txt:1:1

    > 1 [masked-private-key-material]

<a id="rule-5"></a>

## TS_JWT_RSA_ALGS

RSA-family JWT signing algorithms detected in AST nodes.

Check: Migrate JWT signing to ML-DSA or hybrid signatures.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-11"></a>[holdout/jwt-rsa.js:2:64](#finding-11)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-11)|
|<a id="finding-12"></a>[tuning/jwt/sign.js:1:33](#finding-12)|RS256|Migrate JWT signing to ML-DSA or hybrid signatures. / [Source](#source-12)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Stop issuing new JWTs with RSA/PKCS#1/ECDSA-only algorithms](#action-2)
- [Upgrade Node.js runtime for built-in WebCrypto PQC support](#action-3)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-11"></a>

### holdout/jwt-rsa.js:2:64

      1 var privateKey = fs.readFileSync('private.key');
    > 2 var token = jwt.sign({ foo: 'bar' }, privateKey, { algorithm: 'RS256' });

<a id="source-12"></a>

### tuning/jwt/sign.js:1:33

    > 1 sign(payload, key, {algorithm: "RS256"});

<a id="rule-6"></a>

## API_CIPHER_RSA

RSA cipher API usage detected.

Check: Migrate to hybrid KEM+AEAD cryptographic design.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-13"></a>[tuning/encryption/Encrypt.java:1:1](#finding-13)|Cipher.g***e("RSA|Provide BouncyCastle PQC fallback path / [Upgrade Java runtime baseline for standard PQC APIs](#action-6) / [Provide BouncyCastle PQC fallback path](#action-7) / [Source](#source-13)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Verify deployed runtime and protocol PQC capabilities](#action-8)

<a id="source-13"></a>

### tuning/encryption/Encrypt.java:1:1

    > 1 Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");

<a id="rule-7"></a>

## API_JOSE_RSA_ALG

RSA-family JOSE algorithm detected.

Check: Update JOSE algorithms to PQC-ready alternatives.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-14"></a>[holdout/jwt-rsa.js:2:64](#finding-14)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-14)|
|<a id="finding-15"></a>[tuning/jwt/sign.js:1:33](#finding-15)|RS256|Update JOSE algorithms to PQC-ready alternatives. / [Source](#source-15)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Introduce crypto abstraction boundary for algorithm agility](#action-9)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-14"></a>

### holdout/jwt-rsa.js:2:64

      1 var privateKey = fs.readFileSync('private.key');
    > 2 var token = jwt.sign({ foo: 'bar' }, privateKey, { algorithm: 'RS256' });

<a id="source-15"></a>

### tuning/jwt/sign.js:1:33

    > 1 sign(payload, key, {algorithm: "RS256"});

<a id="rule-8"></a>

## API_SIGNATURE_RSA

RSA signature API usage detected.

Check: Migrate to ML-DSA signing APIs.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-16"></a>[tuning/java/Neg.java:1:1](#finding-16)|Signatur***thRSA"|Provide BouncyCastle PQC fallback path / [Upgrade Java runtime baseline for standard PQC APIs](#action-6) / [Provide BouncyCastle PQC fallback path](#action-7) / [Source](#source-16)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Verify deployed runtime and protocol PQC capabilities](#action-8)

<a id="source-16"></a>

### tuning/java/Neg.java:1:1

    > 1 Signature.getInstance("SHA256withRSA");

<a id="rule-9"></a>

## CERT_ECDSA_SIGNATURE

ECDSA certificate signature detected.

Check: Evaluate ML-DSA and SLH-DSA alternatives.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-17"></a>[tuning/certs/p256.der:1:1](#finding-17)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)

<a id="rule-10"></a>

## CERT_RSA_3072

Certificate subject public key is 3072-bit RSA.

Check: Evaluate standardized PQC signatures in supported issuance and verification environments.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-18"></a>[tuning/certs/public-rsa3072.cer:1:1](#finding-18)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / Source unavailable|
|<a id="finding-19"></a>[tuning/certs/public-rsa3072.crt:1:1](#finding-19)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / Source unavailable|
|<a id="finding-20"></a>[tuning/certs/public-rsa3072.pem:1:1](#finding-20)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / [Source](#source-20)|
|<a id="finding-21"></a>[tuning/certs/rsa3072.der:1:1](#finding-21)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / Source unavailable|
|<a id="finding-22"></a>[tuning/width/public-unencrypted.p12:1:1](#finding-22)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / Source unavailable|
|<a id="finding-23"></a>[tuning/width/public-unencrypted.pfx:1:1](#finding-23)|RSA 3072-bit|Evaluate standardized PQC signatures in supported issuance and verification environments. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)

<a id="source-20"></a>

### tuning/certs/public-rsa3072.pem:1:1

    > 1 -----BEGIN CERTIFICATE-----
      2 [masked-sensitive-content]
      3 c2Nhbi1wdWJsaWMtdGVzdDAeFw0yNjExMDkwNzU1NTFaFw0zNjExMDYwNzU1NTFa

<a id="rule-11"></a>

## ENVOY_TLS_MIN_VERSION_LEGACY

Envoy configuration allows TLSv1.0/1.1.

Check: Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-24"></a>[tuning/width/envoy/selection.conf:1:1](#finding-24)|tls_mini***LSv1_0|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Validate Envoy PQC signature compatibility in control/data planes](#action-10) / [Source](#source-24)|

<a id="source-24"></a>

### tuning/width/envoy/selection.conf:1:1

    > 1 tls_minimum_protocol_version: TLSv1_0

<a id="rule-12"></a>

## HAPROXY_BIND_TLSV1

HAProxy configuration explicitly enables TLSv1.0/1.1.

Check: Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-25"></a>[tuning/width/haproxy/selection.conf:1:1](#finding-25)|bind :44***tlsv10|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Validate HAProxy TLS stack PQC signature readiness before production](#action-11) / [Source](#source-25)|

<a id="source-25"></a>

### tuning/width/haproxy/selection.conf:1:1

    > 1 bind :443 ssl force-tlsv10

<a id="rule-13"></a>

## HTTPD_SSLPROTOCOL_LEGACY

Legacy TLSv1.x is enabled in Apache httpd configuration.

Check: Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-26"></a>[tuning/width/apache/selection.conf:1:1](#finding-26)|SSLProtocol TLSv1.0|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Source](#source-26)|

<a id="source-26"></a>

### tuning/width/apache/selection.conf:1:1

    > 1 SSLProtocol TLSv1.0

<a id="rule-14"></a>

## ISTIO_DESTINATIONRULE_TLSV1

Istio configuration permits TLSv1.0/1.1.

Check: Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-27"></a>[tuning/width/istio/selection.conf:1:1](#finding-27)|minProto***LSV1_0|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Validate Istio mesh-wide PQC signature interoperability before enforcement](#action-12) / [Source](#source-27)|

<a id="source-27"></a>

### tuning/width/istio/selection.conf:1:1

    > 1 minProtocolVersion: TLSV1_0

<a id="rule-15"></a>

## ISTIO_GATEWAY_TLSV1

TLSv1.0/1.1 setting detected in Istio Gateway configuration.

Check: Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-28"></a>[tuning/width/istio/selection.conf:1:1](#finding-28)|minProto***LSV1_0|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Validate Istio mesh-wide PQC signature interoperability before enforcement](#action-12) / [Source](#source-28)|

<a id="source-28"></a>

### tuning/width/istio/selection.conf:1:1

    > 1 minProtocolVersion: TLSV1_0

<a id="rule-16"></a>

## K8S_INGRESS_RSA_CIPHERS

RSA or weak cipher suites are configured in a Kubernetes Ingress annotation.

Check: Remove RSA key-exchange dependency from Ingress cipher suites.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-29"></a>[tuning/width/kubernetes/selection.conf:1:1](#finding-29)|nginx.in***s: RSA|Remove RSA key-exchange dependency from Ingress cipher suites. / [Validate Kubernetes PQC signature readiness before production rollout](#action-13) / [Source](#source-29)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)

<a id="source-29"></a>

### tuning/width/kubernetes/selection.conf:1:1

    > 1 nginx.ingress.kubernetes.io/ssl-ciphers: RSA

<a id="rule-17"></a>

## NGINX_SSL_CIPHERS_RSA

RSA or weak cipher suites detected in nginx configuration.

Check: Refresh nginx cipher suites for PQC-hybrid migration readiness.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-30"></a>[tuning/width/nginx/selection.conf:1:1](#finding-30)|ssl_ciphers RSA|Refresh nginx cipher suites for PQC-hybrid migration readiness. / [Validate nginx/OpenSSL PQC signature interoperability before rollout](#action-14) / [Source](#source-30)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)

<a id="source-30"></a>

### tuning/width/nginx/selection.conf:1:1

    > 1 ssl_ciphers RSA;

<a id="rule-18"></a>

## SSH_DSS_SIGALG

Deprecated ssh-dss usage detected.

Check: Disable ssh-dss.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-31"></a>[tuning/ssh/dsa.conf:1:19](#finding-31)|ssh-dss|Disable ssh-dss. / [Source](#source-31)|
|<a id="finding-32"></a>[tuning/width/parameter/dsa.conf:1:21](#finding-32)|ssh-dss|Disable ssh-dss. / [Source](#source-32)|

<a id="source-31"></a>

### tuning/ssh/dsa.conf:1:19

    > 1 HostKeyAlgorithms ssh-dss

<a id="source-32"></a>

### tuning/width/parameter/dsa.conf:1:21

    > 1 # HostKeyAlgorithms ssh-dss

<a id="rule-19"></a>

## TLS_VERSION_1_0

Legacy TLS 1.0 configuration detected.

Check: Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-33"></a>[tuning/width/apache/selection.conf:1:12](#finding-33)|TLSv1.0|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Harden Apache httpd SSL/TLS directives](#action-16) / [Source](#source-33)|
|<a id="finding-34"></a>[tuning/width/envoy/alternative.conf:1:30](#finding-34)|TLSv1_|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Validate Envoy PQC signature compatibility in control/data planes](#action-10) / [Set modern TLS policy in Envoy](#action-17) / [Source](#source-34)|
|<a id="finding-35"></a>[tuning/width/envoy/selection.conf:1:30](#finding-35)|TLSv1_|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Validate Envoy PQC signature compatibility in control/data planes](#action-10) / [Set modern TLS policy in Envoy](#action-17) / [Source](#source-35)|

Shared checks for these locations (not verified facts about each line):

- [Prefer TLS 1.3 and review legacy key exchange](#action-15)

<a id="source-33"></a>

### tuning/width/apache/selection.conf:1:12

    > 1 SSLProtocol TLSv1.0

<a id="source-34"></a>

### tuning/width/envoy/alternative.conf:1:30

    > 1 tls_minimum_protocol_version: TLSv1_3

<a id="source-35"></a>

### tuning/width/envoy/selection.conf:1:30

    > 1 tls_minimum_protocol_version: TLSv1_0

<a id="rule-20"></a>

## TS_JAVA_RSA_API

RSA-related API symbols detected from Java AST.

Check: Replace Java RSA API usage with PQC-capable libraries.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-36"></a>[tuning/encryption/Encrypt.java:1:1](#finding-36)|Cipher.g***e("RSA|Replace Java RSA API usage with PQC-capable libraries. / [Source](#source-36)|
|<a id="finding-37"></a>[tuning/java/Neg.java:1:1](#finding-37)|Signatur***ithRSA|Replace Java RSA API usage with PQC-capable libraries. / [Source](#source-37)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Upgrade Java runtime baseline for standard PQC APIs](#action-6)
- [Provide BouncyCastle PQC fallback path](#action-7)
- [Verify deployed runtime and protocol PQC capabilities](#action-8)

<a id="source-36"></a>

### tuning/encryption/Encrypt.java:1:1

    > 1 Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");

<a id="source-37"></a>

### tuning/java/Neg.java:1:1

    > 1 Signature.getInstance("SHA256withRSA");

<a id="rule-21"></a>

## TS_RSA_KEY_SIZE_LITERAL

Classical public-key size literals detected in AST nodes.

Check: Shift from key-length based planning to PQC signatures/key exchange.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-38"></a>[holdout/rsa-sign.js:8:3](#finding-38)|modulusLength: 2048|Shift from key-length based planning to PQC signatures/key exchange. / [Source](#source-38)|
|<a id="finding-39"></a>[tuning/js/same-line.js:1:44](#finding-39)|KeyPairS***m-1024|Shift from key-length based planning to PQC signatures/key exchange. / [Source](#source-39)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-38"></a>

### holdout/rsa-sign.js:8:3

      6 
      7 const { privateKey, publicKey } = generateKeyPairSync('rsa', {
    > 8   modulusLength: 2048,
      9 });
      10 

<a id="source-39"></a>

### tuning/js/same-line.js:1:44

    > 1 generateKeyPairSync("ml-kem-512"); generateKeyPairSync("ml-kem-1024");

<a id="rule-22"></a>

## CERT_P12_CONTAINER

PKCS#12/PFX container file detected.

Check: Audit algorithms used inside PKCS#12/PFX containers.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-40"></a>[tuning/certs/broken.p12:1:1](#finding-40)|broken.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-41"></a>[tuning/certs/broken.pfx:1:1](#finding-41)|broken.pfx|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-42"></a>[tuning/certs/public-only.p12:1:1](#finding-42)|public-only.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-43"></a>[tuning/certs/public-only.pfx:1:1](#finding-43)|public-only.pfx|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-44"></a>[tuning/width/public-unencrypted.p12:1:1](#finding-44)|public-u***ed.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-45"></a>[tuning/width/public-unencrypted.pfx:1:1](#finding-45)|public-u***ed.pfx|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)

<a id="rule-23"></a>

## DEP_BOUNCYCASTLE

BouncyCastle dependency detected.

Check: Verify BouncyCastle PQC support status.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-46"></a>[tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1](#finding-46)|org.boun***n@1.80|Verify BouncyCastle PQC support status. / [Source](#source-46)|
|<a id="finding-47"></a>[tuning/manifests/pom.xml/declared/pom.xml:1:1](#finding-47)|org.boun***n@1.80|Verify BouncyCastle PQC support status. / [Source](#source-47)|

Shared checks for these locations (not verified facts about each line):

- [Prefer TLS 1.3 and review legacy key exchange](#action-15)
- [Track PQC readiness of dependent libraries](#action-18)

<a id="source-46"></a>

### tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-47"></a>

### tuning/manifests/pom.xml/declared/pom.xml:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-24"></a>

## DEP_JAVA_BOUNCYCASTLE

Java BouncyCastle dependency detected.

Check: Evaluate adoption of BouncyCastle PQC provider modules.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-48"></a>[tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1](#finding-48)|org.boun***n@1.80|Evaluate adoption of BouncyCastle PQC provider modules. / [Source](#source-48)|
|<a id="finding-49"></a>[tuning/manifests/pom.xml/declared/pom.xml:1:1](#finding-49)|org.boun***n@1.80|Evaluate adoption of BouncyCastle PQC provider modules. / [Source](#source-49)|

Shared checks for these locations (not verified facts about each line):

- [Introduce crypto abstraction boundary for algorithm agility](#action-9)
- [Track PQC readiness of dependent libraries](#action-18)

<a id="source-48"></a>

### tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-49"></a>

### tuning/manifests/pom.xml/declared/pom.xml:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-25"></a>

## DEP_OPENSSL

OpenSSL dependency detected.

Check: Review the OpenSSL PQC roadmap.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-50"></a>[tuning/manifests/Cargo.lock/declared/Cargo.lock:3:1](#finding-50)|openssl@0.10.75|Review the OpenSSL PQC roadmap. / [Source](#source-50)|
|<a id="finding-51"></a>[tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1](#finding-51)|openssl@0.10.75|Review the OpenSSL PQC roadmap. / [Source](#source-51)|
|<a id="finding-52"></a>[tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1](#finding-52)|openssl@3.3.0|Review the OpenSSL PQC roadmap. / [Source](#source-52)|
|<a id="finding-53"></a>[tuning/manifests/Gemfile/declared/Gemfile:1:1](#finding-53)|openssl@3.3.0|Review the OpenSSL PQC roadmap. / [Source](#source-53)|
|<a id="finding-54"></a>[tuning/manifests/gems.locked/declared/gems.locked:3:1](#finding-54)|openssl@3.3.0|Review the OpenSSL PQC roadmap. / [Source](#source-54)|
|<a id="finding-55"></a>[tuning/manifests/gems.rb/declared/gems.rb:1:1](#finding-55)|openssl@3.3.0|Verify deployed runtime and protocol PQC capabilities / [Verify deployed runtime and protocol PQC capabilities](#action-19) / [Source](#source-55)|
|<a id="finding-56"></a>[tuning/sbom/CycloneDX-1.5/declared/bom.json:1:1](#finding-56)|openssl@3.5.0|Review the OpenSSL PQC roadmap. / [Source](#source-56)|
|<a id="finding-57"></a>[tuning/sbom/SPDX-2.3/declared/bom.json:1:1](#finding-57)|openssl@3.5.0|Review the OpenSSL PQC roadmap. / [Source](#source-57)|
|<a id="finding-58"></a>[tuning/width/cdx-1.4/library/bom.json:1:1](#finding-58)|openssl@3.5.0|Review the OpenSSL PQC roadmap. / [Source](#source-58)|
|<a id="finding-59"></a>[tuning/width/cdx-1.6/library/bom.json:1:1](#finding-59)|openssl@3.5.0|Review the OpenSSL PQC roadmap. / [Source](#source-59)|
|<a id="finding-60"></a>[tuning/width/cdx-1.7/library/bom.json:1:1](#finding-60)|openssl@3.5.0|Review the OpenSSL PQC roadmap. / [Source](#source-60)|
|<a id="finding-61"></a>[tuning/width/spdx-2.2/library/bom.json:1:1](#finding-61)|openssl@3.5.0|Review the OpenSSL PQC roadmap. / [Source](#source-61)|

Shared checks for these locations (not verified facts about each line):

- [Prefer TLS 1.3 and review legacy key exchange](#action-15)
- [Track PQC readiness of dependent libraries](#action-18)

<a id="source-50"></a>

### tuning/manifests/Cargo.lock/declared/Cargo.lock:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-51"></a>

### tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-52"></a>

### tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-53"></a>

### tuning/manifests/Gemfile/declared/Gemfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-54"></a>

### tuning/manifests/gems.locked/declared/gems.locked:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-55"></a>

### tuning/manifests/gems.rb/declared/gems.rb:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-56"></a>

### tuning/sbom/CycloneDX-1.5/declared/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-57"></a>

### tuning/sbom/SPDX-2.3/declared/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-58"></a>

### tuning/width/cdx-1.4/library/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-59"></a>

### tuning/width/cdx-1.6/library/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-60"></a>

### tuning/width/cdx-1.7/library/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-61"></a>

### tuning/width/spdx-2.2/library/bom.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-26"></a>

## DEP_PYCA_CRYPTOGRAPHY

Python cryptography dependency detected.

Check: Track PQC support status in the cryptography package.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-62"></a>[tuning/manifests/Pipfile.lock/declared/Pipfile.lock:1:1](#finding-62)|cryptogr***48.0.0|Track PQC support status in the cryptography package. / [Source](#source-62)|
|<a id="finding-63"></a>[tuning/manifests/poetry.lock/declared/poetry.lock:2:1](#finding-63)|cryptography@48.0.0|Track PQC support status in the cryptography package. / [Source](#source-63)|
|<a id="finding-64"></a>[tuning/manifests/requirements.txt/declared/requirements.txt:1:1](#finding-64)|cryptography@48.0.0|Track PQC support status in the cryptography package. / [Source](#source-64)|

Shared checks for these locations (not verified facts about each line):

- [Introduce crypto abstraction boundary for algorithm agility](#action-9)
- [Track PQC readiness of dependent libraries](#action-18)

<a id="source-62"></a>

### tuning/manifests/Pipfile.lock/declared/Pipfile.lock:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-63"></a>

### tuning/manifests/poetry.lock/declared/poetry.lock:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-64"></a>

### tuning/manifests/requirements.txt/declared/requirements.txt:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-27"></a>

## DEP_RUBY_OPENSSL

Ruby OpenSSL dependency detected.

Check: Review OpenSSL usage in Ruby and prepare PQC migration path.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-65"></a>[tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1](#finding-65)|openssl@3.3.0|Review OpenSSL usage in Ruby and prepare PQC migration path. / [Source](#source-65)|
|<a id="finding-66"></a>[tuning/manifests/Gemfile/declared/Gemfile:1:1](#finding-66)|openssl@3.3.0|Review OpenSSL usage in Ruby and prepare PQC migration path. / [Source](#source-66)|
|<a id="finding-67"></a>[tuning/manifests/gems.locked/declared/gems.locked:3:1](#finding-67)|openssl@3.3.0|Review OpenSSL usage in Ruby and prepare PQC migration path. / [Source](#source-67)|
|<a id="finding-68"></a>[tuning/manifests/gems.rb/declared/gems.rb:1:1](#finding-68)|openssl@3.3.0|Verify deployed runtime and protocol PQC capabilities / [Verify deployed runtime and protocol PQC capabilities](#action-19) / [Source](#source-68)|

Shared checks for these locations (not verified facts about each line):

- [Introduce crypto abstraction boundary for algorithm agility](#action-9)
- [Track PQC readiness of dependent libraries](#action-18)

<a id="source-65"></a>

### tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-66"></a>

### tuning/manifests/Gemfile/declared/Gemfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-67"></a>

### tuning/manifests/gems.locked/declared/gems.locked:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-68"></a>

### tuning/manifests/gems.rb/declared/gems.rb:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-28"></a>

## DEP_RUST_OPENSSL

Rust TLS/crypto dependency detected.

Check: Track PQC migration options for Rust openssl/rustls crypto stacks.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-69"></a>[tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1](#finding-69)|openssl@0.10.75|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-69)|

Shared checks for these locations (not verified facts about each line):

- [Introduce crypto abstraction boundary for algorithm agility](#action-9)
- [Track PQC readiness of dependent libraries](#action-18)

<a id="source-69"></a>

### tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="rule-29"></a>

## JWT_LIB_JOSE

jose dependency detected.

Check: Verify PQC support in the JOSE implementation.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-70"></a>[tuning/manifests/package-lock.json/declared/package-lock.json:1:1](#finding-70)|jose@6.0.0|Verify PQC support in the JOSE implementation. / [Source](#source-70)|
|<a id="finding-71"></a>[tuning/manifests/package.json/declared/package.json:1:1](#finding-71)|jose@6.0.0|Verify PQC support in the JOSE implementation. / [Source](#source-71)|
|<a id="finding-72"></a>[tuning/manifests/pnpm-lock.yaml/declared/pnpm-lock.yaml:3:1](#finding-72)|jose@6.0.0|Verify PQC support in the JOSE implementation. / [Source](#source-72)|

Shared checks for these locations (not verified facts about each line):

- [Stop issuing new JWTs with RSA/PKCS#1/ECDSA-only algorithms](#action-2)

<a id="source-70"></a>

### tuning/manifests/package-lock.json/declared/package-lock.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-71"></a>

### tuning/manifests/package.json/declared/package.json:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-72"></a>

### tuning/manifests/pnpm-lock.yaml/declared/pnpm-lock.yaml:3:1

    > 3 [masked-sensitive-file-content]

<a id="rule-30"></a>

## SSH_DH_GROUP14_SHA1

SHA-1 dependent SSH KEX detected.

Check: Retire SHA-1 based key exchange.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-73"></a>[tuning/ssh/dh.conf:1:15](#finding-73)|diffie-h***4-sha1|Retire SHA-1 based key exchange. / [Source](#source-73)|

<a id="source-73"></a>

### tuning/ssh/dh.conf:1:15

    > 1 KexAlgorithms diffie-hellman-group14-sha1

<a id="rule-31"></a>

## TRAEFIK_TLS_OPTIONS_LEGACY

Traefik configuration contains a low minimum TLS version.

Check: Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-74"></a>[tuning/width/traefik/selection.conf:1:1](#finding-74)|minVersi***nTLS10|Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. / [Validate Traefik PQC signature interoperability with all entrypoints](#action-20) / [Source](#source-74)|

<a id="source-74"></a>

### tuning/width/traefik/selection.conf:1:1

    > 1 minVersion: VersionTLS10

<a id="rule-32"></a>

## TS_NODE_JOSE_USAGE

JOSE/JWT calls detected from JavaScript/TypeScript AST.

Check: Evaluate PQC-capable options in JOSE/JWT implementations.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-75"></a>[holdout/jwt-helper.js:65:20](#finding-75)|jwt.verify|Evaluate PQC-capable options in JOSE/JWT implementations. / [Source](#source-75)|
|<a id="finding-76"></a>[holdout/jwt-helper.js:70:3](#finding-76)|jwt.verify|Evaluate PQC-capable options in JOSE/JWT implementations. / [Source](#source-76)|
|<a id="finding-77"></a>[holdout/jwt-helper.js:102:18](#finding-77)|jwt.sign|Evaluate PQC-capable options in JOSE/JWT implementations. / [Source](#source-77)|
|<a id="finding-78"></a>[holdout/jwt-helper.js:107:3](#finding-78)|jwt.sign|Evaluate PQC-capable options in JOSE/JWT implementations. / [Source](#source-78)|
|<a id="finding-79"></a>[holdout/jwt-rsa.js:2:13](#finding-79)|jwt.sign|Evaluate PQC-capable options in JOSE/JWT implementations. / [Source](#source-79)|

Shared checks for these locations (not verified facts about each line):

- [Stop issuing new JWTs with RSA/PKCS#1/ECDSA-only algorithms](#action-2)
- [Upgrade Node.js runtime for built-in WebCrypto PQC support](#action-3)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-75"></a>

### holdout/jwt-helper.js:65:20

      63   let syncVerified;
      64   try {
    > 65     syncVerified = jwt.verify(jwtString, secretOrPrivateKey, options);
      66   }
      67   catch (err) {

<a id="source-76"></a>

### holdout/jwt-helper.js:70:3

      68     error = err;
      69   }
    > 70   jwt.verify(jwtString, secretOrPrivateKey, options, (err, asyncVerifiedToken) => {
      71     try {
      72       if (error) {

<a id="source-77"></a>

### holdout/jwt-helper.js:102:18

      100   let syncSigned;
      101   try {
    > 102     syncSigned = jwt.sign(payload, secretOrPrivateKey, options);
      103   }
      104   catch (err) {

<a id="source-78"></a>

### holdout/jwt-helper.js:107:3

      105     error = err;
      106   }
    > 107   jwt.sign(payload, secretOrPrivateKey, options, (err, asyncSigned) => {
      108     fakeClock.restore();
      109     if (error) {

<a id="source-79"></a>

### holdout/jwt-rsa.js:2:13

      1 var privateKey = fs.readFileSync('private.key');
    > 2 var token = jwt.sign({ foo: 'bar' }, privateKey, { algorithm: 'RS256' });

<a id="rule-33"></a>

## TS_NODE_RSA_USAGE

RSA-related API symbols detected from JavaScript/TypeScript AST.

Check: Migrate Node.js RSA signing/verification logic to a PQC-ready design.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-80"></a>[holdout/jwt-rsa.js:2:64](#finding-80)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-80)|
|<a id="finding-81"></a>[tuning/jwt/sign.js:1:33](#finding-81)|RS256|Migrate Node.js RSA signing/verification logic to a PQC-ready design. / [Source](#source-81)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-0)
- [Introduce crypto abstraction boundary for algorithm agility](#action-9)
- [Verify deployed runtime and protocol PQC capabilities](#action-4)

<a id="source-80"></a>

### holdout/jwt-rsa.js:2:64

      1 var privateKey = fs.readFileSync('private.key');
    > 2 var token = jwt.sign({ foo: 'bar' }, privateKey, { algorithm: 'RS256' });

<a id="source-81"></a>

### tuning/jwt/sign.js:1:33

    > 1 sign(payload, key, {algorithm: "RS256"});

<a id="rule-34"></a>

## CERT_PEM_CONTAINER

Certificate container file detected.

Check: Validate signing algorithms in PEM-based certificates.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-82"></a>[tuning/certs/broken.cer:1:1](#finding-82)|broken.cer|Validate signing algorithms in PEM-based certificates. / [Source](#source-82)|
|<a id="finding-83"></a>[tuning/certs/broken.crt:1:1](#finding-83)|broken.crt|Validate signing algorithms in PEM-based certificates. / [Source](#source-83)|
|<a id="finding-84"></a>[tuning/certs/broken.der:1:1](#finding-84)|broken.der|Validate signing algorithms in PEM-based certificates. / [Source](#source-84)|
|<a id="finding-85"></a>[tuning/certs/broken.pem:1:1](#finding-85)|broken.pem|Validate signing algorithms in PEM-based certificates. / [Source](#source-85)|

Shared checks for these locations (not verified facts about each line):

- [Prepare hybrid certificate issuance and trust-store rollout](#action-1)

<a id="source-82"></a>

### tuning/certs/broken.cer:1:1

    > 1 not a certificate

<a id="source-83"></a>

### tuning/certs/broken.crt:1:1

    > 1 not a certificate

<a id="source-84"></a>

### tuning/certs/broken.der:1:1

    > 1 not a certificate

<a id="source-85"></a>

### tuning/certs/broken.pem:1:1

    > 1 not a certificate

<a id="rule-35"></a>

## DEP_PQC_CAPABLE_LIBRARY

Library with version-dependent PQC capabilities inventoried; capability is not an enabled-state finding.

Check: Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-86"></a>[tuning/manifests/Cargo.lock/declared/Cargo.lock:3:1](#finding-86)|openssl@0.10.75|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-86)|
|<a id="finding-87"></a>[tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1](#finding-87)|openssl@0.10.75|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-87)|
|<a id="finding-88"></a>[tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1](#finding-88)|openssl@3.3.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-88)|
|<a id="finding-89"></a>[tuning/manifests/Gemfile/declared/Gemfile:1:1](#finding-89)|openssl@3.3.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-89)|
|<a id="finding-90"></a>[tuning/manifests/Pipfile.lock/declared/Pipfile.lock:1:1](#finding-90)|cryptogr***48.0.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-90)|
|<a id="finding-91"></a>[tuning/manifests/gems.locked/declared/gems.locked:3:1](#finding-91)|openssl@3.3.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-91)|
|<a id="finding-92"></a>[tuning/manifests/gems.rb/declared/gems.rb:1:1](#finding-92)|openssl@3.3.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-92)|
|<a id="finding-93"></a>[tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1](#finding-93)|org.boun***n@1.80|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-93)|
|<a id="finding-94"></a>[tuning/manifests/poetry.lock/declared/poetry.lock:2:1](#finding-94)|cryptography@48.0.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-94)|
|<a id="finding-95"></a>[tuning/manifests/pom.xml/declared/pom.xml:1:1](#finding-95)|org.boun***n@1.80|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-95)|
|<a id="finding-96"></a>[tuning/manifests/requirements.txt/declared/requirements.txt:1:1](#finding-96)|cryptography@48.0.0|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-96)|

Shared checks for these locations (not verified facts about each line):

- [Track PQC readiness of dependent libraries](#action-18)

<a id="source-86"></a>

### tuning/manifests/Cargo.lock/declared/Cargo.lock:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-87"></a>

### tuning/manifests/Cargo.toml/declared/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-88"></a>

### tuning/manifests/Gemfile.lock/declared/Gemfile.lock:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-89"></a>

### tuning/manifests/Gemfile/declared/Gemfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-90"></a>

### tuning/manifests/Pipfile.lock/declared/Pipfile.lock:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-91"></a>

### tuning/manifests/gems.locked/declared/gems.locked:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-92"></a>

### tuning/manifests/gems.rb/declared/gems.rb:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-93"></a>

### tuning/manifests/gradle.lockfile/declared/gradle.lockfile:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-94"></a>

### tuning/manifests/poetry.lock/declared/poetry.lock:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-95"></a>

### tuning/manifests/pom.xml/declared/pom.xml:1:1

    > 1 [masked-sensitive-file-content]

<a id="source-96"></a>

### tuning/manifests/requirements.txt/declared/requirements.txt:1:1

    > 1 [masked-sensitive-file-content]

<a id="rule-36"></a>

## PQC_GO_API

Standard Go PQC package imported; import alone does not prove negotiated protection.

Check: crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-97"></a>[tuning/go/main.go:2:8](#finding-97)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-97)|

<a id="source-97"></a>

### tuning/go/main.go:2:8

      1 package data
    > 2 import "crypto/mlkem"

<a id="rule-37"></a>

## PQC_JAVA_API

Standard PQC algorithm requested through Java APIs; runtime success is not established.

Check: JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-98"></a>[holdout/MLDSA.java:1:36](#finding-98)|KeyPairG***SA-44"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-98)|
|<a id="finding-99"></a>[tuning/java/Kem.java:1:1](#finding-99)|KEM.getI***-1024"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-99)|
|<a id="finding-100"></a>[tuning/java/ML.java:1:1](#finding-100)|Signatur***SA-44"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-100)|

<a id="source-98"></a>

### holdout/MLDSA.java:1:36

    > 1         KeyPairGenerator kpGen44 = KeyPairGenerator.getInstance("ML-DSA-44");

<a id="source-99"></a>

### tuning/java/Kem.java:1:1

    > 1 KEM.getInstance("ML-KEM-1024");

<a id="source-100"></a>

### tuning/java/ML.java:1:1

    > 1 Signature.getInstance("ML-DSA-44");

<a id="rule-38"></a>

## PQC_NODE_API

Node-style PQC key generation call; bindings and actual execution require confirmation.

Check: Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-101"></a>[tuning/js/dead.js:1:12](#finding-101)|generate***m-768"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-101)|
|<a id="finding-102"></a>[tuning/js/direct.js:1:1](#finding-102)|generate***m-512"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-102)|
|<a id="finding-103"></a>[tuning/js/mixed.js:1:29](#finding-103)|generate***m-768"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-103)|
|<a id="finding-104"></a>[tuning/js/namesake.js:2:1](#finding-104)|generate***m-768"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-104)|
|<a id="finding-105"></a>[tuning/js/same-line.js:1:1](#finding-105)|generate***m-512"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-105)|
|<a id="finding-106"></a>[tuning/js/same-line.js:1:36](#finding-106)|generate***-1024"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-106)|
|<a id="finding-107"></a>[tuning/js/shadow.js:2:47](#finding-107)|generate***m-768"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-107)|
|<a id="finding-108"></a>[tuning/js/string.js:1:15](#finding-108)|generate***m-768"|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-108)|

<a id="source-101"></a>

### tuning/js/dead.js:1:12

    > 1 if (false) generateKeyPairSync("ml-kem-768");

<a id="source-102"></a>

### tuning/js/direct.js:1:1

    > 1 generateKeyPairSync("ml-kem-512");

<a id="source-103"></a>

### tuning/js/mixed.js:1:29

    > 1 generateKeyPairSync("rsa"); generateKeyPairSync("ml-kem-768");

<a id="source-104"></a>

### tuning/js/namesake.js:2:1

      1 function generateKeyPairSync(x) { return x; }
    > 2 generateKeyPairSync("ml-kem-768");

<a id="source-105"></a>

### tuning/js/same-line.js:1:1

    > 1 generateKeyPairSync("ml-kem-512"); generateKeyPairSync("ml-kem-1024");

<a id="source-106"></a>

### tuning/js/same-line.js:1:36

    > 1 generateKeyPairSync("ml-kem-512"); generateKeyPairSync("ml-kem-1024");

<a id="source-107"></a>

### tuning/js/shadow.js:2:47

      1 import {generateKeyPairSync} from "node:crypto";
    > 2 function render(generateKeyPairSync) { return generateKeyPairSync("ml-kem-768"); }

<a id="source-108"></a>

### tuning/js/string.js:1:15

    > 1 const help = 'generateKeyPairSync("ml-kem-768")';

<a id="rule-39"></a>

## PQC_PYTHON_API

Python PQC key generation reference; backend support is not established.

Check: cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-109"></a>[tuning/python/pqc.py:2:5](#finding-109)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-109)|

<a id="source-109"></a>

### tuning/python/pqc.py:2:5

      1 from cryptography.hazmat.primitives.asymmetric import mlkem
    > 2 k = mlkem.MLKEM768PrivateKey.generate()

<a id="rule-40"></a>

## PQC_RUBY_API

Ruby PQC algorithm literal referenced; key generation or signing success is not established.

Check: Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-110"></a>[tuning/ruby/pqc.rb:1:28](#finding-110)|"ML-DSA-87"|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-110)|

<a id="source-110"></a>

### tuning/ruby/pqc.rb:1:28

    > 1 OpenSSL::PKey.generate_key("ML-DSA-87")

<a id="rule-41"></a>

## PQC_RUST_API

Rust PQC crate symbol referenced; execution and protocol use require confirmation.

Check: Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-111"></a>[tuning/rust/pqc.rs:1:5](#finding-111)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-111)|

<a id="source-111"></a>

### tuning/rust/pqc.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="rule-42"></a>

## PQC_WEBCRYPTO_API

WebCrypto-style PQC algorithm request; this is not proof of browser support.

Check: Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-112"></a>[tuning/typescript/web.ts:1:15](#finding-112)|generate***M-768"|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-112)|
|<a id="finding-113"></a>[tuning/width/tsx/standard.tsx:2:15](#finding-113)|generate***M-768"|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-113)|

<a id="source-112"></a>

### tuning/typescript/web.ts:1:15

    > 1 crypto.subtle.generateKey({name: "ML-KEM-768"}, true, ["encapsulateBits"]);

<a id="source-113"></a>

### tuning/width/tsx/standard.tsx:2:15

      1 const enabled: boolean = true;
    > 2 crypto.subtle.generateKey({name: "ML-KEM-768"}, true, []);

## Action details

Each location links only to its applicable action. Identical payloads are printed once.

<a id="action-0"></a>


#### Adopt a phased hybrid PQC migration plan (near-term)

The detected primitive is vulnerable to cryptographically relevant quantum attacks. Hybrid rollout minimizes compatibility risk.

1. Inventory all call sites using this algorithm and owner teams.
2. Introduce dual-stack or hybrid mode (classical + PQC) before hard cut-over.
3. Define retirement dates for legacy classical algorithms.

References:

- https://www.nist.gov/itl/post-quantum-cryptography
- https://csrc.nist.gov/pubs/fips/203/final
- https://csrc.nist.gov/pubs/fips/204/final
<a id="action-1"></a>


#### Prepare hybrid certificate issuance and trust-store rollout (near-term)

PKI updates require coordinated CA, chain, and relying-party compatibility planning.

1. Inventory certificate signature algorithms and key sizes from CBOM/report output.
2. Pilot hybrid chain issuance in non-production trust stores.
3. Define reissuance plan for quantum-vulnerable roots/intermediates/end-entity certs.

References:

- https://csrc.nist.gov/pubs/fips/204/final
- https://csrc.nist.gov/pubs/fips/205/final
<a id="action-2"></a>


#### Stop issuing new JWTs with RSA/PKCS#1/ECDSA-only algorithms (near-term)

JWT signatures using classical public-key algorithms become long-term high risk under quantum adversaries.

1. Restrict accepted alg values and explicitly deny weak/legacy defaults.
2. Introduce short-lived tokens during the migration phase.
3. Prepare verifier rollout before signer rollout to avoid compatibility outages.
4. Confirm JOSE algorithm identifiers, key encoding, JWT library support and all verifiers before changing token signatures; primitive support alone is insufficient.

References:

- https://www.rfc-editor.org/rfc/rfc7519
<a id="action-3"></a>


#### Upgrade Node.js runtime for built-in WebCrypto PQC support (planned)

Node.js runtime level determines whether built-in PQC APIs are available for direct migration.

1. Node crypto: ML-DSA 24.6+, ML-KEM 24.7+, SLH-DSA 24.8+; WebCrypto ML-DSA/ML-KEM 24.7+. Check exact runtime and algorithm support.
2. Distinguish Node.js from browser execution; TypeScript types do not establish runtime capabilities. ML-KEM key exchange does not replace JWT signatures.

References:

- https://nodejs.org/api/webcrypto.html

Before (javascript)

    import jwt from "jsonwebtoken";
    const token = jwt.sign(payload, privateKey, { algorithm: "RS256" });

After

    // Replace RS256 token-signing path with a PQC-capable signing service
    // or WebCrypto ML-DSA workflow once runtime support is enabled.
    const token = await signWithPqc(payload);

<a id="action-4"></a>


#### Verify deployed runtime and protocol PQC capabilities (planned)

Source declarations and primitive availability do not establish deployment or peer support.

1. Node crypto ML-DSA requires 24.6+, ML-KEM 24.7+, SLH-DSA 24.8+; WebCrypto ML-DSA/ML-KEM requires 24.7+. Verify browser support independently of TypeScript declarations.
2. Check resolved versions, provider/features and interoperability before changing production policy.

References:

- https://nodejs.org/api/webcrypto.html
<a id="action-5"></a>


#### Rotate exposed private keys and revoke affected credentials (immediate)

Private key material was detected. This is an active key-management incident and must be remediated immediately.

1. Revoke/disable the exposed key and issue a replacement key pair.
2. Invalidate sessions/tokens signed by the compromised key if applicable.
3. Move keys to a secret manager or HSM and enforce commit scanning in CI.

References:

- https://cheatsheetseries.owasp.org/cheatsheets/Secrets_Management_Cheat_Sheet.html
<a id="action-6"></a>


#### Upgrade Java runtime baseline for standard PQC APIs (planned)

Detected Java version appears older than JDK releases with standardized PQC APIs.

1. Target JDK 24+ for ML-KEM and ML-DSA support planning.
2. Pilot compatibility testing in CI before production migration.

References:

- https://openjdk.org/jeps/496
- https://openjdk.org/jeps/497
<a id="action-7"></a>


#### Provide BouncyCastle PQC fallback path (near-term)

BouncyCastle can be used as a pragmatic transition option when standard runtime support is unavailable or incomplete.

1. Add BC provider initialization at bootstrap.
2. Use BC ML-DSA / ML-KEM parameter specs for migration pilot implementations.
3. Document provider ordering and FIPS/compliance impact.

References:

- https://www.bouncycastle.org/java.html
- https://downloads.bouncycastle.org/java/docs/bcprov-jdk18on-javadoc/

Before (java)

    Security.addProvider(new BouncyCastleProvider());
    Signature sig = Signature.getInstance("SHA256withRSA", "BC");

After

    Security.addProvider(new BouncyCastlePQCProvider());
    Signature sig = Signature.getInstance("ML-DSA", "BCPQC");
    // Configure parameter set (example): MLDSAParameterSpec.ml_dsa_65

<a id="action-8"></a>


#### Verify deployed runtime and protocol PQC capabilities (planned)

Source declarations and primitive availability do not establish deployment or peer support.

1. JDK 24 adds ML-KEM and ML-DSA primitives. Check deployed JSSE hybrid TLS support separately and inspect jdk.tls.namedGroups restrictions.
2. Check resolved versions, provider/features and interoperability before changing production policy.

References:

- https://docs.oracle.com/en/java/javase/27/security/java-secure-socket-extension-jsse-reference-guide.html
<a id="action-9"></a>


#### Introduce crypto abstraction boundary for algorithm agility (near-term)

Direct algorithm calls create high migration cost. A boundary layer enables staged classical-to-PQC transitions.

1. Wrap signing, verification, keygen, and key exchange behind stable interfaces.
2. Add policy controls to select classical, hybrid, or PQC paths at runtime.

References:

- https://www.nist.gov/itl/post-quantum-cryptography
<a id="action-10"></a>


#### Validate Envoy PQC signature compatibility in control/data planes (advisory)

Envoy TLS behavior depends on configured providers and peer capabilities; PQC signature readiness can vary between mesh edges, sidecars, and external clients.

1. Harden min/max TLS versions and remove legacy RSA suites first.
2. Verify PQC certificate-signature compatibility in both downstream and upstream clusters.
3. Gate production rollout with staged canary tests and explicit fallback paths.

References:

- https://www.envoyproxy.io/docs/envoy/latest/intro/arch_overview/security/ssl.html
- https://www.envoyproxy.io/docs/envoy/latest/api-v3/extensions/transport_sockets/tls/v3/tls.proto
<a id="action-11"></a>


#### Validate HAProxy TLS stack PQC signature readiness before production (advisory)

HAProxy TLS capabilities are tied to the linked TLS stack and runtime policy; PQC signature behavior may differ by build and client compatibility.

1. Keep TLS 1.2+/1.3 policy and remove legacy protocol/cipher options first.
2. Run interoperability tests for PQC certificate signatures with all major client types.
3. Use phased rollout with rollback/fallback controls while collecting compatibility evidence.

References:

- https://www.haproxy.com/documentation/haproxy-configuration-tutorials/security/ssl-tls/
<a id="action-12"></a>


#### Validate Istio mesh-wide PQC signature interoperability before enforcement (advisory)

Istio rollout spans gateways, sidecars, and service-to-service traffic; mesh-wide certificate-signature interoperability must be validated end-to-end.

1. Standardize TLS modernization policy in DestinationRule/Gateway resources.
2. Test PQC signature compatibility across ingress gateway, sidecars, and external clients.
3. Roll out with progressive policies and keep compatibility fallbacks during migration.

References:

- https://istio.io/latest/docs/reference/config/networking/destination-rule/
- https://istio.io/latest/docs/reference/config/networking/gateway/
<a id="action-13"></a>


#### Validate Kubernetes PQC signature readiness before production rollout (advisory)

As described in Kubernetes guidance dated July 18, 2025, ecosystem readiness is currently stronger for hybrid key exchange than for end-to-end PQC certificate signatures.

1. Treat TLS modernization (TLS 1.2+/1.3) and hybrid KEM pilots as the immediate baseline.
2. Do not assume ML-DSA/SLH-DSA certificate signatures are natively interoperable across ingress/controller/mesh/CA/client paths.
3. Run staged compatibility tests before enforcing PQC signatures in production.

References:

- https://kubernetes.io/blog/2025/07/18/pqc-in-k8s/
- https://go.dev/doc/go1.26
<a id="action-14"></a>


#### Validate nginx/OpenSSL PQC signature interoperability before rollout (advisory)

nginx relies on TLS library behavior; hybrid KEM support and PQC certificate-signature interoperability can differ by OpenSSL/provider build and client ecosystem.

1. Keep TLS 1.2+/1.3 hardening as baseline and pilot hybrid KEM first.
2. Test ML-DSA/SLH-DSA certificate-chain interoperability across nginx, upstream TLS endpoints, and client stacks.
3. Roll out behind canary and keep fallback policy until interoperability evidence is complete.

References:

- https://nginx.org/en/docs/http/ngx_http_ssl_module.html
- https://openssl-library.org/post/2025-04-08-openssl-3.5-final/
<a id="action-15"></a>


#### Prefer TLS 1.3 and review legacy key exchange (near-term)

RSA key exchange and legacy protocol versions are high-priority migration blockers for PQC readiness.

1. Prefer TLS 1.3; restrict connections to TLS 1.3 when all peers support it. Disable TLS 1.0 and 1.1.
2. Retain securely configured TLS 1.2 only where interoperability requires it, and record the compatibility reason.
3. Prefer ECDHE today and plan hybrid KEM suites for next phase.
4. Continuously test interoperability across clients and load balancers.

References:

- https://www.rfc-editor.org/rfc/rfc8446
<a id="action-16"></a>


#### Harden Apache httpd SSL/TLS directives (near-term)

Apache TLS settings can be migrated safely via explicit protocol and cipher controls.

1. Prefer \`SSLProtocol -all +TLSv1.3\` when all peers support it; retain TLSv1.2 only for a documented interoperability need.
2. Review \`SSLCipherSuite\` and remove RSA key-exchange suites.

References:

- https://httpd.apache.org/docs/trunk/mod/mod_ssl.html
<a id="action-17"></a>


#### Set modern TLS policy in Envoy (near-term)

Envoy control-plane config supports strict min/max protocol and cipher suite policy.

1. Prefer \`tls_minimum_protocol_version: TLSv1_3\`; use TLSv1_2 only when interoperability requires it.
2. Remove RSA-dependent suites from \`cipher_suites\`.

References:

- https://www.envoyproxy.io/docs/envoy/latest/api-v3/extensions/transport_sockets/tls/v3/tls.proto
<a id="action-18"></a>


#### Track PQC readiness of dependent libraries (planned)

Dependency-level crypto libraries strongly influence migration options and operational timelines.

1. Record current versions in dependency-sbom.json and define upgrade targets.
2. Subscribe to release notes for PQC feature availability and API changes.
3. Run integration tests for PQC or hybrid modes before promoting to production.

References:

- https://cyclonedx.org/
- https://spdx.dev/
<a id="action-19"></a>


#### Verify deployed runtime and protocol PQC capabilities (planned)

Source declarations and primitive availability do not establish deployment or peer support.

1. Check openssl gem and linked library/provider versions. gem 4 adds groups=, sigalgs= and negotiated group inspection; Ruby version alone is insufficient.
2. Check resolved versions, provider/features and interoperability before changing production policy.

References:

- https://ruby.github.io/openssl/History_md.html
<a id="action-20"></a>


#### Validate Traefik PQC signature interoperability with all entrypoints (advisory)

Traefik TLS options and provider integrations can produce environment-specific PQC signature behavior that must be validated before strict enforcement.

1. Raise minimum TLS version and remove legacy suites/options as baseline.
2. Test PQC certificate-signature compatibility for edge traffic, internal services, and automation clients.
3. Apply staged rollout with explicit compatibility fallback configuration.

References:

- https://doc.traefik.io/traefik/https/tls/
- https://doc.traefik.io/traefik/routing/routers/#tls

## Inventory exports

- [CBOM](cbom.json): 114
- [Dependency SBOM](dependency-sbom.json): 42


## Inspection coverage

Completeness covers supported inspection within the declared scope, after ignore settings, exclusions and size limits. It does not prove runtime use, certificate trust or security. Unenumerated files remain unknown.

|Item|Value|
|---|---|
|Status|Some inspection could not complete (partial)|
|Selected files|206|
|Read successfully|206|
|Read failed|0|
|Analyzed|153|
|Partial|32|
|Analysis failed|0|
|Unsupported|0|
|Not applicable|0|
|Unknown|21|
|Enumerated exclusions|0|
|Enumeration failures|0|
|Unenumerated population|Unknown|

## Inspection diagnostics

Safe reason codes, paths and detector names; file contents and arbitrary error messages are omitted.

|Item|Value|
|---|---|
|Detector does not report completeness (detector_not_reported)|- / dependency_detector|
|Only part of inspection completed (detector_partial)|tuning/certs/broken.cer / certificate_detector|
|Only part of inspection completed (detector_partial)|tuning/certs/broken.crt / certificate_detector|
|Only part of inspection completed (detector_partial)|tuning/certs/broken.der / certificate_detector|
|Only part of inspection completed (detector_partial)|tuning/certs/broken.p12 / certificate_detector|
|Only part of inspection completed (detector_partial)|tuning/certs/broken.pem / certificate_detector|
|Only part of inspection completed (detector_partial)|tuning/certs/broken.pfx / certificate_detector|
|Inspection unsupported (detector_unsupported)|tuning/certs/public-only.p12 / certificate_detector|
|Inspection unsupported (detector_unsupported)|tuning/certs/public-only.pfx / certificate_detector|
|Only part of inspection completed (detector_partial)|tuning/encryption/BrokenCipher.java / tree_sitter_detector|
|Only part of inspection completed (detector_partial)|tuning/go/broken.go / tree_sitter_detector|
|Only part of inspection completed (detector_partial)|tuning/java/Broken.java / tree_sitter_detector|
|Only part of inspection completed (detector_partial)|tuning/jwt/broken.js / tree_sitter_detector|
|Detector failed (detector_failed)|tuning/manifests/Cargo.lock/malformed/Cargo.lock / dependency_detector|
|Detector failed (detector_failed)|tuning/manifests/Cargo.toml/malformed/Cargo.toml / dependency_detector|
|Detector failed (detector_failed)|tuning/manifests/Pipfile.lock/malformed/Pipfile.lock / dependency_detector|
|Only part of inspection completed (detector_partial)|tuning/manifests/gems.rb/malformed/gems.rb / tree_sitter_detector|
|Detector failed (detector_failed)|tuning/manifests/package-lock.json/malformed/package-lock.json / dependency_detector|
|Detector failed (detector_failed)|tuning/manifests/package.json/malformed/package.json / dependency_detector|
|Inspection unsupported (detector_unsupported)|tuning/manifests/pnpm-lock.yaml/malformed/pnpm-lock.yaml / dependency_detector|
|Detector failed (detector_failed)|tuning/manifests/poetry.lock/malformed/poetry.lock / dependency_detector|
|Detector failed (detector_failed)|tuning/manifests/pom.xml/malformed/pom.xml / dependency_detector|
|Only part of inspection completed (detector_partial)|tuning/python/broken.py / tree_sitter_detector|
|Only part of inspection completed (detector_partial)|tuning/ruby/broken.rb / tree_sitter_detector|
|Only part of inspection completed (detector_partial)|tuning/rust/broken.rs / tree_sitter_detector|
|Detector failed (detector_failed)|tuning/sbom/CycloneDX-1.5/malformed/bom.json / dependency_detector|
|Detector failed (detector_failed)|tuning/sbom/SPDX-2.3/malformed/bom.json / dependency_detector|
|Only part of inspection completed (detector_partial)|tuning/typescript/broken.ts / tree_sitter_detector|
|Detector failed (detector_failed)|tuning/width/cdx-1.4/broken/bom.json / dependency_detector|
|Detector failed (detector_failed)|tuning/width/cdx-1.6/broken/bom.json / dependency_detector|
|Detector failed (detector_failed)|tuning/width/cdx-1.7/broken/bom.json / dependency_detector|
|Detector failed (detector_failed)|tuning/width/spdx-2.2/broken/bom.json / dependency_detector|
|Only part of inspection completed (detector_partial)|tuning/width/tsx/broken.tsx / tree_sitter_detector|
