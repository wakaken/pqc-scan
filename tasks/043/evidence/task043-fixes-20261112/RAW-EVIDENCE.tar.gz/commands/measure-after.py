import pathlib,subprocess,json,time,datetime
R=pathlib.Path.cwd();P=R/'target/quality-task-043-fixes-20261112';S=P/'before-checkout';checks=[]
def run(name,cmd):
 start=time.monotonic();log=P/(name+'.log');print('START',name,flush=True)
 with log.open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 checks.append(dict(name=name,command=cmd,cwd=str(R),exitCode=r.returncode,wallSeconds=time.monotonic()-start,log=str(log.relative_to(R)),timestampUtc=datetime.datetime.now(datetime.timezone.utc).isoformat()));(P/'AFTER-MEASUREMENT-COMMANDS.json').write_text(json.dumps(checks,indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode:print(log.read_text()[-2000:]);raise SystemExit(1)
for name,corpus in [('v3','task043-corpus'),('v2','expanded-v2'),('v1','expanded'),('lock','expanded-v2-lock-controls'),('original',None)]:
 out=str((P/('after-'+name)).relative_to(R));cmd=['python3','tests/quality/run.py','--out-dir',out,'--build-profile','release','--repeats','3','--skip-benchmarks'];opts=[] if corpus is None else ['--corpus-dir','tests/quality/'+corpus];run('after-'+name,cmd+opts)
 cmd=['python3','tests/quality/report.py','--baseline',out,'--out-dir',out+'-report']+opts
 if name=='v3':cmd+=['--reference',str(S/'target/before-v3-final/summary.json')]
 if name=='v2':cmd+=['--applicability','tests/quality/applicability-042-v2/assessment.json']
 if name=='original':cmd+=['--reference','docs/quality/task023/BASELINE.json']
 run('after-'+name+'-report',cmd)
