import json,hashlib,datetime,pathlib,sys
sys.path.insert(0,'tests/quality');from taxonomy import annotation
P=pathlib.Path('tests/quality/task043-corpus');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=json.loads((P/'labels-a.json').read_text());b=json.loads((P/'labels-b.json').read_text());A={r['id']:r for r in a['labels']};B={r['id']:r for r in b['labels']};decisions=[]
for id in A:
 if annotation(A[id])!=annotation(B[id]):
  # Direct named JWT API is an ordinary different API; unconstrained helper options are dynamic.
  row=A[id].copy();row['caseKind']='ordinary' if id=='fresh-jwt-node-direct' else 'dynamic';A[id]=row
  decisions.append(dict(id=id,reason='Source shows jwt.sign, a different named library API rather than a Node crypto namesake. The helper receives external options and an unspecified key; dynamic describes that control, not a known RSA/PQC use. Labels agree; this adjudication concerns case taxonomy only.',resolution=annotation(row)))
truth=dict(version=1,corpusSha256=sha(P/'corpus.json'),annotationAuditRequired=True,labelSources={name:sha(P/name) for name in ['labels-a.json','labels-b.json']},adjudications=decisions,labels=list(A.values()),freeze=dict(timestampUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),beforeFirstMeasurement=True,protocolSha256=sha(P/'PROTOCOL.md'),provenanceSha256=sha(P/'provenance.json')),evaluationHistory='All inherited data are post-observation tuning. Two independently sourced reviewers inspected all input/rule pairs, then consulted original source labels as inherited oracle evidence; this is disclosed, not a fresh blind labeling of inherited data. Nine added questions were independently source-labeled before current version measurements. Seven questions in two pre-scanner upstream lineages are fresh holdout; correlated questions do not establish population accuracy. Six encrypted attributes are unsupported by existing public contract, not deleted failures; original v2 object truth retained.')
(P/'truth.json').write_text(json.dumps(truth,ensure_ascii=False,indent=2)+'\n')
from evaluate import load_truth,validate_corpus
D,L=load_truth(P.resolve());validate_corpus(D,pathlib.Path.cwd());print('Frozen validated',len(L),'units',truth['freeze']['timestampUtc'])
