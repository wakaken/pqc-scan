import pathlib,json,hashlib,shutil
R=pathlib.Path.cwd();P=R/'target/quality-task-043-fixes-20261112';E=json.loads((P/'ENTRY.json').read_text());S=P/'before-checkout';S.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
count=0
for name,expected in E['sourceBindings'].items():
 if not (name.startswith(('crates/','rules/','schemas/','tests/quality/')) or name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','docs/quality/RULE-QUALITY-METADATA.json']): continue
 saved=P/'before/source'/name;src=saved if saved.is_file() else R/name
 if sha(src)!=expected:raise ValueError('Old source unavailable '+name)
 dst=S/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);count+=1
# All corpus source files are exact immutable data; cover sources outside runtime bindings.
for manifest in sorted((R/'tests/quality').glob('**/corpus.json')):
 if 'task043-corpus' in str(manifest):continue
 d=json.loads(manifest.read_text())
 for f in d.get('files',[]):
  if 'source' not in f:continue
  src=R/f['source'];dst=S/f['source']
  if sha(src)!=f['sha256']:raise ValueError(f['source'])
  dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
(S/'target/release').mkdir(parents=True);shutil.copy2(P/'before/pqc-scan',S/'target/release/pqc-scan')
record={'purpose':'Before-source+before-rules+before-binary snapshot, not oldbinary with current rules','entrySha256':sha(P/'ENTRY.json'),'verifiedEntryFiles':count,'runtimeRoot':str(S),'binarySha256':sha(S/'target/release/pqc-scan'),'gitContext':'Nested target directory inherits outer Git HEAD; exact file/binary bindings, not HEAD alone, identify measured sources. Snapshot never built or mutated.'};(P/'BEFORE-SNAPSHOT.json').write_text(json.dumps(record,indent=2)+'\n');print(record)
