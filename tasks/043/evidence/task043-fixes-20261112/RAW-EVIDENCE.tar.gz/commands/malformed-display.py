text = 'mlkem.MLKEM768PrivateKey.generate(
