import pathlib,re
p=pathlib.Path('rules/default/pqc.yml');s=p.read_text()
def edit(id,pattern=None,description=None):
 global s
 a=s.index('- id: '+id+'\n');b=s.find('\n- id:',a+1);b=len(s) if b<0 else b;part=s[a:b]
 if pattern is not None:part=re.sub(r'^  pattern: .*$',lambda m:"  pattern: '"+pattern.replace("'","''")+"'",part,flags=re.M)
 if description is not None:part=re.sub(r'^  description: .*$',lambda m:'  description: '+description,part,flags=re.M)
 s=s[:a]+part+s[b:]
standard=r'(?:ML-(?:KEM|DSA)(?:-(?:512|768|1024|44|65|87))?|SLH-DSA-(?:SHA2|SHAKE)-(?:128|192|256)[sf])'
edit('PQC_JAVA_API',r'(?:KEM|Signature|KeyPairGenerator)\s*\.\s*getInstance\(\s*"'+standard+'"')
edit('PQC_RUBY_API',r'[\'"](?:ML-(?:KEM-(?:512|768|1024)|DSA-(?:44|65|87))|SLH-DSA-(?:SHA2|SHAKE)-(?:128|192|256)[sf])[\'"]')
edit('PQC_DRAFT_ALGORITHM',r'(?i)\b(?:X25519Kyber768Draft00|Kyber(?:512|768|1024)|Dilithium[235])\b')
group=r'(?:x25519|x448|secp256r1|secp384r1|secp521r1)';values=group+r'(?:\s*,\s*'+group+r')*'
edit('PQC_JAVA_CLASSICAL_GROUPS',r'(?im)^\s*(?:jdk\.tls\.namedGroups\s*=\s*'+values+r'|System\.setProperty\(\s*"jdk\.tls\.namedGroups"\s*,\s*"'+values+r'"\s*\)\s*;?|<entry\s+key="jdk\.tls\.namedGroups"\s*>\s*'+values+r'\s*</entry>)\s*$', 'Explicit classical-only Java property intent in assignment, XML entry or static System.setProperty; effective loading is not established.')
edit('DEP_PQC_CAPABLE_LIBRARY',r'^(?:(?:rustls|aws-lc-rs|ml-kem|ml-dsa|slh-dsa|openssl)\s+\S+\s+cargo\b|@noble/post-quantum\s+\S+\s+npm\b|cryptography\s+\S+\s+pypi\b|openssl\s+\S+\s+(?:gem|generic|unknown)\b|org\.bouncycastle:bcprov-jdk18on\s+\S+\s+maven\b|github\.com/cloudflare/circl\s+\S+\s+golang\b)')
p.write_text(s)
