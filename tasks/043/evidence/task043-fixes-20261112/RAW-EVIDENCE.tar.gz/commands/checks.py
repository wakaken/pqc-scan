import pathlib,subprocess,time,json,datetime,sys
p=pathlib.Path('target/quality-task-043-fixes-20261112');record=[]
checks=[('fmt',['cargo','fmt','--all','--','--check']),('workspace',['cargo','test','--workspace','--offline','--locked']),('clippy',['cargo','clippy','--workspace','--all-targets','--offline','--locked','--','-D','warnings']),('python-quality',['python3','-m','unittest','discover','-s','tests/quality','-p','test_*.py']),('python-protocol',['python3','-m','unittest','discover','-s','tests/protocol','-p','test_*.py']),('python-distribution',['python3','-m','unittest','discover','-s','tests/distribution']),('node',['node','--test',*map(str,sorted(pathlib.Path('shell').glob('*.test.cjs')))]),('release',['cargo','build','--workspace','--release','--offline','--locked'])]
for name,cmd in checks:
 start=time.monotonic();log=p/('native-'+name+'.log');print('START',name,flush=True)
 with log.open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 item=dict(name=name,command=cmd,exitCode=r.returncode,wallSeconds=time.monotonic()-start,log=str(log),timestampUtc=datetime.datetime.now(datetime.timezone.utc).isoformat());record.append(item);(p/'NATIVE-CHECKS.json').write_text(json.dumps(record,indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode:print(log.read_text()[-3000:],flush=True)
sys.exit(any(x['exitCode'] for x in record))
