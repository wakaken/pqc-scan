import pathlib,subprocess,json,time,datetime,shutil,sys
R=pathlib.Path.cwd();P=R/'target/quality-task-043-fixes-20261112';S=P/'before-checkout';
checks=[]
def run(name,cmd,cwd):
 log=P/(name+'.log');start=time.monotonic();print('START',name,flush=True)
 with log.open('w') as f:r=subprocess.run(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 row=dict(name=name,command=cmd,cwd=str(cwd),exitCode=r.returncode,wallSeconds=time.monotonic()-start,log=str(log.relative_to(R)),timestampUtc=datetime.datetime.now(datetime.timezone.utc).isoformat());checks.append(row);(P/'AUDITED-BEFORE-COMMANDS.json').write_text(json.dumps(checks,indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode: print(log.read_text()[-2500:],flush=True);raise SystemExit(1)
# Current binary rebuilt separately after final code; before measurements can proceed now.
run('before-audited',['python3','tests/quality/run.py','--corpus-dir','tests/quality/task043-corpus-v2','--out-dir','target/before-audited','--build-profile','release','--repeats','3','--skip-benchmarks'],S)
run('before-audited-report',['python3','tests/quality/report.py','--corpus-dir','tests/quality/task043-corpus-v2','--baseline','target/before-audited','--out-dir','target/before-audited-report'],S)
print('Before complete. Current measurements use separate final commands.',flush=True)
