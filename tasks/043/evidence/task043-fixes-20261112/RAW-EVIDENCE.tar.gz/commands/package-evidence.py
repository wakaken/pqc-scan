import pathlib,json,hashlib,tarfile
R=pathlib.Path.cwd();P=R/'target/quality-task-043-fixes-20261112';D=R/'docs/quality/task043-fixes-20261112'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
before=load(P/'before-checkout/target/before-complete/summary.json')['environment'];after=load(P/'complete-after-v3/summary.json')['environment'];historical=load(R/'docs/quality/task042-reopen-20261112/v2-report/quality.json')['environment']
assert all(before[k]==historical[k] for k in ['binarySha256','runtimeSourceDigest'])
(D/'BEFORE-BASELINE-MATCH.json').write_text(json.dumps(dict(status='Verified',fields=['binarySha256','runtimeSourceDigest'],historical='docs/quality/task042-reopen-20261112/v2-report/quality.json',baseline=before['binarySha256'],sourceDigest=before['runtimeSourceDigest'],harness='Updated identical evaluation harness on both versions; no old/current rule mixing'),indent=2)+'\n')
source_archive=D/'SOURCE-OVERLAYS.tar.gz'
with tarfile.open(source_archive,'w:gz') as t:
 for label,root,env in [('before',P/'before-checkout',before),('after',R,after)]:
  for name,h in env['runtimeSourceBindings'].items():
   f=root/name;assert sha(f)==h,name;t.add(f,arcname=label+'/'+name,recursive=False)
 t.add(P/'PRODUCT.patch',arcname='PRODUCT.patch',recursive=False)
raw_archive=D/'RAW-EVIDENCE.tar.gz'
with tarfile.open(raw_archive,'w:gz') as t:
 # Reports and raw accuracy measurements, not upstream test source files or binaries.
 for name in ['before-complete','before-complete-report']:
  t.add(P/'before-checkout/target'/name,arcname='before/'+name)
 for name in ['v3','v2','v1','lock','original']:
  for suffix in ['', '-report']:
   path=P/('complete-after-'+name+suffix);t.add(path,arcname='after/'+path.name)
 for f in sorted(P.glob('*.log')):t.add(f,arcname='logs/'+f.name,recursive=False)
 for f in sorted(P.glob('*.py')):t.add(f,arcname='commands/'+f.name,recursive=False)
 for f in sorted(P.glob('*.json')):t.add(f,arcname='records/'+f.name,recursive=False)
 for name in ['final-self-scan/report.sarif','final-self-scan-upload.sarif','final-self-scan-audit.json']:
  t.add(P/name,arcname=name,recursive=False)
 for name in ['reviewer-repro','reviewer-rust-repro']:
  if (P/name).exists():t.add(P/name,arcname='review/'+name)
 for root in ['task043-corpus','task043-corpus-v2']:
  t.add(R/'tests/quality'/root,arcname='corpus/'+root)
index={str(f.relative_to(D)):dict(sha256=sha(f),bytes=f.stat().st_size) for f in sorted(D.rglob('*')) if f.is_file() and f.name!='EVIDENCE-INDEX.json'}
(D/'EVIDENCE-INDEX.json').write_text(json.dumps(index,indent=2)+'\n');print('sources',source_archive.stat().st_size,'raw evidence',raw_archive.stat().st_size)
