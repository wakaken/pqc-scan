import pathlib,json,hashlib,collections,sys,difflib
R=pathlib.Path.cwd();P=R/'target/quality-task-043-fixes-20261112';D=R/'docs/quality/task043-fixes-20261112';D.mkdir(exist_ok=True)
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
targets=load(P/'TARGETS.json');scored=load(P/'complete-after-v2/summary.json')['accuracy'];by=collections.defaultdict(list)
for d in scored['details']:
 if d['unit']:by[d['unit']].append(d)
def specs(row):
 id=row['unit'];r=row['ruleId']
 if row['disposition']=='fp':return 'A','node_alias_calls_are_real_calls_and_local_scopes_are_respected' if r=='PQC_NODE_API' else 'ssh_disabled_comment_is_not_an_enabled_algorithm'
 if r=='DEP_PQC_CAPABLE_LIBRARY':return 'C','gradle_static_declarations_are_found_without_executing_dsl; gemspec_binds_the_declared_block_variable; capable_library_rule_respects_exact_identity_and_source_ecosystem'
 if r=='PQC_JAVA_CLASSICAL_GROUPS':return 'A','java_static_property_forms_preserve_intent_not_effective_state'
 if id=='x014':return 'D','malformed_calls_retain_explicit_facts_and_partial_status'
 if id in ['x005','x011']:return 'B','malformed_calls_retain_explicit_facts_and_partial_status'
 if id in ['x003','x016','x036']:return 'B','slhdsa_and_prestandard_names_have_exact_variant_boundaries'
 if id.startswith('x') and id[1:].isdigit() and 131<=int(id[1:])<=139:return 'E','node_static_loop_variants_are_one_reference_per_call'
 if r=='PQC_NODE_API':return 'A','node_alias_calls_are_real_calls_and_local_scopes_are_respected'
 return 'D','rsa_generation_and_key_bound_signatures_do_not_infer_rsa_from_digest; explicit_python_import_and_rust_typed_operations_are_separate_references'
before_details=load(P/'before-checkout/target/before-complete/summary.json')['accuracy']['details'];before_by=collections.defaultdict(list)
for d in before_details:
 if d['unit']:before_by[d['unit']].append(d)
ledger=[]
for row in targets:
 assert len(before_by[row['unit']])==1 and before_by[row['unit']][0]['disposition']==row['disposition'],row['unit']
 expected='tn' if row['disposition']=='fp' else 'tp';actual=by[row['unit']];assert len(actual)==1 and actual[0]['disposition']==expected,(row['unit'],actual)
 group,tests=specs(row);source=row['sourceUnit'];f=next(f for f in load(R/'tests/quality/expanded-v2/corpus.json')['files'] if f['path']==source['path'])
 ledger.append(dict(id=row['unit'],ruleId=row['ruleId'],before=row['disposition'],after=expected,status='Passed',group=group,input=f['source'],inputSha256=f['sha256'],sourceUnit=source,matchedObservation=actual[0],tests=tests.split('; '),oldTruthChanged=False))
# Ensure referenced function names actually exist; source-derived ledger catches stale documentation.
testtext=(R/'crates/pqc_scan_detectors/tests/task043_detection_fixes.rs').read_text()
missing=sorted({t for row in ledger for t in row['tests'] if 'fn '+t+'(' not in testtext});assert not missing,missing
save(D/'REPAIRS.json',dict(scope='Original supported 042-v2 FP4/FN40, fixed annotations unchanged',sourceCommit=load(P/'ENTRY.json')['head'],branch='codex/quality-assessment-model',entries=ledger,counts=dict(fpFixed=4,fnFixed=40,remaining=0)))
rows=['# 元の44観測の修正台帳','', '元の042-v2正解と対応範囲を変えず照合しています。全件の入力hash・位置・試験参照は[REPAIRS.json](REPAIRS.json)を参照してください。','', '| ID | 規則 | 修正前→後 | 実装単位 | 結果 |','|---|---|---|---|---|']
rows += [f"| {r['id']} | {r['ruleId']} | {r['before'].upper()}→{r['after'].upper()} | {r['group']} | Passed |" for r in ledger];(D/'REPAIRS.md').write_text('\n'.join(rows)+'\n')
entry=load(P/'ENTRY.json');frozen={}
for name,h in entry['sourceBindings'].items():
 if (name.startswith(('tests/quality/expanded/','tests/quality/expanded-v2/','tests/quality/expanded-v2-lock-controls/','tests/quality/applicability-042-v2/','docs/quality/task042/','docs/quality/task042-reopen-20261112/','docs/quality/task043/','docs/quality/assessment-20261111/')) or name in ['tests/quality/corpus.json','tests/quality/truth.json','tests/quality/PROTOCOL.md']):
  assert sha(R/name)==h,name;frozen[name]=h
save(D/'FROZEN-EVIDENCE.json',dict(status='Verified',fileCount=len(frozen),bindings=frozen,originalBinarySha256=sha(P/'before/pqc-scan'),originalEntrySha256=sha(P/'ENTRY.json')))
# Only current-request product changes, relative to saved dirty entry, not git HEAD.
paths=sorted(p for parent in ['crates','rules'] for p in (R/parent).rglob('*') if p.is_file())
changes=[];patch=[]
for f in paths:
 name=str(f.relative_to(R));old=entry['sourceBindings'].get(name);h=sha(f)
 if old==h:continue
 saved=P/'before/source'/name
 if old is not None:assert saved.exists() and sha(saved)==old,name
 changes.append(dict(path=name,beforeSha256=old,afterSha256=h))
 if f.suffix in ['.rs','.yml']:
  before=saved.read_text().splitlines(True) if saved.exists() else [];patch.extend(difflib.unified_diff(before,f.read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(P/'PRODUCT.patch').write_text(''.join(patch));save(D/'PRODUCT-DELTA.json',dict(baseCommit=entry['head'],baseKind='saved worktree entry, including earlier uncommitted changes',files=changes,patchSha256=sha(P/'PRODUCT.patch')))
print('44 repairs verified;',len(frozen),'historical files unchanged;',len(changes),'product files changed')
