import pathlib,subprocess,json,time,datetime,shutil,sys
R=pathlib.Path.cwd();P=R/'target/quality-task-043-fixes-20261112';S=P/'before-checkout';C=R/'tests/quality/task043-corpus';shutil.copytree(C,S/'tests/quality/task043-corpus',dirs_exist_ok=True);(S/'target/release/pqc-scan').chmod(0o755)
checks=[]
def run(name,cmd,cwd):
 log=P/(name+'.log');start=time.monotonic();print('START',name,flush=True)
 with log.open('w') as f:r=subprocess.run(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 row=dict(name=name,command=cmd,cwd=str(cwd),exitCode=r.returncode,wallSeconds=time.monotonic()-start,log=str(log.relative_to(R)),timestampUtc=datetime.datetime.now(datetime.timezone.utc).isoformat());checks.append(row);(P/'MEASUREMENT-COMMANDS.json').write_text(json.dumps(checks,indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode: print(log.read_text()[-2500:],flush=True);raise SystemExit(1)
# Current binary rebuilt separately after final code; before measurements can proceed now.
run('before-v3-final',['python3','tests/quality/run.py','--corpus-dir','tests/quality/task043-corpus','--out-dir','target/before-v3-final','--build-profile','release','--repeats','3','--skip-benchmarks'],S)
run('before-v3-report',['python3','tests/quality/report.py','--corpus-dir','tests/quality/task043-corpus','--baseline','target/before-v3-final','--out-dir','target/before-v3-final-report'],S)
print('Before complete. Current measurements use separate final commands.',flush=True)
