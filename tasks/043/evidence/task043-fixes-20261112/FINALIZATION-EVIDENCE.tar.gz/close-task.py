from pathlib import Path
import json,hashlib,datetime,shutil
R=Path.cwd();P=R/'target/quality-task-043-fixes-20261112';D=R/'docs/quality/task043-fixes-20261112'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Preserve the reviewer-visible manifest and the two exact pre-addendum versions.
old_index=json.loads((D/'EVIDENCE-INDEX.json').read_text());H=D/'reviewed-snapshot';H.mkdir(exist_ok=True);shutil.copyfile(D/'EVIDENCE-INDEX.json',H/'EVIDENCE-INDEX.json')
old_source=json.loads((D/'FINAL-SOURCE.json').read_text())
for name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','docs/quality/RULE-QUALITY-METADATA.json','docs/quality/SELF-SCAN-EXPECTATIONS.json']:old_source.pop(name)
f=H/'FINAL-SOURCE.json';f.write_text(json.dumps(old_source,indent=2)+'\n');assert sha(f)==old_index['FINAL-SOURCE.json']['sha256']
old_validation=json.loads((D/'VALIDATION.json').read_text());old_validation['sourceBindingsSha256']=sha(f);f=H/'VALIDATION.json';f.write_text(json.dumps(old_validation,ensure_ascii=False,indent=2)+'\n');assert sha(f)==old_index['VALIDATION.json']['sha256']
review_files=[]
for pattern in ['IMPLEMENTATION-REVIEW*.json','IMPLEMENTATION-REVIEW.md','TEST-REVIEW*.json','TEST-REVIEW.md']:
 for f in sorted(P.glob(pattern)):
  dst=D/f.name
  if dst.exists():assert sha(dst)==sha(f),f.name
  else:shutil.copyfile(f,dst)
  review_files.append(dict(path=str(dst.relative_to(R)),sha256=sha(dst)))
assert json.loads((D/'IMPLEMENTATION-REVIEW-COMBINED-APPROVAL.json').read_text())
assert '最終判定: **承認**' in (D/'TEST-REVIEW.md').read_text()
checks=json.loads((D/'VALIDATION.json').read_text());assert all(r['exitCode']==0 for r in checks['commands'] if r['name']!='node');assert checks['correction']['exitCode']==0
metrics=json.loads((D/'METRICS.json').read_text());assert metrics['originalTargets']==dict(fpFixed=4,fnFixed=40,remaining=0)
acceptance=dict(task='043',status='done',decision='Passed',evaluator='Main agent acting as Evaluator; two independent reviewer identities',timestampUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseCommit='0a281e90d4e7e0402e2dd5d0aa19a7249c5373bf',branch='codex/quality-assessment-model',worktree='Uncommitted current changes; earlier work preserved',mandatoryRequirements=[dict(id='all-original-errors',status='Passed',evidence='REPAIRS.json',fpFixed=4,fnFixed=40,remaining=0),dict(id='frozen-oracle-and-history',status='Verified',evidence='FROZEN-EVIDENCE.json',unchangedFiles=343),dict(id='same-input-before-after',status='Verified',evidence=['METRICS.json','BEFORE-BASELINE-MATCH.json','FINAL-SOURCE-MATCH.json']),dict(id='independent-source-and-new-controls',status='Verified',evidence=['FINAL-quality.json','UPSTREAM-HASH-VERIFICATION.json'],scope='Original independent freeze preserved; metadata-only replay is not a new independent trial'),dict(id='positive-negative-boundary-security-compatibility',status='Passed',evidence='VALIDATION.json'),dict(id='implementation-review',status='Passed',evidence='IMPLEMENTATION-REVIEW-COMBINED-APPROVAL.json',unresolved=[]),dict(id='test-adequacy-review',status='Passed',evidence='TEST-REVIEW.md',unresolved=[])],historicalMetricSignals=dict(original57='Failed retained; independent source attribution of interval/unannotated/literal definition differences; no new product defect established',original042v2='Raw unannotated verification facts retained as FP2; supplemented only in a distinct audited corpus',releaseDecision='Unknown; no gate waiver/publication/release requested or performed'),requiredWorkOutstanding=[],deferredOriginalP1P2Fixes=[],reviews=review_files,historicalReviewerIndex=dict(path='reviewed-snapshot/EVIDENCE-INDEX.json',sha256=sha(H/'EVIDENCE-INDEX.json'),note='Review-time snapshot; original versions of two later-binding addenda retained alongside. Final packet manifest regenerated separately.'),publication='No commit/push/PR/merge/tag/release',scope='Completion of approved FP4/FN40 repairs within043; no claim of all Q1-Q6 or universal detection correctness')
(D/'ACCEPTANCE.json').write_text(json.dumps(acceptance,ensure_ascii=False,indent=2)+'\n')
p=R/'tasks/043-quality-detection-triage.yaml';s=p.read_text().replace('status: review','status: done',1).replace('owner: Reviewer Agent','owner: Evaluator Agent',1);s+='''fixes_execution_record:
  date: '2026-11-12'
  status: done
  base_commit: 0a281e90d4e7e0402e2dd5d0aa19a7249c5373bf
  branch: codex/quality-assessment-model
  scope: 追加承認されたP1/P2の元FP4件・FN40件を全件修正。別タスクへの延期なし。
  report: docs/quality/TASK-043-FIXES-RESULTS.md
  acceptance: docs/quality/task043-fixes-20261112/ACCEPTANCE.json
  validation: docs/quality/task043-fixes-20261112/VALIDATION.json
  repairs: docs/quality/task043-fixes-20261112/REPAIRS.json
  source: docs/quality/task043-fixes-20261112/FINAL-SOURCE-MATCH.json
  reviews: 実装と試験妥当性の各1名が承認。IR1〜4/TR1〜4未解消なし。
  original_targets_remaining: 0
  observed_corpus: 206ファイル255単位。適格197単位でTP103/FP0/FN0/TN94、Unsupported53/Ambiguous5を保持。
  old_metric_signal: 旧57単位のFailedと旧042-v2の未注釈FP2は履歴を保持。独立にソース帰属を確認し、品質ゲートは緩和しない。
  privacy_and_limits: 新経路の上限・Unicode位置・byte span・8成果物の合成credential秘匿を検証。
  publication: commit/push/PR/merge/tag/releaseは未実施。
''';p.write_text(s)
p=R/'docs/quality/TASK-043-FIXES-PLAN.md';s=p.read_text().replace('- [ ]','- [x]');s+='\n全必須条件を二段階レビューとEvaluatorが照合し、[受入記録](task043-fixes-20261112/ACCEPTANCE.json)に完了判定を保存しました。\n';p.write_text(s)
p=R/'docs/quality/QUALITY-ROADMAP.md';s=p.read_text().replace('043は2026-11-12の追加指示により、対応範囲内のFP4件・FN40件を全件修正・検証するタスクとして再開しました。','043は2026-11-12の追加指示により再開し、対応範囲内のFP4件・FN40件の全修正・検証・二段階レビューを終えてdoneとしました。');p.write_text(s)
p=R/'docs/quality/QUALITY-REQUIREMENTS.md';s=p.read_text().replace('実装・計測済み。44観測の解消、注釈補完、出典訂正、旧数値信号を分けて最終受入で照合する','44観測の修正・比較・二段階レビューを受入済み。注釈補完と出典訂正は別版で追跡し、旧数値信号を保持');p.write_text(s)
# The manifest is finalized after review artifacts and acceptance; it does not hash itself.
index={str(f.relative_to(D)):dict(sha256=sha(f),bytes=f.stat().st_size) for f in sorted(D.rglob('*')) if f.is_file() and f!=D/'EVIDENCE-INDEX.json'}
(D/'EVIDENCE-INDEX.json').write_text(json.dumps(index,indent=2)+'\n')
for name,v in index.items():assert sha(D/name)==v['sha256'] and (D/name).stat().st_size==v['bytes'],name
for name,h in json.loads((D/'FINAL-SOURCE.json').read_text()).items():assert sha(R/name)==h,name
for row in json.loads((D/'PRODUCT-DELTA.json').read_text())['files']:assert sha(R/row['path'])==row['afterSha256'],row['path']
print('TASK043 done;',len(index),'final packet bindings verified; 44/44 repaired; no required work outstanding.')
