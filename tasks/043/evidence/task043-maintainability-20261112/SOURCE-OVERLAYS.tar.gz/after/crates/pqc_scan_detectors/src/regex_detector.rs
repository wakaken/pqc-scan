use anyhow::Result;

use crate::comment_filter::should_skip_comment_only_match;
use pqc_scan_core::model::{line_col_for_offset, mask_preview, snippet_around};
use pqc_scan_core::{
    Detection, Detector, DetectorOutcome, DetectorStatus, Evidence, Location, ScannableFile,
};
use pqc_scan_rules::{RuleKind, RuleSet};

#[derive(Debug, Default)]
pub struct RegexDetector;

impl Detector for RegexDetector {
    fn name(&self) -> &'static str {
        "regex_detector"
    }

    fn detect(&self, file: &ScannableFile, rules: &RuleSet) -> Result<Vec<Detection>> {
        Ok(self.detect_detailed(file, rules)?.into_detections())
    }

    fn detect_detailed(&self, file: &ScannableFile, rules: &RuleSet) -> Result<DetectorOutcome> {
        self.detect_internal(file, rules, false)
    }
    fn detect_observed(&self, file: &ScannableFile, rules: &RuleSet) -> Result<DetectorOutcome> {
        self.detect_internal(file, rules, true)
    }
}
impl RegexDetector {
    fn detect_internal(
        &self,
        file: &ScannableFile,
        rules: &RuleSet,
        observe: bool,
    ) -> Result<DetectorOutcome> {
        let text = match file.text.as_ref() {
            Some(v) => v,
            None => {
                return Ok(DetectorOutcome::new(
                    Vec::new(),
                    DetectorStatus::NotApplicable,
                ))
            }
        };

        let mut observations = Vec::new();
        let mut out = Vec::new();
        let mut status = DetectorStatus::NotApplicable;
        let source_facts = crate::source_facts::for_regex(file, rules);

        for rule in rules.by_kind(RuleKind::Regex) {
            if status == DetectorStatus::NotApplicable {
                status = DetectorStatus::Complete;
            }
            if rule.id == "API_NODE_CRYPTO_SIGN_RSA" && crate::source_facts::builtin(rule) {
                if let Some(facts) = &source_facts {
                    if facts.status() != DetectorStatus::Complete
                        && (status != DetectorStatus::Truncated || facts.truncated)
                    {
                        status = facts.status();
                    }
                    for found in facts.rule_matches(rule).iter().take(33) {
                        if out
                            .iter()
                            .filter(|d: &&Detection| d.rule_id == rule.id)
                            .count()
                            == 32
                        {
                            status = DetectorStatus::Truncated;
                            break;
                        }
                        let (line, column) = line_col_for_offset(text, found.start);
                        let raw = &text[found.start..found.end];
                        let detection = Detection {
                            rule_id: rule.id.clone(),
                            location: Location {
                                file: file.path.to_string_lossy().into_owned(),
                                line,
                                column,
                            },
                            evidence: Evidence {
                                r#type: "regex_match".into(),
                                r#match: mask_preview(raw),
                                snippet_preview: snippet_around(text, found.start, found.end, 64),
                                metadata: std::collections::BTreeMap::from([
                                    ("detector".into(), self.name().into()),
                                    ("scope".into(), rule.scope.clone()),
                                    ("source_resolution".into(), found.reason.into()),
                                ]),
                            },
                        };
                        if observe {
                            observations.push(pqc_scan_core::ObservationDraft::source(
                                &detection,
                                pqc_scan_core::ObservationMethod::AstPattern,
                                raw,
                                Some((found.start, found.end)),
                            ));
                        }
                        out.push(detection);
                    }
                    continue;
                }
            }
            let regex = match rule.compiled_pattern() {
                Some(v) => v,
                None => {
                    if status != DetectorStatus::Truncated {
                        status = DetectorStatus::Partial;
                    }
                    continue;
                }
            };

            let mut accepted = 0;
            for (examined, found) in regex.find_iter(text).enumerate() {
                if examined >= crate::MAX_RULE_MATCH_CANDIDATES {
                    status = DetectorStatus::Truncated;
                    break;
                }
                if should_skip_comment_only_match(&file.path, text, found.start()) {
                    continue;
                }
                if accepted == 32 {
                    status = DetectorStatus::Truncated;
                    break;
                }
                let (line, column) = line_col_for_offset(text, found.start());
                out.push(Detection {
                    rule_id: rule.id.clone(),
                    location: Location {
                        file: file.path.to_string_lossy().into_owned(),
                        line,
                        column,
                    },
                    evidence: Evidence {
                        r#type: "regex_match".to_string(),
                        r#match: mask_preview(found.as_str()),
                        snippet_preview: snippet_around(text, found.start(), found.end(), 64),
                        metadata: std::collections::BTreeMap::from([
                            ("detector".to_string(), self.name().to_string()),
                            ("scope".to_string(), rule.scope.clone()),
                        ]),
                    },
                });
                if observe {
                    observations.push(pqc_scan_core::ObservationDraft::source(
                        out.last().expect("accepted detection"),
                        if rule.scope == "config" {
                            pqc_scan_core::ObservationMethod::Configuration
                        } else {
                            pqc_scan_core::ObservationMethod::LexicalMatch
                        },
                        found.as_str(),
                        Some((found.start(), found.end())),
                    ));
                }
                accepted += 1;
            }
        }

        Ok(DetectorOutcome::new(out, status).with_observations(observations))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use pqc_scan_rules::RuleSet;
    use std::fs;
    use std::path::PathBuf;
    use std::time::{SystemTime, UNIX_EPOCH};

    fn temp_dir(prefix: &str) -> PathBuf {
        let mut dir = std::env::temp_dir();
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        dir.push(format!("pqc-scan-{prefix}-{}-{nanos}", std::process::id()));
        fs::create_dir_all(&dir).expect("create temp dir");
        dir
    }

    fn regex_rules(pattern: &str) -> RuleSet {
        let dir = temp_dir("regex-rules");
        fs::write(
            dir.join("rules.yml"),
            format!(
                r#"
- id: TEST_REGEX
  kind: regex
  category: TLS
  severity: high
  risk: quantum-vulnerable
  confidence: 0.9
  migration_hint: Replace legacy crypto.
  pattern: "{pattern}"
  scope: code
"#
            ),
        )
        .expect("write rules");
        RuleSet::load_from_dir(&dir).expect("load rules")
    }

    #[test]
    fn detects_regex_match_with_location_and_metadata() {
        let detector = RegexDetector;
        let rules = regex_rules("RS256");
        let file = ScannableFile::from_bytes(
            PathBuf::from("src/app.js"),
            b"const alg = \"RS256\";\n".to_vec(),
        );

        let detections = detector.detect(&file, &rules).expect("detect");

        assert_eq!(detections.len(), 1);
        let detection = &detections[0];
        assert_eq!(detection.rule_id, "TEST_REGEX");
        assert_eq!(detection.location.file, "src/app.js");
        assert_eq!(detection.location.line, 1);
        assert_eq!(detection.location.column, 14);
        assert_eq!(detection.evidence.r#type, "regex_match");
        assert_eq!(detection.evidence.r#match, "RS256");
        assert_eq!(
            detection
                .evidence
                .metadata
                .get("detector")
                .map(String::as_str),
            Some("regex_detector")
        );
        assert_eq!(
            detection.evidence.metadata.get("scope").map(String::as_str),
            Some("code")
        );
    }

    #[test]
    fn skips_comment_only_matches_for_javascript() {
        let detector = RegexDetector;
        let rules = regex_rules("RS256");
        let file = ScannableFile::from_bytes(
            PathBuf::from("src/app.js"),
            b"// RS256 should not count\nconst alg = \"RS256\";\n/* RS256 block */\n".to_vec(),
        );

        let detections = detector.detect(&file, &rules).expect("detect");

        assert_eq!(detections.len(), 1);
        assert_eq!(detections[0].location.line, 2);
        assert_eq!(detections[0].location.column, 14);
        assert_eq!(detections[0].evidence.r#match, "RS256");
    }

    #[test]
    fn masks_private_key_like_matches_in_evidence_and_snippet() {
        let detector = RegexDetector;
        let rules = regex_rules("PRIVATE KEY");
        let file = ScannableFile::from_bytes(
            PathBuf::from("keys/sample.txt"),
            b"prefix -----BEGIN PRIVATE KEY----- suffix\n".to_vec(),
        );

        let detections = detector.detect(&file, &rules).expect("detect");

        assert_eq!(detections.len(), 1);
        assert_eq!(detections[0].evidence.r#match, "[masked-private-key]");
        assert_eq!(
            detections[0].evidence.snippet_preview,
            "[masked-private-key]"
        );
    }

    #[test]
    fn limits_matches_per_rule_to_thirty_two() {
        let detector = RegexDetector;
        let rules = regex_rules("RS256");
        let text = std::iter::repeat_n("RS256\n", 40).collect::<String>();
        let file = ScannableFile::from_bytes(PathBuf::from("fixtures/plain.txt"), text.into());

        let detections = detector.detect(&file, &rules).expect("detect");

        assert_eq!(detections.len(), 32);
        assert_eq!(detections.first().map(|d| d.location.line), Some(1));
        assert_eq!(detections.last().map(|d| d.location.line), Some(32));
    }
}
