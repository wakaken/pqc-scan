//! Local source facts for the explicitly supported built-in reference rules.
//! Unrelated/custom patterns retain the generic matching path.
mod context;
mod javascript;
mod python;
mod rust;
use context::Context;
use pqc_scan_core::{DetectorStatus, ScannableFile};
use pqc_scan_rules::{Rule, RuleSet};
use std::collections::HashMap;
use tree_sitter::Node;

#[derive(Clone, Debug)]
pub(crate) struct SourceMatch {
    pub start: usize,
    pub end: usize,
    pub reason: &'static str,
}
#[derive(Default)]
pub(crate) struct Facts {
    hits: HashMap<&'static str, Vec<SourceMatch>>,
    pub truncated: bool,
    pub partial: bool,
}
impl Facts {
    fn push(&mut self, id: &'static str, start: usize, end: usize, reason: &'static str) {
        if end.saturating_sub(start) > 8192 {
            self.truncated = true;
            return;
        }
        let hits = self.hits.entry(id).or_default();
        if hits.len() >= 4096 {
            self.truncated = true;
            return;
        }
        if start < end {
            hits.push(SourceMatch { start, end, reason });
        }
    }
    fn node(&mut self, id: &'static str, node: Node<'_>, reason: &'static str) {
        self.push(id, node.start_byte(), node.end_byte(), reason);
    }
    fn call(&mut self, id: &'static str, node: Node<'_>, reason: &'static str) {
        let Some(function) = node.child_by_field_name("function") else {
            return;
        };
        let end = if id == "PQC_RUST_API" {
            function.end_byte()
        } else {
            node.child_by_field_name("arguments")
                .and_then(|args| context::children(args).first().copied())
                .map_or(function.end_byte(), |arg| arg.end_byte())
        };
        self.push(id, node.start_byte(), end, reason);
    }
    pub fn rule_matches(&self, rule: &Rule) -> &[SourceMatch] {
        if !builtin(rule) {
            return &[];
        }
        self.hits.get(rule.id.as_str()).map_or(&[], Vec::as_slice)
    }
    pub fn replaces(&self, rule: &Rule) -> bool {
        builtin(rule)
            && matches!(
                rule.id.as_str(),
                "PQC_NODE_API" | "PQC_PYTHON_API" | "PQC_RUST_API" | "PQC_JAVA_API"
            )
    }
    pub fn status(&self) -> DetectorStatus {
        if self.truncated {
            DetectorStatus::Truncated
        } else if self.partial {
            DetectorStatus::Partial
        } else {
            DetectorStatus::Complete
        }
    }
}

// Exact source fingerprints bind enhanced semantics to these default patterns.
// Changing a custom rule's pattern never silently invokes a built-in predicate.
const PQC_JAVA_API: &str = r###"\b(?:KEM|Signature|KeyPairGenerator)\s*\.\s*getInstance\(\s*"(?:ML-KEM(?:-(?:512|768|1024))?|ML-DSA(?:-(?:44|65|87))?|SLH-DSA-(?:SHA2|SHAKE)-(?:128|192|256)[sf])""###;
const PQC_NODE_API: &str = r###"\bgenerateKeyPair(?:Sync)?\(\s*['"](?:ml-kem-(?:512|768|1024)|ml-dsa-(?:44|65|87)|slh-dsa-(?:sha2|shake)-(?:128|192|256)[sf])['"]"###;
const PQC_PYTHON_API: &str = r###"\b(?:mlkem\.)?MLKEM(?:768|1024)PrivateKey\.generate\(|\b(?:mldsa\.)?MLDSA(?:44|65|87)PrivateKey\.generate\("###;
const PQC_RUST_API: &str = r###"\b(?:ml_kem|ml_dsa|slh_dsa)::[A-Za-z][A-Za-z0-9_]*"###;
const TS_NODE_RSA_USAGE: &str = r###"(?i)(\b(createSign|createVerify)\s*\(\s*['"]RSA|\b(privateEncrypt|publicDecrypt)\s*\(|\b(RS|PS)(256|384|512)\b)"###;
const API_NODE_CRYPTO_SIGN_RSA: &str = r###"create(Sign|Verify)\(\s*['"]RSA"###;
pub(crate) fn builtin(rule: &Rule) -> bool {
    let pattern = match rule.id.as_str() {
        "PQC_NODE_API" => PQC_NODE_API,
        "PQC_JAVA_API" => PQC_JAVA_API,
        "PQC_PYTHON_API" => PQC_PYTHON_API,
        "PQC_RUST_API" => PQC_RUST_API,
        "TS_NODE_RSA_USAGE" => TS_NODE_RSA_USAGE,
        "API_NODE_CRYPTO_SIGN_RSA" => API_NODE_CRYPTO_SIGN_RSA,
        _ => return false,
    };
    let scope = match rule.id.as_str() {
        "PQC_JAVA_API" => "java",
        "PQC_PYTHON_API" => "python",
        "PQC_RUST_API" => "rust",
        "API_NODE_CRYPTO_SIGN_RSA" => "code",
        _ => "javascript,typescript",
    };
    let kind = if rule.id == "API_NODE_CRYPTO_SIGN_RSA" {
        pqc_scan_rules::RuleKind::Regex
    } else {
        pqc_scan_rules::RuleKind::TreeSitter
    };
    rule.pattern == pattern && rule.scope == scope && rule.kind == kind
}
pub(crate) fn inspect(root: Node<'_>, text: &str, language: &str, rules: &RuleSet) -> Facts {
    let mut facts = Facts {
        partial: root.has_error(),
        ..Facts::default()
    };
    let relevant: &[&str] = match language {
        "javascript" | "typescript" => &[
            "PQC_NODE_API",
            "TS_NODE_RSA_USAGE",
            "API_NODE_CRYPTO_SIGN_RSA",
        ],
        "python" => &["PQC_PYTHON_API"],
        "rust" => &["PQC_RUST_API"],
        "java" => &["PQC_JAVA_API"],
        _ => &[],
    };
    if !relevant.iter().any(|id| rules.get(id).is_some_and(builtin)) {
        return facts;
    }
    let mut context = Context::new(root, text, language);
    if context.truncated.get() {
        facts.truncated = true;
        return facts;
    }
    match language {
        "javascript" | "typescript" => javascript::inspect(&mut context, &mut facts),
        "python" => python::inspect(&mut context, &mut facts),
        "rust" => rust::inspect(&mut context, &mut facts),
        "java" => {
            if let Some(rule) = rules.get("PQC_JAVA_API").filter(|r| builtin(r)) {
                for node in &context.nodes {
                    if !matches!(node.kind(), "method_invocation" | "ERROR") {
                        continue;
                    }
                    let raw = context.source(*node);
                    let boundary = raw.char_indices().nth(2000).map_or(raw.len(), |(i, _)| i);
                    facts.truncated |= boundary < raw.len();
                    for hit in rule
                        .compiled_pattern()
                        .unwrap()
                        .find_iter(&raw[..boundary])
                        .take(4096)
                    {
                        let start = node.start_byte() + hit.start();
                        let embedded = text[..start]
                            .chars()
                            .next_back()
                            .is_some_and(|c| c.is_alphanumeric() || c == '_');
                        if context.code_at(start) && !embedded {
                            facts.push(
                                "PQC_JAVA_API",
                                start,
                                node.start_byte() + hit.end(),
                                if node.kind() == "ERROR" {
                                    "bounded_syntax_recovery"
                                } else {
                                    "explicit_api_request"
                                },
                            );
                        }
                    }
                }
            }
        }
        _ => {}
    }
    facts.truncated |= context.truncated.get();
    for (id, matches) in &mut facts.hits {
        if let Some(pattern) = rules
            .get(id)
            .filter(|r| builtin(r))
            .and_then(|r| r.compiled_pattern())
        {
            for hit in matches.iter_mut() {
                if let Some(original) = pattern
                    .find(&text[hit.start..hit.end])
                    .filter(|m| m.start() == 0)
                {
                    hit.end = hit.start + original.end();
                }
            }
        }
        matches.sort_by_key(|m| (m.start, m.end));
        matches.dedup_by_key(|m| m.start);
    }
    facts
}
pub(crate) fn for_regex(file: &ScannableFile, rules: &RuleSet) -> Option<Facts> {
    if !rules.get("API_NODE_CRYPTO_SIGN_RSA").is_some_and(builtin) {
        return None;
    }
    let (language, name) = crate::tree_sitter_detector::resolve_language(&file.path)?;
    if !matches!(name, "javascript" | "typescript") {
        return None;
    }
    let text = file.text.as_deref()?;
    let mut parser = tree_sitter::Parser::new();
    if parser.set_language(&language).is_err() {
        return Some(Facts {
            partial: true,
            ..Facts::default()
        });
    }
    let Some(tree) = parser.parse(text, None) else {
        return Some(Facts {
            partial: true,
            ..Facts::default()
        });
    };
    Some(inspect(tree.root_node(), text, name, rules))
}
