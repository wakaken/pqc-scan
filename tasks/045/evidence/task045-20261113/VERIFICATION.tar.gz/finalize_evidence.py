import hashlib,json,re,tarfile,subprocess
from pathlib import Path
base=Path('target/quality-task-045/run-20261113')
final=base/'sample-final-r2'
out=Path('docs/quality/task045-20261113')
out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
x=json.loads((final/'results.json').read_text())
h=json.loads((final/'HOST-RESULTS.json').read_text())
assert h['exit']==0 and h['containerRemoved'] and h['sourceBeforeAfterMatch']
assert len(x['mutations'])==20
controls=json.loads((final/'controls.json').read_text())
assert all(k==v['actual'] for k,v in controls.items())
report={'rawCounts':x['counts'],'rawScorePercent':x['scorePercent'],
        'equivalentMutations':['M20'],'nonEquivalentScore':{'caught':14,'missed':5,'denominator':19,'percent':100*14/19},
        'scope':'Linux aarch64, Rust1.93.1, all-features; fixed 20 mutations; not product-wide score',
        'unverified':'default-feature-only configuration, doctests, other platforms and unselected mutations',
        'sourceBeforeAfterMatch':True,'containerRemoved':True,'image':h['image'],'mutations':[],'baselines':{}}
for row in x['mutations']:
    failures=[]
    for log in sorted(final.glob(row['id']+'*-test-*.log')):
        failures+=re.findall(r'^test (.+) \.\.\. FAILED$',log.read_text(),re.M)
    report['mutations'].append(dict(row,failedTests=failures))
for prefix in ['baseline-workspace','restored-workspace']:
    totals={'passed':0,'failed':0,'ignored':0,'binaries':0}
    for log in final.glob(prefix+'-test-*.log'):
        states=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text())
        assert len(states)==1,(log,states)
        p,f,i=map(int,states[0]);totals['passed']+=p;totals['failed']+=f;totals['ignored']+=i;totals['binaries']+=1
    assert totals['failed']==0 and totals['passed']>0
    report['baselines'][prefix]=totals
assert x['counts']=={'caught':14,'missed':6,'timeout':0,'unviable':0},x['counts']
cmds=json.loads((final/'commands.json').read_text())
report['recordedCommandWallSeconds']=sum(c['wallSeconds'] for c in cmds)
report['recordedCommands']=len(cmds)
(out/'RESULTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
paths=['tests/quality/task045/study.py','tests/quality/task045/entry.py','tests/quality/task045/mutations.json','tests/quality/test_mutation045.py','tests/protocol/container_runner.py','tests/protocol/container_entry.py']
bindings={p:sha(p) for p in paths}
assert all(h['sourceBindings'][p]==digest for p,digest in bindings.items())
(out/'SOURCE.json').write_text(json.dumps({'baseHead':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'files':bindings,'scopeSha256':hashlib.sha256(json.dumps(bindings,sort_keys=True).encode()).hexdigest(),
    'productChanged':False,'preexistingUncommittedDocument':'docs/quality/TASK-044-RETIREMENT.md',
    'measurementSourceBindings':'VERIFICATION.tar.gz:sample-final-r2/HOST-RESULTS.json',
    'finalAdministrativeUpdates':'task status, review records, roadmap and result documentation are updated after measurement'},indent=2)+'\n')
with tarfile.open(out/'VERIFICATION.tar.gz','w:gz') as tar:
    for p in sorted(base.rglob('*')):
        if p.is_file():tar.add(p,arcname=str(p.relative_to(base)))
    for p in paths:tar.add(p,arcname='final-source/'+p)
print(json.dumps({k:v for k,v in report.items() if k not in ['mutations']},ensure_ascii=False,indent=2))
