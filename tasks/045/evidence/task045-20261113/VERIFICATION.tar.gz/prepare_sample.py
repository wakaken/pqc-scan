import json
from pathlib import Path
rows=[]
def add(group,path,old,new,meaning):
    p='crates/'+path
    assert Path(p).read_text().count(old)==1,(p,old)
    rows.append(dict(id=f'M{len(rows)+1:02}',group=group,path=p,old=old,new=new,meaning=meaning))
r='pqc_scan_core/src/risk.rs'
add('risk',r,'if rule.confidence < 0.45 {','if rule.confidence >= 0.45 {','高信頼と低信頼の昇格条件を反転')
add('risk',r,'if !sensitive_category {','if sensitive_category {','対象カテゴリの昇格条件を反転')
add('risk',r,'Severity::Info => Severity::Low,','Severity::Info => Severity::Info,','InfoからLowへの昇格を省略。044の未記録候補')
add('risk',r,'Severity::Low => Severity::Medium,','Severity::Low => Severity::Low,','LowからMediumへの昇格を省略。044の未記録候補')
r='pqc_scan_core/src/safe_read.rs'
add('read',r,'if bytes.len() > max {','if false {','読み取り後のサイズ超過拒否を省略')
add('read',r,'.take((max as u64).saturating_add(1))','.take(max as u64)','超過確認の1バイトを読まず切り詰めを成功扱い')
r='pqc_scan_core/src/pipeline.rs'
add('normalization',r,'if !dedup.insert(finding_id.clone()) {','if dedup.insert(finding_id.clone()) {','重複排除の条件を反転')
add('normalization',r,'line: detection.location.line,','line: 0,','正規化後の検出行を喪失')
add('normalization',r,'confidence: rule.confidence,','confidence: 0.0,','正規化後の確信度を喪失')
add('inspection',r,'D::ReadFailed => coverage.read_failed_files += 1,','D::ReadFailed => coverage.analyzed_files += 1,','読み取り失敗を解析成功として計上')
r='pqc_scan_core/src/diagnostic.rs'
add('inspection',r,'} else if self.unknown_files > 0 {','} else if false {','不明な検査を完了扱い')
add('inspection',r,'let incomplete = self.partial_files + self.unsupported_files;','let incomplete = 0;','部分検査と未対応を完了判定から除外')
r='pqc_scan_core/src/privacy.rs'
add('privacy',r,'return self.private_marker || !self.credentials.is_empty();','return false;','行不明時の保守的な秘匿を解除。044の未記録候補')
add('privacy',r,'if column == 0 {\n                return true;','if column == 0 {\n                return false;','列不明時の保守的な秘匿を解除。044の未記録候補')
add('privacy',r,'return Cow::Borrowed(PRIVATE);','return Cow::Borrowed(input);','秘密鍵マーカーを含むテキストの秘匿を解除')
r='pqc_scan_detectors/src/regex_detector.rs'
add('rule_matching',r,'if should_skip_comment_only_match(&file.path, text, start) {','if false {','コメント中の一致を誤って検出')
add('rule_matching',r,'if accepted == budget.max_hits_per_rule {','if accepted != budget.max_hits_per_rule {','検出件数上限の条件を反転')
add('rule_matching',r,'regex.find_iter(target) {','regex.find_iter(target).take(0) {','正規表現の一致を全て見落とす')
r='pqc_scan_detectors/src/certificate_detector/attributes.rs'
add('certificate',r,'out.key_bits = Some(bits);\n                        out.key_size_kind = "rsa_modulus";','out.key_bits = Some(bits + 1);\n                        out.key_size_kind = "rsa_modulus";','RSA鍵長を1ビット過大評価')
add('certificate',r,'if !rest.is_empty() {\n        return Err(PublicDerParseError);\n    }\n    certificate_attributes(&cert, der)','if false {\n        return Err(PublicDerParseError);\n    }\n    certificate_attributes(&cert, der)','証明書DER末尾の余剰データを許容')
Path('tests/quality/task045/mutations.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print(len(rows),sorted(set(r['group'] for r in rows)))
