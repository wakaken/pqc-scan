# Inventory comparison

This compares reported static records, not runtime security or completed PQC migration.

| Record set | Added | Removed | Changed | Unchanged | Unresolved |
|---|---:|---:|---:|---:|---:|
| Assets | 0 | 0 | 0 | 18 | 4 |
| Occurrences | 0 | 0 | 0 | 11 | 4 |

Metadata drift categories: 0. Heuristic move candidates: 0.

Missing-after records remain unresolved because inventory v1 cannot prove exhaustive inspection of that target. Added means newly present in the compared records. Move candidates do not merge identities. Removal would describe an observation set, never remediation of cryptographic risk. See scan.diff.v1.json for exact keys and reason codes.
