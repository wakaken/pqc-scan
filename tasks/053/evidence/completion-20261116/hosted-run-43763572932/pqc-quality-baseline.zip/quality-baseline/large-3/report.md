# PQC Migration Scan Report

Generated: 2026-11-15 21:26:54.732764112 UTC

Risk candidates: 544 / Inventory findings: 1120 / Scanned files: 1312

Cryptographic references found in source code and configuration.

|Severity|Count (all findings)|
|---|---:|
|critical|128|
|high|96|
|info|1120|
|low|32|
|medium|288|

## Risk candidate index

|Rule / description|Severity|Risk|Hits|Files|
|---|---|---|---:|---:|
|[CERT_RSA_1024](#rule-0) Certificate subject public key is 1024-bit RSA.|critical|non-quantum-risk|32|32|
|[CERT_RSA_SIGNATURE](#rule-1) Certificate signed with an RSA-based algorithm detected.|critical|quantum-vulnerable|64|64|
|[PRIVATE_KEY_PKCS8_HEADER](#rule-2) PKCS#8 private key header detected.|critical|non-quantum-risk|32|32|
|[API_SIGNATURE_RSA](#rule-3) RSA signature API usage detected.|high|quantum-vulnerable|32|32|
|[CERT_ECDSA_SIGNATURE](#rule-4) ECDSA certificate signature detected.|high|quantum-vulnerable|32|32|
|[TS_JAVA_RSA_API](#rule-5) RSA-related API symbols detected from Java AST.|high|quantum-vulnerable|32|32|
|[CERT_P12_CONTAINER](#rule-6) PKCS#12/PFX container file detected.|medium|quantum-uncertain|32|32|
|[DEP_OPENSSL](#rule-7) OpenSSL dependency detected.|medium|quantum-uncertain|32|32|
|[DEP_RUST_OPENSSL](#rule-8) Rust TLS/crypto dependency detected.|medium|quantum-uncertain|64|64|
|[PQC_DRAFT_ALGORITHM](#rule-9) Pre-standard PQC algorithm name referenced; check compatibility before replacing it.|medium|quantum-uncertain|32|32|
|[PQC_GO_TLS_DISABLED](#rule-10) Go hybrid TLS default explicitly disabled; inspect effective environment and group overrides.|medium|quantum-uncertain|32|32|
|[PQC_JAVA_CLASSICAL_GROUPS](#rule-11) Explicit classical-only Java property intent in assignment, XML entry or static System.setProperty; ...|medium|quantum-uncertain|64|64|
|[PQC_RUBY_CLASSICAL_GROUPS](#rule-12) Ruby-style group assignment explicitly restricts the recognized list to classical groups.|medium|quantum-uncertain|32|32|
|[CERT_PEM_CONTAINER](#rule-13) PEM/DER cryptographic container detected; certificate presence is not established.|low|quantum-uncertain|32|32|

## Informational inventory index

|Rule / description|Severity|Risk|Hits|Files|
|---|---|---|---:|---:|
|[DEP_PQC_CAPABLE_LIBRARY](#rule-14) Library with version-dependent PQC capabilities inventoried; capability is not an enabled-state find...|info|quantum-uncertain|96|96|
|[PQC_GO_API](#rule-15) Standard Go PQC package imported; import alone does not prove negotiated protection.|info|quantum-safe|32|32|
|[PQC_JAVA_API](#rule-16) Standard PQC algorithm requested through Java APIs; runtime success is not established.|info|quantum-safe|96|96|
|[PQC_NODE_API](#rule-17) Node-style PQC key generation call; bindings and actual execution require confirmation.|info|quantum-safe|160|128|
|[PQC_PYTHON_API](#rule-18) Python PQC key generation reference; backend support is not established.|info|quantum-safe|160|128|
|[PQC_RUBY_API](#rule-19) Ruby PQC algorithm literal referenced; key generation or signing success is not established.|info|quantum-safe|64|64|
|[PQC_RUST_API](#rule-20) Rust PQC crate symbol referenced; execution and protocol use require confirmation.|info|quantum-safe|32|32|
|[PQC_STANDARD_REFERENCE](#rule-21) Standard PQC algorithm or hybrid group name referenced; API execution, enabled state and conformance...|info|quantum-safe|416|384|
|[PQC_WEBCRYPTO_API](#rule-22) WebCrypto-style PQC algorithm request; this is not proof of browser support.|info|quantum-safe|64|64|

<a id="rule-0"></a>

## CERT_RSA_1024

Certificate subject public key is 1024-bit RSA.

Check: Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-0"></a>[copy-000/tuning/rsa1024.der:1:1](#finding-0)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-1"></a>[copy-001/tuning/rsa1024.der:1:1](#finding-1)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-2"></a>[copy-002/tuning/rsa1024.der:1:1](#finding-2)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-3"></a>[copy-003/tuning/rsa1024.der:1:1](#finding-3)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-4"></a>[copy-004/tuning/rsa1024.der:1:1](#finding-4)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-5"></a>[copy-005/tuning/rsa1024.der:1:1](#finding-5)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-6"></a>[copy-006/tuning/rsa1024.der:1:1](#finding-6)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-7"></a>[copy-007/tuning/rsa1024.der:1:1](#finding-7)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-8"></a>[copy-008/tuning/rsa1024.der:1:1](#finding-8)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-9"></a>[copy-009/tuning/rsa1024.der:1:1](#finding-9)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-10"></a>[copy-010/tuning/rsa1024.der:1:1](#finding-10)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-11"></a>[copy-011/tuning/rsa1024.der:1:1](#finding-11)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-12"></a>[copy-012/tuning/rsa1024.der:1:1](#finding-12)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-13"></a>[copy-013/tuning/rsa1024.der:1:1](#finding-13)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-14"></a>[copy-014/tuning/rsa1024.der:1:1](#finding-14)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-15"></a>[copy-015/tuning/rsa1024.der:1:1](#finding-15)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-16"></a>[copy-016/tuning/rsa1024.der:1:1](#finding-16)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-17"></a>[copy-017/tuning/rsa1024.der:1:1](#finding-17)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-18"></a>[copy-018/tuning/rsa1024.der:1:1](#finding-18)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-19"></a>[copy-019/tuning/rsa1024.der:1:1](#finding-19)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-20"></a>[copy-020/tuning/rsa1024.der:1:1](#finding-20)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-21"></a>[copy-021/tuning/rsa1024.der:1:1](#finding-21)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-22"></a>[copy-022/tuning/rsa1024.der:1:1](#finding-22)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-23"></a>[copy-023/tuning/rsa1024.der:1:1](#finding-23)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-24"></a>[copy-024/tuning/rsa1024.der:1:1](#finding-24)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-25"></a>[copy-025/tuning/rsa1024.der:1:1](#finding-25)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-26"></a>[copy-026/tuning/rsa1024.der:1:1](#finding-26)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-27"></a>[copy-027/tuning/rsa1024.der:1:1](#finding-27)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-28"></a>[copy-028/tuning/rsa1024.der:1:1](#finding-28)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-29"></a>[copy-029/tuning/rsa1024.der:1:1](#finding-29)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-30"></a>[copy-030/tuning/rsa1024.der:1:1](#finding-30)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|
|<a id="finding-31"></a>[copy-031/tuning/rsa1024.der:1:1](#finding-31)|RSA 1024-bit|Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Plan certificate algorithm and trust-store migration](#action-0)

<a id="rule-1"></a>

## CERT_RSA_SIGNATURE

Certificate signed with an RSA-based algorithm detected.

Check: Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-32"></a>[copy-000/tuning/p256-rsa-signed.der:1:1](#finding-32)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-33"></a>[copy-000/tuning/rsa1024.der:1:1](#finding-33)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-34"></a>[copy-001/tuning/p256-rsa-signed.der:1:1](#finding-34)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-35"></a>[copy-001/tuning/rsa1024.der:1:1](#finding-35)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-36"></a>[copy-002/tuning/p256-rsa-signed.der:1:1](#finding-36)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-37"></a>[copy-002/tuning/rsa1024.der:1:1](#finding-37)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-38"></a>[copy-003/tuning/p256-rsa-signed.der:1:1](#finding-38)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-39"></a>[copy-003/tuning/rsa1024.der:1:1](#finding-39)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-40"></a>[copy-004/tuning/p256-rsa-signed.der:1:1](#finding-40)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-41"></a>[copy-004/tuning/rsa1024.der:1:1](#finding-41)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-42"></a>[copy-005/tuning/p256-rsa-signed.der:1:1](#finding-42)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-43"></a>[copy-005/tuning/rsa1024.der:1:1](#finding-43)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-44"></a>[copy-006/tuning/p256-rsa-signed.der:1:1](#finding-44)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-45"></a>[copy-006/tuning/rsa1024.der:1:1](#finding-45)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-46"></a>[copy-007/tuning/p256-rsa-signed.der:1:1](#finding-46)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-47"></a>[copy-007/tuning/rsa1024.der:1:1](#finding-47)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-48"></a>[copy-008/tuning/p256-rsa-signed.der:1:1](#finding-48)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-49"></a>[copy-008/tuning/rsa1024.der:1:1](#finding-49)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-50"></a>[copy-009/tuning/p256-rsa-signed.der:1:1](#finding-50)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-51"></a>[copy-009/tuning/rsa1024.der:1:1](#finding-51)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-52"></a>[copy-010/tuning/p256-rsa-signed.der:1:1](#finding-52)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-53"></a>[copy-010/tuning/rsa1024.der:1:1](#finding-53)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-54"></a>[copy-011/tuning/p256-rsa-signed.der:1:1](#finding-54)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-55"></a>[copy-011/tuning/rsa1024.der:1:1](#finding-55)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-56"></a>[copy-012/tuning/p256-rsa-signed.der:1:1](#finding-56)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-57"></a>[copy-012/tuning/rsa1024.der:1:1](#finding-57)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-58"></a>[copy-013/tuning/p256-rsa-signed.der:1:1](#finding-58)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-59"></a>[copy-013/tuning/rsa1024.der:1:1](#finding-59)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-60"></a>[copy-014/tuning/p256-rsa-signed.der:1:1](#finding-60)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-61"></a>[copy-014/tuning/rsa1024.der:1:1](#finding-61)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-62"></a>[copy-015/tuning/p256-rsa-signed.der:1:1](#finding-62)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-63"></a>[copy-015/tuning/rsa1024.der:1:1](#finding-63)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-64"></a>[copy-016/tuning/p256-rsa-signed.der:1:1](#finding-64)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-65"></a>[copy-016/tuning/rsa1024.der:1:1](#finding-65)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-66"></a>[copy-017/tuning/p256-rsa-signed.der:1:1](#finding-66)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-67"></a>[copy-017/tuning/rsa1024.der:1:1](#finding-67)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-68"></a>[copy-018/tuning/p256-rsa-signed.der:1:1](#finding-68)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-69"></a>[copy-018/tuning/rsa1024.der:1:1](#finding-69)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-70"></a>[copy-019/tuning/p256-rsa-signed.der:1:1](#finding-70)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-71"></a>[copy-019/tuning/rsa1024.der:1:1](#finding-71)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-72"></a>[copy-020/tuning/p256-rsa-signed.der:1:1](#finding-72)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-73"></a>[copy-020/tuning/rsa1024.der:1:1](#finding-73)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-74"></a>[copy-021/tuning/p256-rsa-signed.der:1:1](#finding-74)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-75"></a>[copy-021/tuning/rsa1024.der:1:1](#finding-75)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-76"></a>[copy-022/tuning/p256-rsa-signed.der:1:1](#finding-76)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-77"></a>[copy-022/tuning/rsa1024.der:1:1](#finding-77)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-78"></a>[copy-023/tuning/p256-rsa-signed.der:1:1](#finding-78)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-79"></a>[copy-023/tuning/rsa1024.der:1:1](#finding-79)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-80"></a>[copy-024/tuning/p256-rsa-signed.der:1:1](#finding-80)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-81"></a>[copy-024/tuning/rsa1024.der:1:1](#finding-81)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-82"></a>[copy-025/tuning/p256-rsa-signed.der:1:1](#finding-82)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-83"></a>[copy-025/tuning/rsa1024.der:1:1](#finding-83)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-84"></a>[copy-026/tuning/p256-rsa-signed.der:1:1](#finding-84)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-85"></a>[copy-026/tuning/rsa1024.der:1:1](#finding-85)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-86"></a>[copy-027/tuning/p256-rsa-signed.der:1:1](#finding-86)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-87"></a>[copy-027/tuning/rsa1024.der:1:1](#finding-87)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-88"></a>[copy-028/tuning/p256-rsa-signed.der:1:1](#finding-88)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-89"></a>[copy-028/tuning/rsa1024.der:1:1](#finding-89)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-90"></a>[copy-029/tuning/p256-rsa-signed.der:1:1](#finding-90)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-91"></a>[copy-029/tuning/rsa1024.der:1:1](#finding-91)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-92"></a>[copy-030/tuning/p256-rsa-signed.der:1:1](#finding-92)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-93"></a>[copy-030/tuning/rsa1024.der:1:1](#finding-93)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-94"></a>[copy-031/tuning/p256-rsa-signed.der:1:1](#finding-94)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|
|<a id="finding-95"></a>[copy-031/tuning/rsa1024.der:1:1](#finding-95)|sha256WithRSAEncryption|Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-1)
- [Plan certificate algorithm and trust-store migration](#action-0)

<a id="rule-2"></a>

## PRIVATE_KEY_PKCS8_HEADER

PKCS#8 private key header detected.

Check: Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-96"></a>[copy-000/tuning/marker.pem:1:1](#finding-96)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-96)|
|<a id="finding-97"></a>[copy-001/tuning/marker.pem:1:1](#finding-97)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-97)|
|<a id="finding-98"></a>[copy-002/tuning/marker.pem:1:1](#finding-98)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-98)|
|<a id="finding-99"></a>[copy-003/tuning/marker.pem:1:1](#finding-99)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-99)|
|<a id="finding-100"></a>[copy-004/tuning/marker.pem:1:1](#finding-100)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-100)|
|<a id="finding-101"></a>[copy-005/tuning/marker.pem:1:1](#finding-101)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-101)|
|<a id="finding-102"></a>[copy-006/tuning/marker.pem:1:1](#finding-102)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-102)|
|<a id="finding-103"></a>[copy-007/tuning/marker.pem:1:1](#finding-103)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-103)|
|<a id="finding-104"></a>[copy-008/tuning/marker.pem:1:1](#finding-104)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-104)|
|<a id="finding-105"></a>[copy-009/tuning/marker.pem:1:1](#finding-105)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-105)|
|<a id="finding-106"></a>[copy-010/tuning/marker.pem:1:1](#finding-106)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-106)|
|<a id="finding-107"></a>[copy-011/tuning/marker.pem:1:1](#finding-107)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-107)|
|<a id="finding-108"></a>[copy-012/tuning/marker.pem:1:1](#finding-108)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-108)|
|<a id="finding-109"></a>[copy-013/tuning/marker.pem:1:1](#finding-109)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-109)|
|<a id="finding-110"></a>[copy-014/tuning/marker.pem:1:1](#finding-110)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-110)|
|<a id="finding-111"></a>[copy-015/tuning/marker.pem:1:1](#finding-111)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-111)|
|<a id="finding-112"></a>[copy-016/tuning/marker.pem:1:1](#finding-112)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-112)|
|<a id="finding-113"></a>[copy-017/tuning/marker.pem:1:1](#finding-113)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-113)|
|<a id="finding-114"></a>[copy-018/tuning/marker.pem:1:1](#finding-114)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-114)|
|<a id="finding-115"></a>[copy-019/tuning/marker.pem:1:1](#finding-115)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-115)|
|<a id="finding-116"></a>[copy-020/tuning/marker.pem:1:1](#finding-116)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-116)|
|<a id="finding-117"></a>[copy-021/tuning/marker.pem:1:1](#finding-117)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-117)|
|<a id="finding-118"></a>[copy-022/tuning/marker.pem:1:1](#finding-118)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-118)|
|<a id="finding-119"></a>[copy-023/tuning/marker.pem:1:1](#finding-119)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-119)|
|<a id="finding-120"></a>[copy-024/tuning/marker.pem:1:1](#finding-120)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-120)|
|<a id="finding-121"></a>[copy-025/tuning/marker.pem:1:1](#finding-121)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-121)|
|<a id="finding-122"></a>[copy-026/tuning/marker.pem:1:1](#finding-122)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-122)|
|<a id="finding-123"></a>[copy-027/tuning/marker.pem:1:1](#finding-123)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-123)|
|<a id="finding-124"></a>[copy-028/tuning/marker.pem:1:1](#finding-124)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-124)|
|<a id="finding-125"></a>[copy-029/tuning/marker.pem:1:1](#finding-125)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-125)|
|<a id="finding-126"></a>[copy-030/tuning/marker.pem:1:1](#finding-126)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-126)|
|<a id="finding-127"></a>[copy-031/tuning/marker.pem:1:1](#finding-127)|\[masked-private-key\]|Confirm whether complete live key material is present. If exposure is confirmed, revoke or rotate the affected credentials. / [Source](#source-127)|

Shared checks for these locations (not verified facts about each line):

- [Review private-key markers and rotate exposed live credentials](#action-2)

<a id="source-96"></a>

### copy-000/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-97"></a>

### copy-001/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-98"></a>

### copy-002/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-99"></a>

### copy-003/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-100"></a>

### copy-004/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-101"></a>

### copy-005/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-102"></a>

### copy-006/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-103"></a>

### copy-007/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-104"></a>

### copy-008/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-105"></a>

### copy-009/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-106"></a>

### copy-010/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-107"></a>

### copy-011/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-108"></a>

### copy-012/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-109"></a>

### copy-013/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-110"></a>

### copy-014/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-111"></a>

### copy-015/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-112"></a>

### copy-016/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-113"></a>

### copy-017/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-114"></a>

### copy-018/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-115"></a>

### copy-019/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-116"></a>

### copy-020/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-117"></a>

### copy-021/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-118"></a>

### copy-022/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-119"></a>

### copy-023/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-120"></a>

### copy-024/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-121"></a>

### copy-025/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-122"></a>

### copy-026/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-123"></a>

### copy-027/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-124"></a>

### copy-028/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-125"></a>

### copy-029/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-126"></a>

### copy-030/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="source-127"></a>

### copy-031/tuning/marker.pem:1:1

    > 1 [masked-private-key-material]

<a id="rule-3"></a>

## API_SIGNATURE_RSA

RSA signature API usage detected.

Check: Migrate to ML-DSA signing APIs.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-128"></a>[copy-000/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-128)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-128)|
|<a id="finding-129"></a>[copy-001/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-129)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-129)|
|<a id="finding-130"></a>[copy-002/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-130)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-130)|
|<a id="finding-131"></a>[copy-003/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-131)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-131)|
|<a id="finding-132"></a>[copy-004/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-132)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-132)|
|<a id="finding-133"></a>[copy-005/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-133)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-133)|
|<a id="finding-134"></a>[copy-006/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-134)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-134)|
|<a id="finding-135"></a>[copy-007/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-135)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-135)|
|<a id="finding-136"></a>[copy-008/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-136)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-136)|
|<a id="finding-137"></a>[copy-009/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-137)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-137)|
|<a id="finding-138"></a>[copy-010/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-138)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-138)|
|<a id="finding-139"></a>[copy-011/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-139)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-139)|
|<a id="finding-140"></a>[copy-012/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-140)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-140)|
|<a id="finding-141"></a>[copy-013/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-141)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-141)|
|<a id="finding-142"></a>[copy-014/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-142)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-142)|
|<a id="finding-143"></a>[copy-015/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-143)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-143)|
|<a id="finding-144"></a>[copy-016/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-144)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-144)|
|<a id="finding-145"></a>[copy-017/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-145)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-145)|
|<a id="finding-146"></a>[copy-018/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-146)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-146)|
|<a id="finding-147"></a>[copy-019/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-147)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-147)|
|<a id="finding-148"></a>[copy-020/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-148)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-148)|
|<a id="finding-149"></a>[copy-021/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-149)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-149)|
|<a id="finding-150"></a>[copy-022/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-150)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-150)|
|<a id="finding-151"></a>[copy-023/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-151)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-151)|
|<a id="finding-152"></a>[copy-024/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-152)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-152)|
|<a id="finding-153"></a>[copy-025/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-153)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-153)|
|<a id="finding-154"></a>[copy-026/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-154)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-154)|
|<a id="finding-155"></a>[copy-027/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-155)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-155)|
|<a id="finding-156"></a>[copy-028/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-156)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-156)|
|<a id="finding-157"></a>[copy-029/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-157)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-157)|
|<a id="finding-158"></a>[copy-030/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-158)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-158)|
|<a id="finding-159"></a>[copy-031/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-159)|Signatur***thRSA"|Migrate to ML-DSA signing APIs. / [Source](#source-159)|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-1)
- [Check Java runtime baseline for standard PQC APIs](#action-3)
- [Provide BouncyCastle PQC fallback path](#action-4)
- [Verify deployed runtime and protocol PQC capabilities](#action-5)

<a id="source-128"></a>

### copy-000/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-129"></a>

### copy-001/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-130"></a>

### copy-002/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-131"></a>

### copy-003/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-132"></a>

### copy-004/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-133"></a>

### copy-005/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-134"></a>

### copy-006/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-135"></a>

### copy-007/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-136"></a>

### copy-008/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-137"></a>

### copy-009/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-138"></a>

### copy-010/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-139"></a>

### copy-011/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-140"></a>

### copy-012/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-141"></a>

### copy-013/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-142"></a>

### copy-014/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-143"></a>

### copy-015/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-144"></a>

### copy-016/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-145"></a>

### copy-017/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-146"></a>

### copy-018/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-147"></a>

### copy-019/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-148"></a>

### copy-020/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-149"></a>

### copy-021/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-150"></a>

### copy-022/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-151"></a>

### copy-023/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-152"></a>

### copy-024/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-153"></a>

### copy-025/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-154"></a>

### copy-026/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-155"></a>

### copy-027/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-156"></a>

### copy-028/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-157"></a>

### copy-029/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-158"></a>

### copy-030/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-159"></a>

### copy-031/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="rule-4"></a>

## CERT_ECDSA_SIGNATURE

ECDSA certificate signature detected.

Check: Evaluate ML-DSA and SLH-DSA alternatives.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-160"></a>[copy-000/tuning/p521.der:1:1](#finding-160)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-161"></a>[copy-001/tuning/p521.der:1:1](#finding-161)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-162"></a>[copy-002/tuning/p521.der:1:1](#finding-162)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-163"></a>[copy-003/tuning/p521.der:1:1](#finding-163)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-164"></a>[copy-004/tuning/p521.der:1:1](#finding-164)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-165"></a>[copy-005/tuning/p521.der:1:1](#finding-165)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-166"></a>[copy-006/tuning/p521.der:1:1](#finding-166)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-167"></a>[copy-007/tuning/p521.der:1:1](#finding-167)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-168"></a>[copy-008/tuning/p521.der:1:1](#finding-168)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-169"></a>[copy-009/tuning/p521.der:1:1](#finding-169)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-170"></a>[copy-010/tuning/p521.der:1:1](#finding-170)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-171"></a>[copy-011/tuning/p521.der:1:1](#finding-171)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-172"></a>[copy-012/tuning/p521.der:1:1](#finding-172)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-173"></a>[copy-013/tuning/p521.der:1:1](#finding-173)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-174"></a>[copy-014/tuning/p521.der:1:1](#finding-174)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-175"></a>[copy-015/tuning/p521.der:1:1](#finding-175)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-176"></a>[copy-016/tuning/p521.der:1:1](#finding-176)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-177"></a>[copy-017/tuning/p521.der:1:1](#finding-177)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-178"></a>[copy-018/tuning/p521.der:1:1](#finding-178)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-179"></a>[copy-019/tuning/p521.der:1:1](#finding-179)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-180"></a>[copy-020/tuning/p521.der:1:1](#finding-180)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-181"></a>[copy-021/tuning/p521.der:1:1](#finding-181)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-182"></a>[copy-022/tuning/p521.der:1:1](#finding-182)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-183"></a>[copy-023/tuning/p521.der:1:1](#finding-183)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-184"></a>[copy-024/tuning/p521.der:1:1](#finding-184)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-185"></a>[copy-025/tuning/p521.der:1:1](#finding-185)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-186"></a>[copy-026/tuning/p521.der:1:1](#finding-186)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-187"></a>[copy-027/tuning/p521.der:1:1](#finding-187)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-188"></a>[copy-028/tuning/p521.der:1:1](#finding-188)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-189"></a>[copy-029/tuning/p521.der:1:1](#finding-189)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-190"></a>[copy-030/tuning/p521.der:1:1](#finding-190)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|
|<a id="finding-191"></a>[copy-031/tuning/p521.der:1:1](#finding-191)|ecdsa-with-SHA256|Evaluate ML-DSA and SLH-DSA alternatives. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Adopt a phased hybrid PQC migration plan](#action-1)
- [Plan certificate algorithm and trust-store migration](#action-0)

<a id="rule-5"></a>

## TS_JAVA_RSA_API

RSA-related API symbols detected from Java AST.

Check: Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-192"></a>[copy-000/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-192)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-192)|
|<a id="finding-193"></a>[copy-001/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-193)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-193)|
|<a id="finding-194"></a>[copy-002/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-194)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-194)|
|<a id="finding-195"></a>[copy-003/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-195)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-195)|
|<a id="finding-196"></a>[copy-004/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-196)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-196)|
|<a id="finding-197"></a>[copy-005/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-197)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-197)|
|<a id="finding-198"></a>[copy-006/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-198)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-198)|
|<a id="finding-199"></a>[copy-007/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-199)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-199)|
|<a id="finding-200"></a>[copy-008/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-200)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-200)|
|<a id="finding-201"></a>[copy-009/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-201)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-201)|
|<a id="finding-202"></a>[copy-010/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-202)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-202)|
|<a id="finding-203"></a>[copy-011/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-203)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-203)|
|<a id="finding-204"></a>[copy-012/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-204)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-204)|
|<a id="finding-205"></a>[copy-013/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-205)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-205)|
|<a id="finding-206"></a>[copy-014/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-206)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-206)|
|<a id="finding-207"></a>[copy-015/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-207)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-207)|
|<a id="finding-208"></a>[copy-016/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-208)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-208)|
|<a id="finding-209"></a>[copy-017/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-209)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-209)|
|<a id="finding-210"></a>[copy-018/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-210)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-210)|
|<a id="finding-211"></a>[copy-019/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-211)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-211)|
|<a id="finding-212"></a>[copy-020/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-212)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-212)|
|<a id="finding-213"></a>[copy-021/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-213)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-213)|
|<a id="finding-214"></a>[copy-022/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-214)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-214)|
|<a id="finding-215"></a>[copy-023/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-215)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-215)|
|<a id="finding-216"></a>[copy-024/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-216)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-216)|
|<a id="finding-217"></a>[copy-025/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-217)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-217)|
|<a id="finding-218"></a>[copy-026/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-218)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-218)|
|<a id="finding-219"></a>[copy-027/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-219)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-219)|
|<a id="finding-220"></a>[copy-028/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-220)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-220)|
|<a id="finding-221"></a>[copy-029/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-221)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-221)|
|<a id="finding-222"></a>[copy-030/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-222)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-222)|
|<a id="finding-223"></a>[copy-031/holdout/approval-adapter/ApprovalEnvelope.java:11:30](#finding-223)|Signatur***ithRSA|Review the Java RSA reference, provider and any existing PQC composition before selecting compatible migration changes. / [Source](#source-223)|

Shared checks for these locations (not verified facts about each line):

- [Review the cryptographic reference and its actual purpose](#action-6)

<a id="source-192"></a>

### copy-000/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-193"></a>

### copy-001/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-194"></a>

### copy-002/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-195"></a>

### copy-003/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-196"></a>

### copy-004/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-197"></a>

### copy-005/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-198"></a>

### copy-006/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-199"></a>

### copy-007/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-200"></a>

### copy-008/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-201"></a>

### copy-009/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-202"></a>

### copy-010/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-203"></a>

### copy-011/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-204"></a>

### copy-012/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-205"></a>

### copy-013/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-206"></a>

### copy-014/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-207"></a>

### copy-015/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-208"></a>

### copy-016/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-209"></a>

### copy-017/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-210"></a>

### copy-018/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-211"></a>

### copy-019/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-212"></a>

### copy-020/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-213"></a>

### copy-021/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-214"></a>

### copy-022/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-215"></a>

### copy-023/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-216"></a>

### copy-024/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-217"></a>

### copy-025/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-218"></a>

### copy-026/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-219"></a>

### copy-027/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-220"></a>

### copy-028/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-221"></a>

### copy-029/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-222"></a>

### copy-030/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="source-223"></a>

### copy-031/holdout/approval-adapter/ApprovalEnvelope.java:11:30

      9 
      10     Object archivedApprovalVerifier() throws Exception {
    > 11         return java.security.Signature.getInstance(
      12             "SHA256withRSA"
      13         );

<a id="rule-6"></a>

## CERT_P12_CONTAINER

PKCS#12/PFX container file detected.

Check: Audit algorithms used inside PKCS#12/PFX containers.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-224"></a>[copy-000/holdout/unsupported.p12:1:1](#finding-224)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-225"></a>[copy-001/holdout/unsupported.p12:1:1](#finding-225)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-226"></a>[copy-002/holdout/unsupported.p12:1:1](#finding-226)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-227"></a>[copy-003/holdout/unsupported.p12:1:1](#finding-227)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-228"></a>[copy-004/holdout/unsupported.p12:1:1](#finding-228)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-229"></a>[copy-005/holdout/unsupported.p12:1:1](#finding-229)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-230"></a>[copy-006/holdout/unsupported.p12:1:1](#finding-230)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-231"></a>[copy-007/holdout/unsupported.p12:1:1](#finding-231)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-232"></a>[copy-008/holdout/unsupported.p12:1:1](#finding-232)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-233"></a>[copy-009/holdout/unsupported.p12:1:1](#finding-233)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-234"></a>[copy-010/holdout/unsupported.p12:1:1](#finding-234)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-235"></a>[copy-011/holdout/unsupported.p12:1:1](#finding-235)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-236"></a>[copy-012/holdout/unsupported.p12:1:1](#finding-236)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-237"></a>[copy-013/holdout/unsupported.p12:1:1](#finding-237)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-238"></a>[copy-014/holdout/unsupported.p12:1:1](#finding-238)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-239"></a>[copy-015/holdout/unsupported.p12:1:1](#finding-239)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-240"></a>[copy-016/holdout/unsupported.p12:1:1](#finding-240)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-241"></a>[copy-017/holdout/unsupported.p12:1:1](#finding-241)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-242"></a>[copy-018/holdout/unsupported.p12:1:1](#finding-242)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-243"></a>[copy-019/holdout/unsupported.p12:1:1](#finding-243)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-244"></a>[copy-020/holdout/unsupported.p12:1:1](#finding-244)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-245"></a>[copy-021/holdout/unsupported.p12:1:1](#finding-245)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-246"></a>[copy-022/holdout/unsupported.p12:1:1](#finding-246)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-247"></a>[copy-023/holdout/unsupported.p12:1:1](#finding-247)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-248"></a>[copy-024/holdout/unsupported.p12:1:1](#finding-248)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-249"></a>[copy-025/holdout/unsupported.p12:1:1](#finding-249)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-250"></a>[copy-026/holdout/unsupported.p12:1:1](#finding-250)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-251"></a>[copy-027/holdout/unsupported.p12:1:1](#finding-251)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-252"></a>[copy-028/holdout/unsupported.p12:1:1](#finding-252)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-253"></a>[copy-029/holdout/unsupported.p12:1:1](#finding-253)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-254"></a>[copy-030/holdout/unsupported.p12:1:1](#finding-254)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|
|<a id="finding-255"></a>[copy-031/holdout/unsupported.p12:1:1](#finding-255)|unsupported.p12|Audit algorithms used inside PKCS#12/PFX containers. / Source unavailable|

Shared checks for these locations (not verified facts about each line):

- [Plan certificate algorithm and trust-store migration](#action-0)

<a id="rule-7"></a>

## DEP_OPENSSL

OpenSSL dependency detected.

Check: Review the OpenSSL PQC roadmap.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-256"></a>[copy-000/holdout/sbom.json (line unavailable)](#finding-256)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-256)|
|<a id="finding-257"></a>[copy-001/holdout/sbom.json (line unavailable)](#finding-257)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-257)|
|<a id="finding-258"></a>[copy-002/holdout/sbom.json (line unavailable)](#finding-258)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-258)|
|<a id="finding-259"></a>[copy-003/holdout/sbom.json (line unavailable)](#finding-259)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-259)|
|<a id="finding-260"></a>[copy-004/holdout/sbom.json (line unavailable)](#finding-260)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-260)|
|<a id="finding-261"></a>[copy-005/holdout/sbom.json (line unavailable)](#finding-261)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-261)|
|<a id="finding-262"></a>[copy-006/holdout/sbom.json (line unavailable)](#finding-262)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-262)|
|<a id="finding-263"></a>[copy-007/holdout/sbom.json (line unavailable)](#finding-263)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-263)|
|<a id="finding-264"></a>[copy-008/holdout/sbom.json (line unavailable)](#finding-264)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-264)|
|<a id="finding-265"></a>[copy-009/holdout/sbom.json (line unavailable)](#finding-265)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-265)|
|<a id="finding-266"></a>[copy-010/holdout/sbom.json (line unavailable)](#finding-266)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-266)|
|<a id="finding-267"></a>[copy-011/holdout/sbom.json (line unavailable)](#finding-267)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-267)|
|<a id="finding-268"></a>[copy-012/holdout/sbom.json (line unavailable)](#finding-268)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-268)|
|<a id="finding-269"></a>[copy-013/holdout/sbom.json (line unavailable)](#finding-269)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-269)|
|<a id="finding-270"></a>[copy-014/holdout/sbom.json (line unavailable)](#finding-270)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-270)|
|<a id="finding-271"></a>[copy-015/holdout/sbom.json (line unavailable)](#finding-271)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-271)|
|<a id="finding-272"></a>[copy-016/holdout/sbom.json (line unavailable)](#finding-272)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-272)|
|<a id="finding-273"></a>[copy-017/holdout/sbom.json (line unavailable)](#finding-273)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-273)|
|<a id="finding-274"></a>[copy-018/holdout/sbom.json (line unavailable)](#finding-274)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-274)|
|<a id="finding-275"></a>[copy-019/holdout/sbom.json (line unavailable)](#finding-275)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-275)|
|<a id="finding-276"></a>[copy-020/holdout/sbom.json (line unavailable)](#finding-276)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-276)|
|<a id="finding-277"></a>[copy-021/holdout/sbom.json (line unavailable)](#finding-277)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-277)|
|<a id="finding-278"></a>[copy-022/holdout/sbom.json (line unavailable)](#finding-278)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-278)|
|<a id="finding-279"></a>[copy-023/holdout/sbom.json (line unavailable)](#finding-279)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-279)|
|<a id="finding-280"></a>[copy-024/holdout/sbom.json (line unavailable)](#finding-280)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-280)|
|<a id="finding-281"></a>[copy-025/holdout/sbom.json (line unavailable)](#finding-281)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-281)|
|<a id="finding-282"></a>[copy-026/holdout/sbom.json (line unavailable)](#finding-282)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-282)|
|<a id="finding-283"></a>[copy-027/holdout/sbom.json (line unavailable)](#finding-283)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-283)|
|<a id="finding-284"></a>[copy-028/holdout/sbom.json (line unavailable)](#finding-284)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-284)|
|<a id="finding-285"></a>[copy-029/holdout/sbom.json (line unavailable)](#finding-285)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-285)|
|<a id="finding-286"></a>[copy-030/holdout/sbom.json (line unavailable)](#finding-286)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-286)|
|<a id="finding-287"></a>[copy-031/holdout/sbom.json (line unavailable)](#finding-287)|openssl@1.1.1|Review the OpenSSL PQC roadmap. / [Source](#source-287)|

Shared checks for these locations (not verified facts about each line):

- [Track PQC readiness of dependent libraries](#action-7)

<a id="source-256"></a>

### copy-000/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-257"></a>

### copy-001/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-258"></a>

### copy-002/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-259"></a>

### copy-003/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-260"></a>

### copy-004/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-261"></a>

### copy-005/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-262"></a>

### copy-006/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-263"></a>

### copy-007/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-264"></a>

### copy-008/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-265"></a>

### copy-009/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-266"></a>

### copy-010/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-267"></a>

### copy-011/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-268"></a>

### copy-012/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-269"></a>

### copy-013/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-270"></a>

### copy-014/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-271"></a>

### copy-015/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-272"></a>

### copy-016/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-273"></a>

### copy-017/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-274"></a>

### copy-018/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-275"></a>

### copy-019/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-276"></a>

### copy-020/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-277"></a>

### copy-021/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-278"></a>

### copy-022/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-279"></a>

### copy-023/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-280"></a>

### copy-024/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-281"></a>

### copy-025/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-282"></a>

### copy-026/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-283"></a>

### copy-027/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-284"></a>

### copy-028/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-285"></a>

### copy-029/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-286"></a>

### copy-030/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-287"></a>

### copy-031/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="rule-8"></a>

## DEP_RUST_OPENSSL

Rust TLS/crypto dependency detected.

Check: Track PQC migration options for Rust openssl/rustls crypto stacks.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-288"></a>[copy-000/holdout/sbom.json (line unavailable)](#finding-288)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-288)|
|<a id="finding-289"></a>[copy-000/tuning/Cargo.toml:3:1](#finding-289)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-289)|
|<a id="finding-290"></a>[copy-001/holdout/sbom.json (line unavailable)](#finding-290)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-290)|
|<a id="finding-291"></a>[copy-001/tuning/Cargo.toml:3:1](#finding-291)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-291)|
|<a id="finding-292"></a>[copy-002/holdout/sbom.json (line unavailable)](#finding-292)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-292)|
|<a id="finding-293"></a>[copy-002/tuning/Cargo.toml:3:1](#finding-293)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-293)|
|<a id="finding-294"></a>[copy-003/holdout/sbom.json (line unavailable)](#finding-294)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-294)|
|<a id="finding-295"></a>[copy-003/tuning/Cargo.toml:3:1](#finding-295)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-295)|
|<a id="finding-296"></a>[copy-004/holdout/sbom.json (line unavailable)](#finding-296)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-296)|
|<a id="finding-297"></a>[copy-004/tuning/Cargo.toml:3:1](#finding-297)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-297)|
|<a id="finding-298"></a>[copy-005/holdout/sbom.json (line unavailable)](#finding-298)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-298)|
|<a id="finding-299"></a>[copy-005/tuning/Cargo.toml:3:1](#finding-299)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-299)|
|<a id="finding-300"></a>[copy-006/holdout/sbom.json (line unavailable)](#finding-300)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-300)|
|<a id="finding-301"></a>[copy-006/tuning/Cargo.toml:3:1](#finding-301)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-301)|
|<a id="finding-302"></a>[copy-007/holdout/sbom.json (line unavailable)](#finding-302)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-302)|
|<a id="finding-303"></a>[copy-007/tuning/Cargo.toml:3:1](#finding-303)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-303)|
|<a id="finding-304"></a>[copy-008/holdout/sbom.json (line unavailable)](#finding-304)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-304)|
|<a id="finding-305"></a>[copy-008/tuning/Cargo.toml:3:1](#finding-305)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-305)|
|<a id="finding-306"></a>[copy-009/holdout/sbom.json (line unavailable)](#finding-306)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-306)|
|<a id="finding-307"></a>[copy-009/tuning/Cargo.toml:3:1](#finding-307)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-307)|
|<a id="finding-308"></a>[copy-010/holdout/sbom.json (line unavailable)](#finding-308)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-308)|
|<a id="finding-309"></a>[copy-010/tuning/Cargo.toml:3:1](#finding-309)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-309)|
|<a id="finding-310"></a>[copy-011/holdout/sbom.json (line unavailable)](#finding-310)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-310)|
|<a id="finding-311"></a>[copy-011/tuning/Cargo.toml:3:1](#finding-311)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-311)|
|<a id="finding-312"></a>[copy-012/holdout/sbom.json (line unavailable)](#finding-312)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-312)|
|<a id="finding-313"></a>[copy-012/tuning/Cargo.toml:3:1](#finding-313)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-313)|
|<a id="finding-314"></a>[copy-013/holdout/sbom.json (line unavailable)](#finding-314)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-314)|
|<a id="finding-315"></a>[copy-013/tuning/Cargo.toml:3:1](#finding-315)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-315)|
|<a id="finding-316"></a>[copy-014/holdout/sbom.json (line unavailable)](#finding-316)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-316)|
|<a id="finding-317"></a>[copy-014/tuning/Cargo.toml:3:1](#finding-317)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-317)|
|<a id="finding-318"></a>[copy-015/holdout/sbom.json (line unavailable)](#finding-318)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-318)|
|<a id="finding-319"></a>[copy-015/tuning/Cargo.toml:3:1](#finding-319)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-319)|
|<a id="finding-320"></a>[copy-016/holdout/sbom.json (line unavailable)](#finding-320)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-320)|
|<a id="finding-321"></a>[copy-016/tuning/Cargo.toml:3:1](#finding-321)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-321)|
|<a id="finding-322"></a>[copy-017/holdout/sbom.json (line unavailable)](#finding-322)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-322)|
|<a id="finding-323"></a>[copy-017/tuning/Cargo.toml:3:1](#finding-323)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-323)|
|<a id="finding-324"></a>[copy-018/holdout/sbom.json (line unavailable)](#finding-324)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-324)|
|<a id="finding-325"></a>[copy-018/tuning/Cargo.toml:3:1](#finding-325)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-325)|
|<a id="finding-326"></a>[copy-019/holdout/sbom.json (line unavailable)](#finding-326)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-326)|
|<a id="finding-327"></a>[copy-019/tuning/Cargo.toml:3:1](#finding-327)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-327)|
|<a id="finding-328"></a>[copy-020/holdout/sbom.json (line unavailable)](#finding-328)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-328)|
|<a id="finding-329"></a>[copy-020/tuning/Cargo.toml:3:1](#finding-329)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-329)|
|<a id="finding-330"></a>[copy-021/holdout/sbom.json (line unavailable)](#finding-330)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-330)|
|<a id="finding-331"></a>[copy-021/tuning/Cargo.toml:3:1](#finding-331)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-331)|
|<a id="finding-332"></a>[copy-022/holdout/sbom.json (line unavailable)](#finding-332)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-332)|
|<a id="finding-333"></a>[copy-022/tuning/Cargo.toml:3:1](#finding-333)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-333)|
|<a id="finding-334"></a>[copy-023/holdout/sbom.json (line unavailable)](#finding-334)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-334)|
|<a id="finding-335"></a>[copy-023/tuning/Cargo.toml:3:1](#finding-335)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-335)|
|<a id="finding-336"></a>[copy-024/holdout/sbom.json (line unavailable)](#finding-336)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-336)|
|<a id="finding-337"></a>[copy-024/tuning/Cargo.toml:3:1](#finding-337)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-337)|
|<a id="finding-338"></a>[copy-025/holdout/sbom.json (line unavailable)](#finding-338)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-338)|
|<a id="finding-339"></a>[copy-025/tuning/Cargo.toml:3:1](#finding-339)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-339)|
|<a id="finding-340"></a>[copy-026/holdout/sbom.json (line unavailable)](#finding-340)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-340)|
|<a id="finding-341"></a>[copy-026/tuning/Cargo.toml:3:1](#finding-341)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-341)|
|<a id="finding-342"></a>[copy-027/holdout/sbom.json (line unavailable)](#finding-342)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-342)|
|<a id="finding-343"></a>[copy-027/tuning/Cargo.toml:3:1](#finding-343)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-343)|
|<a id="finding-344"></a>[copy-028/holdout/sbom.json (line unavailable)](#finding-344)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-344)|
|<a id="finding-345"></a>[copy-028/tuning/Cargo.toml:3:1](#finding-345)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-345)|
|<a id="finding-346"></a>[copy-029/holdout/sbom.json (line unavailable)](#finding-346)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-346)|
|<a id="finding-347"></a>[copy-029/tuning/Cargo.toml:3:1](#finding-347)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-347)|
|<a id="finding-348"></a>[copy-030/holdout/sbom.json (line unavailable)](#finding-348)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-348)|
|<a id="finding-349"></a>[copy-030/tuning/Cargo.toml:3:1](#finding-349)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-349)|
|<a id="finding-350"></a>[copy-031/holdout/sbom.json (line unavailable)](#finding-350)|openssl@1.1.1|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-350)|
|<a id="finding-351"></a>[copy-031/tuning/Cargo.toml:3:1](#finding-351)|my-rustl***er@1.0|Track PQC migration options for Rust openssl/rustls crypto stacks. / [Source](#source-351)|

Shared checks for these locations (not verified facts about each line):

- [Track PQC readiness of dependent libraries](#action-7)

<a id="source-288"></a>

### copy-000/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-289"></a>

### copy-000/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-290"></a>

### copy-001/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-291"></a>

### copy-001/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-292"></a>

### copy-002/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-293"></a>

### copy-002/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-294"></a>

### copy-003/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-295"></a>

### copy-003/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-296"></a>

### copy-004/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-297"></a>

### copy-004/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-298"></a>

### copy-005/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-299"></a>

### copy-005/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-300"></a>

### copy-006/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-301"></a>

### copy-006/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-302"></a>

### copy-007/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-303"></a>

### copy-007/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-304"></a>

### copy-008/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-305"></a>

### copy-008/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-306"></a>

### copy-009/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-307"></a>

### copy-009/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-308"></a>

### copy-010/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-309"></a>

### copy-010/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-310"></a>

### copy-011/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-311"></a>

### copy-011/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-312"></a>

### copy-012/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-313"></a>

### copy-012/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-314"></a>

### copy-013/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-315"></a>

### copy-013/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-316"></a>

### copy-014/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-317"></a>

### copy-014/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-318"></a>

### copy-015/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-319"></a>

### copy-015/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-320"></a>

### copy-016/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-321"></a>

### copy-016/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-322"></a>

### copy-017/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-323"></a>

### copy-017/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-324"></a>

### copy-018/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-325"></a>

### copy-018/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-326"></a>

### copy-019/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-327"></a>

### copy-019/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-328"></a>

### copy-020/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-329"></a>

### copy-020/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-330"></a>

### copy-021/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-331"></a>

### copy-021/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-332"></a>

### copy-022/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-333"></a>

### copy-022/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-334"></a>

### copy-023/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-335"></a>

### copy-023/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-336"></a>

### copy-024/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-337"></a>

### copy-024/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-338"></a>

### copy-025/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-339"></a>

### copy-025/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-340"></a>

### copy-026/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-341"></a>

### copy-026/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-342"></a>

### copy-027/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-343"></a>

### copy-027/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-344"></a>

### copy-028/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-345"></a>

### copy-028/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-346"></a>

### copy-029/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-347"></a>

### copy-029/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-348"></a>

### copy-030/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-349"></a>

### copy-030/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="source-350"></a>

### copy-031/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-351"></a>

### copy-031/tuning/Cargo.toml:3:1

    > 3 [masked-sensitive-file-content]

<a id="rule-9"></a>

## PQC_DRAFT_ALGORITHM

Pre-standard PQC algorithm name referenced; check compatibility before replacing it.

Check: Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-352"></a>[copy-000/tuning/variants/draft.js:1:19](#finding-352)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-352)|
|<a id="finding-353"></a>[copy-001/tuning/variants/draft.js:1:19](#finding-353)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-353)|
|<a id="finding-354"></a>[copy-002/tuning/variants/draft.js:1:19](#finding-354)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-354)|
|<a id="finding-355"></a>[copy-003/tuning/variants/draft.js:1:19](#finding-355)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-355)|
|<a id="finding-356"></a>[copy-004/tuning/variants/draft.js:1:19](#finding-356)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-356)|
|<a id="finding-357"></a>[copy-005/tuning/variants/draft.js:1:19](#finding-357)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-357)|
|<a id="finding-358"></a>[copy-006/tuning/variants/draft.js:1:19](#finding-358)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-358)|
|<a id="finding-359"></a>[copy-007/tuning/variants/draft.js:1:19](#finding-359)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-359)|
|<a id="finding-360"></a>[copy-008/tuning/variants/draft.js:1:19](#finding-360)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-360)|
|<a id="finding-361"></a>[copy-009/tuning/variants/draft.js:1:19](#finding-361)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-361)|
|<a id="finding-362"></a>[copy-010/tuning/variants/draft.js:1:19](#finding-362)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-362)|
|<a id="finding-363"></a>[copy-011/tuning/variants/draft.js:1:19](#finding-363)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-363)|
|<a id="finding-364"></a>[copy-012/tuning/variants/draft.js:1:19](#finding-364)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-364)|
|<a id="finding-365"></a>[copy-013/tuning/variants/draft.js:1:19](#finding-365)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-365)|
|<a id="finding-366"></a>[copy-014/tuning/variants/draft.js:1:19](#finding-366)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-366)|
|<a id="finding-367"></a>[copy-015/tuning/variants/draft.js:1:19](#finding-367)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-367)|
|<a id="finding-368"></a>[copy-016/tuning/variants/draft.js:1:19](#finding-368)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-368)|
|<a id="finding-369"></a>[copy-017/tuning/variants/draft.js:1:19](#finding-369)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-369)|
|<a id="finding-370"></a>[copy-018/tuning/variants/draft.js:1:19](#finding-370)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-370)|
|<a id="finding-371"></a>[copy-019/tuning/variants/draft.js:1:19](#finding-371)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-371)|
|<a id="finding-372"></a>[copy-020/tuning/variants/draft.js:1:19](#finding-372)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-372)|
|<a id="finding-373"></a>[copy-021/tuning/variants/draft.js:1:19](#finding-373)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-373)|
|<a id="finding-374"></a>[copy-022/tuning/variants/draft.js:1:19](#finding-374)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-374)|
|<a id="finding-375"></a>[copy-023/tuning/variants/draft.js:1:19](#finding-375)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-375)|
|<a id="finding-376"></a>[copy-024/tuning/variants/draft.js:1:19](#finding-376)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-376)|
|<a id="finding-377"></a>[copy-025/tuning/variants/draft.js:1:19](#finding-377)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-377)|
|<a id="finding-378"></a>[copy-026/tuning/variants/draft.js:1:19](#finding-378)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-378)|
|<a id="finding-379"></a>[copy-027/tuning/variants/draft.js:1:19](#finding-379)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-379)|
|<a id="finding-380"></a>[copy-028/tuning/variants/draft.js:1:19](#finding-380)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-380)|
|<a id="finding-381"></a>[copy-029/tuning/variants/draft.js:1:19](#finding-381)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-381)|
|<a id="finding-382"></a>[copy-030/tuning/variants/draft.js:1:19](#finding-382)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-382)|
|<a id="finding-383"></a>[copy-031/tuning/variants/draft.js:1:19](#finding-383)|X25519Ky***raft00|Identify the exact implementation and wire format; draft Kyber/Dilithium names are not evidence of final ML-KEM/ML-DSA conformance. / [Source](#source-383)|

<a id="source-352"></a>

### copy-000/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-353"></a>

### copy-001/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-354"></a>

### copy-002/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-355"></a>

### copy-003/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-356"></a>

### copy-004/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-357"></a>

### copy-005/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-358"></a>

### copy-006/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-359"></a>

### copy-007/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-360"></a>

### copy-008/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-361"></a>

### copy-009/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-362"></a>

### copy-010/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-363"></a>

### copy-011/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-364"></a>

### copy-012/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-365"></a>

### copy-013/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-366"></a>

### copy-014/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-367"></a>

### copy-015/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-368"></a>

### copy-016/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-369"></a>

### copy-017/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-370"></a>

### copy-018/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-371"></a>

### copy-019/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-372"></a>

### copy-020/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-373"></a>

### copy-021/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-374"></a>

### copy-022/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-375"></a>

### copy-023/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-376"></a>

### copy-024/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-377"></a>

### copy-025/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-378"></a>

### copy-026/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-379"></a>

### copy-027/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-380"></a>

### copy-028/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-381"></a>

### copy-029/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-382"></a>

### copy-030/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="source-383"></a>

### copy-031/tuning/variants/draft.js:1:19

    > 1 const oldGroup = 'X25519Kyber768Draft00';
      2 const finalGroup = 'X25519MLKEM768';

<a id="rule-10"></a>

## PQC_GO_TLS_DISABLED

Go hybrid TLS default explicitly disabled; inspect effective environment and group overrides.

Check: Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-384"></a>[copy-000/tuning/overrides.conf:1:1](#finding-384)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-384)|
|<a id="finding-385"></a>[copy-001/tuning/overrides.conf:1:1](#finding-385)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-385)|
|<a id="finding-386"></a>[copy-002/tuning/overrides.conf:1:1](#finding-386)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-386)|
|<a id="finding-387"></a>[copy-003/tuning/overrides.conf:1:1](#finding-387)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-387)|
|<a id="finding-388"></a>[copy-004/tuning/overrides.conf:1:1](#finding-388)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-388)|
|<a id="finding-389"></a>[copy-005/tuning/overrides.conf:1:1](#finding-389)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-389)|
|<a id="finding-390"></a>[copy-006/tuning/overrides.conf:1:1](#finding-390)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-390)|
|<a id="finding-391"></a>[copy-007/tuning/overrides.conf:1:1](#finding-391)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-391)|
|<a id="finding-392"></a>[copy-008/tuning/overrides.conf:1:1](#finding-392)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-392)|
|<a id="finding-393"></a>[copy-009/tuning/overrides.conf:1:1](#finding-393)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-393)|
|<a id="finding-394"></a>[copy-010/tuning/overrides.conf:1:1](#finding-394)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-394)|
|<a id="finding-395"></a>[copy-011/tuning/overrides.conf:1:1](#finding-395)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-395)|
|<a id="finding-396"></a>[copy-012/tuning/overrides.conf:1:1](#finding-396)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-396)|
|<a id="finding-397"></a>[copy-013/tuning/overrides.conf:1:1](#finding-397)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-397)|
|<a id="finding-398"></a>[copy-014/tuning/overrides.conf:1:1](#finding-398)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-398)|
|<a id="finding-399"></a>[copy-015/tuning/overrides.conf:1:1](#finding-399)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-399)|
|<a id="finding-400"></a>[copy-016/tuning/overrides.conf:1:1](#finding-400)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-400)|
|<a id="finding-401"></a>[copy-017/tuning/overrides.conf:1:1](#finding-401)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-401)|
|<a id="finding-402"></a>[copy-018/tuning/overrides.conf:1:1](#finding-402)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-402)|
|<a id="finding-403"></a>[copy-019/tuning/overrides.conf:1:1](#finding-403)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-403)|
|<a id="finding-404"></a>[copy-020/tuning/overrides.conf:1:1](#finding-404)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-404)|
|<a id="finding-405"></a>[copy-021/tuning/overrides.conf:1:1](#finding-405)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-405)|
|<a id="finding-406"></a>[copy-022/tuning/overrides.conf:1:1](#finding-406)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-406)|
|<a id="finding-407"></a>[copy-023/tuning/overrides.conf:1:1](#finding-407)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-407)|
|<a id="finding-408"></a>[copy-024/tuning/overrides.conf:1:1](#finding-408)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-408)|
|<a id="finding-409"></a>[copy-025/tuning/overrides.conf:1:1](#finding-409)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-409)|
|<a id="finding-410"></a>[copy-026/tuning/overrides.conf:1:1](#finding-410)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-410)|
|<a id="finding-411"></a>[copy-027/tuning/overrides.conf:1:1](#finding-411)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-411)|
|<a id="finding-412"></a>[copy-028/tuning/overrides.conf:1:1](#finding-412)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-412)|
|<a id="finding-413"></a>[copy-029/tuning/overrides.conf:1:1](#finding-413)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-413)|
|<a id="finding-414"></a>[copy-030/tuning/overrides.conf:1:1](#finding-414)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-414)|
|<a id="finding-415"></a>[copy-031/tuning/overrides.conf:1:1](#finding-415)|GODEBUG=tlsmlkem=0|Review why tlsmlkem=0 is set; Go 1.24+ enables hybrid ML-KEM TLS by default. Test peers before removing overrides. / [Source](#source-415)|

Shared checks for these locations (not verified facts about each line):

- [Review the explicit PQC override: GODEBUG=tlsmlkem=0](#action-8)

<a id="source-384"></a>

### copy-000/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-385"></a>

### copy-001/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-386"></a>

### copy-002/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-387"></a>

### copy-003/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-388"></a>

### copy-004/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-389"></a>

### copy-005/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-390"></a>

### copy-006/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-391"></a>

### copy-007/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-392"></a>

### copy-008/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-393"></a>

### copy-009/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-394"></a>

### copy-010/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-395"></a>

### copy-011/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-396"></a>

### copy-012/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-397"></a>

### copy-013/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-398"></a>

### copy-014/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-399"></a>

### copy-015/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-400"></a>

### copy-016/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-401"></a>

### copy-017/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-402"></a>

### copy-018/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-403"></a>

### copy-019/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-404"></a>

### copy-020/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-405"></a>

### copy-021/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-406"></a>

### copy-022/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-407"></a>

### copy-023/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-408"></a>

### copy-024/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-409"></a>

### copy-025/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-410"></a>

### copy-026/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-411"></a>

### copy-027/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-412"></a>

### copy-028/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-413"></a>

### copy-029/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-414"></a>

### copy-030/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-415"></a>

### copy-031/tuning/overrides.conf:1:1

    > 1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="rule-11"></a>

## PQC_JAVA_CLASSICAL_GROUPS

Explicit classical-only Java property intent in assignment, XML entry or static System.setProperty; effective loading is not established.

Check: Review explicit group restrictions against the deployed JSSE version and peer support.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-416"></a>[copy-000/holdout/approval-adapter/archive-policy.xml:6:1](#finding-416)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-416)|
|<a id="finding-417"></a>[copy-000/tuning/overrides.conf:2:1](#finding-417)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-417)|
|<a id="finding-418"></a>[copy-001/holdout/approval-adapter/archive-policy.xml:6:1](#finding-418)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-418)|
|<a id="finding-419"></a>[copy-001/tuning/overrides.conf:2:1](#finding-419)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-419)|
|<a id="finding-420"></a>[copy-002/holdout/approval-adapter/archive-policy.xml:6:1](#finding-420)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-420)|
|<a id="finding-421"></a>[copy-002/tuning/overrides.conf:2:1](#finding-421)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-421)|
|<a id="finding-422"></a>[copy-003/holdout/approval-adapter/archive-policy.xml:6:1](#finding-422)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-422)|
|<a id="finding-423"></a>[copy-003/tuning/overrides.conf:2:1](#finding-423)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-423)|
|<a id="finding-424"></a>[copy-004/holdout/approval-adapter/archive-policy.xml:6:1](#finding-424)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-424)|
|<a id="finding-425"></a>[copy-004/tuning/overrides.conf:2:1](#finding-425)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-425)|
|<a id="finding-426"></a>[copy-005/holdout/approval-adapter/archive-policy.xml:6:1](#finding-426)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-426)|
|<a id="finding-427"></a>[copy-005/tuning/overrides.conf:2:1](#finding-427)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-427)|
|<a id="finding-428"></a>[copy-006/holdout/approval-adapter/archive-policy.xml:6:1](#finding-428)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-428)|
|<a id="finding-429"></a>[copy-006/tuning/overrides.conf:2:1](#finding-429)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-429)|
|<a id="finding-430"></a>[copy-007/holdout/approval-adapter/archive-policy.xml:6:1](#finding-430)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-430)|
|<a id="finding-431"></a>[copy-007/tuning/overrides.conf:2:1](#finding-431)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-431)|
|<a id="finding-432"></a>[copy-008/holdout/approval-adapter/archive-policy.xml:6:1](#finding-432)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-432)|
|<a id="finding-433"></a>[copy-008/tuning/overrides.conf:2:1](#finding-433)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-433)|
|<a id="finding-434"></a>[copy-009/holdout/approval-adapter/archive-policy.xml:6:1](#finding-434)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-434)|
|<a id="finding-435"></a>[copy-009/tuning/overrides.conf:2:1](#finding-435)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-435)|
|<a id="finding-436"></a>[copy-010/holdout/approval-adapter/archive-policy.xml:6:1](#finding-436)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-436)|
|<a id="finding-437"></a>[copy-010/tuning/overrides.conf:2:1](#finding-437)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-437)|
|<a id="finding-438"></a>[copy-011/holdout/approval-adapter/archive-policy.xml:6:1](#finding-438)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-438)|
|<a id="finding-439"></a>[copy-011/tuning/overrides.conf:2:1](#finding-439)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-439)|
|<a id="finding-440"></a>[copy-012/holdout/approval-adapter/archive-policy.xml:6:1](#finding-440)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-440)|
|<a id="finding-441"></a>[copy-012/tuning/overrides.conf:2:1](#finding-441)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-441)|
|<a id="finding-442"></a>[copy-013/holdout/approval-adapter/archive-policy.xml:6:1](#finding-442)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-442)|
|<a id="finding-443"></a>[copy-013/tuning/overrides.conf:2:1](#finding-443)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-443)|
|<a id="finding-444"></a>[copy-014/holdout/approval-adapter/archive-policy.xml:6:1](#finding-444)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-444)|
|<a id="finding-445"></a>[copy-014/tuning/overrides.conf:2:1](#finding-445)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-445)|
|<a id="finding-446"></a>[copy-015/holdout/approval-adapter/archive-policy.xml:6:1](#finding-446)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-446)|
|<a id="finding-447"></a>[copy-015/tuning/overrides.conf:2:1](#finding-447)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-447)|
|<a id="finding-448"></a>[copy-016/holdout/approval-adapter/archive-policy.xml:6:1](#finding-448)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-448)|
|<a id="finding-449"></a>[copy-016/tuning/overrides.conf:2:1](#finding-449)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-449)|
|<a id="finding-450"></a>[copy-017/holdout/approval-adapter/archive-policy.xml:6:1](#finding-450)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-450)|
|<a id="finding-451"></a>[copy-017/tuning/overrides.conf:2:1](#finding-451)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-451)|
|<a id="finding-452"></a>[copy-018/holdout/approval-adapter/archive-policy.xml:6:1](#finding-452)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-452)|
|<a id="finding-453"></a>[copy-018/tuning/overrides.conf:2:1](#finding-453)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-453)|
|<a id="finding-454"></a>[copy-019/holdout/approval-adapter/archive-policy.xml:6:1](#finding-454)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-454)|
|<a id="finding-455"></a>[copy-019/tuning/overrides.conf:2:1](#finding-455)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-455)|
|<a id="finding-456"></a>[copy-020/holdout/approval-adapter/archive-policy.xml:6:1](#finding-456)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-456)|
|<a id="finding-457"></a>[copy-020/tuning/overrides.conf:2:1](#finding-457)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-457)|
|<a id="finding-458"></a>[copy-021/holdout/approval-adapter/archive-policy.xml:6:1](#finding-458)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-458)|
|<a id="finding-459"></a>[copy-021/tuning/overrides.conf:2:1](#finding-459)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-459)|
|<a id="finding-460"></a>[copy-022/holdout/approval-adapter/archive-policy.xml:6:1](#finding-460)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-460)|
|<a id="finding-461"></a>[copy-022/tuning/overrides.conf:2:1](#finding-461)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-461)|
|<a id="finding-462"></a>[copy-023/holdout/approval-adapter/archive-policy.xml:6:1](#finding-462)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-462)|
|<a id="finding-463"></a>[copy-023/tuning/overrides.conf:2:1](#finding-463)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-463)|
|<a id="finding-464"></a>[copy-024/holdout/approval-adapter/archive-policy.xml:6:1](#finding-464)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-464)|
|<a id="finding-465"></a>[copy-024/tuning/overrides.conf:2:1](#finding-465)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-465)|
|<a id="finding-466"></a>[copy-025/holdout/approval-adapter/archive-policy.xml:6:1](#finding-466)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-466)|
|<a id="finding-467"></a>[copy-025/tuning/overrides.conf:2:1](#finding-467)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-467)|
|<a id="finding-468"></a>[copy-026/holdout/approval-adapter/archive-policy.xml:6:1](#finding-468)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-468)|
|<a id="finding-469"></a>[copy-026/tuning/overrides.conf:2:1](#finding-469)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-469)|
|<a id="finding-470"></a>[copy-027/holdout/approval-adapter/archive-policy.xml:6:1](#finding-470)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-470)|
|<a id="finding-471"></a>[copy-027/tuning/overrides.conf:2:1](#finding-471)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-471)|
|<a id="finding-472"></a>[copy-028/holdout/approval-adapter/archive-policy.xml:6:1](#finding-472)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-472)|
|<a id="finding-473"></a>[copy-028/tuning/overrides.conf:2:1](#finding-473)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-473)|
|<a id="finding-474"></a>[copy-029/holdout/approval-adapter/archive-policy.xml:6:1](#finding-474)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-474)|
|<a id="finding-475"></a>[copy-029/tuning/overrides.conf:2:1](#finding-475)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-475)|
|<a id="finding-476"></a>[copy-030/holdout/approval-adapter/archive-policy.xml:6:1](#finding-476)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-476)|
|<a id="finding-477"></a>[copy-030/tuning/overrides.conf:2:1](#finding-477)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-477)|
|<a id="finding-478"></a>[copy-031/holdout/approval-adapter/archive-policy.xml:6:1](#finding-478)|&lt;entry k***entry&gt;|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-478)|
|<a id="finding-479"></a>[copy-031/tuning/overrides.conf:2:1](#finding-479)|jdk.tls.***p256r1|Review explicit group restrictions against the deployed JSSE version and peer support. / [Source](#source-479)|

Shared checks for these locations (not verified facts about each line):

- [Review the explicit PQC override: jdk.tls.namedGroups](#action-9)

<a id="source-416"></a>

### copy-000/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-417"></a>

### copy-000/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-418"></a>

### copy-001/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-419"></a>

### copy-001/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-420"></a>

### copy-002/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-421"></a>

### copy-002/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-422"></a>

### copy-003/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-423"></a>

### copy-003/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-424"></a>

### copy-004/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-425"></a>

### copy-004/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-426"></a>

### copy-005/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-427"></a>

### copy-005/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-428"></a>

### copy-006/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-429"></a>

### copy-006/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-430"></a>

### copy-007/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-431"></a>

### copy-007/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-432"></a>

### copy-008/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-433"></a>

### copy-008/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-434"></a>

### copy-009/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-435"></a>

### copy-009/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-436"></a>

### copy-010/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-437"></a>

### copy-010/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-438"></a>

### copy-011/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-439"></a>

### copy-011/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-440"></a>

### copy-012/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-441"></a>

### copy-012/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-442"></a>

### copy-013/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-443"></a>

### copy-013/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-444"></a>

### copy-014/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-445"></a>

### copy-014/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-446"></a>

### copy-015/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-447"></a>

### copy-015/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-448"></a>

### copy-016/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-449"></a>

### copy-016/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-450"></a>

### copy-017/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-451"></a>

### copy-017/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-452"></a>

### copy-018/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-453"></a>

### copy-018/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-454"></a>

### copy-019/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-455"></a>

### copy-019/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-456"></a>

### copy-020/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-457"></a>

### copy-020/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-458"></a>

### copy-021/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-459"></a>

### copy-021/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-460"></a>

### copy-022/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-461"></a>

### copy-022/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-462"></a>

### copy-023/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-463"></a>

### copy-023/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-464"></a>

### copy-024/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-465"></a>

### copy-024/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-466"></a>

### copy-025/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-467"></a>

### copy-025/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-468"></a>

### copy-026/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-469"></a>

### copy-026/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-470"></a>

### copy-027/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-471"></a>

### copy-027/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-472"></a>

### copy-028/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-473"></a>

### copy-028/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-474"></a>

### copy-029/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-475"></a>

### copy-029/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-476"></a>

### copy-030/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-477"></a>

### copy-030/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="source-478"></a>

### copy-031/holdout/approval-adapter/archive-policy.xml:6:1

      4 <properties>
      5   <comment>Offline archive client group policy</comment>
    > 6   <entry key="jdk.tls.namedGroups">secp384r1,secp521r1</entry>
      7 </properties>

<a id="source-479"></a>

### copy-031/tuning/overrides.conf:2:1

      1 GODEBUG=tlsmlkem=0
    > 2 jdk.tls.namedGroups=x25519,secp256r1
      3 ctx.groups = 'X25519:P-256'

<a id="rule-12"></a>

## PQC_RUBY_CLASSICAL_GROUPS

Ruby-style group assignment explicitly restricts the recognized list to classical groups.

Check: Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-480"></a>[copy-000/tuning/overrides.conf:3:1](#finding-480)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-480)|
|<a id="finding-481"></a>[copy-001/tuning/overrides.conf:3:1](#finding-481)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-481)|
|<a id="finding-482"></a>[copy-002/tuning/overrides.conf:3:1](#finding-482)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-482)|
|<a id="finding-483"></a>[copy-003/tuning/overrides.conf:3:1](#finding-483)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-483)|
|<a id="finding-484"></a>[copy-004/tuning/overrides.conf:3:1](#finding-484)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-484)|
|<a id="finding-485"></a>[copy-005/tuning/overrides.conf:3:1](#finding-485)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-485)|
|<a id="finding-486"></a>[copy-006/tuning/overrides.conf:3:1](#finding-486)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-486)|
|<a id="finding-487"></a>[copy-007/tuning/overrides.conf:3:1](#finding-487)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-487)|
|<a id="finding-488"></a>[copy-008/tuning/overrides.conf:3:1](#finding-488)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-488)|
|<a id="finding-489"></a>[copy-009/tuning/overrides.conf:3:1](#finding-489)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-489)|
|<a id="finding-490"></a>[copy-010/tuning/overrides.conf:3:1](#finding-490)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-490)|
|<a id="finding-491"></a>[copy-011/tuning/overrides.conf:3:1](#finding-491)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-491)|
|<a id="finding-492"></a>[copy-012/tuning/overrides.conf:3:1](#finding-492)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-492)|
|<a id="finding-493"></a>[copy-013/tuning/overrides.conf:3:1](#finding-493)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-493)|
|<a id="finding-494"></a>[copy-014/tuning/overrides.conf:3:1](#finding-494)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-494)|
|<a id="finding-495"></a>[copy-015/tuning/overrides.conf:3:1](#finding-495)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-495)|
|<a id="finding-496"></a>[copy-016/tuning/overrides.conf:3:1](#finding-496)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-496)|
|<a id="finding-497"></a>[copy-017/tuning/overrides.conf:3:1](#finding-497)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-497)|
|<a id="finding-498"></a>[copy-018/tuning/overrides.conf:3:1](#finding-498)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-498)|
|<a id="finding-499"></a>[copy-019/tuning/overrides.conf:3:1](#finding-499)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-499)|
|<a id="finding-500"></a>[copy-020/tuning/overrides.conf:3:1](#finding-500)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-500)|
|<a id="finding-501"></a>[copy-021/tuning/overrides.conf:3:1](#finding-501)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-501)|
|<a id="finding-502"></a>[copy-022/tuning/overrides.conf:3:1](#finding-502)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-502)|
|<a id="finding-503"></a>[copy-023/tuning/overrides.conf:3:1](#finding-503)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-503)|
|<a id="finding-504"></a>[copy-024/tuning/overrides.conf:3:1](#finding-504)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-504)|
|<a id="finding-505"></a>[copy-025/tuning/overrides.conf:3:1](#finding-505)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-505)|
|<a id="finding-506"></a>[copy-026/tuning/overrides.conf:3:1](#finding-506)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-506)|
|<a id="finding-507"></a>[copy-027/tuning/overrides.conf:3:1](#finding-507)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-507)|
|<a id="finding-508"></a>[copy-028/tuning/overrides.conf:3:1](#finding-508)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-508)|
|<a id="finding-509"></a>[copy-029/tuning/overrides.conf:3:1](#finding-509)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-509)|
|<a id="finding-510"></a>[copy-030/tuning/overrides.conf:3:1](#finding-510)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-510)|
|<a id="finding-511"></a>[copy-031/tuning/overrides.conf:3:1](#finding-511)|ctx.grou***P-256'|Review groups= or ecdh_curves= restrictions with the linked TLS library; test hybrid group interoperability. / [Source](#source-511)|

Shared checks for these locations (not verified facts about each line):

- [Review the explicit PQC override: groups= / ecdh_curves=](#action-10)

<a id="source-480"></a>

### copy-000/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-481"></a>

### copy-001/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-482"></a>

### copy-002/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-483"></a>

### copy-003/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-484"></a>

### copy-004/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-485"></a>

### copy-005/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-486"></a>

### copy-006/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-487"></a>

### copy-007/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-488"></a>

### copy-008/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-489"></a>

### copy-009/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-490"></a>

### copy-010/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-491"></a>

### copy-011/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-492"></a>

### copy-012/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-493"></a>

### copy-013/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-494"></a>

### copy-014/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-495"></a>

### copy-015/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-496"></a>

### copy-016/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-497"></a>

### copy-017/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-498"></a>

### copy-018/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-499"></a>

### copy-019/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-500"></a>

### copy-020/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-501"></a>

### copy-021/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-502"></a>

### copy-022/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-503"></a>

### copy-023/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-504"></a>

### copy-024/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-505"></a>

### copy-025/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-506"></a>

### copy-026/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-507"></a>

### copy-027/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-508"></a>

### copy-028/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-509"></a>

### copy-029/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-510"></a>

### copy-030/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="source-511"></a>

### copy-031/tuning/overrides.conf:3:1

      1 GODEBUG=tlsmlkem=0
      2 jdk.tls.namedGroups=x25519,secp256r1
    > 3 ctx.groups = 'X25519:P-256'

<a id="rule-13"></a>

## CERT_PEM_CONTAINER

PEM/DER cryptographic container detected; certificate presence is not established.

Check: Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-512"></a>[copy-000/holdout/misleading-rsa1024.der:1:1](#finding-512)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-512)|
|<a id="finding-513"></a>[copy-001/holdout/misleading-rsa1024.der:1:1](#finding-513)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-513)|
|<a id="finding-514"></a>[copy-002/holdout/misleading-rsa1024.der:1:1](#finding-514)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-514)|
|<a id="finding-515"></a>[copy-003/holdout/misleading-rsa1024.der:1:1](#finding-515)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-515)|
|<a id="finding-516"></a>[copy-004/holdout/misleading-rsa1024.der:1:1](#finding-516)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-516)|
|<a id="finding-517"></a>[copy-005/holdout/misleading-rsa1024.der:1:1](#finding-517)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-517)|
|<a id="finding-518"></a>[copy-006/holdout/misleading-rsa1024.der:1:1](#finding-518)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-518)|
|<a id="finding-519"></a>[copy-007/holdout/misleading-rsa1024.der:1:1](#finding-519)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-519)|
|<a id="finding-520"></a>[copy-008/holdout/misleading-rsa1024.der:1:1](#finding-520)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-520)|
|<a id="finding-521"></a>[copy-009/holdout/misleading-rsa1024.der:1:1](#finding-521)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-521)|
|<a id="finding-522"></a>[copy-010/holdout/misleading-rsa1024.der:1:1](#finding-522)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-522)|
|<a id="finding-523"></a>[copy-011/holdout/misleading-rsa1024.der:1:1](#finding-523)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-523)|
|<a id="finding-524"></a>[copy-012/holdout/misleading-rsa1024.der:1:1](#finding-524)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-524)|
|<a id="finding-525"></a>[copy-013/holdout/misleading-rsa1024.der:1:1](#finding-525)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-525)|
|<a id="finding-526"></a>[copy-014/holdout/misleading-rsa1024.der:1:1](#finding-526)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-526)|
|<a id="finding-527"></a>[copy-015/holdout/misleading-rsa1024.der:1:1](#finding-527)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-527)|
|<a id="finding-528"></a>[copy-016/holdout/misleading-rsa1024.der:1:1](#finding-528)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-528)|
|<a id="finding-529"></a>[copy-017/holdout/misleading-rsa1024.der:1:1](#finding-529)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-529)|
|<a id="finding-530"></a>[copy-018/holdout/misleading-rsa1024.der:1:1](#finding-530)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-530)|
|<a id="finding-531"></a>[copy-019/holdout/misleading-rsa1024.der:1:1](#finding-531)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-531)|
|<a id="finding-532"></a>[copy-020/holdout/misleading-rsa1024.der:1:1](#finding-532)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-532)|
|<a id="finding-533"></a>[copy-021/holdout/misleading-rsa1024.der:1:1](#finding-533)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-533)|
|<a id="finding-534"></a>[copy-022/holdout/misleading-rsa1024.der:1:1](#finding-534)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-534)|
|<a id="finding-535"></a>[copy-023/holdout/misleading-rsa1024.der:1:1](#finding-535)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-535)|
|<a id="finding-536"></a>[copy-024/holdout/misleading-rsa1024.der:1:1](#finding-536)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-536)|
|<a id="finding-537"></a>[copy-025/holdout/misleading-rsa1024.der:1:1](#finding-537)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-537)|
|<a id="finding-538"></a>[copy-026/holdout/misleading-rsa1024.der:1:1](#finding-538)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-538)|
|<a id="finding-539"></a>[copy-027/holdout/misleading-rsa1024.der:1:1](#finding-539)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-539)|
|<a id="finding-540"></a>[copy-028/holdout/misleading-rsa1024.der:1:1](#finding-540)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-540)|
|<a id="finding-541"></a>[copy-029/holdout/misleading-rsa1024.der:1:1](#finding-541)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-541)|
|<a id="finding-542"></a>[copy-030/holdout/misleading-rsa1024.der:1:1](#finding-542)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-542)|
|<a id="finding-543"></a>[copy-031/holdout/misleading-rsa1024.der:1:1](#finding-543)|misleadi***24.der|Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. / [Source](#source-543)|

Shared checks for these locations (not verified facts about each line):

- [Plan certificate algorithm and trust-store migration](#action-0)

<a id="source-512"></a>

### copy-000/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-513"></a>

### copy-001/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-514"></a>

### copy-002/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-515"></a>

### copy-003/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-516"></a>

### copy-004/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-517"></a>

### copy-005/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-518"></a>

### copy-006/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-519"></a>

### copy-007/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-520"></a>

### copy-008/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-521"></a>

### copy-009/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-522"></a>

### copy-010/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-523"></a>

### copy-011/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-524"></a>

### copy-012/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-525"></a>

### copy-013/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-526"></a>

### copy-014/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-527"></a>

### copy-015/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-528"></a>

### copy-016/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-529"></a>

### copy-017/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-530"></a>

### copy-018/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-531"></a>

### copy-019/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-532"></a>

### copy-020/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-533"></a>

### copy-021/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-534"></a>

### copy-022/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-535"></a>

### copy-023/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-536"></a>

### copy-024/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-537"></a>

### copy-025/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-538"></a>

### copy-026/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-539"></a>

### copy-027/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-540"></a>

### copy-028/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-541"></a>

### copy-029/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-542"></a>

### copy-030/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="source-543"></a>

### copy-031/holdout/misleading-rsa1024.der:1:1

    > 1 not a certificate

<a id="rule-14"></a>

## DEP_PQC_CAPABLE_LIBRARY

Library with version-dependent PQC capabilities inventoried; capability is not an enabled-state finding.

Check: Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-544"></a>[copy-000/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-544)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-544)|
|<a id="finding-545"></a>[copy-000/holdout/sbom.json (line unavailable)](#finding-545)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-545)|
|<a id="finding-546"></a>[copy-000/tuning/Cargo.toml:2:1](#finding-546)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-546)|
|<a id="finding-547"></a>[copy-001/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-547)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-547)|
|<a id="finding-548"></a>[copy-001/holdout/sbom.json (line unavailable)](#finding-548)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-548)|
|<a id="finding-549"></a>[copy-001/tuning/Cargo.toml:2:1](#finding-549)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-549)|
|<a id="finding-550"></a>[copy-002/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-550)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-550)|
|<a id="finding-551"></a>[copy-002/holdout/sbom.json (line unavailable)](#finding-551)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-551)|
|<a id="finding-552"></a>[copy-002/tuning/Cargo.toml:2:1](#finding-552)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-552)|
|<a id="finding-553"></a>[copy-003/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-553)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-553)|
|<a id="finding-554"></a>[copy-003/holdout/sbom.json (line unavailable)](#finding-554)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-554)|
|<a id="finding-555"></a>[copy-003/tuning/Cargo.toml:2:1](#finding-555)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-555)|
|<a id="finding-556"></a>[copy-004/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-556)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-556)|
|<a id="finding-557"></a>[copy-004/holdout/sbom.json (line unavailable)](#finding-557)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-557)|
|<a id="finding-558"></a>[copy-004/tuning/Cargo.toml:2:1](#finding-558)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-558)|
|<a id="finding-559"></a>[copy-005/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-559)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-559)|
|<a id="finding-560"></a>[copy-005/holdout/sbom.json (line unavailable)](#finding-560)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-560)|
|<a id="finding-561"></a>[copy-005/tuning/Cargo.toml:2:1](#finding-561)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-561)|
|<a id="finding-562"></a>[copy-006/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-562)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-562)|
|<a id="finding-563"></a>[copy-006/holdout/sbom.json (line unavailable)](#finding-563)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-563)|
|<a id="finding-564"></a>[copy-006/tuning/Cargo.toml:2:1](#finding-564)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-564)|
|<a id="finding-565"></a>[copy-007/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-565)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-565)|
|<a id="finding-566"></a>[copy-007/holdout/sbom.json (line unavailable)](#finding-566)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-566)|
|<a id="finding-567"></a>[copy-007/tuning/Cargo.toml:2:1](#finding-567)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-567)|
|<a id="finding-568"></a>[copy-008/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-568)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-568)|
|<a id="finding-569"></a>[copy-008/holdout/sbom.json (line unavailable)](#finding-569)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-569)|
|<a id="finding-570"></a>[copy-008/tuning/Cargo.toml:2:1](#finding-570)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-570)|
|<a id="finding-571"></a>[copy-009/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-571)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-571)|
|<a id="finding-572"></a>[copy-009/holdout/sbom.json (line unavailable)](#finding-572)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-572)|
|<a id="finding-573"></a>[copy-009/tuning/Cargo.toml:2:1](#finding-573)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-573)|
|<a id="finding-574"></a>[copy-010/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-574)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-574)|
|<a id="finding-575"></a>[copy-010/holdout/sbom.json (line unavailable)](#finding-575)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-575)|
|<a id="finding-576"></a>[copy-010/tuning/Cargo.toml:2:1](#finding-576)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-576)|
|<a id="finding-577"></a>[copy-011/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-577)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-577)|
|<a id="finding-578"></a>[copy-011/holdout/sbom.json (line unavailable)](#finding-578)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-578)|
|<a id="finding-579"></a>[copy-011/tuning/Cargo.toml:2:1](#finding-579)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-579)|
|<a id="finding-580"></a>[copy-012/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-580)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-580)|
|<a id="finding-581"></a>[copy-012/holdout/sbom.json (line unavailable)](#finding-581)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-581)|
|<a id="finding-582"></a>[copy-012/tuning/Cargo.toml:2:1](#finding-582)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-582)|
|<a id="finding-583"></a>[copy-013/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-583)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-583)|
|<a id="finding-584"></a>[copy-013/holdout/sbom.json (line unavailable)](#finding-584)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-584)|
|<a id="finding-585"></a>[copy-013/tuning/Cargo.toml:2:1](#finding-585)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-585)|
|<a id="finding-586"></a>[copy-014/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-586)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-586)|
|<a id="finding-587"></a>[copy-014/holdout/sbom.json (line unavailable)](#finding-587)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-587)|
|<a id="finding-588"></a>[copy-014/tuning/Cargo.toml:2:1](#finding-588)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-588)|
|<a id="finding-589"></a>[copy-015/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-589)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-589)|
|<a id="finding-590"></a>[copy-015/holdout/sbom.json (line unavailable)](#finding-590)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-590)|
|<a id="finding-591"></a>[copy-015/tuning/Cargo.toml:2:1](#finding-591)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-591)|
|<a id="finding-592"></a>[copy-016/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-592)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-592)|
|<a id="finding-593"></a>[copy-016/holdout/sbom.json (line unavailable)](#finding-593)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-593)|
|<a id="finding-594"></a>[copy-016/tuning/Cargo.toml:2:1](#finding-594)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-594)|
|<a id="finding-595"></a>[copy-017/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-595)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-595)|
|<a id="finding-596"></a>[copy-017/holdout/sbom.json (line unavailable)](#finding-596)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-596)|
|<a id="finding-597"></a>[copy-017/tuning/Cargo.toml:2:1](#finding-597)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-597)|
|<a id="finding-598"></a>[copy-018/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-598)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-598)|
|<a id="finding-599"></a>[copy-018/holdout/sbom.json (line unavailable)](#finding-599)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-599)|
|<a id="finding-600"></a>[copy-018/tuning/Cargo.toml:2:1](#finding-600)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-600)|
|<a id="finding-601"></a>[copy-019/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-601)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-601)|
|<a id="finding-602"></a>[copy-019/holdout/sbom.json (line unavailable)](#finding-602)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-602)|
|<a id="finding-603"></a>[copy-019/tuning/Cargo.toml:2:1](#finding-603)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-603)|
|<a id="finding-604"></a>[copy-020/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-604)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-604)|
|<a id="finding-605"></a>[copy-020/holdout/sbom.json (line unavailable)](#finding-605)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-605)|
|<a id="finding-606"></a>[copy-020/tuning/Cargo.toml:2:1](#finding-606)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-606)|
|<a id="finding-607"></a>[copy-021/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-607)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-607)|
|<a id="finding-608"></a>[copy-021/holdout/sbom.json (line unavailable)](#finding-608)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-608)|
|<a id="finding-609"></a>[copy-021/tuning/Cargo.toml:2:1](#finding-609)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-609)|
|<a id="finding-610"></a>[copy-022/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-610)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-610)|
|<a id="finding-611"></a>[copy-022/holdout/sbom.json (line unavailable)](#finding-611)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-611)|
|<a id="finding-612"></a>[copy-022/tuning/Cargo.toml:2:1](#finding-612)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-612)|
|<a id="finding-613"></a>[copy-023/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-613)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-613)|
|<a id="finding-614"></a>[copy-023/holdout/sbom.json (line unavailable)](#finding-614)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-614)|
|<a id="finding-615"></a>[copy-023/tuning/Cargo.toml:2:1](#finding-615)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-615)|
|<a id="finding-616"></a>[copy-024/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-616)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-616)|
|<a id="finding-617"></a>[copy-024/holdout/sbom.json (line unavailable)](#finding-617)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-617)|
|<a id="finding-618"></a>[copy-024/tuning/Cargo.toml:2:1](#finding-618)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-618)|
|<a id="finding-619"></a>[copy-025/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-619)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-619)|
|<a id="finding-620"></a>[copy-025/holdout/sbom.json (line unavailable)](#finding-620)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-620)|
|<a id="finding-621"></a>[copy-025/tuning/Cargo.toml:2:1](#finding-621)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-621)|
|<a id="finding-622"></a>[copy-026/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-622)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-622)|
|<a id="finding-623"></a>[copy-026/holdout/sbom.json (line unavailable)](#finding-623)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-623)|
|<a id="finding-624"></a>[copy-026/tuning/Cargo.toml:2:1](#finding-624)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-624)|
|<a id="finding-625"></a>[copy-027/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-625)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-625)|
|<a id="finding-626"></a>[copy-027/holdout/sbom.json (line unavailable)](#finding-626)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-626)|
|<a id="finding-627"></a>[copy-027/tuning/Cargo.toml:2:1](#finding-627)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-627)|
|<a id="finding-628"></a>[copy-028/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-628)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-628)|
|<a id="finding-629"></a>[copy-028/holdout/sbom.json (line unavailable)](#finding-629)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-629)|
|<a id="finding-630"></a>[copy-028/tuning/Cargo.toml:2:1](#finding-630)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-630)|
|<a id="finding-631"></a>[copy-029/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-631)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-631)|
|<a id="finding-632"></a>[copy-029/holdout/sbom.json (line unavailable)](#finding-632)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-632)|
|<a id="finding-633"></a>[copy-029/tuning/Cargo.toml:2:1](#finding-633)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-633)|
|<a id="finding-634"></a>[copy-030/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-634)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-634)|
|<a id="finding-635"></a>[copy-030/holdout/sbom.json (line unavailable)](#finding-635)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-635)|
|<a id="finding-636"></a>[copy-030/tuning/Cargo.toml:2:1](#finding-636)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-636)|
|<a id="finding-637"></a>[copy-031/holdout/approval-adapter/Cargo.toml (line unavailable)](#finding-637)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-637)|
|<a id="finding-638"></a>[copy-031/holdout/sbom.json (line unavailable)](#finding-638)|openssl@1.1.1|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-638)|
|<a id="finding-639"></a>[copy-031/tuning/Cargo.toml:2:1](#finding-639)|ml-kem@0.2|Inspect resolved version, features and backend. rustls 0.23.27 prefers hybrid TLS with aws-lc-rs; cryptography 48+ supports OpenSSL 3.5+ PQC. Presence alone proves no protection. / [Source](#source-639)|

Shared checks for these locations (not verified facts about each line):

- [Track PQC readiness of dependent libraries](#action-7)

<a id="source-544"></a>

### copy-000/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-545"></a>

### copy-000/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-546"></a>

### copy-000/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-547"></a>

### copy-001/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-548"></a>

### copy-001/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-549"></a>

### copy-001/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-550"></a>

### copy-002/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-551"></a>

### copy-002/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-552"></a>

### copy-002/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-553"></a>

### copy-003/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-554"></a>

### copy-003/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-555"></a>

### copy-003/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-556"></a>

### copy-004/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-557"></a>

### copy-004/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-558"></a>

### copy-004/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-559"></a>

### copy-005/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-560"></a>

### copy-005/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-561"></a>

### copy-005/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-562"></a>

### copy-006/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-563"></a>

### copy-006/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-564"></a>

### copy-006/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-565"></a>

### copy-007/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-566"></a>

### copy-007/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-567"></a>

### copy-007/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-568"></a>

### copy-008/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-569"></a>

### copy-008/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-570"></a>

### copy-008/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-571"></a>

### copy-009/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-572"></a>

### copy-009/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-573"></a>

### copy-009/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-574"></a>

### copy-010/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-575"></a>

### copy-010/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-576"></a>

### copy-010/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-577"></a>

### copy-011/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-578"></a>

### copy-011/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-579"></a>

### copy-011/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-580"></a>

### copy-012/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-581"></a>

### copy-012/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-582"></a>

### copy-012/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-583"></a>

### copy-013/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-584"></a>

### copy-013/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-585"></a>

### copy-013/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-586"></a>

### copy-014/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-587"></a>

### copy-014/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-588"></a>

### copy-014/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-589"></a>

### copy-015/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-590"></a>

### copy-015/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-591"></a>

### copy-015/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-592"></a>

### copy-016/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-593"></a>

### copy-016/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-594"></a>

### copy-016/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-595"></a>

### copy-017/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-596"></a>

### copy-017/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-597"></a>

### copy-017/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-598"></a>

### copy-018/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-599"></a>

### copy-018/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-600"></a>

### copy-018/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-601"></a>

### copy-019/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-602"></a>

### copy-019/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-603"></a>

### copy-019/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-604"></a>

### copy-020/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-605"></a>

### copy-020/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-606"></a>

### copy-020/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-607"></a>

### copy-021/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-608"></a>

### copy-021/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-609"></a>

### copy-021/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-610"></a>

### copy-022/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-611"></a>

### copy-022/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-612"></a>

### copy-022/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-613"></a>

### copy-023/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-614"></a>

### copy-023/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-615"></a>

### copy-023/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-616"></a>

### copy-024/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-617"></a>

### copy-024/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-618"></a>

### copy-024/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-619"></a>

### copy-025/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-620"></a>

### copy-025/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-621"></a>

### copy-025/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-622"></a>

### copy-026/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-623"></a>

### copy-026/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-624"></a>

### copy-026/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-625"></a>

### copy-027/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-626"></a>

### copy-027/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-627"></a>

### copy-027/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-628"></a>

### copy-028/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-629"></a>

### copy-028/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-630"></a>

### copy-028/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-631"></a>

### copy-029/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-632"></a>

### copy-029/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-633"></a>

### copy-029/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-634"></a>

### copy-030/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-635"></a>

### copy-030/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-636"></a>

### copy-030/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="source-637"></a>

### copy-031/holdout/approval-adapter/Cargo.toml (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-638"></a>

### copy-031/holdout/sbom.json (line unavailable)

    > 0 [masked-sensitive-file-content]

<a id="source-639"></a>

### copy-031/tuning/Cargo.toml:2:1

    > 2 [masked-sensitive-file-content]

<a id="rule-15"></a>

## PQC_GO_API

Standard Go PQC package imported; import alone does not prove negotiated protection.

Check: crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-640"></a>[copy-000/tuning/example.go:3:8](#finding-640)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-640)|
|<a id="finding-641"></a>[copy-001/tuning/example.go:3:8](#finding-641)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-641)|
|<a id="finding-642"></a>[copy-002/tuning/example.go:3:8](#finding-642)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-642)|
|<a id="finding-643"></a>[copy-003/tuning/example.go:3:8](#finding-643)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-643)|
|<a id="finding-644"></a>[copy-004/tuning/example.go:3:8](#finding-644)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-644)|
|<a id="finding-645"></a>[copy-005/tuning/example.go:3:8](#finding-645)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-645)|
|<a id="finding-646"></a>[copy-006/tuning/example.go:3:8](#finding-646)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-646)|
|<a id="finding-647"></a>[copy-007/tuning/example.go:3:8](#finding-647)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-647)|
|<a id="finding-648"></a>[copy-008/tuning/example.go:3:8](#finding-648)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-648)|
|<a id="finding-649"></a>[copy-009/tuning/example.go:3:8](#finding-649)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-649)|
|<a id="finding-650"></a>[copy-010/tuning/example.go:3:8](#finding-650)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-650)|
|<a id="finding-651"></a>[copy-011/tuning/example.go:3:8](#finding-651)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-651)|
|<a id="finding-652"></a>[copy-012/tuning/example.go:3:8](#finding-652)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-652)|
|<a id="finding-653"></a>[copy-013/tuning/example.go:3:8](#finding-653)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-653)|
|<a id="finding-654"></a>[copy-014/tuning/example.go:3:8](#finding-654)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-654)|
|<a id="finding-655"></a>[copy-015/tuning/example.go:3:8](#finding-655)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-655)|
|<a id="finding-656"></a>[copy-016/tuning/example.go:3:8](#finding-656)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-656)|
|<a id="finding-657"></a>[copy-017/tuning/example.go:3:8](#finding-657)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-657)|
|<a id="finding-658"></a>[copy-018/tuning/example.go:3:8](#finding-658)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-658)|
|<a id="finding-659"></a>[copy-019/tuning/example.go:3:8](#finding-659)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-659)|
|<a id="finding-660"></a>[copy-020/tuning/example.go:3:8](#finding-660)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-660)|
|<a id="finding-661"></a>[copy-021/tuning/example.go:3:8](#finding-661)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-661)|
|<a id="finding-662"></a>[copy-022/tuning/example.go:3:8](#finding-662)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-662)|
|<a id="finding-663"></a>[copy-023/tuning/example.go:3:8](#finding-663)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-663)|
|<a id="finding-664"></a>[copy-024/tuning/example.go:3:8](#finding-664)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-664)|
|<a id="finding-665"></a>[copy-025/tuning/example.go:3:8](#finding-665)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-665)|
|<a id="finding-666"></a>[copy-026/tuning/example.go:3:8](#finding-666)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-666)|
|<a id="finding-667"></a>[copy-027/tuning/example.go:3:8](#finding-667)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-667)|
|<a id="finding-668"></a>[copy-028/tuning/example.go:3:8](#finding-668)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-668)|
|<a id="finding-669"></a>[copy-029/tuning/example.go:3:8](#finding-669)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-669)|
|<a id="finding-670"></a>[copy-030/tuning/example.go:3:8](#finding-670)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-670)|
|<a id="finding-671"></a>[copy-031/tuning/example.go:3:8](#finding-671)|"crypto/mlkem"|crypto/mlkem requires Go 1.24+; crypto/mldsa requires Go 1.27+. Verify actual call sites. / [Source](#source-671)|

<a id="source-640"></a>

### copy-000/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-641"></a>

### copy-001/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-642"></a>

### copy-002/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-643"></a>

### copy-003/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-644"></a>

### copy-004/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-645"></a>

### copy-005/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-646"></a>

### copy-006/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-647"></a>

### copy-007/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-648"></a>

### copy-008/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-649"></a>

### copy-009/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-650"></a>

### copy-010/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-651"></a>

### copy-011/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-652"></a>

### copy-012/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-653"></a>

### copy-013/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-654"></a>

### copy-014/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-655"></a>

### copy-015/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-656"></a>

### copy-016/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-657"></a>

### copy-017/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-658"></a>

### copy-018/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-659"></a>

### copy-019/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-660"></a>

### copy-020/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-661"></a>

### copy-021/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-662"></a>

### copy-022/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-663"></a>

### copy-023/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-664"></a>

### copy-024/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-665"></a>

### copy-025/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-666"></a>

### copy-026/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-667"></a>

### copy-027/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-668"></a>

### copy-028/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-669"></a>

### copy-029/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-670"></a>

### copy-030/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="source-671"></a>

### copy-031/tuning/example.go:3:8

      1 package example
      2 
    > 3 import "crypto/mlkem"

<a id="rule-16"></a>

## PQC_JAVA_API

Standard PQC algorithm requested through Java APIs; runtime success is not established.

Check: JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-672"></a>[copy-000/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-672)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-672)|
|<a id="finding-673"></a>[copy-000/tuning/Example.java:3:9](#finding-673)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-673)|
|<a id="finding-674"></a>[copy-000/tuning/variants/dead.java:1:55](#finding-674)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-674)|
|<a id="finding-675"></a>[copy-001/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-675)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-675)|
|<a id="finding-676"></a>[copy-001/tuning/Example.java:3:9](#finding-676)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-676)|
|<a id="finding-677"></a>[copy-001/tuning/variants/dead.java:1:55](#finding-677)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-677)|
|<a id="finding-678"></a>[copy-002/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-678)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-678)|
|<a id="finding-679"></a>[copy-002/tuning/Example.java:3:9](#finding-679)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-679)|
|<a id="finding-680"></a>[copy-002/tuning/variants/dead.java:1:55](#finding-680)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-680)|
|<a id="finding-681"></a>[copy-003/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-681)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-681)|
|<a id="finding-682"></a>[copy-003/tuning/Example.java:3:9](#finding-682)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-682)|
|<a id="finding-683"></a>[copy-003/tuning/variants/dead.java:1:55](#finding-683)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-683)|
|<a id="finding-684"></a>[copy-004/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-684)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-684)|
|<a id="finding-685"></a>[copy-004/tuning/Example.java:3:9](#finding-685)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-685)|
|<a id="finding-686"></a>[copy-004/tuning/variants/dead.java:1:55](#finding-686)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-686)|
|<a id="finding-687"></a>[copy-005/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-687)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-687)|
|<a id="finding-688"></a>[copy-005/tuning/Example.java:3:9](#finding-688)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-688)|
|<a id="finding-689"></a>[copy-005/tuning/variants/dead.java:1:55](#finding-689)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-689)|
|<a id="finding-690"></a>[copy-006/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-690)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-690)|
|<a id="finding-691"></a>[copy-006/tuning/Example.java:3:9](#finding-691)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-691)|
|<a id="finding-692"></a>[copy-006/tuning/variants/dead.java:1:55](#finding-692)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-692)|
|<a id="finding-693"></a>[copy-007/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-693)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-693)|
|<a id="finding-694"></a>[copy-007/tuning/Example.java:3:9](#finding-694)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-694)|
|<a id="finding-695"></a>[copy-007/tuning/variants/dead.java:1:55](#finding-695)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-695)|
|<a id="finding-696"></a>[copy-008/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-696)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-696)|
|<a id="finding-697"></a>[copy-008/tuning/Example.java:3:9](#finding-697)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-697)|
|<a id="finding-698"></a>[copy-008/tuning/variants/dead.java:1:55](#finding-698)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-698)|
|<a id="finding-699"></a>[copy-009/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-699)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-699)|
|<a id="finding-700"></a>[copy-009/tuning/Example.java:3:9](#finding-700)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-700)|
|<a id="finding-701"></a>[copy-009/tuning/variants/dead.java:1:55](#finding-701)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-701)|
|<a id="finding-702"></a>[copy-010/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-702)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-702)|
|<a id="finding-703"></a>[copy-010/tuning/Example.java:3:9](#finding-703)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-703)|
|<a id="finding-704"></a>[copy-010/tuning/variants/dead.java:1:55](#finding-704)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-704)|
|<a id="finding-705"></a>[copy-011/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-705)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-705)|
|<a id="finding-706"></a>[copy-011/tuning/Example.java:3:9](#finding-706)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-706)|
|<a id="finding-707"></a>[copy-011/tuning/variants/dead.java:1:55](#finding-707)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-707)|
|<a id="finding-708"></a>[copy-012/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-708)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-708)|
|<a id="finding-709"></a>[copy-012/tuning/Example.java:3:9](#finding-709)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-709)|
|<a id="finding-710"></a>[copy-012/tuning/variants/dead.java:1:55](#finding-710)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-710)|
|<a id="finding-711"></a>[copy-013/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-711)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-711)|
|<a id="finding-712"></a>[copy-013/tuning/Example.java:3:9](#finding-712)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-712)|
|<a id="finding-713"></a>[copy-013/tuning/variants/dead.java:1:55](#finding-713)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-713)|
|<a id="finding-714"></a>[copy-014/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-714)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-714)|
|<a id="finding-715"></a>[copy-014/tuning/Example.java:3:9](#finding-715)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-715)|
|<a id="finding-716"></a>[copy-014/tuning/variants/dead.java:1:55](#finding-716)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-716)|
|<a id="finding-717"></a>[copy-015/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-717)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-717)|
|<a id="finding-718"></a>[copy-015/tuning/Example.java:3:9](#finding-718)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-718)|
|<a id="finding-719"></a>[copy-015/tuning/variants/dead.java:1:55](#finding-719)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-719)|
|<a id="finding-720"></a>[copy-016/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-720)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-720)|
|<a id="finding-721"></a>[copy-016/tuning/Example.java:3:9](#finding-721)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-721)|
|<a id="finding-722"></a>[copy-016/tuning/variants/dead.java:1:55](#finding-722)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-722)|
|<a id="finding-723"></a>[copy-017/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-723)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-723)|
|<a id="finding-724"></a>[copy-017/tuning/Example.java:3:9](#finding-724)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-724)|
|<a id="finding-725"></a>[copy-017/tuning/variants/dead.java:1:55](#finding-725)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-725)|
|<a id="finding-726"></a>[copy-018/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-726)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-726)|
|<a id="finding-727"></a>[copy-018/tuning/Example.java:3:9](#finding-727)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-727)|
|<a id="finding-728"></a>[copy-018/tuning/variants/dead.java:1:55](#finding-728)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-728)|
|<a id="finding-729"></a>[copy-019/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-729)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-729)|
|<a id="finding-730"></a>[copy-019/tuning/Example.java:3:9](#finding-730)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-730)|
|<a id="finding-731"></a>[copy-019/tuning/variants/dead.java:1:55](#finding-731)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-731)|
|<a id="finding-732"></a>[copy-020/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-732)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-732)|
|<a id="finding-733"></a>[copy-020/tuning/Example.java:3:9](#finding-733)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-733)|
|<a id="finding-734"></a>[copy-020/tuning/variants/dead.java:1:55](#finding-734)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-734)|
|<a id="finding-735"></a>[copy-021/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-735)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-735)|
|<a id="finding-736"></a>[copy-021/tuning/Example.java:3:9](#finding-736)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-736)|
|<a id="finding-737"></a>[copy-021/tuning/variants/dead.java:1:55](#finding-737)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-737)|
|<a id="finding-738"></a>[copy-022/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-738)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-738)|
|<a id="finding-739"></a>[copy-022/tuning/Example.java:3:9](#finding-739)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-739)|
|<a id="finding-740"></a>[copy-022/tuning/variants/dead.java:1:55](#finding-740)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-740)|
|<a id="finding-741"></a>[copy-023/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-741)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-741)|
|<a id="finding-742"></a>[copy-023/tuning/Example.java:3:9](#finding-742)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-742)|
|<a id="finding-743"></a>[copy-023/tuning/variants/dead.java:1:55](#finding-743)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-743)|
|<a id="finding-744"></a>[copy-024/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-744)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-744)|
|<a id="finding-745"></a>[copy-024/tuning/Example.java:3:9](#finding-745)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-745)|
|<a id="finding-746"></a>[copy-024/tuning/variants/dead.java:1:55](#finding-746)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-746)|
|<a id="finding-747"></a>[copy-025/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-747)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-747)|
|<a id="finding-748"></a>[copy-025/tuning/Example.java:3:9](#finding-748)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-748)|
|<a id="finding-749"></a>[copy-025/tuning/variants/dead.java:1:55](#finding-749)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-749)|
|<a id="finding-750"></a>[copy-026/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-750)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-750)|
|<a id="finding-751"></a>[copy-026/tuning/Example.java:3:9](#finding-751)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-751)|
|<a id="finding-752"></a>[copy-026/tuning/variants/dead.java:1:55](#finding-752)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-752)|
|<a id="finding-753"></a>[copy-027/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-753)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-753)|
|<a id="finding-754"></a>[copy-027/tuning/Example.java:3:9](#finding-754)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-754)|
|<a id="finding-755"></a>[copy-027/tuning/variants/dead.java:1:55](#finding-755)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-755)|
|<a id="finding-756"></a>[copy-028/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-756)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-756)|
|<a id="finding-757"></a>[copy-028/tuning/Example.java:3:9](#finding-757)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-757)|
|<a id="finding-758"></a>[copy-028/tuning/variants/dead.java:1:55](#finding-758)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-758)|
|<a id="finding-759"></a>[copy-029/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-759)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-759)|
|<a id="finding-760"></a>[copy-029/tuning/Example.java:3:9](#finding-760)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-760)|
|<a id="finding-761"></a>[copy-029/tuning/variants/dead.java:1:55](#finding-761)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-761)|
|<a id="finding-762"></a>[copy-030/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-762)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-762)|
|<a id="finding-763"></a>[copy-030/tuning/Example.java:3:9](#finding-763)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-763)|
|<a id="finding-764"></a>[copy-030/tuning/variants/dead.java:1:55](#finding-764)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-764)|
|<a id="finding-765"></a>[copy-031/holdout/approval-adapter/ApprovalEnvelope.java:5:29](#finding-765)|KEM.getI***L-KEM"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-765)|
|<a id="finding-766"></a>[copy-031/tuning/Example.java:3:9](#finding-766)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-766)|
|<a id="finding-767"></a>[copy-031/tuning/variants/dead.java:1:55](#finding-767)|Signatur***L-DSA"|JDK 24+ provides ML-KEM and ML-DSA; verify provider and protocol support independently. / [Source](#source-767)|

<a id="source-672"></a>

### copy-000/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-673"></a>

### copy-000/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-674"></a>

### copy-000/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-675"></a>

### copy-001/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-676"></a>

### copy-001/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-677"></a>

### copy-001/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-678"></a>

### copy-002/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-679"></a>

### copy-002/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-680"></a>

### copy-002/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-681"></a>

### copy-003/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-682"></a>

### copy-003/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-683"></a>

### copy-003/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-684"></a>

### copy-004/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-685"></a>

### copy-004/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-686"></a>

### copy-004/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-687"></a>

### copy-005/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-688"></a>

### copy-005/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-689"></a>

### copy-005/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-690"></a>

### copy-006/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-691"></a>

### copy-006/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-692"></a>

### copy-006/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-693"></a>

### copy-007/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-694"></a>

### copy-007/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-695"></a>

### copy-007/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-696"></a>

### copy-008/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-697"></a>

### copy-008/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-698"></a>

### copy-008/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-699"></a>

### copy-009/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-700"></a>

### copy-009/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-701"></a>

### copy-009/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-702"></a>

### copy-010/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-703"></a>

### copy-010/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-704"></a>

### copy-010/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-705"></a>

### copy-011/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-706"></a>

### copy-011/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-707"></a>

### copy-011/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-708"></a>

### copy-012/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-709"></a>

### copy-012/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-710"></a>

### copy-012/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-711"></a>

### copy-013/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-712"></a>

### copy-013/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-713"></a>

### copy-013/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-714"></a>

### copy-014/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-715"></a>

### copy-014/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-716"></a>

### copy-014/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-717"></a>

### copy-015/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-718"></a>

### copy-015/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-719"></a>

### copy-015/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-720"></a>

### copy-016/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-721"></a>

### copy-016/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-722"></a>

### copy-016/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-723"></a>

### copy-017/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-724"></a>

### copy-017/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-725"></a>

### copy-017/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-726"></a>

### copy-018/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-727"></a>

### copy-018/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-728"></a>

### copy-018/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-729"></a>

### copy-019/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-730"></a>

### copy-019/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-731"></a>

### copy-019/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-732"></a>

### copy-020/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-733"></a>

### copy-020/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-734"></a>

### copy-020/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-735"></a>

### copy-021/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-736"></a>

### copy-021/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-737"></a>

### copy-021/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-738"></a>

### copy-022/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-739"></a>

### copy-022/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-740"></a>

### copy-022/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-741"></a>

### copy-023/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-742"></a>

### copy-023/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-743"></a>

### copy-023/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-744"></a>

### copy-024/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-745"></a>

### copy-024/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-746"></a>

### copy-024/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-747"></a>

### copy-025/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-748"></a>

### copy-025/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-749"></a>

### copy-025/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-750"></a>

### copy-026/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-751"></a>

### copy-026/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-752"></a>

### copy-026/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-753"></a>

### copy-027/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-754"></a>

### copy-027/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-755"></a>

### copy-027/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-756"></a>

### copy-028/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-757"></a>

### copy-028/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-758"></a>

### copy-028/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-759"></a>

### copy-029/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-760"></a>

### copy-029/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-761"></a>

### copy-029/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-762"></a>

### copy-030/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-763"></a>

### copy-030/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-764"></a>

### copy-030/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="source-765"></a>

### copy-031/holdout/approval-adapter/ApprovalEnvelope.java:5:29

      3 final class ApprovalEnvelope {
      4     Object recipientMechanism() throws Exception {
    > 5         return javax.crypto.KEM.getInstance(
      6             "ML-KEM"
      7         );

<a id="source-766"></a>

### copy-031/tuning/Example.java:3:9

      1 class Example {
      2     void inspect() throws Exception {
    > 3         Signature.getInstance("ML-DSA");
      4     }
      5 }

<a id="source-767"></a>

### copy-031/tuning/variants/dead.java:1:55

    > 1 class Dead { void f() throws Exception { if (false) { Signature.getInstance("ML-DSA"); } } }

<a id="rule-17"></a>

## PQC_NODE_API

Node-style PQC key generation call; bindings and actual execution require confirmation.

Check: Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-768"></a>[copy-000/holdout/approval-adapter/rotation_queue.js:6:3](#finding-768)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-768)|
|<a id="finding-769"></a>[copy-000/tuning/example.js:1:1](#finding-769)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-769)|
|<a id="finding-770"></a>[copy-000/tuning/variants/alias.js:2:1](#finding-770)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-770)|
|<a id="finding-771"></a>[copy-000/tuning/variants/twice.js:1:1](#finding-771)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-771)|
|<a id="finding-772"></a>[copy-000/tuning/variants/twice.js:1:36](#finding-772)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-772)|
|<a id="finding-773"></a>[copy-001/holdout/approval-adapter/rotation_queue.js:6:3](#finding-773)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-773)|
|<a id="finding-774"></a>[copy-001/tuning/example.js:1:1](#finding-774)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-774)|
|<a id="finding-775"></a>[copy-001/tuning/variants/alias.js:2:1](#finding-775)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-775)|
|<a id="finding-776"></a>[copy-001/tuning/variants/twice.js:1:1](#finding-776)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-776)|
|<a id="finding-777"></a>[copy-001/tuning/variants/twice.js:1:36](#finding-777)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-777)|
|<a id="finding-778"></a>[copy-002/holdout/approval-adapter/rotation_queue.js:6:3](#finding-778)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-778)|
|<a id="finding-779"></a>[copy-002/tuning/example.js:1:1](#finding-779)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-779)|
|<a id="finding-780"></a>[copy-002/tuning/variants/alias.js:2:1](#finding-780)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-780)|
|<a id="finding-781"></a>[copy-002/tuning/variants/twice.js:1:1](#finding-781)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-781)|
|<a id="finding-782"></a>[copy-002/tuning/variants/twice.js:1:36](#finding-782)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-782)|
|<a id="finding-783"></a>[copy-003/holdout/approval-adapter/rotation_queue.js:6:3](#finding-783)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-783)|
|<a id="finding-784"></a>[copy-003/tuning/example.js:1:1](#finding-784)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-784)|
|<a id="finding-785"></a>[copy-003/tuning/variants/alias.js:2:1](#finding-785)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-785)|
|<a id="finding-786"></a>[copy-003/tuning/variants/twice.js:1:1](#finding-786)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-786)|
|<a id="finding-787"></a>[copy-003/tuning/variants/twice.js:1:36](#finding-787)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-787)|
|<a id="finding-788"></a>[copy-004/holdout/approval-adapter/rotation_queue.js:6:3](#finding-788)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-788)|
|<a id="finding-789"></a>[copy-004/tuning/example.js:1:1](#finding-789)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-789)|
|<a id="finding-790"></a>[copy-004/tuning/variants/alias.js:2:1](#finding-790)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-790)|
|<a id="finding-791"></a>[copy-004/tuning/variants/twice.js:1:1](#finding-791)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-791)|
|<a id="finding-792"></a>[copy-004/tuning/variants/twice.js:1:36](#finding-792)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-792)|
|<a id="finding-793"></a>[copy-005/holdout/approval-adapter/rotation_queue.js:6:3](#finding-793)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-793)|
|<a id="finding-794"></a>[copy-005/tuning/example.js:1:1](#finding-794)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-794)|
|<a id="finding-795"></a>[copy-005/tuning/variants/alias.js:2:1](#finding-795)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-795)|
|<a id="finding-796"></a>[copy-005/tuning/variants/twice.js:1:1](#finding-796)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-796)|
|<a id="finding-797"></a>[copy-005/tuning/variants/twice.js:1:36](#finding-797)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-797)|
|<a id="finding-798"></a>[copy-006/holdout/approval-adapter/rotation_queue.js:6:3](#finding-798)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-798)|
|<a id="finding-799"></a>[copy-006/tuning/example.js:1:1](#finding-799)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-799)|
|<a id="finding-800"></a>[copy-006/tuning/variants/alias.js:2:1](#finding-800)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-800)|
|<a id="finding-801"></a>[copy-006/tuning/variants/twice.js:1:1](#finding-801)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-801)|
|<a id="finding-802"></a>[copy-006/tuning/variants/twice.js:1:36](#finding-802)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-802)|
|<a id="finding-803"></a>[copy-007/holdout/approval-adapter/rotation_queue.js:6:3](#finding-803)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-803)|
|<a id="finding-804"></a>[copy-007/tuning/example.js:1:1](#finding-804)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-804)|
|<a id="finding-805"></a>[copy-007/tuning/variants/alias.js:2:1](#finding-805)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-805)|
|<a id="finding-806"></a>[copy-007/tuning/variants/twice.js:1:1](#finding-806)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-806)|
|<a id="finding-807"></a>[copy-007/tuning/variants/twice.js:1:36](#finding-807)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-807)|
|<a id="finding-808"></a>[copy-008/holdout/approval-adapter/rotation_queue.js:6:3](#finding-808)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-808)|
|<a id="finding-809"></a>[copy-008/tuning/example.js:1:1](#finding-809)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-809)|
|<a id="finding-810"></a>[copy-008/tuning/variants/alias.js:2:1](#finding-810)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-810)|
|<a id="finding-811"></a>[copy-008/tuning/variants/twice.js:1:1](#finding-811)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-811)|
|<a id="finding-812"></a>[copy-008/tuning/variants/twice.js:1:36](#finding-812)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-812)|
|<a id="finding-813"></a>[copy-009/holdout/approval-adapter/rotation_queue.js:6:3](#finding-813)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-813)|
|<a id="finding-814"></a>[copy-009/tuning/example.js:1:1](#finding-814)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-814)|
|<a id="finding-815"></a>[copy-009/tuning/variants/alias.js:2:1](#finding-815)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-815)|
|<a id="finding-816"></a>[copy-009/tuning/variants/twice.js:1:1](#finding-816)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-816)|
|<a id="finding-817"></a>[copy-009/tuning/variants/twice.js:1:36](#finding-817)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-817)|
|<a id="finding-818"></a>[copy-010/holdout/approval-adapter/rotation_queue.js:6:3](#finding-818)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-818)|
|<a id="finding-819"></a>[copy-010/tuning/example.js:1:1](#finding-819)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-819)|
|<a id="finding-820"></a>[copy-010/tuning/variants/alias.js:2:1](#finding-820)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-820)|
|<a id="finding-821"></a>[copy-010/tuning/variants/twice.js:1:1](#finding-821)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-821)|
|<a id="finding-822"></a>[copy-010/tuning/variants/twice.js:1:36](#finding-822)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-822)|
|<a id="finding-823"></a>[copy-011/holdout/approval-adapter/rotation_queue.js:6:3](#finding-823)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-823)|
|<a id="finding-824"></a>[copy-011/tuning/example.js:1:1](#finding-824)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-824)|
|<a id="finding-825"></a>[copy-011/tuning/variants/alias.js:2:1](#finding-825)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-825)|
|<a id="finding-826"></a>[copy-011/tuning/variants/twice.js:1:1](#finding-826)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-826)|
|<a id="finding-827"></a>[copy-011/tuning/variants/twice.js:1:36](#finding-827)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-827)|
|<a id="finding-828"></a>[copy-012/holdout/approval-adapter/rotation_queue.js:6:3](#finding-828)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-828)|
|<a id="finding-829"></a>[copy-012/tuning/example.js:1:1](#finding-829)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-829)|
|<a id="finding-830"></a>[copy-012/tuning/variants/alias.js:2:1](#finding-830)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-830)|
|<a id="finding-831"></a>[copy-012/tuning/variants/twice.js:1:1](#finding-831)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-831)|
|<a id="finding-832"></a>[copy-012/tuning/variants/twice.js:1:36](#finding-832)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-832)|
|<a id="finding-833"></a>[copy-013/holdout/approval-adapter/rotation_queue.js:6:3](#finding-833)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-833)|
|<a id="finding-834"></a>[copy-013/tuning/example.js:1:1](#finding-834)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-834)|
|<a id="finding-835"></a>[copy-013/tuning/variants/alias.js:2:1](#finding-835)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-835)|
|<a id="finding-836"></a>[copy-013/tuning/variants/twice.js:1:1](#finding-836)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-836)|
|<a id="finding-837"></a>[copy-013/tuning/variants/twice.js:1:36](#finding-837)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-837)|
|<a id="finding-838"></a>[copy-014/holdout/approval-adapter/rotation_queue.js:6:3](#finding-838)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-838)|
|<a id="finding-839"></a>[copy-014/tuning/example.js:1:1](#finding-839)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-839)|
|<a id="finding-840"></a>[copy-014/tuning/variants/alias.js:2:1](#finding-840)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-840)|
|<a id="finding-841"></a>[copy-014/tuning/variants/twice.js:1:1](#finding-841)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-841)|
|<a id="finding-842"></a>[copy-014/tuning/variants/twice.js:1:36](#finding-842)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-842)|
|<a id="finding-843"></a>[copy-015/holdout/approval-adapter/rotation_queue.js:6:3](#finding-843)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-843)|
|<a id="finding-844"></a>[copy-015/tuning/example.js:1:1](#finding-844)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-844)|
|<a id="finding-845"></a>[copy-015/tuning/variants/alias.js:2:1](#finding-845)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-845)|
|<a id="finding-846"></a>[copy-015/tuning/variants/twice.js:1:1](#finding-846)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-846)|
|<a id="finding-847"></a>[copy-015/tuning/variants/twice.js:1:36](#finding-847)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-847)|
|<a id="finding-848"></a>[copy-016/holdout/approval-adapter/rotation_queue.js:6:3](#finding-848)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-848)|
|<a id="finding-849"></a>[copy-016/tuning/example.js:1:1](#finding-849)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-849)|
|<a id="finding-850"></a>[copy-016/tuning/variants/alias.js:2:1](#finding-850)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-850)|
|<a id="finding-851"></a>[copy-016/tuning/variants/twice.js:1:1](#finding-851)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-851)|
|<a id="finding-852"></a>[copy-016/tuning/variants/twice.js:1:36](#finding-852)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-852)|
|<a id="finding-853"></a>[copy-017/holdout/approval-adapter/rotation_queue.js:6:3](#finding-853)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-853)|
|<a id="finding-854"></a>[copy-017/tuning/example.js:1:1](#finding-854)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-854)|
|<a id="finding-855"></a>[copy-017/tuning/variants/alias.js:2:1](#finding-855)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-855)|
|<a id="finding-856"></a>[copy-017/tuning/variants/twice.js:1:1](#finding-856)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-856)|
|<a id="finding-857"></a>[copy-017/tuning/variants/twice.js:1:36](#finding-857)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-857)|
|<a id="finding-858"></a>[copy-018/holdout/approval-adapter/rotation_queue.js:6:3](#finding-858)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-858)|
|<a id="finding-859"></a>[copy-018/tuning/example.js:1:1](#finding-859)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-859)|
|<a id="finding-860"></a>[copy-018/tuning/variants/alias.js:2:1](#finding-860)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-860)|
|<a id="finding-861"></a>[copy-018/tuning/variants/twice.js:1:1](#finding-861)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-861)|
|<a id="finding-862"></a>[copy-018/tuning/variants/twice.js:1:36](#finding-862)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-862)|
|<a id="finding-863"></a>[copy-019/holdout/approval-adapter/rotation_queue.js:6:3](#finding-863)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-863)|
|<a id="finding-864"></a>[copy-019/tuning/example.js:1:1](#finding-864)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-864)|
|<a id="finding-865"></a>[copy-019/tuning/variants/alias.js:2:1](#finding-865)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-865)|
|<a id="finding-866"></a>[copy-019/tuning/variants/twice.js:1:1](#finding-866)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-866)|
|<a id="finding-867"></a>[copy-019/tuning/variants/twice.js:1:36](#finding-867)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-867)|
|<a id="finding-868"></a>[copy-020/holdout/approval-adapter/rotation_queue.js:6:3](#finding-868)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-868)|
|<a id="finding-869"></a>[copy-020/tuning/example.js:1:1](#finding-869)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-869)|
|<a id="finding-870"></a>[copy-020/tuning/variants/alias.js:2:1](#finding-870)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-870)|
|<a id="finding-871"></a>[copy-020/tuning/variants/twice.js:1:1](#finding-871)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-871)|
|<a id="finding-872"></a>[copy-020/tuning/variants/twice.js:1:36](#finding-872)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-872)|
|<a id="finding-873"></a>[copy-021/holdout/approval-adapter/rotation_queue.js:6:3](#finding-873)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-873)|
|<a id="finding-874"></a>[copy-021/tuning/example.js:1:1](#finding-874)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-874)|
|<a id="finding-875"></a>[copy-021/tuning/variants/alias.js:2:1](#finding-875)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-875)|
|<a id="finding-876"></a>[copy-021/tuning/variants/twice.js:1:1](#finding-876)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-876)|
|<a id="finding-877"></a>[copy-021/tuning/variants/twice.js:1:36](#finding-877)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-877)|
|<a id="finding-878"></a>[copy-022/holdout/approval-adapter/rotation_queue.js:6:3](#finding-878)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-878)|
|<a id="finding-879"></a>[copy-022/tuning/example.js:1:1](#finding-879)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-879)|
|<a id="finding-880"></a>[copy-022/tuning/variants/alias.js:2:1](#finding-880)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-880)|
|<a id="finding-881"></a>[copy-022/tuning/variants/twice.js:1:1](#finding-881)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-881)|
|<a id="finding-882"></a>[copy-022/tuning/variants/twice.js:1:36](#finding-882)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-882)|
|<a id="finding-883"></a>[copy-023/holdout/approval-adapter/rotation_queue.js:6:3](#finding-883)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-883)|
|<a id="finding-884"></a>[copy-023/tuning/example.js:1:1](#finding-884)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-884)|
|<a id="finding-885"></a>[copy-023/tuning/variants/alias.js:2:1](#finding-885)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-885)|
|<a id="finding-886"></a>[copy-023/tuning/variants/twice.js:1:1](#finding-886)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-886)|
|<a id="finding-887"></a>[copy-023/tuning/variants/twice.js:1:36](#finding-887)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-887)|
|<a id="finding-888"></a>[copy-024/holdout/approval-adapter/rotation_queue.js:6:3](#finding-888)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-888)|
|<a id="finding-889"></a>[copy-024/tuning/example.js:1:1](#finding-889)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-889)|
|<a id="finding-890"></a>[copy-024/tuning/variants/alias.js:2:1](#finding-890)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-890)|
|<a id="finding-891"></a>[copy-024/tuning/variants/twice.js:1:1](#finding-891)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-891)|
|<a id="finding-892"></a>[copy-024/tuning/variants/twice.js:1:36](#finding-892)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-892)|
|<a id="finding-893"></a>[copy-025/holdout/approval-adapter/rotation_queue.js:6:3](#finding-893)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-893)|
|<a id="finding-894"></a>[copy-025/tuning/example.js:1:1](#finding-894)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-894)|
|<a id="finding-895"></a>[copy-025/tuning/variants/alias.js:2:1](#finding-895)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-895)|
|<a id="finding-896"></a>[copy-025/tuning/variants/twice.js:1:1](#finding-896)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-896)|
|<a id="finding-897"></a>[copy-025/tuning/variants/twice.js:1:36](#finding-897)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-897)|
|<a id="finding-898"></a>[copy-026/holdout/approval-adapter/rotation_queue.js:6:3](#finding-898)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-898)|
|<a id="finding-899"></a>[copy-026/tuning/example.js:1:1](#finding-899)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-899)|
|<a id="finding-900"></a>[copy-026/tuning/variants/alias.js:2:1](#finding-900)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-900)|
|<a id="finding-901"></a>[copy-026/tuning/variants/twice.js:1:1](#finding-901)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-901)|
|<a id="finding-902"></a>[copy-026/tuning/variants/twice.js:1:36](#finding-902)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-902)|
|<a id="finding-903"></a>[copy-027/holdout/approval-adapter/rotation_queue.js:6:3](#finding-903)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-903)|
|<a id="finding-904"></a>[copy-027/tuning/example.js:1:1](#finding-904)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-904)|
|<a id="finding-905"></a>[copy-027/tuning/variants/alias.js:2:1](#finding-905)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-905)|
|<a id="finding-906"></a>[copy-027/tuning/variants/twice.js:1:1](#finding-906)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-906)|
|<a id="finding-907"></a>[copy-027/tuning/variants/twice.js:1:36](#finding-907)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-907)|
|<a id="finding-908"></a>[copy-028/holdout/approval-adapter/rotation_queue.js:6:3](#finding-908)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-908)|
|<a id="finding-909"></a>[copy-028/tuning/example.js:1:1](#finding-909)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-909)|
|<a id="finding-910"></a>[copy-028/tuning/variants/alias.js:2:1](#finding-910)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-910)|
|<a id="finding-911"></a>[copy-028/tuning/variants/twice.js:1:1](#finding-911)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-911)|
|<a id="finding-912"></a>[copy-028/tuning/variants/twice.js:1:36](#finding-912)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-912)|
|<a id="finding-913"></a>[copy-029/holdout/approval-adapter/rotation_queue.js:6:3](#finding-913)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-913)|
|<a id="finding-914"></a>[copy-029/tuning/example.js:1:1](#finding-914)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-914)|
|<a id="finding-915"></a>[copy-029/tuning/variants/alias.js:2:1](#finding-915)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-915)|
|<a id="finding-916"></a>[copy-029/tuning/variants/twice.js:1:1](#finding-916)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-916)|
|<a id="finding-917"></a>[copy-029/tuning/variants/twice.js:1:36](#finding-917)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-917)|
|<a id="finding-918"></a>[copy-030/holdout/approval-adapter/rotation_queue.js:6:3](#finding-918)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-918)|
|<a id="finding-919"></a>[copy-030/tuning/example.js:1:1](#finding-919)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-919)|
|<a id="finding-920"></a>[copy-030/tuning/variants/alias.js:2:1](#finding-920)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-920)|
|<a id="finding-921"></a>[copy-030/tuning/variants/twice.js:1:1](#finding-921)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-921)|
|<a id="finding-922"></a>[copy-030/tuning/variants/twice.js:1:36](#finding-922)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-922)|
|<a id="finding-923"></a>[copy-031/holdout/approval-adapter/rotation_queue.js:6:3](#finding-923)|nodeCryp***sa-87'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-923)|
|<a id="finding-924"></a>[copy-031/tuning/example.js:1:1](#finding-924)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-924)|
|<a id="finding-925"></a>[copy-031/tuning/variants/alias.js:2:1](#finding-925)|pair('ml-kem-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-925)|
|<a id="finding-926"></a>[copy-031/tuning/variants/twice.js:1:1](#finding-926)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-926)|
|<a id="finding-927"></a>[copy-031/tuning/variants/twice.js:1:36](#finding-927)|generate***m-768'|Node crypto requires 24.6+ for ML-DSA, 24.7+ for ML-KEM, and 24.8+ for SLH-DSA. Check runtime support. / [Source](#source-927)|

<a id="source-768"></a>

### copy-000/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-769"></a>

### copy-000/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-770"></a>

### copy-000/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-771"></a>

### copy-000/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-772"></a>

### copy-000/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-773"></a>

### copy-001/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-774"></a>

### copy-001/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-775"></a>

### copy-001/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-776"></a>

### copy-001/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-777"></a>

### copy-001/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-778"></a>

### copy-002/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-779"></a>

### copy-002/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-780"></a>

### copy-002/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-781"></a>

### copy-002/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-782"></a>

### copy-002/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-783"></a>

### copy-003/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-784"></a>

### copy-003/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-785"></a>

### copy-003/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-786"></a>

### copy-003/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-787"></a>

### copy-003/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-788"></a>

### copy-004/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-789"></a>

### copy-004/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-790"></a>

### copy-004/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-791"></a>

### copy-004/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-792"></a>

### copy-004/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-793"></a>

### copy-005/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-794"></a>

### copy-005/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-795"></a>

### copy-005/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-796"></a>

### copy-005/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-797"></a>

### copy-005/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-798"></a>

### copy-006/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-799"></a>

### copy-006/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-800"></a>

### copy-006/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-801"></a>

### copy-006/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-802"></a>

### copy-006/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-803"></a>

### copy-007/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-804"></a>

### copy-007/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-805"></a>

### copy-007/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-806"></a>

### copy-007/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-807"></a>

### copy-007/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-808"></a>

### copy-008/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-809"></a>

### copy-008/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-810"></a>

### copy-008/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-811"></a>

### copy-008/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-812"></a>

### copy-008/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-813"></a>

### copy-009/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-814"></a>

### copy-009/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-815"></a>

### copy-009/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-816"></a>

### copy-009/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-817"></a>

### copy-009/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-818"></a>

### copy-010/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-819"></a>

### copy-010/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-820"></a>

### copy-010/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-821"></a>

### copy-010/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-822"></a>

### copy-010/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-823"></a>

### copy-011/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-824"></a>

### copy-011/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-825"></a>

### copy-011/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-826"></a>

### copy-011/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-827"></a>

### copy-011/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-828"></a>

### copy-012/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-829"></a>

### copy-012/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-830"></a>

### copy-012/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-831"></a>

### copy-012/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-832"></a>

### copy-012/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-833"></a>

### copy-013/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-834"></a>

### copy-013/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-835"></a>

### copy-013/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-836"></a>

### copy-013/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-837"></a>

### copy-013/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-838"></a>

### copy-014/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-839"></a>

### copy-014/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-840"></a>

### copy-014/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-841"></a>

### copy-014/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-842"></a>

### copy-014/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-843"></a>

### copy-015/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-844"></a>

### copy-015/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-845"></a>

### copy-015/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-846"></a>

### copy-015/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-847"></a>

### copy-015/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-848"></a>

### copy-016/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-849"></a>

### copy-016/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-850"></a>

### copy-016/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-851"></a>

### copy-016/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-852"></a>

### copy-016/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-853"></a>

### copy-017/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-854"></a>

### copy-017/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-855"></a>

### copy-017/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-856"></a>

### copy-017/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-857"></a>

### copy-017/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-858"></a>

### copy-018/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-859"></a>

### copy-018/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-860"></a>

### copy-018/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-861"></a>

### copy-018/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-862"></a>

### copy-018/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-863"></a>

### copy-019/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-864"></a>

### copy-019/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-865"></a>

### copy-019/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-866"></a>

### copy-019/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-867"></a>

### copy-019/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-868"></a>

### copy-020/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-869"></a>

### copy-020/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-870"></a>

### copy-020/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-871"></a>

### copy-020/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-872"></a>

### copy-020/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-873"></a>

### copy-021/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-874"></a>

### copy-021/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-875"></a>

### copy-021/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-876"></a>

### copy-021/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-877"></a>

### copy-021/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-878"></a>

### copy-022/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-879"></a>

### copy-022/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-880"></a>

### copy-022/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-881"></a>

### copy-022/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-882"></a>

### copy-022/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-883"></a>

### copy-023/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-884"></a>

### copy-023/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-885"></a>

### copy-023/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-886"></a>

### copy-023/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-887"></a>

### copy-023/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-888"></a>

### copy-024/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-889"></a>

### copy-024/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-890"></a>

### copy-024/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-891"></a>

### copy-024/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-892"></a>

### copy-024/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-893"></a>

### copy-025/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-894"></a>

### copy-025/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-895"></a>

### copy-025/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-896"></a>

### copy-025/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-897"></a>

### copy-025/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-898"></a>

### copy-026/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-899"></a>

### copy-026/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-900"></a>

### copy-026/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-901"></a>

### copy-026/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-902"></a>

### copy-026/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-903"></a>

### copy-027/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-904"></a>

### copy-027/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-905"></a>

### copy-027/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-906"></a>

### copy-027/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-907"></a>

### copy-027/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-908"></a>

### copy-028/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-909"></a>

### copy-028/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-910"></a>

### copy-028/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-911"></a>

### copy-028/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-912"></a>

### copy-028/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-913"></a>

### copy-029/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-914"></a>

### copy-029/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-915"></a>

### copy-029/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-916"></a>

### copy-029/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-917"></a>

### copy-029/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-918"></a>

### copy-030/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-919"></a>

### copy-030/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-920"></a>

### copy-030/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-921"></a>

### copy-030/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-922"></a>

### copy-030/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-923"></a>

### copy-031/holdout/approval-adapter/rotation_queue.js:6:3

      4 
      5 export function prepareApprovalRotation(recordCompletion) {
    > 6   nodeCrypto.generateKeyPair(
      7     'ml-dsa-87',
      8     recordCompletion

<a id="source-924"></a>

### copy-031/tuning/example.js:1:1

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-925"></a>

### copy-031/tuning/variants/alias.js:2:1

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-926"></a>

### copy-031/tuning/variants/twice.js:1:1

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-927"></a>

### copy-031/tuning/variants/twice.js:1:36

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="rule-18"></a>

## PQC_PYTHON_API

Python PQC key generation reference; backend support is not established.

Check: cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-928"></a>[copy-000/holdout/approval-adapter/approval_backend.py:3:1](#finding-928)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-928)|
|<a id="finding-929"></a>[copy-000/tuning/example.py:1:1](#finding-929)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-929)|
|<a id="finding-930"></a>[copy-000/tuning/variants/alias.py:1:1](#finding-930)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-930)|
|<a id="finding-931"></a>[copy-000/tuning/variants/alias.py:2:1](#finding-931)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-931)|
|<a id="finding-932"></a>[copy-000/tuning/variants/broken.py:1:1](#finding-932)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-932)|
|<a id="finding-933"></a>[copy-001/holdout/approval-adapter/approval_backend.py:3:1](#finding-933)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-933)|
|<a id="finding-934"></a>[copy-001/tuning/example.py:1:1](#finding-934)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-934)|
|<a id="finding-935"></a>[copy-001/tuning/variants/alias.py:1:1](#finding-935)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-935)|
|<a id="finding-936"></a>[copy-001/tuning/variants/alias.py:2:1](#finding-936)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-936)|
|<a id="finding-937"></a>[copy-001/tuning/variants/broken.py:1:1](#finding-937)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-937)|
|<a id="finding-938"></a>[copy-002/holdout/approval-adapter/approval_backend.py:3:1](#finding-938)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-938)|
|<a id="finding-939"></a>[copy-002/tuning/example.py:1:1](#finding-939)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-939)|
|<a id="finding-940"></a>[copy-002/tuning/variants/alias.py:1:1](#finding-940)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-940)|
|<a id="finding-941"></a>[copy-002/tuning/variants/alias.py:2:1](#finding-941)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-941)|
|<a id="finding-942"></a>[copy-002/tuning/variants/broken.py:1:1](#finding-942)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-942)|
|<a id="finding-943"></a>[copy-003/holdout/approval-adapter/approval_backend.py:3:1](#finding-943)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-943)|
|<a id="finding-944"></a>[copy-003/tuning/example.py:1:1](#finding-944)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-944)|
|<a id="finding-945"></a>[copy-003/tuning/variants/alias.py:1:1](#finding-945)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-945)|
|<a id="finding-946"></a>[copy-003/tuning/variants/alias.py:2:1](#finding-946)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-946)|
|<a id="finding-947"></a>[copy-003/tuning/variants/broken.py:1:1](#finding-947)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-947)|
|<a id="finding-948"></a>[copy-004/holdout/approval-adapter/approval_backend.py:3:1](#finding-948)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-948)|
|<a id="finding-949"></a>[copy-004/tuning/example.py:1:1](#finding-949)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-949)|
|<a id="finding-950"></a>[copy-004/tuning/variants/alias.py:1:1](#finding-950)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-950)|
|<a id="finding-951"></a>[copy-004/tuning/variants/alias.py:2:1](#finding-951)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-951)|
|<a id="finding-952"></a>[copy-004/tuning/variants/broken.py:1:1](#finding-952)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-952)|
|<a id="finding-953"></a>[copy-005/holdout/approval-adapter/approval_backend.py:3:1](#finding-953)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-953)|
|<a id="finding-954"></a>[copy-005/tuning/example.py:1:1](#finding-954)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-954)|
|<a id="finding-955"></a>[copy-005/tuning/variants/alias.py:1:1](#finding-955)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-955)|
|<a id="finding-956"></a>[copy-005/tuning/variants/alias.py:2:1](#finding-956)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-956)|
|<a id="finding-957"></a>[copy-005/tuning/variants/broken.py:1:1](#finding-957)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-957)|
|<a id="finding-958"></a>[copy-006/holdout/approval-adapter/approval_backend.py:3:1](#finding-958)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-958)|
|<a id="finding-959"></a>[copy-006/tuning/example.py:1:1](#finding-959)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-959)|
|<a id="finding-960"></a>[copy-006/tuning/variants/alias.py:1:1](#finding-960)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-960)|
|<a id="finding-961"></a>[copy-006/tuning/variants/alias.py:2:1](#finding-961)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-961)|
|<a id="finding-962"></a>[copy-006/tuning/variants/broken.py:1:1](#finding-962)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-962)|
|<a id="finding-963"></a>[copy-007/holdout/approval-adapter/approval_backend.py:3:1](#finding-963)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-963)|
|<a id="finding-964"></a>[copy-007/tuning/example.py:1:1](#finding-964)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-964)|
|<a id="finding-965"></a>[copy-007/tuning/variants/alias.py:1:1](#finding-965)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-965)|
|<a id="finding-966"></a>[copy-007/tuning/variants/alias.py:2:1](#finding-966)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-966)|
|<a id="finding-967"></a>[copy-007/tuning/variants/broken.py:1:1](#finding-967)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-967)|
|<a id="finding-968"></a>[copy-008/holdout/approval-adapter/approval_backend.py:3:1](#finding-968)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-968)|
|<a id="finding-969"></a>[copy-008/tuning/example.py:1:1](#finding-969)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-969)|
|<a id="finding-970"></a>[copy-008/tuning/variants/alias.py:1:1](#finding-970)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-970)|
|<a id="finding-971"></a>[copy-008/tuning/variants/alias.py:2:1](#finding-971)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-971)|
|<a id="finding-972"></a>[copy-008/tuning/variants/broken.py:1:1](#finding-972)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-972)|
|<a id="finding-973"></a>[copy-009/holdout/approval-adapter/approval_backend.py:3:1](#finding-973)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-973)|
|<a id="finding-974"></a>[copy-009/tuning/example.py:1:1](#finding-974)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-974)|
|<a id="finding-975"></a>[copy-009/tuning/variants/alias.py:1:1](#finding-975)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-975)|
|<a id="finding-976"></a>[copy-009/tuning/variants/alias.py:2:1](#finding-976)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-976)|
|<a id="finding-977"></a>[copy-009/tuning/variants/broken.py:1:1](#finding-977)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-977)|
|<a id="finding-978"></a>[copy-010/holdout/approval-adapter/approval_backend.py:3:1](#finding-978)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-978)|
|<a id="finding-979"></a>[copy-010/tuning/example.py:1:1](#finding-979)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-979)|
|<a id="finding-980"></a>[copy-010/tuning/variants/alias.py:1:1](#finding-980)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-980)|
|<a id="finding-981"></a>[copy-010/tuning/variants/alias.py:2:1](#finding-981)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-981)|
|<a id="finding-982"></a>[copy-010/tuning/variants/broken.py:1:1](#finding-982)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-982)|
|<a id="finding-983"></a>[copy-011/holdout/approval-adapter/approval_backend.py:3:1](#finding-983)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-983)|
|<a id="finding-984"></a>[copy-011/tuning/example.py:1:1](#finding-984)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-984)|
|<a id="finding-985"></a>[copy-011/tuning/variants/alias.py:1:1](#finding-985)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-985)|
|<a id="finding-986"></a>[copy-011/tuning/variants/alias.py:2:1](#finding-986)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-986)|
|<a id="finding-987"></a>[copy-011/tuning/variants/broken.py:1:1](#finding-987)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-987)|
|<a id="finding-988"></a>[copy-012/holdout/approval-adapter/approval_backend.py:3:1](#finding-988)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-988)|
|<a id="finding-989"></a>[copy-012/tuning/example.py:1:1](#finding-989)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-989)|
|<a id="finding-990"></a>[copy-012/tuning/variants/alias.py:1:1](#finding-990)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-990)|
|<a id="finding-991"></a>[copy-012/tuning/variants/alias.py:2:1](#finding-991)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-991)|
|<a id="finding-992"></a>[copy-012/tuning/variants/broken.py:1:1](#finding-992)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-992)|
|<a id="finding-993"></a>[copy-013/holdout/approval-adapter/approval_backend.py:3:1](#finding-993)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-993)|
|<a id="finding-994"></a>[copy-013/tuning/example.py:1:1](#finding-994)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-994)|
|<a id="finding-995"></a>[copy-013/tuning/variants/alias.py:1:1](#finding-995)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-995)|
|<a id="finding-996"></a>[copy-013/tuning/variants/alias.py:2:1](#finding-996)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-996)|
|<a id="finding-997"></a>[copy-013/tuning/variants/broken.py:1:1](#finding-997)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-997)|
|<a id="finding-998"></a>[copy-014/holdout/approval-adapter/approval_backend.py:3:1](#finding-998)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-998)|
|<a id="finding-999"></a>[copy-014/tuning/example.py:1:1](#finding-999)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-999)|
|<a id="finding-1000"></a>[copy-014/tuning/variants/alias.py:1:1](#finding-1000)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1000)|
|<a id="finding-1001"></a>[copy-014/tuning/variants/alias.py:2:1](#finding-1001)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1001)|
|<a id="finding-1002"></a>[copy-014/tuning/variants/broken.py:1:1](#finding-1002)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1002)|
|<a id="finding-1003"></a>[copy-015/holdout/approval-adapter/approval_backend.py:3:1](#finding-1003)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1003)|
|<a id="finding-1004"></a>[copy-015/tuning/example.py:1:1](#finding-1004)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1004)|
|<a id="finding-1005"></a>[copy-015/tuning/variants/alias.py:1:1](#finding-1005)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1005)|
|<a id="finding-1006"></a>[copy-015/tuning/variants/alias.py:2:1](#finding-1006)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1006)|
|<a id="finding-1007"></a>[copy-015/tuning/variants/broken.py:1:1](#finding-1007)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1007)|
|<a id="finding-1008"></a>[copy-016/holdout/approval-adapter/approval_backend.py:3:1](#finding-1008)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1008)|
|<a id="finding-1009"></a>[copy-016/tuning/example.py:1:1](#finding-1009)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1009)|
|<a id="finding-1010"></a>[copy-016/tuning/variants/alias.py:1:1](#finding-1010)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1010)|
|<a id="finding-1011"></a>[copy-016/tuning/variants/alias.py:2:1](#finding-1011)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1011)|
|<a id="finding-1012"></a>[copy-016/tuning/variants/broken.py:1:1](#finding-1012)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1012)|
|<a id="finding-1013"></a>[copy-017/holdout/approval-adapter/approval_backend.py:3:1](#finding-1013)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1013)|
|<a id="finding-1014"></a>[copy-017/tuning/example.py:1:1](#finding-1014)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1014)|
|<a id="finding-1015"></a>[copy-017/tuning/variants/alias.py:1:1](#finding-1015)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1015)|
|<a id="finding-1016"></a>[copy-017/tuning/variants/alias.py:2:1](#finding-1016)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1016)|
|<a id="finding-1017"></a>[copy-017/tuning/variants/broken.py:1:1](#finding-1017)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1017)|
|<a id="finding-1018"></a>[copy-018/holdout/approval-adapter/approval_backend.py:3:1](#finding-1018)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1018)|
|<a id="finding-1019"></a>[copy-018/tuning/example.py:1:1](#finding-1019)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1019)|
|<a id="finding-1020"></a>[copy-018/tuning/variants/alias.py:1:1](#finding-1020)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1020)|
|<a id="finding-1021"></a>[copy-018/tuning/variants/alias.py:2:1](#finding-1021)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1021)|
|<a id="finding-1022"></a>[copy-018/tuning/variants/broken.py:1:1](#finding-1022)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1022)|
|<a id="finding-1023"></a>[copy-019/holdout/approval-adapter/approval_backend.py:3:1](#finding-1023)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1023)|
|<a id="finding-1024"></a>[copy-019/tuning/example.py:1:1](#finding-1024)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1024)|
|<a id="finding-1025"></a>[copy-019/tuning/variants/alias.py:1:1](#finding-1025)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1025)|
|<a id="finding-1026"></a>[copy-019/tuning/variants/alias.py:2:1](#finding-1026)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1026)|
|<a id="finding-1027"></a>[copy-019/tuning/variants/broken.py:1:1](#finding-1027)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1027)|
|<a id="finding-1028"></a>[copy-020/holdout/approval-adapter/approval_backend.py:3:1](#finding-1028)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1028)|
|<a id="finding-1029"></a>[copy-020/tuning/example.py:1:1](#finding-1029)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1029)|
|<a id="finding-1030"></a>[copy-020/tuning/variants/alias.py:1:1](#finding-1030)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1030)|
|<a id="finding-1031"></a>[copy-020/tuning/variants/alias.py:2:1](#finding-1031)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1031)|
|<a id="finding-1032"></a>[copy-020/tuning/variants/broken.py:1:1](#finding-1032)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1032)|
|<a id="finding-1033"></a>[copy-021/holdout/approval-adapter/approval_backend.py:3:1](#finding-1033)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1033)|
|<a id="finding-1034"></a>[copy-021/tuning/example.py:1:1](#finding-1034)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1034)|
|<a id="finding-1035"></a>[copy-021/tuning/variants/alias.py:1:1](#finding-1035)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1035)|
|<a id="finding-1036"></a>[copy-021/tuning/variants/alias.py:2:1](#finding-1036)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1036)|
|<a id="finding-1037"></a>[copy-021/tuning/variants/broken.py:1:1](#finding-1037)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1037)|
|<a id="finding-1038"></a>[copy-022/holdout/approval-adapter/approval_backend.py:3:1](#finding-1038)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1038)|
|<a id="finding-1039"></a>[copy-022/tuning/example.py:1:1](#finding-1039)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1039)|
|<a id="finding-1040"></a>[copy-022/tuning/variants/alias.py:1:1](#finding-1040)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1040)|
|<a id="finding-1041"></a>[copy-022/tuning/variants/alias.py:2:1](#finding-1041)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1041)|
|<a id="finding-1042"></a>[copy-022/tuning/variants/broken.py:1:1](#finding-1042)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1042)|
|<a id="finding-1043"></a>[copy-023/holdout/approval-adapter/approval_backend.py:3:1](#finding-1043)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1043)|
|<a id="finding-1044"></a>[copy-023/tuning/example.py:1:1](#finding-1044)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1044)|
|<a id="finding-1045"></a>[copy-023/tuning/variants/alias.py:1:1](#finding-1045)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1045)|
|<a id="finding-1046"></a>[copy-023/tuning/variants/alias.py:2:1](#finding-1046)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1046)|
|<a id="finding-1047"></a>[copy-023/tuning/variants/broken.py:1:1](#finding-1047)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1047)|
|<a id="finding-1048"></a>[copy-024/holdout/approval-adapter/approval_backend.py:3:1](#finding-1048)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1048)|
|<a id="finding-1049"></a>[copy-024/tuning/example.py:1:1](#finding-1049)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1049)|
|<a id="finding-1050"></a>[copy-024/tuning/variants/alias.py:1:1](#finding-1050)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1050)|
|<a id="finding-1051"></a>[copy-024/tuning/variants/alias.py:2:1](#finding-1051)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1051)|
|<a id="finding-1052"></a>[copy-024/tuning/variants/broken.py:1:1](#finding-1052)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1052)|
|<a id="finding-1053"></a>[copy-025/holdout/approval-adapter/approval_backend.py:3:1](#finding-1053)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1053)|
|<a id="finding-1054"></a>[copy-025/tuning/example.py:1:1](#finding-1054)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1054)|
|<a id="finding-1055"></a>[copy-025/tuning/variants/alias.py:1:1](#finding-1055)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1055)|
|<a id="finding-1056"></a>[copy-025/tuning/variants/alias.py:2:1](#finding-1056)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1056)|
|<a id="finding-1057"></a>[copy-025/tuning/variants/broken.py:1:1](#finding-1057)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1057)|
|<a id="finding-1058"></a>[copy-026/holdout/approval-adapter/approval_backend.py:3:1](#finding-1058)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1058)|
|<a id="finding-1059"></a>[copy-026/tuning/example.py:1:1](#finding-1059)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1059)|
|<a id="finding-1060"></a>[copy-026/tuning/variants/alias.py:1:1](#finding-1060)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1060)|
|<a id="finding-1061"></a>[copy-026/tuning/variants/alias.py:2:1](#finding-1061)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1061)|
|<a id="finding-1062"></a>[copy-026/tuning/variants/broken.py:1:1](#finding-1062)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1062)|
|<a id="finding-1063"></a>[copy-027/holdout/approval-adapter/approval_backend.py:3:1](#finding-1063)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1063)|
|<a id="finding-1064"></a>[copy-027/tuning/example.py:1:1](#finding-1064)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1064)|
|<a id="finding-1065"></a>[copy-027/tuning/variants/alias.py:1:1](#finding-1065)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1065)|
|<a id="finding-1066"></a>[copy-027/tuning/variants/alias.py:2:1](#finding-1066)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1066)|
|<a id="finding-1067"></a>[copy-027/tuning/variants/broken.py:1:1](#finding-1067)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1067)|
|<a id="finding-1068"></a>[copy-028/holdout/approval-adapter/approval_backend.py:3:1](#finding-1068)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1068)|
|<a id="finding-1069"></a>[copy-028/tuning/example.py:1:1](#finding-1069)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1069)|
|<a id="finding-1070"></a>[copy-028/tuning/variants/alias.py:1:1](#finding-1070)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1070)|
|<a id="finding-1071"></a>[copy-028/tuning/variants/alias.py:2:1](#finding-1071)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1071)|
|<a id="finding-1072"></a>[copy-028/tuning/variants/broken.py:1:1](#finding-1072)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1072)|
|<a id="finding-1073"></a>[copy-029/holdout/approval-adapter/approval_backend.py:3:1](#finding-1073)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1073)|
|<a id="finding-1074"></a>[copy-029/tuning/example.py:1:1](#finding-1074)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1074)|
|<a id="finding-1075"></a>[copy-029/tuning/variants/alias.py:1:1](#finding-1075)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1075)|
|<a id="finding-1076"></a>[copy-029/tuning/variants/alias.py:2:1](#finding-1076)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1076)|
|<a id="finding-1077"></a>[copy-029/tuning/variants/broken.py:1:1](#finding-1077)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1077)|
|<a id="finding-1078"></a>[copy-030/holdout/approval-adapter/approval_backend.py:3:1](#finding-1078)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1078)|
|<a id="finding-1079"></a>[copy-030/tuning/example.py:1:1](#finding-1079)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1079)|
|<a id="finding-1080"></a>[copy-030/tuning/variants/alias.py:1:1](#finding-1080)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1080)|
|<a id="finding-1081"></a>[copy-030/tuning/variants/alias.py:2:1](#finding-1081)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1081)|
|<a id="finding-1082"></a>[copy-030/tuning/variants/broken.py:1:1](#finding-1082)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1082)|
|<a id="finding-1083"></a>[copy-031/holdout/approval-adapter/approval_backend.py:3:1](#finding-1083)|from cry***Key, )|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1083)|
|<a id="finding-1084"></a>[copy-031/tuning/example.py:1:1](#finding-1084)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1084)|
|<a id="finding-1085"></a>[copy-031/tuning/variants/alias.py:1:1](#finding-1085)|from cry***as Key|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1085)|
|<a id="finding-1086"></a>[copy-031/tuning/variants/alias.py:2:1](#finding-1086)|Key.generate()|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1086)|
|<a id="finding-1087"></a>[copy-031/tuning/variants/broken.py:1:1](#finding-1087)|mlkem.ML***erate(|cryptography 47 added ML-KEM and ML-DSA; 48 adds OpenSSL 3.5+ support. Confirm backend capability. / [Source](#source-1087)|

<a id="source-928"></a>

### copy-000/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-929"></a>

### copy-000/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-930"></a>

### copy-000/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-931"></a>

### copy-000/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-932"></a>

### copy-000/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-933"></a>

### copy-001/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-934"></a>

### copy-001/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-935"></a>

### copy-001/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-936"></a>

### copy-001/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-937"></a>

### copy-001/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-938"></a>

### copy-002/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-939"></a>

### copy-002/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-940"></a>

### copy-002/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-941"></a>

### copy-002/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-942"></a>

### copy-002/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-943"></a>

### copy-003/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-944"></a>

### copy-003/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-945"></a>

### copy-003/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-946"></a>

### copy-003/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-947"></a>

### copy-003/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-948"></a>

### copy-004/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-949"></a>

### copy-004/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-950"></a>

### copy-004/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-951"></a>

### copy-004/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-952"></a>

### copy-004/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-953"></a>

### copy-005/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-954"></a>

### copy-005/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-955"></a>

### copy-005/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-956"></a>

### copy-005/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-957"></a>

### copy-005/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-958"></a>

### copy-006/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-959"></a>

### copy-006/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-960"></a>

### copy-006/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-961"></a>

### copy-006/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-962"></a>

### copy-006/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-963"></a>

### copy-007/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-964"></a>

### copy-007/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-965"></a>

### copy-007/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-966"></a>

### copy-007/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-967"></a>

### copy-007/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-968"></a>

### copy-008/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-969"></a>

### copy-008/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-970"></a>

### copy-008/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-971"></a>

### copy-008/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-972"></a>

### copy-008/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-973"></a>

### copy-009/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-974"></a>

### copy-009/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-975"></a>

### copy-009/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-976"></a>

### copy-009/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-977"></a>

### copy-009/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-978"></a>

### copy-010/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-979"></a>

### copy-010/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-980"></a>

### copy-010/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-981"></a>

### copy-010/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-982"></a>

### copy-010/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-983"></a>

### copy-011/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-984"></a>

### copy-011/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-985"></a>

### copy-011/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-986"></a>

### copy-011/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-987"></a>

### copy-011/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-988"></a>

### copy-012/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-989"></a>

### copy-012/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-990"></a>

### copy-012/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-991"></a>

### copy-012/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-992"></a>

### copy-012/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-993"></a>

### copy-013/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-994"></a>

### copy-013/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-995"></a>

### copy-013/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-996"></a>

### copy-013/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-997"></a>

### copy-013/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-998"></a>

### copy-014/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-999"></a>

### copy-014/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-1000"></a>

### copy-014/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-1001"></a>

### copy-014/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-1002"></a>

### copy-014/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-1003"></a>

### copy-015/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-1004"></a>

### copy-015/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-1005"></a>

### copy-015/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-1006"></a>

### copy-015/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-1007"></a>

### copy-015/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-1008"></a>

### copy-016/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-1009"></a>

### copy-016/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-1010"></a>

### copy-016/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-1011"></a>

### copy-016/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-1012"></a>

### copy-016/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-1013"></a>

### copy-017/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-1014"></a>

### copy-017/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-1015"></a>

### copy-017/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-1016"></a>

### copy-017/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-1017"></a>

### copy-017/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-1018"></a>

### copy-018/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-1019"></a>

### copy-018/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-1020"></a>

### copy-018/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-1021"></a>

### copy-018/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-1022"></a>

### copy-018/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-1023"></a>

### copy-019/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-1024"></a>

### copy-019/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-1025"></a>

### copy-019/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-1026"></a>

### copy-019/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-1027"></a>

### copy-019/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-1028"></a>

### copy-020/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-1029"></a>

### copy-020/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-1030"></a>

### copy-020/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-1031"></a>

### copy-020/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-1032"></a>

### copy-020/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-1033"></a>

### copy-021/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-1034"></a>

### copy-021/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-1035"></a>

### copy-021/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-1036"></a>

### copy-021/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-1037"></a>

### copy-021/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-1038"></a>

### copy-022/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-1039"></a>

### copy-022/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-1040"></a>

### copy-022/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-1041"></a>

### copy-022/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-1042"></a>

### copy-022/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-1043"></a>

### copy-023/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-1044"></a>

### copy-023/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-1045"></a>

### copy-023/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-1046"></a>

### copy-023/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-1047"></a>

### copy-023/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-1048"></a>

### copy-024/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-1049"></a>

### copy-024/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-1050"></a>

### copy-024/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-1051"></a>

### copy-024/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-1052"></a>

### copy-024/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-1053"></a>

### copy-025/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-1054"></a>

### copy-025/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-1055"></a>

### copy-025/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-1056"></a>

### copy-025/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-1057"></a>

### copy-025/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-1058"></a>

### copy-026/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-1059"></a>

### copy-026/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-1060"></a>

### copy-026/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-1061"></a>

### copy-026/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-1062"></a>

### copy-026/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-1063"></a>

### copy-027/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-1064"></a>

### copy-027/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-1065"></a>

### copy-027/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-1066"></a>

### copy-027/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-1067"></a>

### copy-027/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-1068"></a>

### copy-028/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-1069"></a>

### copy-028/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-1070"></a>

### copy-028/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-1071"></a>

### copy-028/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-1072"></a>

### copy-028/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-1073"></a>

### copy-029/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-1074"></a>

### copy-029/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-1075"></a>

### copy-029/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-1076"></a>

### copy-029/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-1077"></a>

### copy-029/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-1078"></a>

### copy-030/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-1079"></a>

### copy-030/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-1080"></a>

### copy-030/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-1081"></a>

### copy-030/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-1082"></a>

### copy-030/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="source-1083"></a>

### copy-031/holdout/approval-adapter/approval_backend.py:3:1

      1 # SPDX-License-Identifier: MIT
      2 # Static fixture data: offline approval backend; never import or execute.
    > 3 from cryptography.hazmat.primitives.asymmetric.mldsa import (
      4     MLDSA87PrivateKey,
      5 )

<a id="source-1084"></a>

### copy-031/tuning/example.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate()

<a id="source-1085"></a>

### copy-031/tuning/variants/alias.py:1:1

    > 1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
      2 Key.generate()

<a id="source-1086"></a>

### copy-031/tuning/variants/alias.py:2:1

      1 from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey as Key
    > 2 Key.generate()

<a id="source-1087"></a>

### copy-031/tuning/variants/broken.py:1:1

    > 1 mlkem.MLKEM768PrivateKey.generate(

<a id="rule-19"></a>

## PQC_RUBY_API

Ruby PQC algorithm literal referenced; key generation or signing success is not established.

Check: Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-1088"></a>[copy-000/tuning/example.rb:1:28](#finding-1088)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1088)|
|<a id="finding-1089"></a>[copy-000/tuning/variants/display.rb:1:6](#finding-1089)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1089)|
|<a id="finding-1090"></a>[copy-001/tuning/example.rb:1:28](#finding-1090)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1090)|
|<a id="finding-1091"></a>[copy-001/tuning/variants/display.rb:1:6](#finding-1091)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1091)|
|<a id="finding-1092"></a>[copy-002/tuning/example.rb:1:28](#finding-1092)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1092)|
|<a id="finding-1093"></a>[copy-002/tuning/variants/display.rb:1:6](#finding-1093)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1093)|
|<a id="finding-1094"></a>[copy-003/tuning/example.rb:1:28](#finding-1094)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1094)|
|<a id="finding-1095"></a>[copy-003/tuning/variants/display.rb:1:6](#finding-1095)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1095)|
|<a id="finding-1096"></a>[copy-004/tuning/example.rb:1:28](#finding-1096)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1096)|
|<a id="finding-1097"></a>[copy-004/tuning/variants/display.rb:1:6](#finding-1097)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1097)|
|<a id="finding-1098"></a>[copy-005/tuning/example.rb:1:28](#finding-1098)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1098)|
|<a id="finding-1099"></a>[copy-005/tuning/variants/display.rb:1:6](#finding-1099)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1099)|
|<a id="finding-1100"></a>[copy-006/tuning/example.rb:1:28](#finding-1100)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1100)|
|<a id="finding-1101"></a>[copy-006/tuning/variants/display.rb:1:6](#finding-1101)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1101)|
|<a id="finding-1102"></a>[copy-007/tuning/example.rb:1:28](#finding-1102)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1102)|
|<a id="finding-1103"></a>[copy-007/tuning/variants/display.rb:1:6](#finding-1103)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1103)|
|<a id="finding-1104"></a>[copy-008/tuning/example.rb:1:28](#finding-1104)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1104)|
|<a id="finding-1105"></a>[copy-008/tuning/variants/display.rb:1:6](#finding-1105)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1105)|
|<a id="finding-1106"></a>[copy-009/tuning/example.rb:1:28](#finding-1106)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1106)|
|<a id="finding-1107"></a>[copy-009/tuning/variants/display.rb:1:6](#finding-1107)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1107)|
|<a id="finding-1108"></a>[copy-010/tuning/example.rb:1:28](#finding-1108)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1108)|
|<a id="finding-1109"></a>[copy-010/tuning/variants/display.rb:1:6](#finding-1109)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1109)|
|<a id="finding-1110"></a>[copy-011/tuning/example.rb:1:28](#finding-1110)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1110)|
|<a id="finding-1111"></a>[copy-011/tuning/variants/display.rb:1:6](#finding-1111)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1111)|
|<a id="finding-1112"></a>[copy-012/tuning/example.rb:1:28](#finding-1112)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1112)|
|<a id="finding-1113"></a>[copy-012/tuning/variants/display.rb:1:6](#finding-1113)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1113)|
|<a id="finding-1114"></a>[copy-013/tuning/example.rb:1:28](#finding-1114)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1114)|
|<a id="finding-1115"></a>[copy-013/tuning/variants/display.rb:1:6](#finding-1115)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1115)|
|<a id="finding-1116"></a>[copy-014/tuning/example.rb:1:28](#finding-1116)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1116)|
|<a id="finding-1117"></a>[copy-014/tuning/variants/display.rb:1:6](#finding-1117)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1117)|
|<a id="finding-1118"></a>[copy-015/tuning/example.rb:1:28](#finding-1118)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1118)|
|<a id="finding-1119"></a>[copy-015/tuning/variants/display.rb:1:6](#finding-1119)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1119)|
|<a id="finding-1120"></a>[copy-016/tuning/example.rb:1:28](#finding-1120)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1120)|
|<a id="finding-1121"></a>[copy-016/tuning/variants/display.rb:1:6](#finding-1121)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1121)|
|<a id="finding-1122"></a>[copy-017/tuning/example.rb:1:28](#finding-1122)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1122)|
|<a id="finding-1123"></a>[copy-017/tuning/variants/display.rb:1:6](#finding-1123)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1123)|
|<a id="finding-1124"></a>[copy-018/tuning/example.rb:1:28](#finding-1124)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1124)|
|<a id="finding-1125"></a>[copy-018/tuning/variants/display.rb:1:6](#finding-1125)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1125)|
|<a id="finding-1126"></a>[copy-019/tuning/example.rb:1:28](#finding-1126)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1126)|
|<a id="finding-1127"></a>[copy-019/tuning/variants/display.rb:1:6](#finding-1127)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1127)|
|<a id="finding-1128"></a>[copy-020/tuning/example.rb:1:28](#finding-1128)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1128)|
|<a id="finding-1129"></a>[copy-020/tuning/variants/display.rb:1:6](#finding-1129)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1129)|
|<a id="finding-1130"></a>[copy-021/tuning/example.rb:1:28](#finding-1130)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1130)|
|<a id="finding-1131"></a>[copy-021/tuning/variants/display.rb:1:6](#finding-1131)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1131)|
|<a id="finding-1132"></a>[copy-022/tuning/example.rb:1:28](#finding-1132)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1132)|
|<a id="finding-1133"></a>[copy-022/tuning/variants/display.rb:1:6](#finding-1133)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1133)|
|<a id="finding-1134"></a>[copy-023/tuning/example.rb:1:28](#finding-1134)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1134)|
|<a id="finding-1135"></a>[copy-023/tuning/variants/display.rb:1:6](#finding-1135)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1135)|
|<a id="finding-1136"></a>[copy-024/tuning/example.rb:1:28](#finding-1136)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1136)|
|<a id="finding-1137"></a>[copy-024/tuning/variants/display.rb:1:6](#finding-1137)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1137)|
|<a id="finding-1138"></a>[copy-025/tuning/example.rb:1:28](#finding-1138)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1138)|
|<a id="finding-1139"></a>[copy-025/tuning/variants/display.rb:1:6](#finding-1139)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1139)|
|<a id="finding-1140"></a>[copy-026/tuning/example.rb:1:28](#finding-1140)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1140)|
|<a id="finding-1141"></a>[copy-026/tuning/variants/display.rb:1:6](#finding-1141)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1141)|
|<a id="finding-1142"></a>[copy-027/tuning/example.rb:1:28](#finding-1142)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1142)|
|<a id="finding-1143"></a>[copy-027/tuning/variants/display.rb:1:6](#finding-1143)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1143)|
|<a id="finding-1144"></a>[copy-028/tuning/example.rb:1:28](#finding-1144)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1144)|
|<a id="finding-1145"></a>[copy-028/tuning/variants/display.rb:1:6](#finding-1145)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1145)|
|<a id="finding-1146"></a>[copy-029/tuning/example.rb:1:28](#finding-1146)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1146)|
|<a id="finding-1147"></a>[copy-029/tuning/variants/display.rb:1:6](#finding-1147)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1147)|
|<a id="finding-1148"></a>[copy-030/tuning/example.rb:1:28](#finding-1148)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1148)|
|<a id="finding-1149"></a>[copy-030/tuning/variants/display.rb:1:6](#finding-1149)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1149)|
|<a id="finding-1150"></a>[copy-031/tuning/example.rb:1:28](#finding-1150)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1150)|
|<a id="finding-1151"></a>[copy-031/tuning/variants/display.rb:1:6](#finding-1151)|'ML-DSA-65'|Verify openssl gem and linked OpenSSL/provider capabilities, not Ruby version alone. / [Source](#source-1151)|

<a id="source-1088"></a>

### copy-000/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1089"></a>

### copy-000/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1090"></a>

### copy-001/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1091"></a>

### copy-001/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1092"></a>

### copy-002/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1093"></a>

### copy-002/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1094"></a>

### copy-003/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1095"></a>

### copy-003/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1096"></a>

### copy-004/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1097"></a>

### copy-004/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1098"></a>

### copy-005/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1099"></a>

### copy-005/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1100"></a>

### copy-006/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1101"></a>

### copy-006/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1102"></a>

### copy-007/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1103"></a>

### copy-007/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1104"></a>

### copy-008/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1105"></a>

### copy-008/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1106"></a>

### copy-009/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1107"></a>

### copy-009/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1108"></a>

### copy-010/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1109"></a>

### copy-010/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1110"></a>

### copy-011/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1111"></a>

### copy-011/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1112"></a>

### copy-012/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1113"></a>

### copy-012/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1114"></a>

### copy-013/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1115"></a>

### copy-013/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1116"></a>

### copy-014/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1117"></a>

### copy-014/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1118"></a>

### copy-015/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1119"></a>

### copy-015/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1120"></a>

### copy-016/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1121"></a>

### copy-016/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1122"></a>

### copy-017/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1123"></a>

### copy-017/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1124"></a>

### copy-018/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1125"></a>

### copy-018/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1126"></a>

### copy-019/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1127"></a>

### copy-019/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1128"></a>

### copy-020/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1129"></a>

### copy-020/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1130"></a>

### copy-021/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1131"></a>

### copy-021/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1132"></a>

### copy-022/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1133"></a>

### copy-022/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1134"></a>

### copy-023/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1135"></a>

### copy-023/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1136"></a>

### copy-024/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1137"></a>

### copy-024/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1138"></a>

### copy-025/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1139"></a>

### copy-025/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1140"></a>

### copy-026/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1141"></a>

### copy-026/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1142"></a>

### copy-027/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1143"></a>

### copy-027/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1144"></a>

### copy-028/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1145"></a>

### copy-028/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1146"></a>

### copy-029/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1147"></a>

### copy-029/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1148"></a>

### copy-030/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1149"></a>

### copy-030/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="source-1150"></a>

### copy-031/tuning/example.rb:1:28

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1151"></a>

### copy-031/tuning/variants/display.rb:1:6

    > 1 puts 'ML-DSA-65'

<a id="rule-20"></a>

## PQC_RUST_API

Rust PQC crate symbol referenced; execution and protocol use require confirmation.

Check: Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-1152"></a>[copy-000/tuning/example.rs:1:5](#finding-1152)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1152)|
|<a id="finding-1153"></a>[copy-001/tuning/example.rs:1:5](#finding-1153)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1153)|
|<a id="finding-1154"></a>[copy-002/tuning/example.rs:1:5](#finding-1154)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1154)|
|<a id="finding-1155"></a>[copy-003/tuning/example.rs:1:5](#finding-1155)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1155)|
|<a id="finding-1156"></a>[copy-004/tuning/example.rs:1:5](#finding-1156)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1156)|
|<a id="finding-1157"></a>[copy-005/tuning/example.rs:1:5](#finding-1157)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1157)|
|<a id="finding-1158"></a>[copy-006/tuning/example.rs:1:5](#finding-1158)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1158)|
|<a id="finding-1159"></a>[copy-007/tuning/example.rs:1:5](#finding-1159)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1159)|
|<a id="finding-1160"></a>[copy-008/tuning/example.rs:1:5](#finding-1160)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1160)|
|<a id="finding-1161"></a>[copy-009/tuning/example.rs:1:5](#finding-1161)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1161)|
|<a id="finding-1162"></a>[copy-010/tuning/example.rs:1:5](#finding-1162)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1162)|
|<a id="finding-1163"></a>[copy-011/tuning/example.rs:1:5](#finding-1163)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1163)|
|<a id="finding-1164"></a>[copy-012/tuning/example.rs:1:5](#finding-1164)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1164)|
|<a id="finding-1165"></a>[copy-013/tuning/example.rs:1:5](#finding-1165)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1165)|
|<a id="finding-1166"></a>[copy-014/tuning/example.rs:1:5](#finding-1166)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1166)|
|<a id="finding-1167"></a>[copy-015/tuning/example.rs:1:5](#finding-1167)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1167)|
|<a id="finding-1168"></a>[copy-016/tuning/example.rs:1:5](#finding-1168)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1168)|
|<a id="finding-1169"></a>[copy-017/tuning/example.rs:1:5](#finding-1169)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1169)|
|<a id="finding-1170"></a>[copy-018/tuning/example.rs:1:5](#finding-1170)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1170)|
|<a id="finding-1171"></a>[copy-019/tuning/example.rs:1:5](#finding-1171)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1171)|
|<a id="finding-1172"></a>[copy-020/tuning/example.rs:1:5](#finding-1172)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1172)|
|<a id="finding-1173"></a>[copy-021/tuning/example.rs:1:5](#finding-1173)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1173)|
|<a id="finding-1174"></a>[copy-022/tuning/example.rs:1:5](#finding-1174)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1174)|
|<a id="finding-1175"></a>[copy-023/tuning/example.rs:1:5](#finding-1175)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1175)|
|<a id="finding-1176"></a>[copy-024/tuning/example.rs:1:5](#finding-1176)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1176)|
|<a id="finding-1177"></a>[copy-025/tuning/example.rs:1:5](#finding-1177)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1177)|
|<a id="finding-1178"></a>[copy-026/tuning/example.rs:1:5](#finding-1178)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1178)|
|<a id="finding-1179"></a>[copy-027/tuning/example.rs:1:5](#finding-1179)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1179)|
|<a id="finding-1180"></a>[copy-028/tuning/example.rs:1:5](#finding-1180)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1180)|
|<a id="finding-1181"></a>[copy-029/tuning/example.rs:1:5](#finding-1181)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1181)|
|<a id="finding-1182"></a>[copy-030/tuning/example.rs:1:5](#finding-1182)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1182)|
|<a id="finding-1183"></a>[copy-031/tuning/example.rs:1:5](#finding-1183)|ml_kem::MlKem768|Confirm crate version, features and provider; a RustCrypto reference alone does not enable PQC TLS. / [Source](#source-1183)|

<a id="source-1152"></a>

### copy-000/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1153"></a>

### copy-001/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1154"></a>

### copy-002/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1155"></a>

### copy-003/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1156"></a>

### copy-004/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1157"></a>

### copy-005/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1158"></a>

### copy-006/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1159"></a>

### copy-007/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1160"></a>

### copy-008/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1161"></a>

### copy-009/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1162"></a>

### copy-010/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1163"></a>

### copy-011/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1164"></a>

### copy-012/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1165"></a>

### copy-013/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1166"></a>

### copy-014/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1167"></a>

### copy-015/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1168"></a>

### copy-016/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1169"></a>

### copy-017/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1170"></a>

### copy-018/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1171"></a>

### copy-019/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1172"></a>

### copy-020/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1173"></a>

### copy-021/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1174"></a>

### copy-022/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1175"></a>

### copy-023/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1176"></a>

### copy-024/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1177"></a>

### copy-025/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1178"></a>

### copy-026/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1179"></a>

### copy-027/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1180"></a>

### copy-028/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1181"></a>

### copy-029/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1182"></a>

### copy-030/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="source-1183"></a>

### copy-031/tuning/example.rs:1:5

    > 1 use ml_kem::MlKem768;

<a id="rule-21"></a>

## PQC_STANDARD_REFERENCE

Standard PQC algorithm or hybrid group name referenced; API execution, enabled state and conformance are not established.

Check: A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-1184"></a>[copy-000/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1184)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1184)|
|<a id="finding-1185"></a>[copy-000/tuning/example.js:1:22](#finding-1185)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1185)|
|<a id="finding-1186"></a>[copy-000/tuning/example.rb:1:29](#finding-1186)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1186)|
|<a id="finding-1187"></a>[copy-000/tuning/example.rs:1:13](#finding-1187)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1187)|
|<a id="finding-1188"></a>[copy-000/tuning/example.ts:1:28](#finding-1188)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1188)|
|<a id="finding-1189"></a>[copy-000/tuning/negative.js:3:16](#finding-1189)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1189)|
|<a id="finding-1190"></a>[copy-000/tuning/variants/alias.js:2:7](#finding-1190)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1190)|
|<a id="finding-1191"></a>[copy-000/tuning/variants/display.rb:1:7](#finding-1191)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1191)|
|<a id="finding-1192"></a>[copy-000/tuning/variants/draft.js:2:21](#finding-1192)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1192)|
|<a id="finding-1193"></a>[copy-000/tuning/variants/shadow.js:2:22](#finding-1193)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1193)|
|<a id="finding-1194"></a>[copy-000/tuning/variants/twice.js:1:22](#finding-1194)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1194)|
|<a id="finding-1195"></a>[copy-000/tuning/variants/twice.js:1:57](#finding-1195)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1195)|
|<a id="finding-1196"></a>[copy-000/tuning/variants/typed.ts:1:64](#finding-1196)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1196)|
|<a id="finding-1197"></a>[copy-001/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1197)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1197)|
|<a id="finding-1198"></a>[copy-001/tuning/example.js:1:22](#finding-1198)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1198)|
|<a id="finding-1199"></a>[copy-001/tuning/example.rb:1:29](#finding-1199)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1199)|
|<a id="finding-1200"></a>[copy-001/tuning/example.rs:1:13](#finding-1200)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1200)|
|<a id="finding-1201"></a>[copy-001/tuning/example.ts:1:28](#finding-1201)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1201)|
|<a id="finding-1202"></a>[copy-001/tuning/negative.js:3:16](#finding-1202)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1202)|
|<a id="finding-1203"></a>[copy-001/tuning/variants/alias.js:2:7](#finding-1203)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1203)|
|<a id="finding-1204"></a>[copy-001/tuning/variants/display.rb:1:7](#finding-1204)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1204)|
|<a id="finding-1205"></a>[copy-001/tuning/variants/draft.js:2:21](#finding-1205)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1205)|
|<a id="finding-1206"></a>[copy-001/tuning/variants/shadow.js:2:22](#finding-1206)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1206)|
|<a id="finding-1207"></a>[copy-001/tuning/variants/twice.js:1:22](#finding-1207)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1207)|
|<a id="finding-1208"></a>[copy-001/tuning/variants/twice.js:1:57](#finding-1208)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1208)|
|<a id="finding-1209"></a>[copy-001/tuning/variants/typed.ts:1:64](#finding-1209)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1209)|
|<a id="finding-1210"></a>[copy-002/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1210)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1210)|
|<a id="finding-1211"></a>[copy-002/tuning/example.js:1:22](#finding-1211)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1211)|
|<a id="finding-1212"></a>[copy-002/tuning/example.rb:1:29](#finding-1212)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1212)|
|<a id="finding-1213"></a>[copy-002/tuning/example.rs:1:13](#finding-1213)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1213)|
|<a id="finding-1214"></a>[copy-002/tuning/example.ts:1:28](#finding-1214)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1214)|
|<a id="finding-1215"></a>[copy-002/tuning/negative.js:3:16](#finding-1215)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1215)|
|<a id="finding-1216"></a>[copy-002/tuning/variants/alias.js:2:7](#finding-1216)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1216)|
|<a id="finding-1217"></a>[copy-002/tuning/variants/display.rb:1:7](#finding-1217)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1217)|
|<a id="finding-1218"></a>[copy-002/tuning/variants/draft.js:2:21](#finding-1218)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1218)|
|<a id="finding-1219"></a>[copy-002/tuning/variants/shadow.js:2:22](#finding-1219)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1219)|
|<a id="finding-1220"></a>[copy-002/tuning/variants/twice.js:1:22](#finding-1220)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1220)|
|<a id="finding-1221"></a>[copy-002/tuning/variants/twice.js:1:57](#finding-1221)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1221)|
|<a id="finding-1222"></a>[copy-002/tuning/variants/typed.ts:1:64](#finding-1222)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1222)|
|<a id="finding-1223"></a>[copy-003/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1223)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1223)|
|<a id="finding-1224"></a>[copy-003/tuning/example.js:1:22](#finding-1224)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1224)|
|<a id="finding-1225"></a>[copy-003/tuning/example.rb:1:29](#finding-1225)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1225)|
|<a id="finding-1226"></a>[copy-003/tuning/example.rs:1:13](#finding-1226)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1226)|
|<a id="finding-1227"></a>[copy-003/tuning/example.ts:1:28](#finding-1227)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1227)|
|<a id="finding-1228"></a>[copy-003/tuning/negative.js:3:16](#finding-1228)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1228)|
|<a id="finding-1229"></a>[copy-003/tuning/variants/alias.js:2:7](#finding-1229)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1229)|
|<a id="finding-1230"></a>[copy-003/tuning/variants/display.rb:1:7](#finding-1230)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1230)|
|<a id="finding-1231"></a>[copy-003/tuning/variants/draft.js:2:21](#finding-1231)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1231)|
|<a id="finding-1232"></a>[copy-003/tuning/variants/shadow.js:2:22](#finding-1232)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1232)|
|<a id="finding-1233"></a>[copy-003/tuning/variants/twice.js:1:22](#finding-1233)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1233)|
|<a id="finding-1234"></a>[copy-003/tuning/variants/twice.js:1:57](#finding-1234)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1234)|
|<a id="finding-1235"></a>[copy-003/tuning/variants/typed.ts:1:64](#finding-1235)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1235)|
|<a id="finding-1236"></a>[copy-004/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1236)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1236)|
|<a id="finding-1237"></a>[copy-004/tuning/example.js:1:22](#finding-1237)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1237)|
|<a id="finding-1238"></a>[copy-004/tuning/example.rb:1:29](#finding-1238)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1238)|
|<a id="finding-1239"></a>[copy-004/tuning/example.rs:1:13](#finding-1239)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1239)|
|<a id="finding-1240"></a>[copy-004/tuning/example.ts:1:28](#finding-1240)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1240)|
|<a id="finding-1241"></a>[copy-004/tuning/negative.js:3:16](#finding-1241)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1241)|
|<a id="finding-1242"></a>[copy-004/tuning/variants/alias.js:2:7](#finding-1242)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1242)|
|<a id="finding-1243"></a>[copy-004/tuning/variants/display.rb:1:7](#finding-1243)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1243)|
|<a id="finding-1244"></a>[copy-004/tuning/variants/draft.js:2:21](#finding-1244)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1244)|
|<a id="finding-1245"></a>[copy-004/tuning/variants/shadow.js:2:22](#finding-1245)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1245)|
|<a id="finding-1246"></a>[copy-004/tuning/variants/twice.js:1:22](#finding-1246)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1246)|
|<a id="finding-1247"></a>[copy-004/tuning/variants/twice.js:1:57](#finding-1247)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1247)|
|<a id="finding-1248"></a>[copy-004/tuning/variants/typed.ts:1:64](#finding-1248)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1248)|
|<a id="finding-1249"></a>[copy-005/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1249)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1249)|
|<a id="finding-1250"></a>[copy-005/tuning/example.js:1:22](#finding-1250)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1250)|
|<a id="finding-1251"></a>[copy-005/tuning/example.rb:1:29](#finding-1251)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1251)|
|<a id="finding-1252"></a>[copy-005/tuning/example.rs:1:13](#finding-1252)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1252)|
|<a id="finding-1253"></a>[copy-005/tuning/example.ts:1:28](#finding-1253)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1253)|
|<a id="finding-1254"></a>[copy-005/tuning/negative.js:3:16](#finding-1254)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1254)|
|<a id="finding-1255"></a>[copy-005/tuning/variants/alias.js:2:7](#finding-1255)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1255)|
|<a id="finding-1256"></a>[copy-005/tuning/variants/display.rb:1:7](#finding-1256)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1256)|
|<a id="finding-1257"></a>[copy-005/tuning/variants/draft.js:2:21](#finding-1257)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1257)|
|<a id="finding-1258"></a>[copy-005/tuning/variants/shadow.js:2:22](#finding-1258)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1258)|
|<a id="finding-1259"></a>[copy-005/tuning/variants/twice.js:1:22](#finding-1259)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1259)|
|<a id="finding-1260"></a>[copy-005/tuning/variants/twice.js:1:57](#finding-1260)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1260)|
|<a id="finding-1261"></a>[copy-005/tuning/variants/typed.ts:1:64](#finding-1261)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1261)|
|<a id="finding-1262"></a>[copy-006/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1262)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1262)|
|<a id="finding-1263"></a>[copy-006/tuning/example.js:1:22](#finding-1263)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1263)|
|<a id="finding-1264"></a>[copy-006/tuning/example.rb:1:29](#finding-1264)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1264)|
|<a id="finding-1265"></a>[copy-006/tuning/example.rs:1:13](#finding-1265)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1265)|
|<a id="finding-1266"></a>[copy-006/tuning/example.ts:1:28](#finding-1266)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1266)|
|<a id="finding-1267"></a>[copy-006/tuning/negative.js:3:16](#finding-1267)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1267)|
|<a id="finding-1268"></a>[copy-006/tuning/variants/alias.js:2:7](#finding-1268)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1268)|
|<a id="finding-1269"></a>[copy-006/tuning/variants/display.rb:1:7](#finding-1269)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1269)|
|<a id="finding-1270"></a>[copy-006/tuning/variants/draft.js:2:21](#finding-1270)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1270)|
|<a id="finding-1271"></a>[copy-006/tuning/variants/shadow.js:2:22](#finding-1271)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1271)|
|<a id="finding-1272"></a>[copy-006/tuning/variants/twice.js:1:22](#finding-1272)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1272)|
|<a id="finding-1273"></a>[copy-006/tuning/variants/twice.js:1:57](#finding-1273)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1273)|
|<a id="finding-1274"></a>[copy-006/tuning/variants/typed.ts:1:64](#finding-1274)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1274)|
|<a id="finding-1275"></a>[copy-007/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1275)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1275)|
|<a id="finding-1276"></a>[copy-007/tuning/example.js:1:22](#finding-1276)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1276)|
|<a id="finding-1277"></a>[copy-007/tuning/example.rb:1:29](#finding-1277)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1277)|
|<a id="finding-1278"></a>[copy-007/tuning/example.rs:1:13](#finding-1278)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1278)|
|<a id="finding-1279"></a>[copy-007/tuning/example.ts:1:28](#finding-1279)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1279)|
|<a id="finding-1280"></a>[copy-007/tuning/negative.js:3:16](#finding-1280)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1280)|
|<a id="finding-1281"></a>[copy-007/tuning/variants/alias.js:2:7](#finding-1281)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1281)|
|<a id="finding-1282"></a>[copy-007/tuning/variants/display.rb:1:7](#finding-1282)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1282)|
|<a id="finding-1283"></a>[copy-007/tuning/variants/draft.js:2:21](#finding-1283)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1283)|
|<a id="finding-1284"></a>[copy-007/tuning/variants/shadow.js:2:22](#finding-1284)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1284)|
|<a id="finding-1285"></a>[copy-007/tuning/variants/twice.js:1:22](#finding-1285)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1285)|
|<a id="finding-1286"></a>[copy-007/tuning/variants/twice.js:1:57](#finding-1286)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1286)|
|<a id="finding-1287"></a>[copy-007/tuning/variants/typed.ts:1:64](#finding-1287)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1287)|
|<a id="finding-1288"></a>[copy-008/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1288)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1288)|
|<a id="finding-1289"></a>[copy-008/tuning/example.js:1:22](#finding-1289)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1289)|
|<a id="finding-1290"></a>[copy-008/tuning/example.rb:1:29](#finding-1290)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1290)|
|<a id="finding-1291"></a>[copy-008/tuning/example.rs:1:13](#finding-1291)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1291)|
|<a id="finding-1292"></a>[copy-008/tuning/example.ts:1:28](#finding-1292)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1292)|
|<a id="finding-1293"></a>[copy-008/tuning/negative.js:3:16](#finding-1293)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1293)|
|<a id="finding-1294"></a>[copy-008/tuning/variants/alias.js:2:7](#finding-1294)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1294)|
|<a id="finding-1295"></a>[copy-008/tuning/variants/display.rb:1:7](#finding-1295)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1295)|
|<a id="finding-1296"></a>[copy-008/tuning/variants/draft.js:2:21](#finding-1296)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1296)|
|<a id="finding-1297"></a>[copy-008/tuning/variants/shadow.js:2:22](#finding-1297)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1297)|
|<a id="finding-1298"></a>[copy-008/tuning/variants/twice.js:1:22](#finding-1298)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1298)|
|<a id="finding-1299"></a>[copy-008/tuning/variants/twice.js:1:57](#finding-1299)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1299)|
|<a id="finding-1300"></a>[copy-008/tuning/variants/typed.ts:1:64](#finding-1300)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1300)|
|<a id="finding-1301"></a>[copy-009/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1301)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1301)|
|<a id="finding-1302"></a>[copy-009/tuning/example.js:1:22](#finding-1302)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1302)|
|<a id="finding-1303"></a>[copy-009/tuning/example.rb:1:29](#finding-1303)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1303)|
|<a id="finding-1304"></a>[copy-009/tuning/example.rs:1:13](#finding-1304)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1304)|
|<a id="finding-1305"></a>[copy-009/tuning/example.ts:1:28](#finding-1305)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1305)|
|<a id="finding-1306"></a>[copy-009/tuning/negative.js:3:16](#finding-1306)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1306)|
|<a id="finding-1307"></a>[copy-009/tuning/variants/alias.js:2:7](#finding-1307)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1307)|
|<a id="finding-1308"></a>[copy-009/tuning/variants/display.rb:1:7](#finding-1308)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1308)|
|<a id="finding-1309"></a>[copy-009/tuning/variants/draft.js:2:21](#finding-1309)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1309)|
|<a id="finding-1310"></a>[copy-009/tuning/variants/shadow.js:2:22](#finding-1310)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1310)|
|<a id="finding-1311"></a>[copy-009/tuning/variants/twice.js:1:22](#finding-1311)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1311)|
|<a id="finding-1312"></a>[copy-009/tuning/variants/twice.js:1:57](#finding-1312)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1312)|
|<a id="finding-1313"></a>[copy-009/tuning/variants/typed.ts:1:64](#finding-1313)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1313)|
|<a id="finding-1314"></a>[copy-010/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1314)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1314)|
|<a id="finding-1315"></a>[copy-010/tuning/example.js:1:22](#finding-1315)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1315)|
|<a id="finding-1316"></a>[copy-010/tuning/example.rb:1:29](#finding-1316)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1316)|
|<a id="finding-1317"></a>[copy-010/tuning/example.rs:1:13](#finding-1317)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1317)|
|<a id="finding-1318"></a>[copy-010/tuning/example.ts:1:28](#finding-1318)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1318)|
|<a id="finding-1319"></a>[copy-010/tuning/negative.js:3:16](#finding-1319)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1319)|
|<a id="finding-1320"></a>[copy-010/tuning/variants/alias.js:2:7](#finding-1320)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1320)|
|<a id="finding-1321"></a>[copy-010/tuning/variants/display.rb:1:7](#finding-1321)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1321)|
|<a id="finding-1322"></a>[copy-010/tuning/variants/draft.js:2:21](#finding-1322)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1322)|
|<a id="finding-1323"></a>[copy-010/tuning/variants/shadow.js:2:22](#finding-1323)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1323)|
|<a id="finding-1324"></a>[copy-010/tuning/variants/twice.js:1:22](#finding-1324)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1324)|
|<a id="finding-1325"></a>[copy-010/tuning/variants/twice.js:1:57](#finding-1325)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1325)|
|<a id="finding-1326"></a>[copy-010/tuning/variants/typed.ts:1:64](#finding-1326)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1326)|
|<a id="finding-1327"></a>[copy-011/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1327)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1327)|
|<a id="finding-1328"></a>[copy-011/tuning/example.js:1:22](#finding-1328)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1328)|
|<a id="finding-1329"></a>[copy-011/tuning/example.rb:1:29](#finding-1329)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1329)|
|<a id="finding-1330"></a>[copy-011/tuning/example.rs:1:13](#finding-1330)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1330)|
|<a id="finding-1331"></a>[copy-011/tuning/example.ts:1:28](#finding-1331)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1331)|
|<a id="finding-1332"></a>[copy-011/tuning/negative.js:3:16](#finding-1332)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1332)|
|<a id="finding-1333"></a>[copy-011/tuning/variants/alias.js:2:7](#finding-1333)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1333)|
|<a id="finding-1334"></a>[copy-011/tuning/variants/display.rb:1:7](#finding-1334)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1334)|
|<a id="finding-1335"></a>[copy-011/tuning/variants/draft.js:2:21](#finding-1335)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1335)|
|<a id="finding-1336"></a>[copy-011/tuning/variants/shadow.js:2:22](#finding-1336)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1336)|
|<a id="finding-1337"></a>[copy-011/tuning/variants/twice.js:1:22](#finding-1337)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1337)|
|<a id="finding-1338"></a>[copy-011/tuning/variants/twice.js:1:57](#finding-1338)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1338)|
|<a id="finding-1339"></a>[copy-011/tuning/variants/typed.ts:1:64](#finding-1339)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1339)|
|<a id="finding-1340"></a>[copy-012/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1340)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1340)|
|<a id="finding-1341"></a>[copy-012/tuning/example.js:1:22](#finding-1341)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1341)|
|<a id="finding-1342"></a>[copy-012/tuning/example.rb:1:29](#finding-1342)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1342)|
|<a id="finding-1343"></a>[copy-012/tuning/example.rs:1:13](#finding-1343)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1343)|
|<a id="finding-1344"></a>[copy-012/tuning/example.ts:1:28](#finding-1344)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1344)|
|<a id="finding-1345"></a>[copy-012/tuning/negative.js:3:16](#finding-1345)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1345)|
|<a id="finding-1346"></a>[copy-012/tuning/variants/alias.js:2:7](#finding-1346)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1346)|
|<a id="finding-1347"></a>[copy-012/tuning/variants/display.rb:1:7](#finding-1347)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1347)|
|<a id="finding-1348"></a>[copy-012/tuning/variants/draft.js:2:21](#finding-1348)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1348)|
|<a id="finding-1349"></a>[copy-012/tuning/variants/shadow.js:2:22](#finding-1349)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1349)|
|<a id="finding-1350"></a>[copy-012/tuning/variants/twice.js:1:22](#finding-1350)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1350)|
|<a id="finding-1351"></a>[copy-012/tuning/variants/twice.js:1:57](#finding-1351)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1351)|
|<a id="finding-1352"></a>[copy-012/tuning/variants/typed.ts:1:64](#finding-1352)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1352)|
|<a id="finding-1353"></a>[copy-013/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1353)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1353)|
|<a id="finding-1354"></a>[copy-013/tuning/example.js:1:22](#finding-1354)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1354)|
|<a id="finding-1355"></a>[copy-013/tuning/example.rb:1:29](#finding-1355)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1355)|
|<a id="finding-1356"></a>[copy-013/tuning/example.rs:1:13](#finding-1356)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1356)|
|<a id="finding-1357"></a>[copy-013/tuning/example.ts:1:28](#finding-1357)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1357)|
|<a id="finding-1358"></a>[copy-013/tuning/negative.js:3:16](#finding-1358)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1358)|
|<a id="finding-1359"></a>[copy-013/tuning/variants/alias.js:2:7](#finding-1359)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1359)|
|<a id="finding-1360"></a>[copy-013/tuning/variants/display.rb:1:7](#finding-1360)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1360)|
|<a id="finding-1361"></a>[copy-013/tuning/variants/draft.js:2:21](#finding-1361)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1361)|
|<a id="finding-1362"></a>[copy-013/tuning/variants/shadow.js:2:22](#finding-1362)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1362)|
|<a id="finding-1363"></a>[copy-013/tuning/variants/twice.js:1:22](#finding-1363)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1363)|
|<a id="finding-1364"></a>[copy-013/tuning/variants/twice.js:1:57](#finding-1364)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1364)|
|<a id="finding-1365"></a>[copy-013/tuning/variants/typed.ts:1:64](#finding-1365)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1365)|
|<a id="finding-1366"></a>[copy-014/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1366)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1366)|
|<a id="finding-1367"></a>[copy-014/tuning/example.js:1:22](#finding-1367)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1367)|
|<a id="finding-1368"></a>[copy-014/tuning/example.rb:1:29](#finding-1368)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1368)|
|<a id="finding-1369"></a>[copy-014/tuning/example.rs:1:13](#finding-1369)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1369)|
|<a id="finding-1370"></a>[copy-014/tuning/example.ts:1:28](#finding-1370)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1370)|
|<a id="finding-1371"></a>[copy-014/tuning/negative.js:3:16](#finding-1371)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1371)|
|<a id="finding-1372"></a>[copy-014/tuning/variants/alias.js:2:7](#finding-1372)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1372)|
|<a id="finding-1373"></a>[copy-014/tuning/variants/display.rb:1:7](#finding-1373)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1373)|
|<a id="finding-1374"></a>[copy-014/tuning/variants/draft.js:2:21](#finding-1374)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1374)|
|<a id="finding-1375"></a>[copy-014/tuning/variants/shadow.js:2:22](#finding-1375)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1375)|
|<a id="finding-1376"></a>[copy-014/tuning/variants/twice.js:1:22](#finding-1376)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1376)|
|<a id="finding-1377"></a>[copy-014/tuning/variants/twice.js:1:57](#finding-1377)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1377)|
|<a id="finding-1378"></a>[copy-014/tuning/variants/typed.ts:1:64](#finding-1378)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1378)|
|<a id="finding-1379"></a>[copy-015/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1379)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1379)|
|<a id="finding-1380"></a>[copy-015/tuning/example.js:1:22](#finding-1380)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1380)|
|<a id="finding-1381"></a>[copy-015/tuning/example.rb:1:29](#finding-1381)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1381)|
|<a id="finding-1382"></a>[copy-015/tuning/example.rs:1:13](#finding-1382)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1382)|
|<a id="finding-1383"></a>[copy-015/tuning/example.ts:1:28](#finding-1383)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1383)|
|<a id="finding-1384"></a>[copy-015/tuning/negative.js:3:16](#finding-1384)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1384)|
|<a id="finding-1385"></a>[copy-015/tuning/variants/alias.js:2:7](#finding-1385)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1385)|
|<a id="finding-1386"></a>[copy-015/tuning/variants/display.rb:1:7](#finding-1386)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1386)|
|<a id="finding-1387"></a>[copy-015/tuning/variants/draft.js:2:21](#finding-1387)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1387)|
|<a id="finding-1388"></a>[copy-015/tuning/variants/shadow.js:2:22](#finding-1388)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1388)|
|<a id="finding-1389"></a>[copy-015/tuning/variants/twice.js:1:22](#finding-1389)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1389)|
|<a id="finding-1390"></a>[copy-015/tuning/variants/twice.js:1:57](#finding-1390)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1390)|
|<a id="finding-1391"></a>[copy-015/tuning/variants/typed.ts:1:64](#finding-1391)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1391)|
|<a id="finding-1392"></a>[copy-016/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1392)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1392)|
|<a id="finding-1393"></a>[copy-016/tuning/example.js:1:22](#finding-1393)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1393)|
|<a id="finding-1394"></a>[copy-016/tuning/example.rb:1:29](#finding-1394)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1394)|
|<a id="finding-1395"></a>[copy-016/tuning/example.rs:1:13](#finding-1395)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1395)|
|<a id="finding-1396"></a>[copy-016/tuning/example.ts:1:28](#finding-1396)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1396)|
|<a id="finding-1397"></a>[copy-016/tuning/negative.js:3:16](#finding-1397)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1397)|
|<a id="finding-1398"></a>[copy-016/tuning/variants/alias.js:2:7](#finding-1398)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1398)|
|<a id="finding-1399"></a>[copy-016/tuning/variants/display.rb:1:7](#finding-1399)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1399)|
|<a id="finding-1400"></a>[copy-016/tuning/variants/draft.js:2:21](#finding-1400)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1400)|
|<a id="finding-1401"></a>[copy-016/tuning/variants/shadow.js:2:22](#finding-1401)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1401)|
|<a id="finding-1402"></a>[copy-016/tuning/variants/twice.js:1:22](#finding-1402)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1402)|
|<a id="finding-1403"></a>[copy-016/tuning/variants/twice.js:1:57](#finding-1403)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1403)|
|<a id="finding-1404"></a>[copy-016/tuning/variants/typed.ts:1:64](#finding-1404)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1404)|
|<a id="finding-1405"></a>[copy-017/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1405)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1405)|
|<a id="finding-1406"></a>[copy-017/tuning/example.js:1:22](#finding-1406)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1406)|
|<a id="finding-1407"></a>[copy-017/tuning/example.rb:1:29](#finding-1407)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1407)|
|<a id="finding-1408"></a>[copy-017/tuning/example.rs:1:13](#finding-1408)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1408)|
|<a id="finding-1409"></a>[copy-017/tuning/example.ts:1:28](#finding-1409)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1409)|
|<a id="finding-1410"></a>[copy-017/tuning/negative.js:3:16](#finding-1410)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1410)|
|<a id="finding-1411"></a>[copy-017/tuning/variants/alias.js:2:7](#finding-1411)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1411)|
|<a id="finding-1412"></a>[copy-017/tuning/variants/display.rb:1:7](#finding-1412)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1412)|
|<a id="finding-1413"></a>[copy-017/tuning/variants/draft.js:2:21](#finding-1413)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1413)|
|<a id="finding-1414"></a>[copy-017/tuning/variants/shadow.js:2:22](#finding-1414)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1414)|
|<a id="finding-1415"></a>[copy-017/tuning/variants/twice.js:1:22](#finding-1415)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1415)|
|<a id="finding-1416"></a>[copy-017/tuning/variants/twice.js:1:57](#finding-1416)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1416)|
|<a id="finding-1417"></a>[copy-017/tuning/variants/typed.ts:1:64](#finding-1417)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1417)|
|<a id="finding-1418"></a>[copy-018/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1418)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1418)|
|<a id="finding-1419"></a>[copy-018/tuning/example.js:1:22](#finding-1419)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1419)|
|<a id="finding-1420"></a>[copy-018/tuning/example.rb:1:29](#finding-1420)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1420)|
|<a id="finding-1421"></a>[copy-018/tuning/example.rs:1:13](#finding-1421)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1421)|
|<a id="finding-1422"></a>[copy-018/tuning/example.ts:1:28](#finding-1422)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1422)|
|<a id="finding-1423"></a>[copy-018/tuning/negative.js:3:16](#finding-1423)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1423)|
|<a id="finding-1424"></a>[copy-018/tuning/variants/alias.js:2:7](#finding-1424)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1424)|
|<a id="finding-1425"></a>[copy-018/tuning/variants/display.rb:1:7](#finding-1425)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1425)|
|<a id="finding-1426"></a>[copy-018/tuning/variants/draft.js:2:21](#finding-1426)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1426)|
|<a id="finding-1427"></a>[copy-018/tuning/variants/shadow.js:2:22](#finding-1427)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1427)|
|<a id="finding-1428"></a>[copy-018/tuning/variants/twice.js:1:22](#finding-1428)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1428)|
|<a id="finding-1429"></a>[copy-018/tuning/variants/twice.js:1:57](#finding-1429)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1429)|
|<a id="finding-1430"></a>[copy-018/tuning/variants/typed.ts:1:64](#finding-1430)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1430)|
|<a id="finding-1431"></a>[copy-019/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1431)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1431)|
|<a id="finding-1432"></a>[copy-019/tuning/example.js:1:22](#finding-1432)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1432)|
|<a id="finding-1433"></a>[copy-019/tuning/example.rb:1:29](#finding-1433)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1433)|
|<a id="finding-1434"></a>[copy-019/tuning/example.rs:1:13](#finding-1434)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1434)|
|<a id="finding-1435"></a>[copy-019/tuning/example.ts:1:28](#finding-1435)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1435)|
|<a id="finding-1436"></a>[copy-019/tuning/negative.js:3:16](#finding-1436)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1436)|
|<a id="finding-1437"></a>[copy-019/tuning/variants/alias.js:2:7](#finding-1437)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1437)|
|<a id="finding-1438"></a>[copy-019/tuning/variants/display.rb:1:7](#finding-1438)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1438)|
|<a id="finding-1439"></a>[copy-019/tuning/variants/draft.js:2:21](#finding-1439)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1439)|
|<a id="finding-1440"></a>[copy-019/tuning/variants/shadow.js:2:22](#finding-1440)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1440)|
|<a id="finding-1441"></a>[copy-019/tuning/variants/twice.js:1:22](#finding-1441)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1441)|
|<a id="finding-1442"></a>[copy-019/tuning/variants/twice.js:1:57](#finding-1442)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1442)|
|<a id="finding-1443"></a>[copy-019/tuning/variants/typed.ts:1:64](#finding-1443)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1443)|
|<a id="finding-1444"></a>[copy-020/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1444)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1444)|
|<a id="finding-1445"></a>[copy-020/tuning/example.js:1:22](#finding-1445)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1445)|
|<a id="finding-1446"></a>[copy-020/tuning/example.rb:1:29](#finding-1446)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1446)|
|<a id="finding-1447"></a>[copy-020/tuning/example.rs:1:13](#finding-1447)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1447)|
|<a id="finding-1448"></a>[copy-020/tuning/example.ts:1:28](#finding-1448)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1448)|
|<a id="finding-1449"></a>[copy-020/tuning/negative.js:3:16](#finding-1449)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1449)|
|<a id="finding-1450"></a>[copy-020/tuning/variants/alias.js:2:7](#finding-1450)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1450)|
|<a id="finding-1451"></a>[copy-020/tuning/variants/display.rb:1:7](#finding-1451)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1451)|
|<a id="finding-1452"></a>[copy-020/tuning/variants/draft.js:2:21](#finding-1452)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1452)|
|<a id="finding-1453"></a>[copy-020/tuning/variants/shadow.js:2:22](#finding-1453)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1453)|
|<a id="finding-1454"></a>[copy-020/tuning/variants/twice.js:1:22](#finding-1454)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1454)|
|<a id="finding-1455"></a>[copy-020/tuning/variants/twice.js:1:57](#finding-1455)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1455)|
|<a id="finding-1456"></a>[copy-020/tuning/variants/typed.ts:1:64](#finding-1456)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1456)|
|<a id="finding-1457"></a>[copy-021/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1457)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1457)|
|<a id="finding-1458"></a>[copy-021/tuning/example.js:1:22](#finding-1458)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1458)|
|<a id="finding-1459"></a>[copy-021/tuning/example.rb:1:29](#finding-1459)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1459)|
|<a id="finding-1460"></a>[copy-021/tuning/example.rs:1:13](#finding-1460)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1460)|
|<a id="finding-1461"></a>[copy-021/tuning/example.ts:1:28](#finding-1461)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1461)|
|<a id="finding-1462"></a>[copy-021/tuning/negative.js:3:16](#finding-1462)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1462)|
|<a id="finding-1463"></a>[copy-021/tuning/variants/alias.js:2:7](#finding-1463)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1463)|
|<a id="finding-1464"></a>[copy-021/tuning/variants/display.rb:1:7](#finding-1464)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1464)|
|<a id="finding-1465"></a>[copy-021/tuning/variants/draft.js:2:21](#finding-1465)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1465)|
|<a id="finding-1466"></a>[copy-021/tuning/variants/shadow.js:2:22](#finding-1466)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1466)|
|<a id="finding-1467"></a>[copy-021/tuning/variants/twice.js:1:22](#finding-1467)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1467)|
|<a id="finding-1468"></a>[copy-021/tuning/variants/twice.js:1:57](#finding-1468)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1468)|
|<a id="finding-1469"></a>[copy-021/tuning/variants/typed.ts:1:64](#finding-1469)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1469)|
|<a id="finding-1470"></a>[copy-022/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1470)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1470)|
|<a id="finding-1471"></a>[copy-022/tuning/example.js:1:22](#finding-1471)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1471)|
|<a id="finding-1472"></a>[copy-022/tuning/example.rb:1:29](#finding-1472)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1472)|
|<a id="finding-1473"></a>[copy-022/tuning/example.rs:1:13](#finding-1473)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1473)|
|<a id="finding-1474"></a>[copy-022/tuning/example.ts:1:28](#finding-1474)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1474)|
|<a id="finding-1475"></a>[copy-022/tuning/negative.js:3:16](#finding-1475)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1475)|
|<a id="finding-1476"></a>[copy-022/tuning/variants/alias.js:2:7](#finding-1476)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1476)|
|<a id="finding-1477"></a>[copy-022/tuning/variants/display.rb:1:7](#finding-1477)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1477)|
|<a id="finding-1478"></a>[copy-022/tuning/variants/draft.js:2:21](#finding-1478)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1478)|
|<a id="finding-1479"></a>[copy-022/tuning/variants/shadow.js:2:22](#finding-1479)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1479)|
|<a id="finding-1480"></a>[copy-022/tuning/variants/twice.js:1:22](#finding-1480)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1480)|
|<a id="finding-1481"></a>[copy-022/tuning/variants/twice.js:1:57](#finding-1481)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1481)|
|<a id="finding-1482"></a>[copy-022/tuning/variants/typed.ts:1:64](#finding-1482)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1482)|
|<a id="finding-1483"></a>[copy-023/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1483)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1483)|
|<a id="finding-1484"></a>[copy-023/tuning/example.js:1:22](#finding-1484)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1484)|
|<a id="finding-1485"></a>[copy-023/tuning/example.rb:1:29](#finding-1485)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1485)|
|<a id="finding-1486"></a>[copy-023/tuning/example.rs:1:13](#finding-1486)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1486)|
|<a id="finding-1487"></a>[copy-023/tuning/example.ts:1:28](#finding-1487)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1487)|
|<a id="finding-1488"></a>[copy-023/tuning/negative.js:3:16](#finding-1488)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1488)|
|<a id="finding-1489"></a>[copy-023/tuning/variants/alias.js:2:7](#finding-1489)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1489)|
|<a id="finding-1490"></a>[copy-023/tuning/variants/display.rb:1:7](#finding-1490)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1490)|
|<a id="finding-1491"></a>[copy-023/tuning/variants/draft.js:2:21](#finding-1491)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1491)|
|<a id="finding-1492"></a>[copy-023/tuning/variants/shadow.js:2:22](#finding-1492)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1492)|
|<a id="finding-1493"></a>[copy-023/tuning/variants/twice.js:1:22](#finding-1493)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1493)|
|<a id="finding-1494"></a>[copy-023/tuning/variants/twice.js:1:57](#finding-1494)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1494)|
|<a id="finding-1495"></a>[copy-023/tuning/variants/typed.ts:1:64](#finding-1495)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1495)|
|<a id="finding-1496"></a>[copy-024/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1496)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1496)|
|<a id="finding-1497"></a>[copy-024/tuning/example.js:1:22](#finding-1497)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1497)|
|<a id="finding-1498"></a>[copy-024/tuning/example.rb:1:29](#finding-1498)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1498)|
|<a id="finding-1499"></a>[copy-024/tuning/example.rs:1:13](#finding-1499)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1499)|
|<a id="finding-1500"></a>[copy-024/tuning/example.ts:1:28](#finding-1500)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1500)|
|<a id="finding-1501"></a>[copy-024/tuning/negative.js:3:16](#finding-1501)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1501)|
|<a id="finding-1502"></a>[copy-024/tuning/variants/alias.js:2:7](#finding-1502)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1502)|
|<a id="finding-1503"></a>[copy-024/tuning/variants/display.rb:1:7](#finding-1503)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1503)|
|<a id="finding-1504"></a>[copy-024/tuning/variants/draft.js:2:21](#finding-1504)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1504)|
|<a id="finding-1505"></a>[copy-024/tuning/variants/shadow.js:2:22](#finding-1505)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1505)|
|<a id="finding-1506"></a>[copy-024/tuning/variants/twice.js:1:22](#finding-1506)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1506)|
|<a id="finding-1507"></a>[copy-024/tuning/variants/twice.js:1:57](#finding-1507)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1507)|
|<a id="finding-1508"></a>[copy-024/tuning/variants/typed.ts:1:64](#finding-1508)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1508)|
|<a id="finding-1509"></a>[copy-025/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1509)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1509)|
|<a id="finding-1510"></a>[copy-025/tuning/example.js:1:22](#finding-1510)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1510)|
|<a id="finding-1511"></a>[copy-025/tuning/example.rb:1:29](#finding-1511)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1511)|
|<a id="finding-1512"></a>[copy-025/tuning/example.rs:1:13](#finding-1512)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1512)|
|<a id="finding-1513"></a>[copy-025/tuning/example.ts:1:28](#finding-1513)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1513)|
|<a id="finding-1514"></a>[copy-025/tuning/negative.js:3:16](#finding-1514)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1514)|
|<a id="finding-1515"></a>[copy-025/tuning/variants/alias.js:2:7](#finding-1515)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1515)|
|<a id="finding-1516"></a>[copy-025/tuning/variants/display.rb:1:7](#finding-1516)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1516)|
|<a id="finding-1517"></a>[copy-025/tuning/variants/draft.js:2:21](#finding-1517)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1517)|
|<a id="finding-1518"></a>[copy-025/tuning/variants/shadow.js:2:22](#finding-1518)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1518)|
|<a id="finding-1519"></a>[copy-025/tuning/variants/twice.js:1:22](#finding-1519)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1519)|
|<a id="finding-1520"></a>[copy-025/tuning/variants/twice.js:1:57](#finding-1520)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1520)|
|<a id="finding-1521"></a>[copy-025/tuning/variants/typed.ts:1:64](#finding-1521)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1521)|
|<a id="finding-1522"></a>[copy-026/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1522)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1522)|
|<a id="finding-1523"></a>[copy-026/tuning/example.js:1:22](#finding-1523)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1523)|
|<a id="finding-1524"></a>[copy-026/tuning/example.rb:1:29](#finding-1524)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1524)|
|<a id="finding-1525"></a>[copy-026/tuning/example.rs:1:13](#finding-1525)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1525)|
|<a id="finding-1526"></a>[copy-026/tuning/example.ts:1:28](#finding-1526)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1526)|
|<a id="finding-1527"></a>[copy-026/tuning/negative.js:3:16](#finding-1527)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1527)|
|<a id="finding-1528"></a>[copy-026/tuning/variants/alias.js:2:7](#finding-1528)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1528)|
|<a id="finding-1529"></a>[copy-026/tuning/variants/display.rb:1:7](#finding-1529)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1529)|
|<a id="finding-1530"></a>[copy-026/tuning/variants/draft.js:2:21](#finding-1530)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1530)|
|<a id="finding-1531"></a>[copy-026/tuning/variants/shadow.js:2:22](#finding-1531)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1531)|
|<a id="finding-1532"></a>[copy-026/tuning/variants/twice.js:1:22](#finding-1532)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1532)|
|<a id="finding-1533"></a>[copy-026/tuning/variants/twice.js:1:57](#finding-1533)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1533)|
|<a id="finding-1534"></a>[copy-026/tuning/variants/typed.ts:1:64](#finding-1534)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1534)|
|<a id="finding-1535"></a>[copy-027/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1535)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1535)|
|<a id="finding-1536"></a>[copy-027/tuning/example.js:1:22](#finding-1536)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1536)|
|<a id="finding-1537"></a>[copy-027/tuning/example.rb:1:29](#finding-1537)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1537)|
|<a id="finding-1538"></a>[copy-027/tuning/example.rs:1:13](#finding-1538)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1538)|
|<a id="finding-1539"></a>[copy-027/tuning/example.ts:1:28](#finding-1539)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1539)|
|<a id="finding-1540"></a>[copy-027/tuning/negative.js:3:16](#finding-1540)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1540)|
|<a id="finding-1541"></a>[copy-027/tuning/variants/alias.js:2:7](#finding-1541)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1541)|
|<a id="finding-1542"></a>[copy-027/tuning/variants/display.rb:1:7](#finding-1542)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1542)|
|<a id="finding-1543"></a>[copy-027/tuning/variants/draft.js:2:21](#finding-1543)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1543)|
|<a id="finding-1544"></a>[copy-027/tuning/variants/shadow.js:2:22](#finding-1544)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1544)|
|<a id="finding-1545"></a>[copy-027/tuning/variants/twice.js:1:22](#finding-1545)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1545)|
|<a id="finding-1546"></a>[copy-027/tuning/variants/twice.js:1:57](#finding-1546)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1546)|
|<a id="finding-1547"></a>[copy-027/tuning/variants/typed.ts:1:64](#finding-1547)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1547)|
|<a id="finding-1548"></a>[copy-028/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1548)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1548)|
|<a id="finding-1549"></a>[copy-028/tuning/example.js:1:22](#finding-1549)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1549)|
|<a id="finding-1550"></a>[copy-028/tuning/example.rb:1:29](#finding-1550)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1550)|
|<a id="finding-1551"></a>[copy-028/tuning/example.rs:1:13](#finding-1551)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1551)|
|<a id="finding-1552"></a>[copy-028/tuning/example.ts:1:28](#finding-1552)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1552)|
|<a id="finding-1553"></a>[copy-028/tuning/negative.js:3:16](#finding-1553)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1553)|
|<a id="finding-1554"></a>[copy-028/tuning/variants/alias.js:2:7](#finding-1554)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1554)|
|<a id="finding-1555"></a>[copy-028/tuning/variants/display.rb:1:7](#finding-1555)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1555)|
|<a id="finding-1556"></a>[copy-028/tuning/variants/draft.js:2:21](#finding-1556)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1556)|
|<a id="finding-1557"></a>[copy-028/tuning/variants/shadow.js:2:22](#finding-1557)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1557)|
|<a id="finding-1558"></a>[copy-028/tuning/variants/twice.js:1:22](#finding-1558)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1558)|
|<a id="finding-1559"></a>[copy-028/tuning/variants/twice.js:1:57](#finding-1559)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1559)|
|<a id="finding-1560"></a>[copy-028/tuning/variants/typed.ts:1:64](#finding-1560)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1560)|
|<a id="finding-1561"></a>[copy-029/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1561)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1561)|
|<a id="finding-1562"></a>[copy-029/tuning/example.js:1:22](#finding-1562)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1562)|
|<a id="finding-1563"></a>[copy-029/tuning/example.rb:1:29](#finding-1563)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1563)|
|<a id="finding-1564"></a>[copy-029/tuning/example.rs:1:13](#finding-1564)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1564)|
|<a id="finding-1565"></a>[copy-029/tuning/example.ts:1:28](#finding-1565)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1565)|
|<a id="finding-1566"></a>[copy-029/tuning/negative.js:3:16](#finding-1566)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1566)|
|<a id="finding-1567"></a>[copy-029/tuning/variants/alias.js:2:7](#finding-1567)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1567)|
|<a id="finding-1568"></a>[copy-029/tuning/variants/display.rb:1:7](#finding-1568)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1568)|
|<a id="finding-1569"></a>[copy-029/tuning/variants/draft.js:2:21](#finding-1569)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1569)|
|<a id="finding-1570"></a>[copy-029/tuning/variants/shadow.js:2:22](#finding-1570)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1570)|
|<a id="finding-1571"></a>[copy-029/tuning/variants/twice.js:1:22](#finding-1571)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1571)|
|<a id="finding-1572"></a>[copy-029/tuning/variants/twice.js:1:57](#finding-1572)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1572)|
|<a id="finding-1573"></a>[copy-029/tuning/variants/typed.ts:1:64](#finding-1573)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1573)|
|<a id="finding-1574"></a>[copy-030/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1574)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1574)|
|<a id="finding-1575"></a>[copy-030/tuning/example.js:1:22](#finding-1575)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1575)|
|<a id="finding-1576"></a>[copy-030/tuning/example.rb:1:29](#finding-1576)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1576)|
|<a id="finding-1577"></a>[copy-030/tuning/example.rs:1:13](#finding-1577)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1577)|
|<a id="finding-1578"></a>[copy-030/tuning/example.ts:1:28](#finding-1578)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1578)|
|<a id="finding-1579"></a>[copy-030/tuning/negative.js:3:16](#finding-1579)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1579)|
|<a id="finding-1580"></a>[copy-030/tuning/variants/alias.js:2:7](#finding-1580)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1580)|
|<a id="finding-1581"></a>[copy-030/tuning/variants/display.rb:1:7](#finding-1581)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1581)|
|<a id="finding-1582"></a>[copy-030/tuning/variants/draft.js:2:21](#finding-1582)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1582)|
|<a id="finding-1583"></a>[copy-030/tuning/variants/shadow.js:2:22](#finding-1583)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1583)|
|<a id="finding-1584"></a>[copy-030/tuning/variants/twice.js:1:22](#finding-1584)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1584)|
|<a id="finding-1585"></a>[copy-030/tuning/variants/twice.js:1:57](#finding-1585)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1585)|
|<a id="finding-1586"></a>[copy-030/tuning/variants/typed.ts:1:64](#finding-1586)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1586)|
|<a id="finding-1587"></a>[copy-031/holdout/approval-adapter/rotation_queue.js:7:6](#finding-1587)|ml-dsa-87|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1587)|
|<a id="finding-1588"></a>[copy-031/tuning/example.js:1:22](#finding-1588)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1588)|
|<a id="finding-1589"></a>[copy-031/tuning/example.rb:1:29](#finding-1589)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1589)|
|<a id="finding-1590"></a>[copy-031/tuning/example.rs:1:13](#finding-1590)|MlKem768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1590)|
|<a id="finding-1591"></a>[copy-031/tuning/example.ts:1:28](#finding-1591)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1591)|
|<a id="finding-1592"></a>[copy-031/tuning/negative.js:3:16](#finding-1592)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1592)|
|<a id="finding-1593"></a>[copy-031/tuning/variants/alias.js:2:7](#finding-1593)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1593)|
|<a id="finding-1594"></a>[copy-031/tuning/variants/display.rb:1:7](#finding-1594)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1594)|
|<a id="finding-1595"></a>[copy-031/tuning/variants/draft.js:2:21](#finding-1595)|X25519MLKEM768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1595)|
|<a id="finding-1596"></a>[copy-031/tuning/variants/shadow.js:2:22](#finding-1596)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1596)|
|<a id="finding-1597"></a>[copy-031/tuning/variants/twice.js:1:22](#finding-1597)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1597)|
|<a id="finding-1598"></a>[copy-031/tuning/variants/twice.js:1:57](#finding-1598)|ml-kem-768|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1598)|
|<a id="finding-1599"></a>[copy-031/tuning/variants/typed.ts:1:64](#finding-1599)|ML-DSA-65|A standardized PQC name or hybrid group is referenced. Check implementation, parameter set, provider and actual use; this is not proof of execution, FIPS conformance or product security. / [Source](#source-1599)|

<a id="source-1184"></a>

### copy-000/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1185"></a>

### copy-000/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1186"></a>

### copy-000/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1187"></a>

### copy-000/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1188"></a>

### copy-000/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1189"></a>

### copy-000/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1190"></a>

### copy-000/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1191"></a>

### copy-000/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1192"></a>

### copy-000/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1193"></a>

### copy-000/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1194"></a>

### copy-000/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1195"></a>

### copy-000/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1196"></a>

### copy-000/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1197"></a>

### copy-001/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1198"></a>

### copy-001/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1199"></a>

### copy-001/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1200"></a>

### copy-001/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1201"></a>

### copy-001/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1202"></a>

### copy-001/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1203"></a>

### copy-001/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1204"></a>

### copy-001/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1205"></a>

### copy-001/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1206"></a>

### copy-001/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1207"></a>

### copy-001/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1208"></a>

### copy-001/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1209"></a>

### copy-001/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1210"></a>

### copy-002/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1211"></a>

### copy-002/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1212"></a>

### copy-002/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1213"></a>

### copy-002/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1214"></a>

### copy-002/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1215"></a>

### copy-002/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1216"></a>

### copy-002/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1217"></a>

### copy-002/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1218"></a>

### copy-002/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1219"></a>

### copy-002/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1220"></a>

### copy-002/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1221"></a>

### copy-002/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1222"></a>

### copy-002/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1223"></a>

### copy-003/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1224"></a>

### copy-003/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1225"></a>

### copy-003/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1226"></a>

### copy-003/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1227"></a>

### copy-003/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1228"></a>

### copy-003/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1229"></a>

### copy-003/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1230"></a>

### copy-003/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1231"></a>

### copy-003/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1232"></a>

### copy-003/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1233"></a>

### copy-003/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1234"></a>

### copy-003/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1235"></a>

### copy-003/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1236"></a>

### copy-004/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1237"></a>

### copy-004/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1238"></a>

### copy-004/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1239"></a>

### copy-004/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1240"></a>

### copy-004/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1241"></a>

### copy-004/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1242"></a>

### copy-004/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1243"></a>

### copy-004/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1244"></a>

### copy-004/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1245"></a>

### copy-004/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1246"></a>

### copy-004/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1247"></a>

### copy-004/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1248"></a>

### copy-004/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1249"></a>

### copy-005/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1250"></a>

### copy-005/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1251"></a>

### copy-005/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1252"></a>

### copy-005/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1253"></a>

### copy-005/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1254"></a>

### copy-005/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1255"></a>

### copy-005/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1256"></a>

### copy-005/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1257"></a>

### copy-005/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1258"></a>

### copy-005/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1259"></a>

### copy-005/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1260"></a>

### copy-005/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1261"></a>

### copy-005/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1262"></a>

### copy-006/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1263"></a>

### copy-006/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1264"></a>

### copy-006/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1265"></a>

### copy-006/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1266"></a>

### copy-006/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1267"></a>

### copy-006/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1268"></a>

### copy-006/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1269"></a>

### copy-006/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1270"></a>

### copy-006/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1271"></a>

### copy-006/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1272"></a>

### copy-006/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1273"></a>

### copy-006/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1274"></a>

### copy-006/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1275"></a>

### copy-007/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1276"></a>

### copy-007/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1277"></a>

### copy-007/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1278"></a>

### copy-007/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1279"></a>

### copy-007/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1280"></a>

### copy-007/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1281"></a>

### copy-007/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1282"></a>

### copy-007/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1283"></a>

### copy-007/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1284"></a>

### copy-007/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1285"></a>

### copy-007/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1286"></a>

### copy-007/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1287"></a>

### copy-007/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1288"></a>

### copy-008/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1289"></a>

### copy-008/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1290"></a>

### copy-008/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1291"></a>

### copy-008/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1292"></a>

### copy-008/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1293"></a>

### copy-008/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1294"></a>

### copy-008/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1295"></a>

### copy-008/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1296"></a>

### copy-008/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1297"></a>

### copy-008/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1298"></a>

### copy-008/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1299"></a>

### copy-008/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1300"></a>

### copy-008/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1301"></a>

### copy-009/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1302"></a>

### copy-009/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1303"></a>

### copy-009/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1304"></a>

### copy-009/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1305"></a>

### copy-009/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1306"></a>

### copy-009/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1307"></a>

### copy-009/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1308"></a>

### copy-009/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1309"></a>

### copy-009/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1310"></a>

### copy-009/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1311"></a>

### copy-009/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1312"></a>

### copy-009/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1313"></a>

### copy-009/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1314"></a>

### copy-010/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1315"></a>

### copy-010/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1316"></a>

### copy-010/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1317"></a>

### copy-010/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1318"></a>

### copy-010/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1319"></a>

### copy-010/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1320"></a>

### copy-010/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1321"></a>

### copy-010/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1322"></a>

### copy-010/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1323"></a>

### copy-010/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1324"></a>

### copy-010/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1325"></a>

### copy-010/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1326"></a>

### copy-010/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1327"></a>

### copy-011/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1328"></a>

### copy-011/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1329"></a>

### copy-011/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1330"></a>

### copy-011/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1331"></a>

### copy-011/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1332"></a>

### copy-011/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1333"></a>

### copy-011/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1334"></a>

### copy-011/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1335"></a>

### copy-011/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1336"></a>

### copy-011/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1337"></a>

### copy-011/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1338"></a>

### copy-011/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1339"></a>

### copy-011/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1340"></a>

### copy-012/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1341"></a>

### copy-012/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1342"></a>

### copy-012/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1343"></a>

### copy-012/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1344"></a>

### copy-012/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1345"></a>

### copy-012/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1346"></a>

### copy-012/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1347"></a>

### copy-012/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1348"></a>

### copy-012/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1349"></a>

### copy-012/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1350"></a>

### copy-012/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1351"></a>

### copy-012/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1352"></a>

### copy-012/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1353"></a>

### copy-013/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1354"></a>

### copy-013/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1355"></a>

### copy-013/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1356"></a>

### copy-013/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1357"></a>

### copy-013/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1358"></a>

### copy-013/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1359"></a>

### copy-013/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1360"></a>

### copy-013/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1361"></a>

### copy-013/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1362"></a>

### copy-013/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1363"></a>

### copy-013/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1364"></a>

### copy-013/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1365"></a>

### copy-013/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1366"></a>

### copy-014/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1367"></a>

### copy-014/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1368"></a>

### copy-014/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1369"></a>

### copy-014/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1370"></a>

### copy-014/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1371"></a>

### copy-014/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1372"></a>

### copy-014/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1373"></a>

### copy-014/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1374"></a>

### copy-014/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1375"></a>

### copy-014/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1376"></a>

### copy-014/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1377"></a>

### copy-014/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1378"></a>

### copy-014/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1379"></a>

### copy-015/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1380"></a>

### copy-015/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1381"></a>

### copy-015/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1382"></a>

### copy-015/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1383"></a>

### copy-015/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1384"></a>

### copy-015/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1385"></a>

### copy-015/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1386"></a>

### copy-015/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1387"></a>

### copy-015/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1388"></a>

### copy-015/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1389"></a>

### copy-015/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1390"></a>

### copy-015/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1391"></a>

### copy-015/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1392"></a>

### copy-016/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1393"></a>

### copy-016/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1394"></a>

### copy-016/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1395"></a>

### copy-016/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1396"></a>

### copy-016/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1397"></a>

### copy-016/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1398"></a>

### copy-016/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1399"></a>

### copy-016/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1400"></a>

### copy-016/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1401"></a>

### copy-016/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1402"></a>

### copy-016/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1403"></a>

### copy-016/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1404"></a>

### copy-016/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1405"></a>

### copy-017/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1406"></a>

### copy-017/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1407"></a>

### copy-017/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1408"></a>

### copy-017/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1409"></a>

### copy-017/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1410"></a>

### copy-017/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1411"></a>

### copy-017/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1412"></a>

### copy-017/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1413"></a>

### copy-017/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1414"></a>

### copy-017/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1415"></a>

### copy-017/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1416"></a>

### copy-017/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1417"></a>

### copy-017/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1418"></a>

### copy-018/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1419"></a>

### copy-018/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1420"></a>

### copy-018/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1421"></a>

### copy-018/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1422"></a>

### copy-018/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1423"></a>

### copy-018/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1424"></a>

### copy-018/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1425"></a>

### copy-018/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1426"></a>

### copy-018/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1427"></a>

### copy-018/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1428"></a>

### copy-018/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1429"></a>

### copy-018/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1430"></a>

### copy-018/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1431"></a>

### copy-019/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1432"></a>

### copy-019/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1433"></a>

### copy-019/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1434"></a>

### copy-019/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1435"></a>

### copy-019/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1436"></a>

### copy-019/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1437"></a>

### copy-019/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1438"></a>

### copy-019/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1439"></a>

### copy-019/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1440"></a>

### copy-019/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1441"></a>

### copy-019/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1442"></a>

### copy-019/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1443"></a>

### copy-019/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1444"></a>

### copy-020/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1445"></a>

### copy-020/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1446"></a>

### copy-020/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1447"></a>

### copy-020/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1448"></a>

### copy-020/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1449"></a>

### copy-020/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1450"></a>

### copy-020/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1451"></a>

### copy-020/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1452"></a>

### copy-020/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1453"></a>

### copy-020/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1454"></a>

### copy-020/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1455"></a>

### copy-020/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1456"></a>

### copy-020/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1457"></a>

### copy-021/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1458"></a>

### copy-021/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1459"></a>

### copy-021/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1460"></a>

### copy-021/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1461"></a>

### copy-021/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1462"></a>

### copy-021/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1463"></a>

### copy-021/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1464"></a>

### copy-021/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1465"></a>

### copy-021/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1466"></a>

### copy-021/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1467"></a>

### copy-021/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1468"></a>

### copy-021/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1469"></a>

### copy-021/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1470"></a>

### copy-022/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1471"></a>

### copy-022/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1472"></a>

### copy-022/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1473"></a>

### copy-022/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1474"></a>

### copy-022/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1475"></a>

### copy-022/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1476"></a>

### copy-022/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1477"></a>

### copy-022/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1478"></a>

### copy-022/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1479"></a>

### copy-022/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1480"></a>

### copy-022/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1481"></a>

### copy-022/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1482"></a>

### copy-022/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1483"></a>

### copy-023/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1484"></a>

### copy-023/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1485"></a>

### copy-023/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1486"></a>

### copy-023/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1487"></a>

### copy-023/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1488"></a>

### copy-023/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1489"></a>

### copy-023/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1490"></a>

### copy-023/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1491"></a>

### copy-023/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1492"></a>

### copy-023/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1493"></a>

### copy-023/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1494"></a>

### copy-023/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1495"></a>

### copy-023/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1496"></a>

### copy-024/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1497"></a>

### copy-024/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1498"></a>

### copy-024/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1499"></a>

### copy-024/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1500"></a>

### copy-024/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1501"></a>

### copy-024/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1502"></a>

### copy-024/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1503"></a>

### copy-024/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1504"></a>

### copy-024/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1505"></a>

### copy-024/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1506"></a>

### copy-024/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1507"></a>

### copy-024/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1508"></a>

### copy-024/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1509"></a>

### copy-025/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1510"></a>

### copy-025/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1511"></a>

### copy-025/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1512"></a>

### copy-025/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1513"></a>

### copy-025/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1514"></a>

### copy-025/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1515"></a>

### copy-025/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1516"></a>

### copy-025/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1517"></a>

### copy-025/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1518"></a>

### copy-025/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1519"></a>

### copy-025/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1520"></a>

### copy-025/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1521"></a>

### copy-025/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1522"></a>

### copy-026/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1523"></a>

### copy-026/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1524"></a>

### copy-026/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1525"></a>

### copy-026/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1526"></a>

### copy-026/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1527"></a>

### copy-026/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1528"></a>

### copy-026/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1529"></a>

### copy-026/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1530"></a>

### copy-026/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1531"></a>

### copy-026/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1532"></a>

### copy-026/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1533"></a>

### copy-026/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1534"></a>

### copy-026/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1535"></a>

### copy-027/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1536"></a>

### copy-027/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1537"></a>

### copy-027/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1538"></a>

### copy-027/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1539"></a>

### copy-027/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1540"></a>

### copy-027/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1541"></a>

### copy-027/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1542"></a>

### copy-027/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1543"></a>

### copy-027/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1544"></a>

### copy-027/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1545"></a>

### copy-027/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1546"></a>

### copy-027/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1547"></a>

### copy-027/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1548"></a>

### copy-028/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1549"></a>

### copy-028/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1550"></a>

### copy-028/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1551"></a>

### copy-028/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1552"></a>

### copy-028/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1553"></a>

### copy-028/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1554"></a>

### copy-028/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1555"></a>

### copy-028/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1556"></a>

### copy-028/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1557"></a>

### copy-028/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1558"></a>

### copy-028/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1559"></a>

### copy-028/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1560"></a>

### copy-028/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1561"></a>

### copy-029/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1562"></a>

### copy-029/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1563"></a>

### copy-029/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1564"></a>

### copy-029/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1565"></a>

### copy-029/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1566"></a>

### copy-029/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1567"></a>

### copy-029/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1568"></a>

### copy-029/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1569"></a>

### copy-029/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1570"></a>

### copy-029/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1571"></a>

### copy-029/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1572"></a>

### copy-029/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1573"></a>

### copy-029/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1574"></a>

### copy-030/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1575"></a>

### copy-030/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1576"></a>

### copy-030/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1577"></a>

### copy-030/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1578"></a>

### copy-030/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1579"></a>

### copy-030/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1580"></a>

### copy-030/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1581"></a>

### copy-030/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1582"></a>

### copy-030/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1583"></a>

### copy-030/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1584"></a>

### copy-030/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1585"></a>

### copy-030/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1586"></a>

### copy-030/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1587"></a>

### copy-031/holdout/approval-adapter/rotation_queue.js:7:6

      5 export function prepareApprovalRotation(recordCompletion) {
      6   nodeCrypto.generateKeyPair(
    > 7     'ml-dsa-87',
      8     recordCompletion
      9   );

<a id="source-1588"></a>

### copy-031/tuning/example.js:1:22

    > 1 generateKeyPairSync('ml-kem-768');

<a id="source-1589"></a>

### copy-031/tuning/example.rb:1:29

    > 1 OpenSSL::PKey.generate_key('ML-DSA-65')

<a id="source-1590"></a>

### copy-031/tuning/example.rs:1:13

    > 1 use ml_kem::MlKem768;

<a id="source-1591"></a>

### copy-031/tuning/example.ts:1:28

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1592"></a>

### copy-031/tuning/negative.js:3:16

      1 // generateKeyPairSync('ml-kem-768');
      2 const ML_KEM_helper = 1;
    > 3 const group = 'X25519MLKEM768';

<a id="source-1593"></a>

### copy-031/tuning/variants/alias.js:2:7

      1 import { generateKeyPairSync as pair } from 'node:crypto';
    > 2 pair('ml-kem-768');

<a id="source-1594"></a>

### copy-031/tuning/variants/display.rb:1:7

    > 1 puts 'ML-DSA-65'

<a id="source-1595"></a>

### copy-031/tuning/variants/draft.js:2:21

      1 const oldGroup = 'X25519Kyber768Draft00';
    > 2 const finalGroup = 'X25519MLKEM768';

<a id="source-1596"></a>

### copy-031/tuning/variants/shadow.js:2:22

      1 function generateKeyPairSync(x) { return x.length; }
    > 2 generateKeyPairSync('ml-kem-768');

<a id="source-1597"></a>

### copy-031/tuning/variants/twice.js:1:22

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1598"></a>

### copy-031/tuning/variants/twice.js:1:57

    > 1 generateKeyPairSync('ml-kem-768'); generateKeyPairSync('ml-kem-768');

<a id="source-1599"></a>

### copy-031/tuning/variants/typed.ts:1:64

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="rule-22"></a>

## PQC_WEBCRYPTO_API

WebCrypto-style PQC algorithm request; this is not proof of browser support.

Check: Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately.

|Location|Evidence|Next action / details|
|---|---|---|
|<a id="finding-1600"></a>[copy-000/tuning/example.ts:1:8](#finding-1600)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1600)|
|<a id="finding-1601"></a>[copy-000/tuning/variants/typed.ts:1:44](#finding-1601)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1601)|
|<a id="finding-1602"></a>[copy-001/tuning/example.ts:1:8](#finding-1602)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1602)|
|<a id="finding-1603"></a>[copy-001/tuning/variants/typed.ts:1:44](#finding-1603)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1603)|
|<a id="finding-1604"></a>[copy-002/tuning/example.ts:1:8](#finding-1604)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1604)|
|<a id="finding-1605"></a>[copy-002/tuning/variants/typed.ts:1:44](#finding-1605)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1605)|
|<a id="finding-1606"></a>[copy-003/tuning/example.ts:1:8](#finding-1606)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1606)|
|<a id="finding-1607"></a>[copy-003/tuning/variants/typed.ts:1:44](#finding-1607)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1607)|
|<a id="finding-1608"></a>[copy-004/tuning/example.ts:1:8](#finding-1608)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1608)|
|<a id="finding-1609"></a>[copy-004/tuning/variants/typed.ts:1:44](#finding-1609)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1609)|
|<a id="finding-1610"></a>[copy-005/tuning/example.ts:1:8](#finding-1610)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1610)|
|<a id="finding-1611"></a>[copy-005/tuning/variants/typed.ts:1:44](#finding-1611)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1611)|
|<a id="finding-1612"></a>[copy-006/tuning/example.ts:1:8](#finding-1612)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1612)|
|<a id="finding-1613"></a>[copy-006/tuning/variants/typed.ts:1:44](#finding-1613)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1613)|
|<a id="finding-1614"></a>[copy-007/tuning/example.ts:1:8](#finding-1614)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1614)|
|<a id="finding-1615"></a>[copy-007/tuning/variants/typed.ts:1:44](#finding-1615)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1615)|
|<a id="finding-1616"></a>[copy-008/tuning/example.ts:1:8](#finding-1616)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1616)|
|<a id="finding-1617"></a>[copy-008/tuning/variants/typed.ts:1:44](#finding-1617)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1617)|
|<a id="finding-1618"></a>[copy-009/tuning/example.ts:1:8](#finding-1618)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1618)|
|<a id="finding-1619"></a>[copy-009/tuning/variants/typed.ts:1:44](#finding-1619)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1619)|
|<a id="finding-1620"></a>[copy-010/tuning/example.ts:1:8](#finding-1620)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1620)|
|<a id="finding-1621"></a>[copy-010/tuning/variants/typed.ts:1:44](#finding-1621)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1621)|
|<a id="finding-1622"></a>[copy-011/tuning/example.ts:1:8](#finding-1622)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1622)|
|<a id="finding-1623"></a>[copy-011/tuning/variants/typed.ts:1:44](#finding-1623)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1623)|
|<a id="finding-1624"></a>[copy-012/tuning/example.ts:1:8](#finding-1624)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1624)|
|<a id="finding-1625"></a>[copy-012/tuning/variants/typed.ts:1:44](#finding-1625)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1625)|
|<a id="finding-1626"></a>[copy-013/tuning/example.ts:1:8](#finding-1626)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1626)|
|<a id="finding-1627"></a>[copy-013/tuning/variants/typed.ts:1:44](#finding-1627)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1627)|
|<a id="finding-1628"></a>[copy-014/tuning/example.ts:1:8](#finding-1628)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1628)|
|<a id="finding-1629"></a>[copy-014/tuning/variants/typed.ts:1:44](#finding-1629)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1629)|
|<a id="finding-1630"></a>[copy-015/tuning/example.ts:1:8](#finding-1630)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1630)|
|<a id="finding-1631"></a>[copy-015/tuning/variants/typed.ts:1:44](#finding-1631)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1631)|
|<a id="finding-1632"></a>[copy-016/tuning/example.ts:1:8](#finding-1632)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1632)|
|<a id="finding-1633"></a>[copy-016/tuning/variants/typed.ts:1:44](#finding-1633)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1633)|
|<a id="finding-1634"></a>[copy-017/tuning/example.ts:1:8](#finding-1634)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1634)|
|<a id="finding-1635"></a>[copy-017/tuning/variants/typed.ts:1:44](#finding-1635)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1635)|
|<a id="finding-1636"></a>[copy-018/tuning/example.ts:1:8](#finding-1636)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1636)|
|<a id="finding-1637"></a>[copy-018/tuning/variants/typed.ts:1:44](#finding-1637)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1637)|
|<a id="finding-1638"></a>[copy-019/tuning/example.ts:1:8](#finding-1638)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1638)|
|<a id="finding-1639"></a>[copy-019/tuning/variants/typed.ts:1:44](#finding-1639)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1639)|
|<a id="finding-1640"></a>[copy-020/tuning/example.ts:1:8](#finding-1640)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1640)|
|<a id="finding-1641"></a>[copy-020/tuning/variants/typed.ts:1:44](#finding-1641)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1641)|
|<a id="finding-1642"></a>[copy-021/tuning/example.ts:1:8](#finding-1642)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1642)|
|<a id="finding-1643"></a>[copy-021/tuning/variants/typed.ts:1:44](#finding-1643)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1643)|
|<a id="finding-1644"></a>[copy-022/tuning/example.ts:1:8](#finding-1644)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1644)|
|<a id="finding-1645"></a>[copy-022/tuning/variants/typed.ts:1:44](#finding-1645)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1645)|
|<a id="finding-1646"></a>[copy-023/tuning/example.ts:1:8](#finding-1646)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1646)|
|<a id="finding-1647"></a>[copy-023/tuning/variants/typed.ts:1:44](#finding-1647)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1647)|
|<a id="finding-1648"></a>[copy-024/tuning/example.ts:1:8](#finding-1648)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1648)|
|<a id="finding-1649"></a>[copy-024/tuning/variants/typed.ts:1:44](#finding-1649)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1649)|
|<a id="finding-1650"></a>[copy-025/tuning/example.ts:1:8](#finding-1650)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1650)|
|<a id="finding-1651"></a>[copy-025/tuning/variants/typed.ts:1:44](#finding-1651)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1651)|
|<a id="finding-1652"></a>[copy-026/tuning/example.ts:1:8](#finding-1652)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1652)|
|<a id="finding-1653"></a>[copy-026/tuning/variants/typed.ts:1:44](#finding-1653)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1653)|
|<a id="finding-1654"></a>[copy-027/tuning/example.ts:1:8](#finding-1654)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1654)|
|<a id="finding-1655"></a>[copy-027/tuning/variants/typed.ts:1:44](#finding-1655)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1655)|
|<a id="finding-1656"></a>[copy-028/tuning/example.ts:1:8](#finding-1656)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1656)|
|<a id="finding-1657"></a>[copy-028/tuning/variants/typed.ts:1:44](#finding-1657)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1657)|
|<a id="finding-1658"></a>[copy-029/tuning/example.ts:1:8](#finding-1658)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1658)|
|<a id="finding-1659"></a>[copy-029/tuning/variants/typed.ts:1:44](#finding-1659)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1659)|
|<a id="finding-1660"></a>[copy-030/tuning/example.ts:1:8](#finding-1660)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1660)|
|<a id="finding-1661"></a>[copy-030/tuning/variants/typed.ts:1:44](#finding-1661)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1661)|
|<a id="finding-1662"></a>[copy-031/tuning/example.ts:1:8](#finding-1662)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1662)|
|<a id="finding-1663"></a>[copy-031/tuning/variants/typed.ts:1:44](#finding-1663)|generate***SA-65'|Node WebCrypto supports ML-KEM and ML-DSA from 24.7; browser support must be checked separately. / [Source](#source-1663)|

<a id="source-1600"></a>

### copy-000/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1601"></a>

### copy-000/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1602"></a>

### copy-001/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1603"></a>

### copy-001/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1604"></a>

### copy-002/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1605"></a>

### copy-002/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1606"></a>

### copy-003/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1607"></a>

### copy-003/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1608"></a>

### copy-004/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1609"></a>

### copy-004/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1610"></a>

### copy-005/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1611"></a>

### copy-005/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1612"></a>

### copy-006/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1613"></a>

### copy-006/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1614"></a>

### copy-007/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1615"></a>

### copy-007/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1616"></a>

### copy-008/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1617"></a>

### copy-008/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1618"></a>

### copy-009/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1619"></a>

### copy-009/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1620"></a>

### copy-010/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1621"></a>

### copy-010/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1622"></a>

### copy-011/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1623"></a>

### copy-011/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1624"></a>

### copy-012/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1625"></a>

### copy-012/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1626"></a>

### copy-013/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1627"></a>

### copy-013/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1628"></a>

### copy-014/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1629"></a>

### copy-014/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1630"></a>

### copy-015/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1631"></a>

### copy-015/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1632"></a>

### copy-016/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1633"></a>

### copy-016/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1634"></a>

### copy-017/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1635"></a>

### copy-017/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1636"></a>

### copy-018/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1637"></a>

### copy-018/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1638"></a>

### copy-019/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1639"></a>

### copy-019/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1640"></a>

### copy-020/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1641"></a>

### copy-020/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1642"></a>

### copy-021/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1643"></a>

### copy-021/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1644"></a>

### copy-022/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1645"></a>

### copy-022/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1646"></a>

### copy-023/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1647"></a>

### copy-023/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1648"></a>

### copy-024/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1649"></a>

### copy-024/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1650"></a>

### copy-025/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1651"></a>

### copy-025/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1652"></a>

### copy-026/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1653"></a>

### copy-026/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1654"></a>

### copy-027/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1655"></a>

### copy-027/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1656"></a>

### copy-028/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1657"></a>

### copy-028/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1658"></a>

### copy-029/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1659"></a>

### copy-029/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1660"></a>

### copy-030/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1661"></a>

### copy-030/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1662"></a>

### copy-031/tuning/example.ts:1:8

    > 1 subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

<a id="source-1663"></a>

### copy-031/tuning/variants/typed.ts:1:44

    > 1 const key: Promise<CryptoKeyPair> = subtle.generateKey({name: 'ML-DSA-65'}, false, ['sign']);

## Action details

Each location links only to its applicable action. Identical payloads are printed once.

<a id="action-0"></a>


#### Plan certificate algorithm and trust-store migration (near-term)

PKI updates require coordinated CA, chain, and relying-party compatibility planning. FIPS 204/205 standardize signature primitives, not a universal hybrid certificate format.

1. Inventory certificate signature algorithms and key sizes from CBOM/report output.
2. Identify the exact certificate construction and encoding, then verify provider, CA, client and trust-store support before planning issuance.
3. Pilot only a supported construction in non-production trust stores; if format or ecosystem support is unavailable, keep issuance unverified and evaluate another supported migration path.
4. Define reissuance plan for quantum-vulnerable roots/intermediates/end-entity certs.

References:

- https://csrc.nist.gov/pubs/fips/204/final
- https://csrc.nist.gov/pubs/fips/205/final
<a id="action-1"></a>


#### Adopt a phased hybrid PQC migration plan (near-term)

The detected primitive is vulnerable to cryptographically relevant quantum attacks. Hybrid rollout minimizes compatibility risk.

1. Inventory all call sites using this algorithm and owner teams.
2. Check for an existing classical + PQC composition; if migration is needed, evaluate compatible staged or hybrid modes before hard cut-over.
3. Define retirement dates for legacy classical algorithms.

References:

- https://www.nist.gov/itl/post-quantum-cryptography
- https://csrc.nist.gov/pubs/fips/203/final
- https://csrc.nist.gov/pubs/fips/204/final
<a id="action-2"></a>


#### Review private-key markers and rotate exposed live credentials (immediate)

A private-key marker was found. Confirm whether complete key material is present and whether it belongs to a live exposed credential; the marker alone does not establish an incident.

1. Check whether the signal is a header reference, a synthetic test key, or complete live key material.
2. If a live credential is exposed, revoke or replace it and invalidate affected sessions/tokens as appropriate.
3. Move keys to a secret manager or HSM and enforce commit scanning in CI.

References:

- https://cheatsheetseries.owasp.org/cheatsheets/Secrets_Management_Cheat_Sheet.html
<a id="action-3"></a>


#### Check Java runtime baseline for standard PQC APIs (planned)

The Java version is unknown; verify the deployed runtime before selecting a PQC API baseline.

1. Target JDK 24+ for ML-KEM and ML-DSA support planning.
2. Pilot compatibility testing in CI before production migration.

References:

- https://openjdk.org/jeps/496
- https://openjdk.org/jeps/497
<a id="action-4"></a>


#### Provide BouncyCastle PQC fallback path (near-term)

BouncyCastle can be used as a pragmatic transition option when standard runtime support is unavailable or incomplete.

1. Verify the resolved BC release and deployed JDK support before provider initialization; the example uses BC Java 1.85 and the BC provider, not BCPQC.
2. Select explicit ML-DSA / ML-KEM parameter sets for the intended purpose. Generate new algorithm-compatible keys and provision matching public keys and encodings to verifiers; never reuse RSA key material.
3. Document provider ordering and FIPS/compliance impact.

References:

- https://www.bouncycastle.org/java.html
- https://downloads.bouncycastle.org/java/docs/bcprov-jdk18on-javadoc/

Before (java)

    Security.addProvider(new BouncyCastleProvider());
    Signature sig = Signature.getInstance("SHA256withRSA", "BC");

After

    // BC Java 1.85 example: verify the resolved release/provider supports this name.
    Security.addProvider(new BouncyCastleProvider());
    // Provision a new ML-DSA-65 key pair and its public key to verifiers.
    // mlDsaPrivateKey must not be the previous RSA key.
    Signature sig = Signature.getInstance("ML-DSA-65", "BC");
    sig.initSign(mlDsaPrivateKey);

<a id="action-5"></a>


#### Verify deployed runtime and protocol PQC capabilities (planned)

Source declarations and primitive availability do not establish deployment or peer support.

1. JDK 24 adds ML-KEM and ML-DSA primitives. Check deployed JSSE hybrid TLS support separately and inspect jdk.tls.namedGroups restrictions.
2. Check resolved versions, provider/features and interoperability before changing production policy.

References:

- https://docs.oracle.com/en/java/javase/27/security/java-secure-socket-extension-jsse-reference-guide.html
<a id="action-6"></a>


#### Review the cryptographic reference and its actual purpose (planned)

A source reference does not establish active signing, JWT issuance, or the absence of an existing PQC/hybrid composition.

1. Identify key generation, signing, verification, encryption or key establishment and separate tests/examples from deployed use.
2. Check existing PQC or hybrid components, provider support and protocol compatibility before selecting a change.

References:

- https://www.nist.gov/itl/post-quantum-cryptography
<a id="action-7"></a>


#### Track PQC readiness of dependent libraries (planned)

Dependency-level crypto libraries strongly influence migration options and operational timelines.

1. Record current versions in dependency-sbom.json and define upgrade targets.
2. Subscribe to release notes for PQC feature availability and API changes.
3. Run integration tests for PQC or hybrid modes before promoting to production.

References:

- https://cyclonedx.org/
- https://spdx.dev/
<a id="action-8"></a>


#### Review the explicit PQC override: GODEBUG=tlsmlkem=0 (near-term)

The detected setting restricts hybrid key exchange. It does not establish RSA usage or the negotiated TLS version.

1. Inspect GODEBUG=tlsmlkem=0 at this location and confirm why the override is required.
2. Verify deployed library and peer support before testing a hybrid group or removing the override.
3. Check key exchange, TLS protocol version and certificate signatures separately; TLS 1.3 alone does not establish PQC protection.

References:

- https://go.dev/doc/godebug
- https://www.rfc-editor.org/rfc/rfc9325.html#section-3.1.1
<a id="action-9"></a>


#### Review the explicit PQC override: jdk.tls.namedGroups (near-term)

The detected setting restricts hybrid key exchange. It does not establish RSA usage or the negotiated TLS version.

1. Inspect jdk.tls.namedGroups at this location and confirm why the override is required.
2. Verify deployed library and peer support before testing a hybrid group or removing the override.
3. Check key exchange, TLS protocol version and certificate signatures separately; TLS 1.3 alone does not establish PQC protection.

References:

- https://go.dev/doc/godebug
- https://www.rfc-editor.org/rfc/rfc9325.html#section-3.1.1
<a id="action-10"></a>


#### Review the explicit PQC override: groups= / ecdh_curves= (near-term)

The detected setting restricts hybrid key exchange. It does not establish RSA usage or the negotiated TLS version.

1. Inspect groups= / ecdh_curves= at this location and confirm why the override is required.
2. Verify deployed library and peer support before testing a hybrid group or removing the override.
3. Check key exchange, TLS protocol version and certificate signatures separately; TLS 1.3 alone does not establish PQC protection.

References:

- https://go.dev/doc/godebug
- https://www.rfc-editor.org/rfc/rfc9325.html#section-3.1.1

## Inventory exports

- [CBOM](cbom.json): 1600
- [Dependency SBOM](dependency-sbom.json): 192


## Inspection coverage

Completeness covers supported inspection within the declared scope, after ignore settings, exclusions and size limits. It does not prove runtime use, certificate trust or security. Unenumerated files remain unknown.

|Item|Value|
|---|---|
|Status|Some inspection could not complete (partial)|
|Selected files|1312|
|Read successfully|1312|
|Read failed|0|
|Analyzed|1152|
|Partial|128|
|Analysis failed|0|
|Unsupported|0|
|Not applicable|0|
|Unknown|32|
|Enumerated exclusions|0|
|Enumeration failures|0|
|Unenumerated population|Unknown|

## Inspection diagnostics

Counts and up to three example paths per reason; full records remain in diagnostics JSON.

|Item|Value|
|---|---|
|Detector failed (detector_failed)|32 records; copy-000/holdout/broken-sbom.json; copy-001/holdout/broken-sbom.json; copy-002/holdout/broken-sbom.json|
|Detector does not report completeness (detector_not_reported)|1 records; |
|Only part of inspection completed (detector_partial)|96 records; copy-000/holdout/misleading-rsa1024.der; copy-000/holdout/unsupported.p12; copy-000/tuning/variants/broken.py|
