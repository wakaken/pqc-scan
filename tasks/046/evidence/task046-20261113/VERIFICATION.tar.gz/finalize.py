import hashlib,json,re,tarfile
from collections import Counter
from pathlib import Path
base=Path('target/quality-task-046/run-20261113');run=base/'confined';out=Path('docs/quality/task046-20261113');out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
host=json.loads((run/'HOST-RESULTS.json').read_text());assert host['exit']==0 and host['sourceBeforeAfterMatch'] and host['containerRemoved']
paths=['crates/pqc_scan_core/src/pipeline.rs','crates/pqc_scan_core/src/quality055.rs','crates/pqc_scan_core/src/quality046.rs','crates/pqc_scan_detectors/tests/quality055.rs','tests/quality/inspection055.py','tests/quality/inspection055_entry.py','tests/quality/test_inspection055.py','tests/protocol/container_runner.py','tests/protocol/container_entry.py']
bindings={p:sha(p) for p in paths};assert all(host['sourceBindings'][p]==h for p,h in bindings.items())
with tarfile.open('docs/quality/task055-20261113/VERIFICATION.tar.gz') as tar:
 old=tar.extractfile('final-source/crates/pqc_scan_core/src/quality055.rs').read()
assert Path('crates/pqc_scan_core/src/quality055.rs').read_bytes().startswith(old)
source={'baseHead':'34b763d188bfc8ada49876c18b15f5406b6628b3','files':bindings,'scopeSha256':hashlib.sha256(json.dumps(bindings,sort_keys=True).encode()).hexdigest(), 'inherited055SourcePrefixUnchanged':True,'productLogicCargoRulesSchemasChanged':False,'sourceBindings':'VERIFICATION.tar.gz:confined/HOST-RESULTS.json'}
(out/'SOURCE.json').write_text(json.dumps(source,indent=2)+'\n')
seeds=[46,20261113,1592642302];configs={};checks={}
names=['quality046_reducer_preserves_failure_and_reaches_one_minimal_input','quality046_generated_pipeline_statistics_semantics_and_unknown_are_preserved','quality046_generated_id_boundaries_are_stable_unique_and_unknown_is_not_guessed','quality046_shrinks_real_unknown_scan_against_a_deliberately_wrong_success_rule']
for mode in ['default','all-features']:
 raw=run/mode/'raw';pipeline=json.loads((raw/'pipeline046.json').read_text());identity=json.loads((raw/'identity046.json').read_text());shrinking=json.loads((raw/'shrinking046.json').read_text())
 assert pipeline['seeds']==identity['seeds']==seeds
 assert pipeline['caseCount']==len(pipeline['results'])==192
 assert {(r['seed'],r['case']) for r in pipeline['results']}=={(s,i) for s in seeds for i in range(64)}
 for row in pipeline['results']:
  record=row['result'];c=Counter(record['input']);counts=record['counts']
  assert counts['selected_files']==len(record['input'])
  assert counts['read_failed_files']==c[7] and counts['unknown_files']==c[6]
  assert counts['partial_files']==c[1]+c[2] and counts['analysis_failed_files']==c[3]
  assert all(record[key] is True for key in ['semanticRepeat','nativeRoundtrip','unknownPreserved','brokenReferenceRejectedWhenPresent'])
 assert identity['generatedCases']==len(identity['results'])==384
 assert {(r['seed'],r['case']) for r in identity['results']}=={(s,i) for s in seeds for i in range(128)}
 assert identity['distinctIds']==1008 and identity['concatenationBoundaryChecks']==303
 assert shrinking['original']==[5,6,5] and shrinking['reduced']==[6] and shrinking['actualCoverage']['status']=='unknown' and shrinking['productFailure'] is False
 text=(run/(mode+'-tests.log')).read_text()
 for name in names:assert f'::{name} ... ok' in text,name
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 checks[mode]={'passed':sum(int(r[0]) for r in rows),'failed':sum(int(r[1]) for r in rows),'ignored':sum(int(r[2]) for r in rows)}
 assert checks[mode]['failed']==0
 configs[mode]={'pipeline':pipeline,'identity':identity,'shrinking':shrinking,'checks':checks[mode]}
result={'task':'046','requirement':'Q4-15','sourceScopeSha256':source['scopeSha256'],'seeds':seeds,'configurations':configs,
 'properties':{'semanticReplay':'verified','failuresNotSuccess':'verified','unknownNotFabricated':'verified','inspectionStatistics':'verified','stableUniqueFramedIds':'verified','generationAndShrinking':'verified'},
 'scope':'Rust1.93.1 Linux arm64 default/all-features, finite generated inputs; no claim of all inputs or product-wide correctness',
 'failures':'No product invariant violation found in final runs. Early development comparison incorrectly required run-scoped observation IDs to match; corrected against existing Inventory v1 contract. Logs retained as development evidence, not product findings.'}
for path in [out/'property-results.json',Path('target/quality-task-046/property-results.json')]:
 with path.open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n')
validation={'source':source,'rust':checks,'commands':json.loads((run/'commands.json').read_text()),'fmt':'exit0; enclosing entry completed','pythonQualityPassed':66,'sourceBeforeAfterMatch':True,'containerRemoved':True,'reused055Assessment':'both configurations completed and retained in archive','githubActions':'Not executed; local verification only'}
(out/'VALIDATION.json').write_text(json.dumps(validation,indent=2)+'\n')
with tarfile.open(out/'VERIFICATION.tar.gz','w:gz') as tar:
 for p in sorted(base.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(base)))
 for p in paths:tar.add(p,arcname='final-source/'+p)
print(source['scopeSha256'],json.dumps(checks))
