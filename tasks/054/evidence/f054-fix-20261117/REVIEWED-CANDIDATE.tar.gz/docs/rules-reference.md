# Rule and Severity Reference

This document lists all built-in detection rules shipped in `rules/default/` and explains severity levels used in reports.

- Total rules: **123**
- Rule files: `cert.yml`, `crypto_api.yml`, `jwt.yml`, `middleware.yml`, `ssh.yml`, `tls.yml`, `tree_sitter.yml`, `pqc.yml`
- Kind breakdown: `certificate`: 18, `dependency`: 16, `key`: 3, `regex`: 60, `tree_sitter`: 26

## Validation and quality review

Task028 established the original 119-rule review. The authorized 2026-11-12 repairs below update selected predicates and add three classical API/reference rules.
The [source-bound companion](quality/rules/RULE-QUALITY.md) reviews purpose/algorithm/
quantum/classical axes, standard editions, method limits and target-layer positive/
negative controls. Known disagreements and false positives are recorded, not tuned
away. These annotations do not replace existing Risk/severity tags or certify
accuracy. See [loader and custom-scope compatibility](architecture/RULE-VALIDATION.md)
for blank ID/confidence/traversal errors and unchanged scope behavior.

## Severity Levels

| Severity | Meaning | Typical handling |
|---|---|---|
| `critical` (7) | Immediate security impact or sensitive material exposure. | Treat as urgent; remediate before release when possible. |
| `high` (41) | Strong crypto risk in production paths. | Prioritize in active migration backlog. |
| `medium` (56) | Meaningful migration signal requiring design/planning. | Schedule remediation with clear owner and target release. |
| `low` (6) | Contextual or lower-confidence finding. | Triage and backlog when confirmed. |
| `info` (12) | Inventory-only informational signal. | Track for visibility and architecture review. |

Note: final severity can be adjusted by context in the risk engine (for example TLS/PKI/JWT/authentication paths).

## Built-in Rule Catalog

### PQC inventory additions (`pqc.yml`)

`quantum-safe` classifies only the primitive referenced, not execution, backend
availability, certificate validity, or completed migration. API rules are
heuristic: aliases, computed names, multiline settings and custom TLS groups may
not match. Only explicit recognized classical-only lists are flagged; absence of
a PQC string does not prove a disabled state. Existing catalog rows below retain
their rule IDs; TLS_RSA_KEY_EXCHANGE and SSH_RSA_ALGO guidance now distinguishes
standard ML-KEM and classical Ed25519 respectively. YAML is authoritative.

| Rule ID | Kind | Severity / Risk | Scope and interpretation |
|---|---|---|---|
| PQC_JAVA_API | tree_sitter | info / quantum-safe | Java JCA PQC request |
| PQC_GO_API | tree_sitter | info / quantum-safe | Go standard PQC import |
| PQC_NODE_API | tree_sitter | info / quantum-safe | JS/TS Node-style key generation |
| PQC_WEBCRYPTO_API | tree_sitter | info / quantum-safe | JS/TS WebCrypto-style key generation |
| PQC_PYTHON_API | tree_sitter | info / quantum-safe | Python PQC key generation |
| PQC_RUST_API | tree_sitter | info / quantum-safe | RustCrypto symbol reference |
| PQC_RUBY_API | tree_sitter | info / quantum-safe | Ruby algorithm literal |
| PQC_GO_TLS_DISABLED | regex | medium / quantum-uncertain | Explicit GODEBUG override |
| PQC_JAVA_CLASSICAL_GROUPS | regex | medium / quantum-uncertain | Recognized classical-only Java property |
| PQC_RUBY_CLASSICAL_GROUPS | regex | medium / quantum-uncertain | Recognized classical-only Ruby assignment |
| DEP_PQC_CAPABLE_LIBRARY | dependency | info / quantum-uncertain | Version-dependent capability; not enabled state |
| PQC_DRAFT_ALGORITHM | tree_sitter | medium / quantum-uncertain | Pre-standard names; verify implementation |
| CERT_ML_DSA_SIGNATURE | certificate | info / quantum-safe | Parsed signature_oid only; RFC 9881 |
| CERT_ML_DSA_PUBLIC_KEY | certificate | info / quantum-safe | Parsed public_key_oid only; RFC 9881 |
| CERT_SLH_DSA_SIGNATURE | certificate | info / quantum-safe | Parsed signature_oid only; RFC 9909 |
| CERT_SLH_DSA_PUBLIC_KEY | certificate | info / quantum-safe | Parsed public_key_oid only; RFC 9909 |

Certificate OID scopes never fall back to matching filenames. Signature and key
algorithms are distinct; evidence metadata for parsed certificates includes
`public_key_oid` alongside `signature_oid`. No serialized struct fields change.

### Exact certificate predicates and validity (task 021)

Built-in signature rules match whole parsed OIDs; RSA-size rules require a known
RSA/PSS subject modulus. Filenames are never algorithm/size/expiry facts for these
scopes. `CERT_ECDSA_SIGNATURE` and `CERT_DSA_SIGNATURE` now carry
`quantum-vulnerable`; their unchanged base severities medium/high become high/critical
under the existing PKI risk engine. Weak digest/key concerns remain separate
findings; legacy DSA verification is distinguished from new signing. Confidence
values are uncalibrated rule heuristics, not measured probabilities.

`certificate_validity` exposes expired/not_yet_valid/valid at the detector's explicit
Unix-second clock. `not_before <= now <= not_after` is valid. The two new IDs are
medium conventional-risk signals and do not prove active deployment or trust.
`legacy_not_after_2026` keeps the date-named old ID as a fixed parsed cutoff
(`not_after < 1798761600`), not a moving expiry rule. Invalid intervals cannot satisfy
these time predicates. Unknown/unsupported parsing retains honest diagnostics.

Legacy custom `certificate`/other scopes retain their old composite target except
newly reserved `rsa_modulus_bits`, `certificate_validity`, `legacy_not_after_2026`.
`signature_oid`/`public_key_oid` remain identifier targets. New typed evidence may
change affected certificate finding IDs/CBOM strings; no serialized field/enum or
core scoring/ID algorithm changes. PSS digest parameters and unlisted signature
identifiers are not exhaustively assessed. See the
[specification](../tasks/021/TASK-021-IMPLEMENTATION.md) and
[focused baseline](../tasks/021/CERTIFICATE-BASELINE-021.md).

### Original catalog

| Rule ID | Kind | Category | Severity | Risk | Confidence | Scope | Source | Description | Migration Hint | Pattern |
|---|---|---|---|---|---:|---|---|---|---|---|
| `API_BC_RSA_ENGINE` | `regex` | CryptoAPI | `medium` | `quantum-vulnerable` | 0.58 | `code` | `crypto_api.yml` | BouncyCastle RSA engine usage detected. | Migrate to BouncyCastle PQC APIs. | `\bRSAEngine\b\|\bRSABlindedEngine\b` |
| `API_CIPHER_RSA` | `regex` | CryptoAPI | `high` | `quantum-vulnerable` | 0.64 | `code` | `crypto_api.yml` | RSA cipher API usage detected. | Migrate to hybrid KEM+AEAD cryptographic design. | `Cipher\.getInstance\(\s*"RSA` |
| `API_EVP_PKEY_RSA` | `regex` | CryptoAPI | `medium` | `quantum-vulnerable` | 0.54 | `code` | `crypto_api.yml` | EVP_PKEY configured for RSA detected. | Use EVP_PKEY abstraction to prepare key-type replacement for PQC. | `EVP_PKEY_(RSA\|set1_RSA)` |
| `API_GO_CRYPTO_RSA` | `regex` | CryptoAPI | `medium` | `quantum-vulnerable` | 0.52 | `code` | `crypto_api.yml` | Go crypto/rsa usage detected. | Introduce hybrid PQC key sharing in Go services. | `\bcrypto/rsa\b` |
| `API_JOSE_RSA_ALG` | `regex` | CryptoAPI | `high` | `quantum-vulnerable` | 0.63 | `code` | `crypto_api.yml` | RSA-family JOSE algorithm detected. | Update JOSE algorithms to PQC-ready alternatives. | `\b(RS256\|RS384\|RS512\|PS256\|PS384\|PS512)\b` |
| `API_NODE_CRYPTO_SIGN_RSA` | `regex` | CryptoAPI | `medium` | `quantum-vulnerable` | 0.50 | `code` | `crypto_api.yml` | Node.js RSA signing API usage detected. | Plan PQC replacement for node:crypto RSA operations. | `create(Sign\|Verify)\(\s*['"]RSA` |
| `API_OPENSSL_RSA_NEW` | `regex` | CryptoAPI | `medium` | `quantum-vulnerable` | 0.55 | `code` | `crypto_api.yml` | OpenSSL low-level RSA API usage detected. | Prefer high-level OpenSSL EVP APIs to ease PQC migration. | `\bRSA_new\b\|\bRSA_generate_key_ex\b` |
| `API_PY_RSA_MODULE` | `regex` | CryptoAPI | `medium` | `quantum-vulnerable` | 0.50 | `code` | `crypto_api.yml` | Python RSA API usage detected. | Evaluate PQC-capable libraries for Python crypto implementations. | `from\s+Crypto\.PublicKey\s+import\s+RSA\|cryptography\.hazmat\.primitives\.asymmetric\.rsa` |
| `API_RSA_KEYPAIR_GENERATOR` | `regex` | CryptoAPI | `high` | `quantum-vulnerable` | 0.65 | `code` | `crypto_api.yml` | Java RSA key-generation API usage detected. | Replace key-generation APIs with PQC-capable implementations. | `KeyPairGenerator\.getInstance\(\s*"RSA"` |
| `API_SIGNATURE_RSA` | `regex` | CryptoAPI | `high` | `quantum-vulnerable` | 0.62 | `code` | `crypto_api.yml` | RSA signature API usage detected. | Migrate to ML-DSA signing APIs. | `Signature\.getInstance\(\s*"SHA(1\|224\|256\|384\|512)withRSA"` |
| `CERT_DSA_SIGNATURE` | `certificate` | PKI | `high` | `quantum-vulnerable` | 0.70 | `signature_oid` | `cert.yml` | DSA-based certificate signature detected. | Plan a supported replacement for DSA signing; assess legacy verification separately from quantum exposure. | `^(?:1\.2\.840\.10040\.4\.3\|2\.16\.840\.1\.101\.3\.4\.3\.[12])$` |
| `CERT_ECDSA_SIGNATURE` | `certificate` | PKI | `medium` | `quantum-vulnerable` | 0.60 | `signature_oid` | `cert.yml` | ECDSA certificate signature detected. | Evaluate ML-DSA and SLH-DSA alternatives. | `^1\.2\.840\.10045\.(?:4\.1\|4\.3\.[1-4])$` |
| `CERT_EXPIRY_2026_OR_BEFORE` | `certificate` | PKI | `medium` | `non-quantum-risk` | 0.25 | `legacy_not_after_2026` | `cert.yml` | Parsed certificate expiry is at or before 2026 (legacy fixed cutoff, not current validity). | Use current-time validity findings for renewal decisions; retain this legacy cutoff only for compatibility. | `^before_2027$` |
| `CERT_MD5_SIGNATURE` | `certificate` | PKI | `critical` | `non-quantum-risk` | 0.90 | `signature_oid` | `cert.yml` | MD5 certificate signature detected. | Reissue the certificate immediately. | `^1\.2\.840\.113549\.1\.1\.4$` |
| `CERT_OID_RSA_PSS` | `certificate` | PKI | `high` | `quantum-vulnerable` | 0.62 | `signature_oid` | `cert.yml` | RSASSA-PSS OID detected. | Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. | `^1\.2\.840\.113549\.1\.1\.10$` |
| `CERT_P12_CONTAINER` | `certificate` | PKI | `medium` | `quantum-uncertain` | 0.35 | `certificate` | `cert.yml` | PKCS#12/PFX container file detected. | Audit algorithms used inside PKCS#12/PFX containers. | `(?i)\.(p12\|pfx)$` |
| `CERT_PEM_CONTAINER` | `certificate` | PKI | `low` | `quantum-uncertain` | 0.30 | `certificate` | `cert.yml` | PEM/DER cryptographic container detected; certificate presence is not established. | Identify the cryptographic object type; inspect certificate algorithms only when a certificate is present. | `(?i)\.(pem\|crt\|cer\|der)$` |
| `CERT_RSA_1024` | `certificate` | PKI | `critical` | `non-quantum-risk` | 0.88 | `rsa_modulus_bits` | `cert.yml` | Certificate subject public key is 1024-bit RSA. | Confirm actual use and issuer/verifier support; replace weak deployed keys while planning purpose-appropriate PQC migration. | `^1024$` |
| `CERT_RSA_2048` | `certificate` | PKI | `high` | `quantum-vulnerable` | 0.78 | `rsa_modulus_bits` | `cert.yml` | Certificate subject public key is 2048-bit RSA. | Plan supported PQC certificate signatures with issuer and peer compatibility checks; larger classical keys alone do not remove quantum exposure. | `^2048$` |
| `CERT_RSA_3072` | `certificate` | PKI | `medium` | `quantum-vulnerable` | 0.65 | `rsa_modulus_bits` | `cert.yml` | Certificate subject public key is 3072-bit RSA. | Evaluate standardized PQC signatures in supported issuance and verification environments. | `^3072$` |
| `CERT_RSA_SIGNATURE` | `certificate` | PKI | `high` | `quantum-vulnerable` | 0.72 | `signature_oid` | `cert.yml` | Certificate signed with an RSA-based algorithm detected. | Verify issuer, verifier and key-format support before evaluating standardized PQC certificate signatures. | `^1\.2\.840\.113549\.1\.1\.(?:4\|5\|10\|11\|12\|13\|14)$` |
| `CERT_SHA1_SIGNATURE` | `certificate` | PKI | `critical` | `non-quantum-risk` | 0.85 | `signature_oid` | `cert.yml` | SHA-1 certificate signature detected. | Upgrade certificate signatures to SHA-256 or stronger. | `^(?:1\.2\.840\.113549\.1\.1\.5\|1\.2\.840\.10040\.4\.3\|1\.2\.840\.10045\.4\.1)$` |
| `CERT_EXPIRED` | `certificate` | PKI | `medium` | `non-quantum-risk` | 0.90 | `certificate_validity` | `cert.yml` | Certificate is expired at the recorded assessment time. | Confirm whether the certificate is deployed and renew it where required; check issuer and verifier compatibility. | `^expired$` |
| `CERT_NOT_YET_VALID` | `certificate` | PKI | `medium` | `non-quantum-risk` | 0.90 | `certificate_validity` | `cert.yml` | Certificate validity has not started at the recorded assessment time. | Check intended deployment time and the system clock; use a currently valid certificate where required. | `^not_yet_valid$` |
| `DEP_BORINGSSL` | `dependency` | TLS | `low` | `quantum-uncertain` | 0.40 | `dependency` | `tls.yml` | BoringSSL dependency detected. | Evaluate BoringSSL PQC experiment paths. | `(?i)\bboringssl\b` |
| `DEP_BOUNCYCASTLE` | `dependency` | TLS | `medium` | `quantum-uncertain` | 0.45 | `dependency` | `tls.yml` | BouncyCastle dependency detected. | Verify BouncyCastle PQC support status. | `(?i)\bbouncycastle\b` |
| `DEP_GO_JOSE` | `dependency` | CryptoAPI | `low` | `quantum-uncertain` | 0.42 | `dependency` | `crypto_api.yml` | Go JOSE dependency detected. | Confirm PQC support status in go-jose. | `(?i)\bgo-jose\b\|gopkg\.in/square/go-jose` |
| `DEP_JAVA_BOUNCYCASTLE` | `dependency` | CryptoAPI | `medium` | `quantum-uncertain` | 0.47 | `dependency` | `crypto_api.yml` | Java BouncyCastle dependency detected. | Evaluate adoption of BouncyCastle PQC provider modules. | `(?i)org\.bouncycastle\|bcpkix\|bcprov` |
| `DEP_LIBSSH` | `dependency` | SSH | `low` | `quantum-uncertain` | 0.35 | `dependency` | `ssh.yml` | libssh dependency detected. | Audit cryptographic settings in libssh usage. | `(?i)\blibssh\b` |
| `DEP_OPENSSL` | `dependency` | TLS | `medium` | `quantum-uncertain` | 0.45 | `dependency` | `tls.yml` | OpenSSL dependency detected. | Review the OpenSSL PQC roadmap. | `(?i)\bopenssl\b` |
| `DEP_PARAMIKO` | `dependency` | SSH | `low` | `quantum-uncertain` | 0.35 | `dependency` | `ssh.yml` | paramiko dependency detected. | Inventory key algorithms used with paramiko. | `(?i)\bparamiko\b` |
| `DEP_PYCA_CRYPTOGRAPHY` | `dependency` | CryptoAPI | `medium` | `quantum-uncertain` | 0.45 | `dependency` | `crypto_api.yml` | Python cryptography dependency detected. | Track PQC support status in the cryptography package. | `(?i)^\s*cryptography(==\|>=\|<=\|~=\|\s\|$)` |
| `DEP_PYCRYPTODOME` | `dependency` | CryptoAPI | `medium` | `quantum-uncertain` | 0.45 | `dependency` | `crypto_api.yml` | pycryptodome dependency detected. | Verify available PQC extensions for this dependency set. | `(?i)\bpycryptodome\b` |
| `DEP_RUBY_JWT` | `dependency` | CryptoAPI | `medium` | `quantum-vulnerable` | 0.48 | `dependency` | `crypto_api.yml` | Ruby JWT dependency detected. | Replace RSA-based JWT signing in Ruby with PQC-ready options. | `(?i)pkg:gem/[^\s]*jwt` |
| `DEP_RUBY_OPENSSL` | `dependency` | CryptoAPI | `medium` | `quantum-uncertain` | 0.44 | `dependency` | `crypto_api.yml` | Ruby OpenSSL dependency detected. | Review OpenSSL usage in Ruby and prepare PQC migration path. | `(?i)pkg:gem/[^\s]*openssl` |
| `DEP_RUST_OPENSSL` | `dependency` | CryptoAPI | `medium` | `quantum-uncertain` | 0.46 | `dependency` | `crypto_api.yml` | Rust TLS/crypto dependency detected. | Track PQC migration options for Rust openssl/rustls crypto stacks. | `(?i)pkg:cargo/[^\s]*(openssl(-sys)?\|rustls)` |
| `DEP_RUST_RSA_CRATE` | `dependency` | CryptoAPI | `medium` | `quantum-vulnerable` | 0.50 | `dependency` | `crypto_api.yml` | Rust RSA/JWT dependency detected. | Plan migration away from classical RSA crates in Rust workloads. | `(?i)(?:^\|\\s)pkg:cargo/(?:rsa\|jsonwebtoken)(?:@[^\\s/?#]+)?\\z` |
| `ENVOY_CIPHER_SUITES_RSA` | `regex` | Middleware | `high` | `quantum-vulnerable` | 0.68 | `config` | `middleware.yml` | Envoy TLS cipher suites include RSA or weak ciphers. | Remove RSA-dependent suites from Envoy cipher_suites. | `cipher_suites\s*:\s*\[[^\]]*(RSA\|3DES\|RC4)` |
| `ENVOY_SIGNATURE_ALGORITHMS_RSA` | `regex` | Middleware | `medium` | `quantum-vulnerable` | 0.62 | `config` | `middleware.yml` | RSA signature algorithms are explicitly configured in Envoy. | Reflect PQC migration plans in Envoy signature algorithm settings. | `signature_algorithms\s*:\s*\[[^\]]*rsa` |
| `ENVOY_TLS_MAX_VERSION_LEGACY` | `regex` | Middleware | `medium` | `non-quantum-risk` | 0.55 | `config` | `middleware.yml` | Envoy maximum TLS version is pinned too low. | Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. | `tls_maximum_protocol_version\s*:\s*TLSv1_[01]` |
| `ENVOY_TLS_MIN_VERSION_LEGACY` | `regex` | Middleware | `high` | `non-quantum-risk` | 0.80 | `config` | `middleware.yml` | Envoy configuration allows TLSv1.0/1.1. | Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. | `tls_minimum_protocol_version\s*:\s*TLSv1_[01]` |
| `GO_TLS_RSA_IMPORT` | `regex` | TLS | `medium` | `quantum-vulnerable` | 0.50 | `code` | `tls.yml` | Go crypto/rsa usage detected. | Adopt hybrid key agreement in Go implementations. | `\bcrypto/rsa\b` |
| `HAPROXY_BIND_TLSV1` | `regex` | Middleware | `high` | `non-quantum-risk` | 0.65 | `config` | `middleware.yml` | HAProxy configuration explicitly enables TLSv1.0/1.1. | Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. | `(?m)^\s*bind\s+[^\n]*\bssl\b[^\n]*(tlsv10\|tlsv11)` |
| `HTTPD_SSLCIPHERSUITE_RSA` | `regex` | Middleware | `high` | `quantum-vulnerable` | 0.72 | `config` | `middleware.yml` | RSA or weak cipher suites detected in Apache httpd configuration. | Reduce RSA key-exchange dependency in Apache cipher suites. | `(?m)^\s*SSLCipherSuite\s+.*(RSA\|3DES\|RC4\|DES)` |
| `HTTPD_SSLHONORCIPHERORDER_OFF` | `regex` | Middleware | `medium` | `non-quantum-risk` | 0.58 | `config` | `middleware.yml` | Server-side cipher ordering is disabled in Apache. | Set SSLHonorCipherOrder to On. | `(?m)^\s*SSLHonorCipherOrder\s+off` |
| `HTTPD_SSLPROTOCOL_LEGACY` | `regex` | Middleware | `high` | `non-quantum-risk` | 0.84 | `config` | `middleware.yml` | Legacy TLSv1.x is enabled in Apache httpd configuration. | Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. | `(?m)^\s*SSLProtocol\s+.*(TLSv1(?:\.0\|\.1)?(?:$\|[^0-9.]))` |
| `ISTIO_DESTINATIONRULE_RSA_CIPHERS` | `regex` | Middleware | `high` | `quantum-vulnerable` | 0.66 | `config` | `middleware.yml` | RSA or weak cipher suites detected in Istio configuration. | Reduce RSA dependency in Istio cipher configuration. | `ciphers\s*:\s*\[[^\]]*(RSA\|3DES\|RC4)` |
| `ISTIO_DESTINATIONRULE_TLSV1` | `regex` | Middleware | `high` | `non-quantum-risk` | 0.74 | `config` | `middleware.yml` | Istio configuration permits TLSv1.0/1.1. | Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. | `minProtocolVersion\s*:\s*TLSV1_[01]` |
| `ISTIO_GATEWAY_TLSV1` | `regex` | Middleware | `high` | `non-quantum-risk` | 0.70 | `config` | `middleware.yml` | TLSv1.0/1.1 setting detected in Istio Gateway configuration. | Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. | `(?s)minProtocolVersion\s*:\s*TLSV1_[01]` |
| `JAVA_KEYFACTORY_RSA` | `regex` | TLS | `medium` | `quantum-vulnerable` | 0.50 | `code` | `tls.yml` | Java KeyFactory configured for RSA. | Phase out RSA-dependent key management. | `KeyFactory\.getInstance\(\s*"RSA"` |
| `JWK_RSA_KEY` | `regex` | JWT | `high` | `quantum-vulnerable` | 0.62 | `code` | `jwt.yml` | RSA key type in JWK detected. | Migrate JWKs to ML-DSA or hybrid key types. | `"kty"\s*:\s*"RSA"` |
| `JWT_ES256` | `regex` | JWT | `medium` | `quantum-uncertain` | 0.50 | `code` | `jwt.yml` | ES256 (ECDSA-based JWT signing) is in use. | Plan migration from ECDSA to PQC signatures. | `\bES256\b` |
| `JWT_KID_HEADER` | `regex` | JWT | `low` | `quantum-uncertain` | 0.35 | `code` | `jwt.yml` | JWT kid header usage detected, indicating key-management touch points. | Add PQC keys into the key-rotation strategy. | `"kid"\s*:` |
| `JWT_LIB_JOSE` | `dependency` | JWT | `medium` | `quantum-uncertain` | 0.45 | `dependency` | `jwt.yml` | jose dependency detected. | Verify PQC support in the JOSE implementation. | `(?i)\bjose\b` |
| `JWT_LIB_JSONWEBTOKEN` | `dependency` | JWT | `medium` | `quantum-uncertain` | 0.48 | `dependency` | `jwt.yml` | jsonwebtoken dependency detected. | Review the library roadmap for PQC-ready algorithms. | `(?i)\bjsonwebtoken\b` |
| `JWT_PS256` | `regex` | JWT | `high` | `quantum-vulnerable` | 0.55 | `code` | `jwt.yml` | PS256 (RSA-PSS) is used for JWT signing. | Migrate to ML-DSA signatures. | `\bPS256\b` |
| `JWT_PS384` | `regex` | JWT | `high` | `quantum-vulnerable` | 0.55 | `code` | `jwt.yml` | PS384 (RSA-PSS) is used for JWT signing. | Migrate to ML-DSA signatures. | `\bPS384\b` |
| `JWT_PS512` | `regex` | JWT | `high` | `quantum-vulnerable` | 0.55 | `code` | `jwt.yml` | PS512 (RSA-PSS) is used for JWT signing. | Migrate to ML-DSA signatures. | `\bPS512\b` |
| `JWT_RS256` | `regex` | JWT | `high` | `quantum-vulnerable` | 0.60 | `code` | `jwt.yml` | RS256 (RSA-based JWT signing) is in use. | Migrate to ML-DSA signatures. | `\bRS256\b` |
| `JWT_RS384` | `regex` | JWT | `high` | `quantum-vulnerable` | 0.60 | `code` | `jwt.yml` | RS384 is used for JWT signing. | Migrate to ML-DSA signatures. | `\bRS384\b` |
| `JWT_RS512` | `regex` | JWT | `high` | `quantum-vulnerable` | 0.60 | `code` | `jwt.yml` | RS512 is used for JWT signing. | Migrate to ML-DSA signatures. | `\bRS512\b` |
| `JWT_SIGNING_METHOD_RS` | `regex` | JWT | `high` | `quantum-vulnerable` | 0.65 | `code` | `jwt.yml` | RS* JWT signing method is used in code. | Migrate to ML-DSA signatures. | `SigningMethodRS(256\|384\|512)` |
| `K8S_GATEWAYAPI_TLSV1` | `regex` | Middleware | `high` | `non-quantum-risk` | 0.65 | `config` | `middleware.yml` | TLSv1.x is configured in Kubernetes Gateway settings. | Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. | `minVersion\s*:\s*TLSv1(?:\.0\|\.1)?(?:$\|[^0-9.])` |
| `K8S_INGRESS_RSA_CIPHERS` | `regex` | Middleware | `high` | `quantum-vulnerable` | 0.70 | `config` | `middleware.yml` | RSA or weak cipher suites are configured in a Kubernetes Ingress annotation. | Remove RSA key-exchange dependency from Ingress cipher suites. | `nginx\.ingress\.kubernetes\.io/ssl-ciphers\s*:\s*['"]?[^\n"]*(RSA\|DES-CBC3-SHA\|3DES\|RC4)` |
| `K8S_INGRESS_SSL_PROTOCOLS_LEGACY` | `regex` | Middleware | `high` | `non-quantum-risk` | 0.80 | `config` | `middleware.yml` | Legacy TLS is enabled in a Kubernetes Ingress annotation. | Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. | `nginx\.ingress\.kubernetes\.io/ssl-protocols\s*:\s*['"]?[^\n"]*TLSv1(?:\.0\|\.1)?(?:$\|[^0-9.])` |
| `NGINX_PROXY_SSL_PROTOCOLS_LEGACY` | `regex` | Middleware | `high` | `non-quantum-risk` | 0.72 | `config` | `middleware.yml` | Legacy TLS protocols are enabled for nginx upstream TLS. | Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. | `(?m)^\s*proxy_ssl_protocols\s+[^;]*(TLSv1(?:\.0\|\.1)?(?:$\|[^0-9.]))` |
| `NGINX_SSL_CIPHERS_RSA` | `regex` | Middleware | `high` | `quantum-vulnerable` | 0.74 | `config` | `middleware.yml` | RSA or weak cipher suites detected in nginx configuration. | Refresh nginx cipher suites for PQC-hybrid migration readiness. | `(?m)^\s*ssl_ciphers\s+[^;]*(RSA\|DES-CBC3-SHA\|3DES\|RC4)` |
| `NGINX_SSL_PREFER_SERVER_CIPHERS_OFF` | `regex` | Middleware | `medium` | `non-quantum-risk` | 0.60 | `config` | `middleware.yml` | Server-side cipher preference is disabled in nginx. | Enable server-side cipher preference. | `(?m)^\s*ssl_prefer_server_ciphers\s+off\s*;` |
| `NGINX_SSL_PROTOCOLS_LEGACY` | `regex` | Middleware | `high` | `non-quantum-risk` | 0.85 | `config` | `middleware.yml` | Legacy TLSv1.x is enabled in nginx configuration. | Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. | `(?m)^\s*ssl_protocols\s+[^;]*(TLSv1(?:\.0\|\.1)?(?:$\|[^0-9.]))` |
| `NODE_TLS_MIN_VERSION` | `regex` | TLS | `medium` | `non-quantum-risk` | 0.65 | `code` | `tls.yml` | Node.js TLS minimum version may be too weak. | Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. | `minVersion\s*:\s*['"]TLSv1(?:[._][01])?['"]` |
| `OIDC_ID_TOKEN_SIGALG` | `regex` | JWT | `medium` | `quantum-uncertain` | 0.40 | `code` | `jwt.yml` | OIDC ID token signature algorithm configuration detected. | Select PQC-ready algorithms in OIDC provider settings. | `id_token_signed_response_alg` |
| `OPENSSL_RSA_API` | `regex` | TLS | `medium` | `quantum-vulnerable` | 0.52 | `code` | `tls.yml` | OpenSSL RSA API call detected. | Replace with EVP_PKEY-based implementation suitable for PQC migration. | `RSA_(generate_key\|public_encrypt\|private_decrypt)` |
| `PRIVATE_KEY_OPENSSH_HEADER` | `key` | KeyMaterial | `critical` | `non-quantum-risk` | 0.95 | `keymaterial` | `ssh.yml` | OpenSSH private key header detected. | Treat OpenSSH private-key exposure as an urgent incident. | `-----BEGIN OPENSSH PRIVATE KEY-----` |
| `PRIVATE_KEY_PKCS8_HEADER` | `key` | KeyMaterial | `critical` | `non-quantum-risk` | 0.95 | `keymaterial` | `ssh.yml` | PKCS#8 private key header detected. | Investigate private-key exposure and rotate credentials. | `-----BEGIN PRIVATE KEY-----` |
| `PRIVATE_KEY_RSA_HEADER` | `key` | KeyMaterial | `critical` | `non-quantum-risk` | 0.95 | `keymaterial` | `ssh.yml` | RSA private key header detected. | Rotate exposed private keys immediately and strengthen key handling. | `-----BEGIN RSA PRIVATE KEY-----` |
| `SSH_AUTHORIZED_KEYS_RSA` | `regex` | SSH | `medium` | `quantum-vulnerable` | 0.57 | `code` | `ssh.yml` | RSA public key detected in authorized_keys. | Gradually rotate RSA keys in authorized_keys. | `(?m)^ssh-rsa\s+` |
| `SSH_CONFIG_HOSTKEY_RSA` | `regex` | SSH | `medium` | `quantum-vulnerable` | 0.58 | `code` | `ssh.yml` | RSA host key file configured in SSH settings. | Include PQC planning in host key rotation. | `HostKey\s+.*ssh_host_rsa_key` |
| `SSH_DH_GROUP1` | `regex` | SSH | `critical` | `non-quantum-risk` | 0.85 | `code` | `ssh.yml` | Weak SSH KEX group1 detected. | Move to group14+ or modern key-exchange methods. | `diffie-hellman-group1-sha1` |
| `SSH_DH_GROUP14_SHA1` | `regex` | SSH | `medium` | `non-quantum-risk` | 0.60 | `code` | `ssh.yml` | SHA-1 dependent SSH KEX detected. | Retire SHA-1 based key exchange. | `diffie-hellman-group14-sha1` |
| `SSH_DSS_SIGALG` | `regex` | SSH | `high` | `non-quantum-risk` | 0.80 | `code` | `ssh.yml` | Deprecated ssh-dss usage detected. | Disable ssh-dss. | `\bssh-dss\b` |
| `SSH_RSA_ALGO` | `regex` | SSH | `high` | `quantum-vulnerable` | 0.70 | `code` | `ssh.yml` | ssh-rsa algorithm usage detected. | Plan PQC host authentication separately from hybrid key exchange; ssh-ed25519 remains a classical signature algorithm. | `\bssh-rsa\b` |
| `SSH_RSA_SHA2_SIGALG` | `regex` | SSH | `medium` | `quantum-vulnerable` | 0.55 | `code` | `ssh.yml` | RSA-SHA2 signature algorithm detected in SSH configuration. | Define a migration plan toward future PQC-ready signature schemes. | `rsa-sha2-(256\|512)` |
| `TLS_CERT_PIN_RSA` | `regex` | TLS | `medium` | `quantum-vulnerable` | 0.42 | `code` | `tls.yml` | RSA certificate pinning configuration detected. | Plan PQC migration for certificate pinning targets. | `pin-.*rsa\|rsa-pin` |
| `TLS_ECDHE_RSA` | `regex` | TLS | `medium` | `quantum-uncertain` | 0.50 | `code` | `tls.yml` | TLS_ECDHE_RSA usage detected. | Plan hybrid PQC key agreement adoption. | `TLS_ECDHE_RSA` |
| `TLS_RSA_CIPHER_SUITE` | `regex` | TLS | `high` | `quantum-vulnerable` | 0.68 | `code` | `tls.yml` | RSA-based TLS cipher suite detected. | Migrate to PQC-ready or hybrid cipher suites. | `\bTLS_(?:[A-Z0-9]+_)*RSA_WITH_[A-Z0-9_]+\b` |
| `TLS_RSA_KEY_EXCHANGE` | `regex` | TLS | `high` | `quantum-vulnerable` | 0.70 | `code` | `tls.yml` | TLS RSA key-exchange suite detected. | Evaluate standardized hybrid key exchange such as X25519MLKEM768 with compatible peers; draft Kyber groups have different wire formats. | `\bTLS_RSA_WITH_[A-Z0-9_]+\b` |
| `TLS_VERSION_1_0` | `regex` | TLS | `high` | `non-quantum-risk` | 0.75 | `code` | `tls.yml` | Legacy TLS 1.0 configuration detected. | Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. | `(?:^\|[^A-Za-z0-9_])TLSv1(?:[._]0)?(?:$\|[^A-Za-z0-9_.])` |
| `TLS_VERSION_1_1` | `regex` | TLS | `high` | `non-quantum-risk` | 0.75 | `code` | `tls.yml` | Legacy TLS 1.1 configuration detected. | Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. | `\bTLSv1[._]1\b` |
| `TRAEFIK_TLS_OPTIONS_LEGACY` | `regex` | Middleware | `medium` | `non-quantum-risk` | 0.58 | `config` | `middleware.yml` | Traefik configuration contains a low minimum TLS version. | Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. | `(?i)minversion\s*:\s*versiontls1(0\|1)` |
| `TS_CERT_SIGALG_LITERAL` | `tree_sitter` | PKI | `medium` | `quantum-vulnerable` | 0.55 | `java,javascript,typescript,python,go,rust,ruby` | `tree_sitter.yml` | Certificate signature algorithm literals detected in AST nodes. | Update certificate signature algorithms to PQC or hybrid schemes. | `(?i)(sha256WithRSAEncryption\|sha384WithRSAEncryption\|sha512WithRSAEncryption\|ecdsa-with-SHA(256\|384\|512))` |
| `TS_GO_RSA_USAGE` | `tree_sitter` | CryptoAPI | `medium` | `quantum-vulnerable` | 0.62 | `go` | `tree_sitter.yml` | RSA-related usage detected from Go AST. | Migrate Go crypto/rsa usage to a PQC-hybrid design. | `(?i)(\bcrypto/rsa\b\|\brsa\.(SignPKCS1v15\|VerifyPKCS1v15\|DecryptOAEP\|EncryptOAEP\|GenerateKey)\b\|\b(Sign\|Verify)(PKCS1v15\|PSS)\b)` |
| `TS_JAVA_RSA_API` | `tree_sitter` | CryptoAPI | `high` | `quantum-vulnerable` | 0.68 | `java` | `tree_sitter.yml` | RSA-related API symbols detected from Java AST. | Replace Java RSA API usage with PQC-capable libraries. | `(KeyPairGenerator\|KeyFactory\|Cipher\|Signature)\s*\.\s*getInstance\s*\(\s*"(RSA\|RSA/[^"\s]*\|SHA(1\|224\|256\|384\|512)withRSA\|RSASSA-PSS)` |
| `TS_JWT_ES_ALG` | `tree_sitter` | JWT | `medium` | `quantum-uncertain` | 0.60 | `java,javascript,typescript,python,go,rust,ruby` | `tree_sitter.yml` | ES-family JWT signing algorithms detected in AST nodes. | Define a PQC migration plan for ES-family algorithms. | `(?i)\b(ES256\|ES384\|ES512)\b` |
| `TS_JWT_RSA_ALGS` | `tree_sitter` | JWT | `high` | `quantum-vulnerable` | 0.72 | `java,javascript,typescript,python,go,rust,ruby` | `tree_sitter.yml` | RSA-family JWT signing algorithms detected in AST nodes. | Migrate JWT signing to ML-DSA or hybrid signatures. | `(?i)\b(RS256\|RS384\|RS512\|PS256\|PS384\|PS512)\b` |
| `TS_NODE_JOSE_USAGE` | `tree_sitter` | JWT | `medium` | `quantum-uncertain` | 0.55 | `javascript,typescript` | `tree_sitter.yml` | JOSE/JWT calls detected from JavaScript/TypeScript AST. | Evaluate PQC-capable options in JOSE/JWT implementations. | `(?i)(\bjwt\.(sign\|verify)\b\|\bjsonwebtoken\.(sign\|verify)\b\|\bjose\.jwtVerify\b\|\bSignJWT\b)` |
| `TS_NODE_RSA_USAGE` | `tree_sitter` | CryptoAPI | `medium` | `quantum-vulnerable` | 0.59 | `javascript,typescript` | `tree_sitter.yml` | RSA-related API symbols detected from JavaScript/TypeScript AST. | Migrate Node.js RSA signing/verification logic to a PQC-ready design. | `(?i)(\b(createSign\|createVerify)\s*\(\s*['"]RSA\|\bgenerateKeyPair(?:Sync)?\s*\(\s*['"]rsa(?:-pss)?['"]\|\b(privateEncrypt\|publicDecrypt)\s*\(\|\b(RS\|PS)(256\|384\|512)\b)` |
| `TS_PY_RSA_USAGE` | `tree_sitter` | CryptoAPI | `medium` | `quantum-vulnerable` | 0.58 | `python` | `tree_sitter.yml` | RSA-related usage detected from Python AST. | Inventory Python RSA API usage as PQC migration targets. | `(?i)(cryptography\.hazmat\.primitives\.asymmetric\.rsa\|Crypto\.PublicKey\.RSA\|\brsa\.(generate_private_key\|RSAPrivateKey\|RSAPublicKey)\b\|PKCS1v15\|PSS)` |
| `TS_RSA_KEY_SIZE_LITERAL` | `tree_sitter` | PKI | `medium` | `quantum-vulnerable` | 0.57 | `java,javascript,typescript,python,go,rust,ruby` | `tree_sitter.yml` | Classical public-key size literals detected in AST nodes. | Shift from key-length based planning to PQC signatures/key exchange. | `(?i)((rsa\|key(size\|length)?\|modulus)[^\n]{0,32}\b(1024\|2048\|3072)\b\|\b(1024\|2048\|3072)\b[^\n]{0,32}(rsa\|key(size\|length)?\|modulus))` |
| `TS_RUBY_RSA_USAGE` | `tree_sitter` | CryptoAPI | `medium` | `quantum-vulnerable` | 0.58 | `ruby` | `tree_sitter.yml` | RSA-related crypto symbols detected from Ruby AST. | Replace Ruby OpenSSL RSA usage with PQC-ready migration targets. | `(?i)(\bOpenSSL::PKey::RSA\b\|\bOpenSSL::PKey::RSA\.new\b\|\bRS(256\|384\|512)\b)` |
| `TS_RUST_RSA_USAGE` | `tree_sitter` | CryptoAPI | `medium` | `quantum-vulnerable` | 0.60 | `rust` | `tree_sitter.yml` | RSA-related crypto symbols detected from Rust AST. | Replace Rust RSA APIs with PQC-ready or hybrid alternatives. | `(?i)(\bopenssl::rsa::Rsa\b\|\brsa::(RsaPrivateKey\|RsaPublicKey\|Pkcs1v15Sign\|Oaep\|Pss)\b\|\bring::signature::RSA_[A-Z0-9_]+\b\|\bAlgorithm::RS(256\|384\|512)\b\|\bRS(256\|384\|512)\b\|\bTLS_[A-Z0-9_]*_RSA_[A-Z0-9_]*\b)` |
| `TS_SSH_RSA_STRING` | `tree_sitter` | SSH | `high` | `quantum-vulnerable` | 0.70 | `java,javascript,typescript,python,go,rust,ruby` | `tree_sitter.yml` | SSH RSA-family algorithm strings detected in AST nodes. | Plan phased retirement of ssh-rsa with hybrid key operations. | `(?i)ssh-rsa\|rsa-sha2-(256\|512)` |
| `TS_TLS_LEGACY_VERSION_LITERAL` | `tree_sitter` | TLS | `high` | `non-quantum-risk` | 0.75 | `java,javascript,typescript,python,go,rust,ruby` | `tree_sitter.yml` | Legacy TLS version literals detected in AST nodes. | Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. | `(?i)(?:^\|[^A-Za-z0-9])TLSv1(?:\.0\|\.1)?(?:$\|[^0-9.])\|TLSv1_0\|TLSv1_1` |
| `TS_TLS_RSA_CIPHER_LITERAL` | `tree_sitter` | TLS | `high` | `quantum-vulnerable` | 0.66 | `java,javascript,typescript,python,go,rust,ruby` | `tree_sitter.yml` | RSA-family TLS cipher suite literals detected in AST nodes. | Update TLS suites containing RSA key exchange to PQC-hybrid suites. | `(?i)TLS_[A-Z0-9_]*RSA[A-Z0-9_]*` |

## TASK-043 bounded source references

The default fingerprints for `PQC_NODE_API`, `PQC_PYTHON_API`, `PQC_RUST_API` and `PQC_JAVA_API` use parsed source facts instead of matching arbitrary node text. `TS_NODE_RSA_USAGE` retains generic matches and adds locally established RSA generation/factory/use references. `API_NODE_CRYPTO_SIGN_RSA` keeps its regex rule kind while using source facts for JavaScript/TypeScript signing **and verification**; its original `create(Sign|Verify)` purpose includes both. Pattern/scope/kind modifications in custom rules retain generic behavior. IDs and cryptographic classifications are unchanged.

Java recognizes KEM 512/768/1024, DSA 44/65/87 and explicit SLH SHA2/SHAKE 128/192/256 s/f parameter names without interchanging families. Ruby adds those SLH literals. Pre-standard Kyber/Dilithium references are case-insensitive and retain draft classification. Java classical-only groups accept explicit property assignments, XML entry values and static `System.setProperty`; loaded/effective configuration is not proved. SSH hash-comments are ignored. CIRCL/golang and OpenSSL generic/unknown SBOM presence are recognized; dependency presence does not establish enabled capability. Static Gradle coordinates and gemspec declarations do not execute DSL code or resolve package versions.

See [the full contract and limits](../tasks/043/TASK-043-FIXES-CONTRACT.md). The source-bound metadata fixtures test compiled patterns only, not the completeness of these detector predicates.

## TASK-043 maintenance follow-up

Default source-analysis bindings derive pattern/scope/kind from the canonical
`pqc.yml`, `tree_sitter.yml` and `crypto_api.yml` compiled into the binary. Rust
keeps the six analysis-handler identities and language/API semantics; it does not
keep a second copy of those selectors. YAML edits are Cargo include dependencies
and take effect when rebuilding from this repository. Runtime rule selection
remains explicit and offline. A changed custom selector/scope/kind retains the
generic matcher.

Node argument selection and Python generation-symbol selection/recovery use the
loaded compiled pattern. Canonical request prefixes must match in full, so an
embedded quote or partial name cannot create a supported algorithm reference.
Language scope rules and library module/type/return-value knowledge remain
explicit in the adapters. This does not make arbitrary APIs or new language
constructs automatically supported. See the [maintenance plan](../tasks/043/TASK-043-MAINTAINABILITY-PLAN.md).
| `TS_TLS_LEGACY_VERSION_LITERAL` | `tree_sitter` | TLS | `high` | `non-quantum-risk` | 0.75 | `java,javascript,typescript,python,go,rust,ruby` | `tree_sitter.yml` | Legacy TLS version literals detected in AST nodes. | Prefer TLS 1.3; restrict to TLS 1.3 when all peers support it. Retain securely configured TLS 1.2 only for a documented interoperability need. Disable TLS 1.0 and 1.1. | `(?i)(?:^\|[^A-Za-z0-9_])TLSv1(?:[._][01])?(?:$\|[^A-Za-z0-9_.])` |
| `TS_TLS_RSA_CIPHER_LITERAL` | `tree_sitter` | TLS | `high` | `quantum-vulnerable` | 0.66 | `java,javascript,typescript,python,go,rust,ruby` | `tree_sitter.yml` | RSA-family TLS cipher suite literals detected in AST nodes. | Update TLS suites containing RSA key exchange to PQC-hybrid suites. | `(?i)\bTLS_(?:[A-Z0-9]+_)*RSA_WITH_[A-Z0-9_]+\b` |

## Source and inspection repairs (2026-11-12)

The current catalog has 122 rules. Existing IDs and serialized report fields are retained.

| Rule | Meaning |
|---|---|
| TS_CLASSICAL_EC_API | Explicit classical EC API reference in supported Python/Ruby/JS/TS source |
| TS_CLASSICAL_EDDSA_API | Explicit EdDSA or classical curve key generation reference |
| TS_JWT_EDDSA_ALG | EdDSA JWT algorithm literal; not proof of active signing |

Python API detection uses supported static import bindings, including `as` aliases; detected rebinding suppresses that adaptation. Ruby RSA calls no longer include generic JWT.encode/decode. Node RSA key generation is included. Go import indicators require actual Go import syntax, not an OpenSSL build path. TLS legacy-version predicates do not mistake TLSv1_2 or TLSv1.3 for TLS 1.0; RSA-suite predicates require the suite's WITH component. The source-bound companion and its pattern controls are refreshed alongside detector integration controls.

Grammar compatibility reads original source for evidence, offsets and matching. It preserves source bytes/line positions and retains original candidate nodes alongside compatible trees. Rust compatibility requiring attribute/type erasure first validates bounded syntax using Syn without macro expansion. Supported V8 intrinsics, source-phase/module attributes, contextual identifiers, JSX, Flow-marked files and selected Babel syntax remain references, not runtime compatibility certification. Unsupported/malformed inputs retain partial diagnostics.

Known non-certificate PEM/DER objects are inapplicable to certificate parsing; native container observations retain their presence without inventing a certificate. ML-DSA and SLH-DSA shapes follow [RFC9881](https://www.rfc-editor.org/rfc/rfc9881.html) and [RFC9909](https://www.rfc-editor.org/rfc/rfc9909.html). Shape completeness is separate from signature/trust validation; encrypted PKCS#12 stays incomplete.

## Audit P1/P2 corrections (2026-11-13)

The user-approved audit remediation retains IDs, schemas and the severity engine. RSA size matching now needs explicit RSA context, avoiding ML-KEM/Falcon parameter names and HSS counters. TLS reference guidance separates static RSA exchange from ECDHE/DHE RSA authentication. Generic protocol names and private-key markers do not establish enabled settings or a live credential incident. General EdDSA names do not establish JWT usage; Java RSA references can already belong to a PQC composition.

`PQC_STANDARD_REFERENCE` (tree_sitter, info, quantum-safe, seven language scopes) inventories recognized standard parameter names and X25519MLKEM768. It is nominal source inventory, not execution, enabled state, implementation conformance or certification. Specific API rules remain separate findings.

The task062 source-bound companion is preserved as [historical audit metadata](../tasks/062/evidence/AUDIT-RULE-QUALITY-METADATA.json). The maintained [rule companion](quality/rules/RULE-QUALITY-METADATA.json) now also records the approved F054-01 correction; historical snapshots and past measurements remain unchanged. These are hand-authored pattern controls, not a calibrated accuracy claim. Actual detector/CLI regression controls are in `crates/pqc_scan_cli/tests/audit_remediation.rs`.

## Exact Cargo RSA/JWT package identity (F054-01)

The maintainer-approved correction limits DEP_RUST_RSA_CRATE to exact rsa and
jsonwebtoken Cargo package components, preserving case-insensitive matching and
all other rule fields. Names such as universal-hash and rsa-helper no longer
produce this finding. Manifest aliases use the actual package name; lock and
supported SBOM records retain their existing version/provenance handling.
Query/subpath or malformed SBOM purls retain the parser's existing partial state.
Package presence still does not prove an enabled algorithm or runtime use.
See the [task054 correction evidence](../tasks/054/evidence/f054-fix-20261117/RULE-COMPATIBILITY.json); no custom predicate or output schema changes.
