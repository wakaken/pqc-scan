import hashlib,json,re,shutil,tarfile
from pathlib import Path
base=Path('target/quality-task-055/run-20261113');run=base/'confined-r3';out=Path('docs/quality/task055-20261113');out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
host=json.loads((run/'HOST-RESULTS.json').read_text());assert host['exit']==0 and host['sourceBeforeAfterMatch'] and host['containerRemoved']
paths=['crates/pqc_scan_core/src/pipeline.rs','crates/pqc_scan_core/src/quality055.rs','crates/pqc_scan_detectors/tests/quality055.rs','tests/quality/inspection055.py','tests/quality/inspection055_entry.py','tests/quality/test_inspection055.py','tests/protocol/container_runner.py','tests/protocol/container_entry.py']
bindings={p:sha(p) for p in paths};assert all(host['sourceBindings'][p]==h for p,h in bindings.items())
source={'baseHead':'34b763d188bfc8ada49876c18b15f5406b6628b3','files':bindings,'scopeSha256':hashlib.sha256(json.dumps(bindings,sort_keys=True).encode()).hexdigest(),'productChange':'cfg(test) collection only; production logic/Cargo/rules/output schemas unchanged','preexistingScope':'045 and 044 document edits preserved; see archived PREEXISTING.json'}
(out/'SOURCE.json').write_text(json.dumps(source,indent=2)+'\n')
summary={}
for mode in ['default','all-features']:
 text=(run/(mode+'-tests.log')).read_text();totals=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 summary[mode]={'passed':sum(int(r[0]) for r in totals),'failed':sum(int(r[1]) for r in totals),'ignored':sum(int(r[2]) for r in totals)}
 assert summary[mode]['failed']==0
# Reuse actual executed boundary tests without duplicating their implementation.
references=[('bounded_outcomes.rs','key_limit_is_eight_masked_headers_and_ninth_proves_truncation'),('bounded_outcomes.rs','ast_collection_exact_limit_can_complete_and_one_more_is_truncated'),('bounded_outcomes.rs','ast_parser_errors_keep_obtainable_hits_and_report_partial_inspection'),('format_dependency_support.rs','resource_limits_are_honest'),('pkcs12_certificates.rs','bounded_nested_contents_are_supported_but_deep_or_oversized_inputs_are_incomplete'),('pkcs12_certificates.rs','inspection_limits_remain_truncated_when_retained_certificate_attributes_are_partial')]
refs=[]
for file,name in references:
 for mode in ['default','all-features']:
  assert f'test {name} ... ok' in (run/(mode+'-tests.log')).read_text(),(mode,name)
 path='crates/pqc_scan_detectors/tests/'+file
 refs.append({'source':path,'sourceSha256':sha(path),'test':name,'results':{'default':'passed','all-features':'passed'}})
for p in sorted((run/'all-features/assessment').iterdir()):
 value=p.read_bytes()
 if p.name=='limit-outcomes.json':
  obj=json.loads(value);obj['existingBoundaryTests']=refs;value=(json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode()
 with (Path('target/quality-task-055')/p.name).open('xb') as f:f.write(value)
 with (out/p.name).open('xb') as f:f.write(value)
summary.update({'commands':json.loads((run/'commands.json').read_text()),'sourceBeforeAfterMatch':True,'containerRemoved':True,'formatInputs':74,'detectorInvocations':370,'pythonQualityPassed':66,'nodePassed':35,'distributionPassed':11,'fmt':'exit 0 (entry completed)','githubActions':'not run; local evidence only'})
(out/'VALIDATION.json').write_text(json.dumps(summary,indent=2)+'\n')
with tarfile.open(out/'VERIFICATION.tar.gz','w:gz') as tar:
 for p in sorted(base.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(base)))
 for p in paths:tar.add(p,arcname='final-source/'+p)
print(source['scopeSha256'],json.dumps({k:summary[k] for k in ['default','all-features']}))
